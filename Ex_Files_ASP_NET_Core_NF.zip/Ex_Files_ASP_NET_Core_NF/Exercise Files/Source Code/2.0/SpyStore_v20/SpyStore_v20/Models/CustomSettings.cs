namespace SpyStore_v20.Models
{
    public class CustomSettings
    {
        public CustomSettings()
        {
        }

        public string MySetting1 { get; set; }
        public int MySetting2 { get; set; }
    }
}
