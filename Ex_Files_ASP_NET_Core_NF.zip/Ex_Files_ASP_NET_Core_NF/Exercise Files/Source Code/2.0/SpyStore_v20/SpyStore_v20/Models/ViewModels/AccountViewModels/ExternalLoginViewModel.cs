using System.ComponentModel.DataAnnotations;

namespace SpyStore_v20.Models.ViewModels.AccountViewModels
{
    public class ExternalLoginViewModel
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }
    }
}
