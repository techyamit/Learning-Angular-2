﻿namespace SpyStore_v20.Models
{
    public static class Secrets
    {
        public const string PASSWORD = "Conner01$";
    }
}