﻿using System;
using System.IO.Compression;
using System.Linq;
using System.Net.WebSockets;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.AspNetCore.Rewrite;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Net.Http.Headers;
using SpyStoreDAL.EfContext;
using SpyStoreDAL.Initializers;
using SpyStoreDAL.Repos;
using SpyStoreDAL.Repos.Interfaces;
using SpyStoreModels.Models;
using SpyStore_v11.Models;
using SpyStore_v11.Services;

namespace SpyStore_v11
{
    public class Startup
    {
        private IHostingEnvironment _env;
        public Startup(IHostingEnvironment env)
        {
            //TODO: Updated in 2.0
            _env = env;
            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true)
                .AddJsonFile(@"Properties/launchSettings.json", optional: false, reloadOnChange: true);

            if (env.IsDevelopment())
            {
                // For more details on using the user secret store see https://go.microsoft.com/fwlink/?LinkID=532709
                builder.AddUserSecrets<Startup>();
            }
            builder.AddEnvironmentVariables();
            var config = builder.Build();
            //builder.AddAzureKeyVault(
            //    $"https://{config["Vault"]}.vault.azure.net/",
            //    config["ClientId"],
            //    config["ClientSecret"]);
            Configuration = builder.Build();

            //var secret1 = Configuration["SecretName"];
            //var secret2a = Configuration["Section:SecretName"];
            //var secret2b = Configuration.GetSection("Section")["SecretName"];
        }

        public IConfigurationRoot Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //Response Caching
            services.AddResponseCaching();
            //services.AddResponseCaching(options =>
            //{
            //    options.MaximumBodySize = 1024;
            //    options.UseCaseSensitivePaths = true;
            //});

            //Response Compression
            //services.AddResponseCompression();
            //services.AddResponseCompression(options => options.Providers.Add<GzipCompressionProvider>());
            //services.Configure<GzipCompressionProviderOptions>(
            //    options => options.Level = CompressionLevel.Fastest);
            //services.AddResponseCompression(options =>
            //{
            //    options.MimeTypes = ResponseCompressionDefaults.MimeTypes.Concat(new[] { "image/svg+xml", "image/png" });
            //    options.Providers.Add<GzipCompressionProvider>();
            //});

            // Add framework services.
            services.AddDbContext<ApplicationDbContext>(options =>
                options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection"), o => o.EnableRetryOnFailure())
                .ConfigureWarnings(warnings => warnings.Throw(RelationalEventId.QueryClientEvaluationWarning)));

            services.AddIdentity<ApplicationUser, IdentityRole>()
                .AddEntityFrameworkStores<ApplicationDbContext>()
                .AddDefaultTokenProviders();


            services.AddMvc();
            //services.AddMvc(options => options.SslPort = 44329);
            //var sslPort = Configuration.GetValue<int>("iisSettings:iisExpress:sslPort");
            //services.AddMvc(options => options.SslPort = sslPort);

            //Added for convenience - fixed in 2.0
            services.AddSingleton(_ => Configuration);


            // Add application services.
            services.AddTransient<IEmailSender, AuthMessageSender>();
            services.AddTransient<ISmsSender, AuthMessageSender>();
            services.AddScoped<ICategoryRepo, CategoryRepo>();
            services.AddScoped<IProductRepo, ProductRepo>();

            services.Configure<CustomSettings>(Configuration.GetSection("CustomSettings"));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            //response caching middleware
            app.UseResponseCaching();

            //response compression middleware
            //Turn off to use compression as filter
            app.UseResponseCompression();

            app.UseWebSockets();
            app.Use(async (context, next) =>
            {
                if (context.Request.Path == "/ws")
                {
                    if (context.WebSockets.IsWebSocketRequest)
                    {
                        WebSocket webSocket = await context.WebSockets.AcceptWebSocketAsync();
                        await Echo(context, webSocket);
                    }
                    else
                    {
                        context.Response.StatusCode = 400;
                    }
                }
                else
                {
                    await next();
                }

            });
            app.UseFileServer();


            loggerFactory.AddConsole(Configuration.GetSection("Logging"));
            loggerFactory.AddDebug();

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseDatabaseErrorPage();
                app.UseBrowserLink();
                StoreDataInitializer.InitializeData(app.ApplicationServices.GetService<ApplicationDbContext>());
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            app.UseStaticFiles();

            app.UseIdentity();

            // Add external authentication middleware below. To configure them please see https://go.microsoft.com/fwlink/?LinkID=532715

            //URL Rewrite Middleware
            var options = new RewriteOptions()
                .AddRedirect("foo", "Products/Featured",302) //status is optional, defaults to 302
                .AddRedirect("(Products/)([^FfPp0-9].*)", "$1Featured")
                .AddRewrite("bar", "Products/Featured", skipRemainingRules: true)
                .Add(RedirectXmlRequests); //Use a method to rewrite
            //.AddRedirectToHttps(302, 63812); //Force SSL
            //.AddApacheModRewrite(env.ContentRootFileProvider, "ApacheModRewrite.txt")
            //.AddIISUrlRewrite(env.ContentRootFileProvider, "IISUrlRewrite.xml")
            app.UseRewriter(options);


            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }

        private void RedirectXmlRequests(RewriteContext context)
        {
            var request = context.HttpContext.Request;

            // Because we're redirecting back to the same app, stop 
            // processing if the request has already been redirected
            if (request.Path.StartsWithSegments(new PathString("/xmlfiles")))
            {
                return;
            }

            if (request.Path.Value.EndsWith(".xml", StringComparison.OrdinalIgnoreCase))
            {
                var response = context.HttpContext.Response;
                response.StatusCode = StatusCodes.Status301MovedPermanently;
                context.Result = RuleResult.EndResponse;
                response.Headers[HeaderNames.Location] =
                    "/xmlfiles" + request.Path + request.QueryString;
            }
        }
        private async Task Echo(HttpContext context, WebSocket webSocket)
        {
            var buffer = new byte[1024 * 4];
            WebSocketReceiveResult result = await webSocket.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);
            while (!result.CloseStatus.HasValue)
            {
                await webSocket.SendAsync(new ArraySegment<byte>(buffer, 0, result.Count), result.MessageType, result.EndOfMessage, CancellationToken.None);

                result = await webSocket.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);
            }
            await webSocket.CloseAsync(result.CloseStatus.Value, result.CloseStatusDescription, CancellationToken.None);
        }

    }
}
