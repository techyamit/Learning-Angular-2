﻿using System.IO;
using System.Security.Cryptography.X509Certificates;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Net.Http.Server;
using SpyStore_v11.Models;

namespace SpyStore_v11
{
    public class Program
    {
        public static void Main(string[] args)
        {
            IWebHost host = null;
            //Kestrel & IIS - No SSL
            host = RunKestrelAndIisNoSsl();

            //Kestrel & IIS with SSL
            //host = RunKestrelAndIisSsl();

            //WebListener
            //host = RunWebListener();

            host.Run();
        }

        internal static IWebHost RunKestrelAndIisNoSsl()
        {
            return new WebHostBuilder()
                .UseKestrel()
                .UseContentRoot(Directory.GetCurrentDirectory())
                .UseIISIntegration()
                .UseStartup<Startup>()
                .UseApplicationInsights()
                //.UseEnvironment("Development")
                .Build();
        }

        internal static IWebHost RunKestrelAndIisSsl()
        {
            var cert = new X509Certificate2("PfjEnterprises.pfx", Secrets.PASSWORD);
            return new WebHostBuilder()
                .UseKestrel(cfg => cfg.UseHttps(cert))
                .UseUrls("http://*:6001;https://*:44329")
                .UseContentRoot(Directory.GetCurrentDirectory())
                .UseIISIntegration()
                .UseStartup<Startup>()
                .UseApplicationInsights()
                .Build();
        }
        internal static IWebHost RunWebListener()
        {
            return new WebHostBuilder()
                .UseWebListener(options =>
                    {
                        options.ListenerSettings.Authentication.Schemes = AuthenticationSchemes.None;
                        options.ListenerSettings.Authentication.AllowAnonymous = true;
                    })
                .UseContentRoot(Directory.GetCurrentDirectory())
                .UseStartup<Startup>()
                .UseApplicationInsights()
                .Build();
        }
    }
}
