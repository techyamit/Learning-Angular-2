using System.ComponentModel.DataAnnotations;

namespace SpyStore_v11.Models.ViewModels.AccountViewModels
{
    public class ExternalLoginConfirmationViewModel
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }
    }
}
