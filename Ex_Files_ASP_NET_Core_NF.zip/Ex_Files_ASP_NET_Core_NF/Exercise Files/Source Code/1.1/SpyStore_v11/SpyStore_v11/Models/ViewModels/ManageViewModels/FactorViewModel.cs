﻿namespace SpyStore_v11.Models.ViewModels.ManageViewModels
{
    public class FactorViewModel
    {
        public string Purpose { get; set; }
    }
}
