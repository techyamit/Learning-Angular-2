﻿namespace SpyStore_v11.Models
{
    public static class Secrets
    {
        public const string PASSWORD = "";
    }
}