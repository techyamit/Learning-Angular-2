﻿using SpyStore_v11.Models.CustomViewModels.Base;

namespace SpyStore_v11.Models.CustomViewModels
{
    public class AddToCartViewModel :CartViewModelBase
    {
        public int Quantity { get; set; }
    }
}