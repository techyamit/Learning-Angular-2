﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;

namespace SpyStoreDAL.EfContext
{
    //TODO: changes in 2.0
    public class ApplicationDbContextFactory : IDbContextFactory<ApplicationDbContext>
    {
        public ApplicationDbContext Create(DbContextFactoryOptions options)
        {
            var optionsBuilder = new DbContextOptionsBuilder<ApplicationDbContext>();
            var connString =
                @"Server=(localdb)\mssqllocaldb;Database=SpyStore_v11;Trusted_Connection=True;MultipleActiveResultSets=true;";
            if (!optionsBuilder.IsConfigured)
            {
				//EnableRetryOnFailure added back in in 1.1
                optionsBuilder.UseSqlServer(connString, o => o.EnableRetryOnFailure())
                    .ConfigureWarnings(warnings => warnings.Throw(RelationalEventId.QueryClientEvaluationWarning));
            }

            return new ApplicationDbContext(optionsBuilder.Options);

        }
    }
}
