﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using SpyStore_v10.Models;

namespace SpyStore_v10
{
    public class Program
    {
        public static void Main(string[] args)
        {
            //var cert = new X509Certificate2("PfjEnterprises.pfx",Secrets.PASSWORD);
            var host = new WebHostBuilder()
                .UseKestrel()
                //.UseKestrel(cfg => cfg.UseHttps(cert))
                //.UseUrls("http://*:6001;https://*:44329")
                .UseContentRoot(Directory.GetCurrentDirectory())
                .UseIISIntegration()
                .UseStartup<Startup>()
                .UseApplicationInsights()
                //.UseEnvironment("Development")
                .Build();

            host.Run();
        }
    }
}
