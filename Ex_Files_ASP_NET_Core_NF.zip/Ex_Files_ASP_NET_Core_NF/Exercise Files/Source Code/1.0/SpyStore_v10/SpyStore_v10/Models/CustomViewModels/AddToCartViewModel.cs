﻿using SpyStore_v10.Models.CustomViewModels.Base;

namespace SpyStore_v10.Models.CustomViewModels
{
    public class AddToCartViewModel :CartViewModelBase
    {
        public int Quantity { get; set; }
    }
}