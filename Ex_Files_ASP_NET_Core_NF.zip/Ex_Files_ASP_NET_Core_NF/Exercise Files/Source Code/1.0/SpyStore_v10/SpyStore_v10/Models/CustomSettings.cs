﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;

namespace SpyStore_v10.Models
{
    public class CustomSettings
    {
        public CustomSettings()
        {
        }

        public string MySetting1 { get; set; }
        public int MySetting2 { get; set; }
    }
}
