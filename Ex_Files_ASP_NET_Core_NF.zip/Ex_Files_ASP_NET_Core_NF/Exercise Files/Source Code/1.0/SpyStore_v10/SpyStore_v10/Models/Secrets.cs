﻿namespace SpyStore_v10.Models
{
    public static class Secrets
    {
        public const string PASSWORD = "";
    }
}