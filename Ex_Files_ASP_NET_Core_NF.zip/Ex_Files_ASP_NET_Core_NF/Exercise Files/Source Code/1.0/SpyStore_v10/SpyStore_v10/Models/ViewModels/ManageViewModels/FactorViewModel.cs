﻿namespace SpyStore_v10.Models.ViewModels.ManageViewModels
{
    public class FactorViewModel
    {
        public string Purpose { get; set; }
    }
}
