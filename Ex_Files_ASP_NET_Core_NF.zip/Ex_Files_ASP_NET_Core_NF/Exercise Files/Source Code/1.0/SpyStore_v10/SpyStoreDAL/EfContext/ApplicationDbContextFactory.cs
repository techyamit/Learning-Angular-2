﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;

namespace SpyStoreDAL.EfContext
{
    //TODO: Changed in 2.0
    public class ApplicationDbContextFactory : IDbContextFactory<ApplicationDbContext>
    {
        public ApplicationDbContext Create(DbContextFactoryOptions options)
        {
            var optionsBuilder = new DbContextOptionsBuilder<ApplicationDbContext>();
            var connString =
                @"Server=(localdb)\mssqllocaldb;Database=SpyStore_v10;Trusted_Connection=True;MultipleActiveResultSets=true;";
            if (!optionsBuilder.IsConfigured)
            {
                //TODO: EnableRetryOnFailure added back in in 1.1
                optionsBuilder.UseSqlServer(connString)
                    .ConfigureWarnings(warnings => warnings.Throw(RelationalEventId.QueryClientEvaluationWarning));
            }
            return new ApplicationDbContext(optionsBuilder.Options);

        }
    }
}
