﻿namespace System.Activities
{
    using System;
    using System.Activities.Runtime;

    public sealed class NativeActivityFaultContext : NativeActivityContext
    {
        private bool isFaultHandled;
        private Exception exception;
        private ActivityInstanceReference source;

        internal NativeActivityFaultContext(System.Activities.ActivityInstance executingActivityInstance, ActivityExecutor executor, BookmarkManager bookmarkManager, Exception exception, ActivityInstanceReference source) : base(executingActivityInstance, executor, bookmarkManager)
        {
            this.exception = exception;
            this.source = source;
        }

        internal FaultContext CreateFaultContext() => 
            new FaultContext(this.exception, this.source);

        public void HandleFault()
        {
            base.ThrowIfDisposed();
            this.isFaultHandled = true;
        }

        internal bool IsFaultHandled =>
            this.isFaultHandled;
    }
}

