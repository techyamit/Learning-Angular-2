﻿namespace System.Activities
{
    using System;
    using System.Activities.Expressions;

    internal class InlinedLocationReference : LocationReference, ILocationReferenceWrapper
    {
        private LocationReference innerReference;
        private Activity validAccessor;
        private bool allowReads;
        private bool allowWrites;
        private bool allowGetLocation;

        public InlinedLocationReference(LocationReference innerReference, Activity validAccessor)
        {
            this.innerReference = innerReference;
            this.validAccessor = validAccessor;
            this.allowReads = true;
            this.allowWrites = true;
            this.allowGetLocation = true;
        }

        public InlinedLocationReference(LocationReference innerReference, Activity validAccessor, ArgumentDirection accessDirection)
        {
            this.innerReference = innerReference;
            this.validAccessor = validAccessor;
            this.allowReads = accessDirection != ArgumentDirection.Out;
            this.allowWrites = accessDirection > ArgumentDirection.In;
        }

        public override Location GetLocation(ActivityContext context)
        {
            if (context == null)
            {
                throw FxTrace.Exception.ArgumentNull("context");
            }
            this.ValidateAccessor(context);
            if (!this.allowGetLocation)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.GetLocationOnPublicAccessReference(context.Activity)));
            }
            return this.GetLocationCore(context);
        }

        private Location GetLocationCore(ActivityContext context)
        {
            Location location;
            try
            {
                context.AllowChainedEnvironmentAccess = true;
                location = this.innerReference.GetLocation(context);
            }
            finally
            {
                context.AllowChainedEnvironmentAccess = false;
            }
            return location;
        }

        internal override Location GetLocationForRead(ActivityContext context)
        {
            this.ValidateAccessor(context);
            if (!this.allowReads)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.ReadAccessToWriteOnlyPublicReference(context.Activity)));
            }
            return this.GetLocationCore(context);
        }

        internal override Location GetLocationForWrite(ActivityContext context)
        {
            this.ValidateAccessor(context);
            if (!this.allowWrites)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.WriteAccessToReadOnlyPublicReference(context.Activity)));
            }
            return this.GetLocationCore(context);
        }

        private void ValidateAccessor(ActivityContext context)
        {
            context.ThrowIfDisposed();
            if (context.Activity != this.validAccessor)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.InlinedLocationReferenceOnlyAccessibleByOwner(context.Activity, this.validAccessor)));
            }
        }

        protected override string NameCore =>
            this.innerReference.Name;

        protected override Type TypeCore =>
            this.innerReference.Type;

        LocationReference ILocationReferenceWrapper.LocationReference =>
            this.innerReference;
    }
}

