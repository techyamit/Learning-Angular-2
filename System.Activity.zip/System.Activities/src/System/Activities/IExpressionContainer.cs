﻿namespace System.Activities
{
    internal interface IExpressionContainer
    {
    }
}

