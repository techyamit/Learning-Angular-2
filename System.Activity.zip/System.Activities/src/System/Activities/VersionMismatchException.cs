﻿namespace System.Activities
{
    using System;
    using System.Runtime.CompilerServices;
    using System.Runtime.Serialization;
    using System.Security;

    [Serializable]
    public class VersionMismatchException : Exception
    {
        public VersionMismatchException()
        {
        }

        public VersionMismatchException(string message) : base(message)
        {
        }

        public VersionMismatchException(WorkflowIdentity expectedVersion, WorkflowIdentity actualVersion) : base(GetMessage(expectedVersion, actualVersion))
        {
            this.ExpectedVersion = expectedVersion;
            this.ActualVersion = actualVersion;
        }

        protected VersionMismatchException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
            this.ExpectedVersion = (WorkflowIdentity) info.GetValue("expectedVersion", typeof(WorkflowIdentity));
            this.ActualVersion = (WorkflowIdentity) info.GetValue("actualVersion", typeof(WorkflowIdentity));
        }

        public VersionMismatchException(string message, Exception innerException) : base(message, innerException)
        {
        }

        public VersionMismatchException(string message, WorkflowIdentity expectedVersion, WorkflowIdentity actualVersion) : base(message)
        {
            this.ExpectedVersion = expectedVersion;
            this.ActualVersion = actualVersion;
        }

        public VersionMismatchException(string message, WorkflowIdentity expectedVersion, WorkflowIdentity actualVersion, Exception innerException) : base(message, innerException)
        {
            this.ExpectedVersion = expectedVersion;
            this.ActualVersion = actualVersion;
        }

        private static string GetMessage(WorkflowIdentity expectedVersion, WorkflowIdentity actualVersion)
        {
            if ((actualVersion == null) && (expectedVersion != null))
            {
                return System.Activities.SR.WorkflowIdentityNullStateId(expectedVersion);
            }
            if ((actualVersion != null) && (expectedVersion == null))
            {
                return System.Activities.SR.WorkflowIdentityNullHostId(actualVersion);
            }
            if (!Equals(expectedVersion, actualVersion))
            {
                return System.Activities.SR.WorkflowIdentityStateIdHostIdMismatch(actualVersion, expectedVersion);
            }
            return null;
        }

        [SecurityCritical]
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);
            info.AddValue("expectedVersion", this.ExpectedVersion);
            info.AddValue("actualVersion", this.ActualVersion);
        }

        public WorkflowIdentity ExpectedVersion { get; private set; }

        public WorkflowIdentity ActualVersion { get; private set; }
    }
}

