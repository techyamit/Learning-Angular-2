﻿namespace System.Activities
{
    using System;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;

    public class WorkflowApplicationEventArgs : EventArgs
    {
        internal WorkflowApplicationEventArgs(System.Activities.WorkflowApplication application)
        {
            this.Owner = application;
        }

        public IEnumerable<T> GetInstanceExtensions<T>() where T: class => 
            this.Owner.InternalGetExtensions<T>();

        internal System.Activities.WorkflowApplication Owner { get; private set; }

        public Guid InstanceId =>
            this.Owner.Id;
    }
}

