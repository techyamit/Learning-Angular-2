﻿namespace System.Activities
{
    using System;
    using System.Collections.ObjectModel;

    internal interface IDynamicActivity
    {
        string Name { get; set; }

        KeyedCollection<string, DynamicActivityProperty> Properties { get; }
    }
}

