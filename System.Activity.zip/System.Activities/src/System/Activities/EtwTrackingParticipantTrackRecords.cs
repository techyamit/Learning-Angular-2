﻿namespace System.Activities
{
    using System;
    using System.Globalization;
    using System.Resources;
    using System.Runtime;
    using System.Runtime.CompilerServices;
    using System.Runtime.Diagnostics;
    using System.Security;

    internal class EtwTrackingParticipantTrackRecords
    {
        private static System.Resources.ResourceManager resourceManager;
        private static CultureInfo resourceCulture;
        [SecurityCritical]
        private static EventDescriptor[] eventDescriptors;
        private static object syncLock = new object();
        private static volatile bool eventDescriptorsCreated;

        private EtwTrackingParticipantTrackRecords()
        {
        }

        internal static bool ActivityScheduledRecord(EtwDiagnosticTrace trace, EventTraceActivity eventTraceActivity, Guid InstanceId, long RecordNumber, long EventTime, string Name, string ActivityId, string ActivityInstanceId, string ActivityTypeName, string ChildActivityName, string ChildActivityId, string ChildActivityInstanceId, string ChildActivityTypeName, string Annotations, string ProfileName, string reference)
        {
            bool flag = true;
            TracePayload payload = trace.GetSerializedPayload(null, null, null);
            if (IsEtwEventEnabled(trace, 0))
            {
                flag = WriteEtwEvent(trace, 0, eventTraceActivity, InstanceId, RecordNumber, EventTime, Name, ActivityId, ActivityInstanceId, ActivityTypeName, ChildActivityName, ChildActivityId, ChildActivityInstanceId, ChildActivityTypeName, Annotations, ProfileName, reference, payload.AppDomainFriendlyName);
            }
            return flag;
        }

        internal static bool ActivityScheduledRecordIsEnabled(EtwDiagnosticTrace trace) => 
            IsEtwEventEnabled(trace, 0);

        internal static bool ActivityStateRecord(EtwDiagnosticTrace trace, EventTraceActivity eventTraceActivity, Guid InstanceId, long RecordNumber, long EventTime, string State, string Name, string ActivityId, string ActivityInstanceId, string ActivityTypeName, string Arguments, string Variables, string Annotations, string ProfileName, string reference)
        {
            bool flag = true;
            TracePayload payload = trace.GetSerializedPayload(null, null, null);
            if (IsEtwEventEnabled(trace, 1))
            {
                flag = WriteEtwEvent(trace, 1, eventTraceActivity, InstanceId, RecordNumber, EventTime, State, Name, ActivityId, ActivityInstanceId, ActivityTypeName, Arguments, Variables, Annotations, ProfileName, reference, payload.AppDomainFriendlyName);
            }
            return flag;
        }

        internal static bool ActivityStateRecordIsEnabled(EtwDiagnosticTrace trace) => 
            IsEtwEventEnabled(trace, 1);

        internal static bool BookmarkResumptionRecord(EtwDiagnosticTrace trace, EventTraceActivity eventTraceActivity, Guid InstanceId, long RecordNumber, long EventTime, string Name, Guid SubInstanceID, string OwnerActivityName, string OwnerActivityId, string OwnerActivityInstanceId, string OwnerActivityTypeName, string Annotations, string ProfileName, string reference)
        {
            bool flag = true;
            TracePayload payload = trace.GetSerializedPayload(null, null, null);
            if (IsEtwEventEnabled(trace, 2))
            {
                flag = WriteEtwEvent(trace, 2, eventTraceActivity, InstanceId, RecordNumber, EventTime, Name, SubInstanceID, OwnerActivityName, OwnerActivityId, OwnerActivityInstanceId, OwnerActivityTypeName, Annotations, ProfileName, reference, payload.AppDomainFriendlyName);
            }
            return flag;
        }

        internal static bool BookmarkResumptionRecordIsEnabled(EtwDiagnosticTrace trace) => 
            IsEtwEventEnabled(trace, 2);

        internal static bool CancelRequestedRecord(EtwDiagnosticTrace trace, EventTraceActivity eventTraceActivity, Guid InstanceId, long RecordNumber, long EventTime, string Name, string ActivityId, string ActivityInstanceId, string ActivityTypeName, string ChildActivityName, string ChildActivityId, string ChildActivityInstanceId, string ChildActivityTypeName, string Annotations, string ProfileName, string reference)
        {
            bool flag = true;
            TracePayload payload = trace.GetSerializedPayload(null, null, null);
            if (IsEtwEventEnabled(trace, 3))
            {
                flag = WriteEtwEvent(trace, 3, eventTraceActivity, InstanceId, RecordNumber, EventTime, Name, ActivityId, ActivityInstanceId, ActivityTypeName, ChildActivityName, ChildActivityId, ChildActivityInstanceId, ChildActivityTypeName, Annotations, ProfileName, reference, payload.AppDomainFriendlyName);
            }
            return flag;
        }

        internal static bool CancelRequestedRecordIsEnabled(EtwDiagnosticTrace trace) => 
            IsEtwEventEnabled(trace, 3);

        [SecuritySafeCritical]
        private static void CreateEventDescriptors()
        {
            eventDescriptors = new EventDescriptor[] { 
                new EventDescriptor(0x68, 0, 0x12, 4, 0, 0xa31, 0x20000000000e0040L), new EventDescriptor(0x67, 0, 0x12, 4, 0, 0xa31, 0x20000000000e0040L), new EventDescriptor(0x6b, 0, 0x12, 4, 0, 0xa31, 0x20000000000e0040L), new EventDescriptor(0x6a, 0, 0x12, 4, 0, 0xa31, 0x20000000000e0040L), new EventDescriptor(0x69, 0, 0x12, 3, 0, 0xa31, 0x20000000000e0040L), new EventDescriptor(0x6c, 0, 0x12, 4, 0, 0x9df, 0x20000000001e0040L), new EventDescriptor(0x6f, 0, 0x12, 2, 0, 0x9df, 0x20000000001e0040L), new EventDescriptor(110, 0, 0x12, 3, 0, 0x9df, 0x20000000001e0040L), new EventDescriptor(0x66, 0, 0x12, 3, 0x90, 0xa30, 0x20000000000e0040L), new EventDescriptor(100, 0, 0x12, 4, 0, 0xa30, 0x20000000000e0040L), new EventDescriptor(0x65, 0, 0x12, 2, 150, 0xa30, 0x20000000000e0040L), new EventDescriptor(0x70, 0, 0x12, 4, 0x92, 0xa30, 0x2000000000040040L), new EventDescriptor(0x71, 0, 0x12, 2, 0x94, 0xa30, 0x20000000000e0040L), new EventDescriptor(0x72, 0, 0x12, 4, 0, 0xa30, 0x2000000000040040L), new EventDescriptor(0x73, 0, 0x12, 3, 0x91, 0xa30, 0x2000000000040040L), new EventDescriptor(0x74, 0, 0x12, 4, 0x93, 0xa30, 0x2000000000040040L),
                new EventDescriptor(0x75, 0, 0x12, 2, 0x95, 0xa30, 0x2000000000040040L), new EventDescriptor(0x76, 0, 0x12, 2, 0x97, 0xa30, 0x2000000000040040L), new EventDescriptor(0x77, 0, 0x12, 4, 0x98, 0xa30, 0x2000000000040040L)
            };
        }

        internal static bool CustomTrackingRecordError(EtwDiagnosticTrace trace, EventTraceActivity eventTraceActivity, Guid InstanceId, long RecordNumber, long EventTime, string Name, string ActivityName, string ActivityId, string ActivityInstanceId, string ActivityTypeName, string Data, string Annotations, string ProfileName, string reference)
        {
            bool flag = true;
            TracePayload payload = trace.GetSerializedPayload(null, null, null);
            if (IsEtwEventEnabled(trace, 6))
            {
                flag = WriteEtwEvent(trace, 6, eventTraceActivity, InstanceId, RecordNumber, EventTime, Name, ActivityName, ActivityId, ActivityInstanceId, ActivityTypeName, Data, Annotations, ProfileName, reference, payload.AppDomainFriendlyName);
            }
            return flag;
        }

        internal static bool CustomTrackingRecordErrorIsEnabled(EtwDiagnosticTrace trace) => 
            IsEtwEventEnabled(trace, 6);

        internal static bool CustomTrackingRecordInfo(EtwDiagnosticTrace trace, EventTraceActivity eventTraceActivity, Guid InstanceId, long RecordNumber, long EventTime, string Name, string ActivityName, string ActivityId, string ActivityInstanceId, string ActivityTypeName, string Data, string Annotations, string ProfileName, string reference)
        {
            bool flag = true;
            TracePayload payload = trace.GetSerializedPayload(null, null, null);
            if (IsEtwEventEnabled(trace, 5))
            {
                flag = WriteEtwEvent(trace, 5, eventTraceActivity, InstanceId, RecordNumber, EventTime, Name, ActivityName, ActivityId, ActivityInstanceId, ActivityTypeName, Data, Annotations, ProfileName, reference, payload.AppDomainFriendlyName);
            }
            return flag;
        }

        internal static bool CustomTrackingRecordInfoIsEnabled(EtwDiagnosticTrace trace) => 
            IsEtwEventEnabled(trace, 5);

        internal static bool CustomTrackingRecordWarning(EtwDiagnosticTrace trace, EventTraceActivity eventTraceActivity, Guid InstanceId, long RecordNumber, long EventTime, string Name, string ActivityName, string ActivityId, string ActivityInstanceId, string ActivityTypeName, string Data, string Annotations, string ProfileName, string reference)
        {
            bool flag = true;
            TracePayload payload = trace.GetSerializedPayload(null, null, null);
            if (IsEtwEventEnabled(trace, 7))
            {
                flag = WriteEtwEvent(trace, 7, eventTraceActivity, InstanceId, RecordNumber, EventTime, Name, ActivityName, ActivityId, ActivityInstanceId, ActivityTypeName, Data, Annotations, ProfileName, reference, payload.AppDomainFriendlyName);
            }
            return flag;
        }

        internal static bool CustomTrackingRecordWarningIsEnabled(EtwDiagnosticTrace trace) => 
            IsEtwEventEnabled(trace, 7);

        private static void EnsureEventDescriptors()
        {
            if (!eventDescriptorsCreated)
            {
                lock (syncLock)
                {
                    if (!eventDescriptorsCreated)
                    {
                        CreateEventDescriptors();
                        eventDescriptorsCreated = true;
                    }
                }
            }
        }

        internal static bool FaultPropagationRecord(EtwDiagnosticTrace trace, EventTraceActivity eventTraceActivity, Guid InstanceId, long RecordNumber, long EventTime, string FaultSourceActivityName, string FaultSourceActivityId, string FaultSourceActivityInstanceId, string FaultSourceActivityTypeName, string FaultHandlerActivityName, string FaultHandlerActivityId, string FaultHandlerActivityInstanceId, string FaultHandlerActivityTypeName, string Fault, bool IsFaultSource, string Annotations, string ProfileName, string reference)
        {
            bool flag = true;
            TracePayload payload = trace.GetSerializedPayload(null, null, null);
            if (IsEtwEventEnabled(trace, 4))
            {
                flag = WriteEtwEvent(trace, 4, eventTraceActivity, InstanceId, RecordNumber, EventTime, FaultSourceActivityName, FaultSourceActivityId, FaultSourceActivityInstanceId, FaultSourceActivityTypeName, FaultHandlerActivityName, FaultHandlerActivityId, FaultHandlerActivityInstanceId, FaultHandlerActivityTypeName, Fault, IsFaultSource, Annotations, ProfileName, reference, payload.AppDomainFriendlyName);
            }
            return flag;
        }

        internal static bool FaultPropagationRecordIsEnabled(EtwDiagnosticTrace trace) => 
            IsEtwEventEnabled(trace, 4);

        [SecuritySafeCritical]
        private static bool IsEtwEventEnabled(EtwDiagnosticTrace trace, int eventIndex)
        {
            if (trace.IsEtwProviderEnabled)
            {
                EnsureEventDescriptors();
                return trace.IsEtwEventEnabled(ref eventDescriptors[eventIndex], false);
            }
            return false;
        }

        internal static bool WorkflowInstanceAbortedRecord(EtwDiagnosticTrace trace, EventTraceActivity eventTraceActivity, Guid InstanceId, long RecordNumber, long EventTime, string ActivityDefinitionId, string Reason, string Annotations, string ProfileName, string reference)
        {
            bool flag = true;
            TracePayload payload = trace.GetSerializedPayload(null, null, null);
            if (IsEtwEventEnabled(trace, 8))
            {
                flag = WriteEtwEvent(trace, 8, eventTraceActivity, InstanceId, RecordNumber, EventTime, ActivityDefinitionId, Reason, Annotations, ProfileName, reference, payload.AppDomainFriendlyName);
            }
            return flag;
        }

        internal static bool WorkflowInstanceAbortedRecordIsEnabled(EtwDiagnosticTrace trace) => 
            IsEtwEventEnabled(trace, 8);

        internal static bool WorkflowInstanceAbortedRecordWithId(EtwDiagnosticTrace trace, EventTraceActivity eventTraceActivity, Guid InstanceId, long RecordNumber, long EventTime, string ActivityDefinitionId, string Reason, string Annotations, string ProfileName, string WorkflowDefinitionIdentity, string reference)
        {
            bool flag = true;
            TracePayload payload = trace.GetSerializedPayload(null, null, null);
            if (IsEtwEventEnabled(trace, 14))
            {
                flag = WriteEtwEvent(trace, 14, eventTraceActivity, InstanceId, RecordNumber, EventTime, ActivityDefinitionId, Reason, Annotations, ProfileName, WorkflowDefinitionIdentity, reference, payload.AppDomainFriendlyName);
            }
            return flag;
        }

        internal static bool WorkflowInstanceAbortedRecordWithIdIsEnabled(EtwDiagnosticTrace trace) => 
            IsEtwEventEnabled(trace, 14);

        internal static bool WorkflowInstanceRecord(EtwDiagnosticTrace trace, EventTraceActivity eventTraceActivity, Guid InstanceId, long RecordNumber, long EventTime, string ActivityDefinitionId, string State, string Annotations, string ProfileName, string reference)
        {
            bool flag = true;
            TracePayload payload = trace.GetSerializedPayload(null, null, null);
            if (IsEtwEventEnabled(trace, 9))
            {
                flag = WriteEtwEvent(trace, 9, eventTraceActivity, InstanceId, RecordNumber, EventTime, ActivityDefinitionId, State, Annotations, ProfileName, reference, payload.AppDomainFriendlyName);
            }
            return flag;
        }

        internal static bool WorkflowInstanceRecordIsEnabled(EtwDiagnosticTrace trace) => 
            IsEtwEventEnabled(trace, 9);

        internal static bool WorkflowInstanceRecordWithId(EtwDiagnosticTrace trace, EventTraceActivity eventTraceActivity, Guid InstanceId, long RecordNumber, long EventTime, string ActivityDefinitionId, string State, string Annotations, string ProfileName, string WorkflowDefinitionIdentity, string reference)
        {
            bool flag = true;
            TracePayload payload = trace.GetSerializedPayload(null, null, null);
            if (IsEtwEventEnabled(trace, 13))
            {
                flag = WriteEtwEvent(trace, 13, eventTraceActivity, InstanceId, RecordNumber, EventTime, ActivityDefinitionId, State, Annotations, ProfileName, WorkflowDefinitionIdentity, reference, payload.AppDomainFriendlyName);
            }
            return flag;
        }

        internal static bool WorkflowInstanceRecordWithIdIsEnabled(EtwDiagnosticTrace trace) => 
            IsEtwEventEnabled(trace, 13);

        internal static bool WorkflowInstanceSuspendedRecord(EtwDiagnosticTrace trace, EventTraceActivity eventTraceActivity, Guid InstanceId, long RecordNumber, long EventTime, string ActivityDefinitionId, string Reason, string Annotations, string ProfileName, string reference)
        {
            bool flag = true;
            TracePayload payload = trace.GetSerializedPayload(null, null, null);
            if (IsEtwEventEnabled(trace, 11))
            {
                flag = WriteEtwEvent(trace, 11, eventTraceActivity, InstanceId, RecordNumber, EventTime, ActivityDefinitionId, Reason, Annotations, ProfileName, reference, payload.AppDomainFriendlyName);
            }
            return flag;
        }

        internal static bool WorkflowInstanceSuspendedRecordIsEnabled(EtwDiagnosticTrace trace) => 
            IsEtwEventEnabled(trace, 11);

        internal static bool WorkflowInstanceSuspendedRecordWithId(EtwDiagnosticTrace trace, EventTraceActivity eventTraceActivity, Guid InstanceId, long RecordNumber, long EventTime, string ActivityDefinitionId, string Reason, string Annotations, string ProfileName, string WorkflowDefinitionIdentity, string reference)
        {
            bool flag = true;
            TracePayload payload = trace.GetSerializedPayload(null, null, null);
            if (IsEtwEventEnabled(trace, 15))
            {
                flag = WriteEtwEvent(trace, 15, eventTraceActivity, InstanceId, RecordNumber, EventTime, ActivityDefinitionId, Reason, Annotations, ProfileName, WorkflowDefinitionIdentity, reference, payload.AppDomainFriendlyName);
            }
            return flag;
        }

        internal static bool WorkflowInstanceSuspendedRecordWithIdIsEnabled(EtwDiagnosticTrace trace) => 
            IsEtwEventEnabled(trace, 15);

        internal static bool WorkflowInstanceTerminatedRecord(EtwDiagnosticTrace trace, EventTraceActivity eventTraceActivity, Guid InstanceId, long RecordNumber, long EventTime, string ActivityDefinitionId, string Reason, string Annotations, string ProfileName, string reference)
        {
            bool flag = true;
            TracePayload payload = trace.GetSerializedPayload(null, null, null);
            if (IsEtwEventEnabled(trace, 12))
            {
                flag = WriteEtwEvent(trace, 12, eventTraceActivity, InstanceId, RecordNumber, EventTime, ActivityDefinitionId, Reason, Annotations, ProfileName, reference, payload.AppDomainFriendlyName);
            }
            return flag;
        }

        internal static bool WorkflowInstanceTerminatedRecordIsEnabled(EtwDiagnosticTrace trace) => 
            IsEtwEventEnabled(trace, 12);

        internal static bool WorkflowInstanceTerminatedRecordWithId(EtwDiagnosticTrace trace, EventTraceActivity eventTraceActivity, Guid InstanceId, long RecordNumber, long EventTime, string ActivityDefinitionId, string Reason, string Annotations, string ProfileName, string WorkflowDefinitionIdentity, string reference)
        {
            bool flag = true;
            TracePayload payload = trace.GetSerializedPayload(null, null, null);
            if (IsEtwEventEnabled(trace, 0x10))
            {
                flag = WriteEtwEvent(trace, 0x10, eventTraceActivity, InstanceId, RecordNumber, EventTime, ActivityDefinitionId, Reason, Annotations, ProfileName, WorkflowDefinitionIdentity, reference, payload.AppDomainFriendlyName);
            }
            return flag;
        }

        internal static bool WorkflowInstanceTerminatedRecordWithIdIsEnabled(EtwDiagnosticTrace trace) => 
            IsEtwEventEnabled(trace, 0x10);

        internal static bool WorkflowInstanceUnhandledExceptionRecord(EtwDiagnosticTrace trace, EventTraceActivity eventTraceActivity, Guid InstanceId, long RecordNumber, long EventTime, string ActivityDefinitionId, string SourceName, string SourceId, string SourceInstanceId, string SourceTypeName, string Exception, string Annotations, string ProfileName, string reference)
        {
            bool flag = true;
            TracePayload payload = trace.GetSerializedPayload(null, null, null);
            if (IsEtwEventEnabled(trace, 10))
            {
                flag = WriteEtwEvent(trace, 10, eventTraceActivity, InstanceId, RecordNumber, EventTime, ActivityDefinitionId, SourceName, SourceId, SourceInstanceId, SourceTypeName, Exception, Annotations, ProfileName, reference, payload.AppDomainFriendlyName);
            }
            return flag;
        }

        internal static bool WorkflowInstanceUnhandledExceptionRecordIsEnabled(EtwDiagnosticTrace trace) => 
            IsEtwEventEnabled(trace, 10);

        internal static bool WorkflowInstanceUnhandledExceptionRecordWithId(EtwDiagnosticTrace trace, EventTraceActivity eventTraceActivity, Guid InstanceId, long RecordNumber, long EventTime, string ActivityDefinitionId, string SourceName, string SourceId, string SourceInstanceId, string SourceTypeName, string Exception, string Annotations, string ProfileName, string WorkflowDefinitionIdentity, string reference)
        {
            bool flag = true;
            TracePayload payload = trace.GetSerializedPayload(null, null, null);
            if (IsEtwEventEnabled(trace, 0x11))
            {
                flag = WriteEtwEvent(trace, 0x11, eventTraceActivity, InstanceId, RecordNumber, EventTime, ActivityDefinitionId, SourceName, SourceId, SourceInstanceId, SourceTypeName, Exception, Annotations, ProfileName, WorkflowDefinitionIdentity, reference, payload.AppDomainFriendlyName);
            }
            return flag;
        }

        internal static bool WorkflowInstanceUnhandledExceptionRecordWithIdIsEnabled(EtwDiagnosticTrace trace) => 
            IsEtwEventEnabled(trace, 0x11);

        internal static bool WorkflowInstanceUpdatedRecord(EtwDiagnosticTrace trace, EventTraceActivity eventTraceActivity, Guid InstanceId, long RecordNumber, long EventTime, string ActivityDefinitionId, string State, string OriginalDefinitionIdentity, string UpdatedDefinitionIdentity, string Annotations, string ProfileName, string reference)
        {
            bool flag = true;
            TracePayload payload = trace.GetSerializedPayload(null, null, null);
            if (IsEtwEventEnabled(trace, 0x12))
            {
                flag = WriteEtwEvent(trace, 0x12, eventTraceActivity, InstanceId, RecordNumber, EventTime, ActivityDefinitionId, State, OriginalDefinitionIdentity, UpdatedDefinitionIdentity, Annotations, ProfileName, reference, payload.AppDomainFriendlyName);
            }
            return flag;
        }

        internal static bool WorkflowInstanceUpdatedRecordIsEnabled(EtwDiagnosticTrace trace) => 
            IsEtwEventEnabled(trace, 0x12);

        [SecuritySafeCritical]
        private static bool WriteEtwEvent(EtwDiagnosticTrace trace, int eventIndex, EventTraceActivity eventParam0, Guid eventParam1, long eventParam2, long eventParam3, string eventParam4, string eventParam5, string eventParam6, string eventParam7, string eventParam8, string eventParam9)
        {
            EnsureEventDescriptors();
            return trace.EtwProvider.WriteEvent(ref eventDescriptors[eventIndex], eventParam0, eventParam1, eventParam2, eventParam3, eventParam4, eventParam5, eventParam6, eventParam7, eventParam8, eventParam9);
        }

        [SecuritySafeCritical]
        private static bool WriteEtwEvent(EtwDiagnosticTrace trace, int eventIndex, EventTraceActivity eventParam0, Guid eventParam1, long eventParam2, long eventParam3, string eventParam4, string eventParam5, string eventParam6, string eventParam7, string eventParam8, string eventParam9, string eventParam10)
        {
            EnsureEventDescriptors();
            object[] eventPayload = new object[] { eventParam1, eventParam2, eventParam3, eventParam4, eventParam5, eventParam6, eventParam7, eventParam8, eventParam9, eventParam10 };
            return trace.EtwProvider.WriteEvent(ref eventDescriptors[eventIndex], eventParam0, eventPayload);
        }

        [SecuritySafeCritical]
        private static bool WriteEtwEvent(EtwDiagnosticTrace trace, int eventIndex, EventTraceActivity eventParam0, Guid eventParam1, long eventParam2, long eventParam3, string eventParam4, string eventParam5, string eventParam6, string eventParam7, string eventParam8, string eventParam9, string eventParam10, string eventParam11)
        {
            EnsureEventDescriptors();
            return trace.EtwProvider.WriteEvent(ref eventDescriptors[eventIndex], eventParam0, eventParam1, eventParam2, eventParam3, eventParam4, eventParam5, eventParam6, eventParam7, eventParam8, eventParam9, eventParam10, eventParam11);
        }

        [SecuritySafeCritical]
        private static bool WriteEtwEvent(EtwDiagnosticTrace trace, int eventIndex, EventTraceActivity eventParam0, Guid eventParam1, long eventParam2, long eventParam3, string eventParam4, Guid eventParam5, string eventParam6, string eventParam7, string eventParam8, string eventParam9, string eventParam10, string eventParam11, string eventParam12, string eventParam13)
        {
            EnsureEventDescriptors();
            return trace.EtwProvider.WriteEvent(ref eventDescriptors[eventIndex], eventParam0, eventParam1, eventParam2, eventParam3, eventParam4, eventParam5, eventParam6, eventParam7, eventParam8, eventParam9, eventParam10, eventParam11, eventParam12, eventParam13);
        }

        [SecuritySafeCritical]
        private static bool WriteEtwEvent(EtwDiagnosticTrace trace, int eventIndex, EventTraceActivity eventParam0, Guid eventParam1, long eventParam2, long eventParam3, string eventParam4, string eventParam5, string eventParam6, string eventParam7, string eventParam8, string eventParam9, string eventParam10, string eventParam11, string eventParam12, string eventParam13)
        {
            EnsureEventDescriptors();
            return trace.EtwProvider.WriteEvent(ref eventDescriptors[eventIndex], eventParam0, eventParam1, eventParam2, eventParam3, eventParam4, eventParam5, eventParam6, eventParam7, eventParam8, eventParam9, eventParam10, eventParam11, eventParam12, eventParam13);
        }

        [SecuritySafeCritical]
        private static bool WriteEtwEvent(EtwDiagnosticTrace trace, int eventIndex, EventTraceActivity eventParam0, Guid eventParam1, long eventParam2, long eventParam3, string eventParam4, string eventParam5, string eventParam6, string eventParam7, string eventParam8, string eventParam9, string eventParam10, string eventParam11, string eventParam12, string eventParam13, string eventParam14)
        {
            EnsureEventDescriptors();
            return trace.EtwProvider.WriteEvent(ref eventDescriptors[eventIndex], eventParam0, eventParam1, eventParam2, eventParam3, eventParam4, eventParam5, eventParam6, eventParam7, eventParam8, eventParam9, eventParam10, eventParam11, eventParam12, eventParam13, eventParam14);
        }

        [SecuritySafeCritical]
        private static bool WriteEtwEvent(EtwDiagnosticTrace trace, int eventIndex, EventTraceActivity eventParam0, Guid eventParam1, long eventParam2, long eventParam3, string eventParam4, string eventParam5, string eventParam6, string eventParam7, string eventParam8, string eventParam9, string eventParam10, string eventParam11, string eventParam12, string eventParam13, string eventParam14, string eventParam15)
        {
            EnsureEventDescriptors();
            return trace.EtwProvider.WriteEvent(ref eventDescriptors[eventIndex], eventParam0, eventParam1, eventParam2, eventParam3, eventParam4, eventParam5, eventParam6, eventParam7, eventParam8, eventParam9, eventParam10, eventParam11, eventParam12, eventParam13, eventParam14, eventParam15);
        }

        [SecuritySafeCritical]
        private static bool WriteEtwEvent(EtwDiagnosticTrace trace, int eventIndex, EventTraceActivity eventParam0, Guid eventParam1, long eventParam2, long eventParam3, string eventParam4, string eventParam5, string eventParam6, string eventParam7, string eventParam8, string eventParam9, string eventParam10, string eventParam11, string eventParam12, bool eventParam13, string eventParam14, string eventParam15, string eventParam16, string eventParam17)
        {
            EnsureEventDescriptors();
            return trace.EtwProvider.WriteEvent(ref eventDescriptors[eventIndex], eventParam0, eventParam1, eventParam2, eventParam3, eventParam4, eventParam5, eventParam6, eventParam7, eventParam8, eventParam9, eventParam10, eventParam11, eventParam12, eventParam13, eventParam14, eventParam15, eventParam16, eventParam17);
        }

        private static System.Resources.ResourceManager ResourceManager
        {
            get
            {
                if (resourceManager == null)
                {
                    resourceManager = new System.Resources.ResourceManager("System.Activities.EtwTrackingParticipantTrackRecords", typeof(EtwTrackingParticipantTrackRecords).Assembly);
                }
                return resourceManager;
            }
        }

        internal static CultureInfo Culture
        {
            get => 
                resourceCulture;
            set => 
                resourceCulture = value;
        }
    }
}

