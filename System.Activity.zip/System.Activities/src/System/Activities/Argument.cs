﻿namespace System.Activities
{
    using System;
    using System.Activities.Runtime;
    using System.Activities.Validation;
    using System.Activities.XamlIntegration;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Runtime.CompilerServices;
    using System.Runtime.Serialization;
    using System.Windows.Markup;

    public abstract class Argument
    {
        public static readonly int UnspecifiedEvaluationOrder = -1;
        public const string ResultValue = "Result";
        private ArgumentDirection direction;
        private System.Activities.RuntimeArgument runtimeArgument;
        private int evaluationOrder = UnspecifiedEvaluationOrder;

        internal Argument()
        {
        }

        internal static void Bind(Argument binding, System.Activities.RuntimeArgument argument)
        {
            if (binding != null)
            {
                binding.RuntimeArgument = argument;
            }
            argument.BoundArgument = binding;
        }

        internal bool CanConvertToString(IValueSerializerContext context) => 
            this.WasDesignTimeNull || ((this.EvaluationOrder == UnspecifiedEvaluationOrder) && ActivityWithResultValueSerializer.CanConvertToStringWrapper(this.Expression, context));

        internal string ConvertToString(IValueSerializerContext context)
        {
            if (this.WasDesignTimeNull)
            {
                return null;
            }
            return ActivityWithResultValueSerializer.ConvertToStringWrapper(this.Expression, context);
        }

        public static Argument Create(Type type, ArgumentDirection direction) => 
            ActivityUtilities.CreateArgument(type, direction);

        internal abstract Location CreateDefaultLocation();
        internal static Location<T> CreateLocation<T>() => 
            new Location<T>();

        public static Argument CreateReference(Argument argumentToReference, string referencedArgumentName)
        {
            if (argumentToReference == null)
            {
                throw System.Activities.FxTrace.Exception.ArgumentNull("argumentToReference");
            }
            if (string.IsNullOrEmpty(referencedArgumentName))
            {
                throw System.Activities.FxTrace.Exception.ArgumentNullOrEmpty("referencedArgumentName");
            }
            return ActivityUtilities.CreateReferenceArgument(argumentToReference.ArgumentType, argumentToReference.Direction, referencedArgumentName);
        }

        internal abstract void Declare(LocationEnvironment targetEnvironment, System.Activities.ActivityInstance activityInstance);
        public object Get(ActivityContext context) => 
            this.Get<object>(context);

        public T Get<T>(ActivityContext context)
        {
            if (context == null)
            {
                throw System.Activities.FxTrace.Exception.ArgumentNull("context");
            }
            this.ThrowIfNotInTree();
            return context.GetValue<T>(this.RuntimeArgument);
        }

        public Location GetLocation(ActivityContext context)
        {
            if (context == null)
            {
                throw System.Activities.FxTrace.Exception.ArgumentNull("context");
            }
            this.ThrowIfNotInTree();
            return this.runtimeArgument.GetLocation(context);
        }

        public void Set(ActivityContext context, object value)
        {
            if (context == null)
            {
                throw System.Activities.FxTrace.Exception.ArgumentNull("context");
            }
            this.ThrowIfNotInTree();
            context.SetValue<object>(this.RuntimeArgument, value);
        }

        internal void ThrowIfNotInTree()
        {
            if (!this.IsInTree)
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.ArgumentNotInTree(this.ArgumentType)));
            }
        }

        internal static void TryBind(Argument binding, System.Activities.RuntimeArgument argument, Activity violationOwner)
        {
            if (argument == null)
            {
                throw System.Activities.FxTrace.Exception.ArgumentNull("argument");
            }
            bool flag = true;
            if (binding != null)
            {
                if (binding.Direction != argument.Direction)
                {
                    violationOwner.AddTempValidationError(new ValidationError(System.Activities.SR.ArgumentDirectionMismatch(argument.Name, argument.Direction, binding.Direction)));
                    flag = false;
                }
                if (binding.ArgumentType != argument.Type)
                {
                    violationOwner.AddTempValidationError(new ValidationError(System.Activities.SR.ArgumentTypeMismatch(argument.Name, argument.Type, binding.ArgumentType)));
                    flag = false;
                }
            }
            if (flag)
            {
                Bind(binding, argument);
            }
        }

        internal abstract bool TryPopulateValue(LocationEnvironment targetEnvironment, System.Activities.ActivityInstance targetActivityInstance, ActivityExecutor executor);
        internal void Validate(Activity owner, ref IList<ValidationError> validationErrors)
        {
            if (this.Expression != null)
            {
                if ((this.Expression.Result != null) && !this.Expression.Result.IsEmpty)
                {
                    ValidationError data = new ValidationError(System.Activities.SR.ResultCannotBeSetOnArgumentExpressions, false, this.RuntimeArgument.Name, owner);
                    ActivityUtilities.Add<ValidationError>(ref validationErrors, data);
                }
                ActivityWithResult expression = this.Expression;
                if (expression is IExpressionWrapper)
                {
                    expression = ((IExpressionWrapper) expression).InnerExpression;
                }
                ArgumentDirection direction = this.Direction;
                if (direction != ArgumentDirection.In)
                {
                    if ((direction - 1) > ArgumentDirection.Out)
                    {
                        return;
                    }
                }
                else
                {
                    if (expression.ResultType != this.ArgumentType)
                    {
                        ActivityUtilities.Add<ValidationError>(ref validationErrors, new ValidationError(System.Activities.SR.ArgumentValueExpressionTypeMismatch(this.ArgumentType, expression.ResultType), false, this.RuntimeArgument.Name, owner));
                    }
                    return;
                }
                if (!ActivityUtilities.IsLocationGenericType(expression.ResultType, out Type type) || (type != this.ArgumentType))
                {
                    Type type2 = ActivityUtilities.CreateActivityWithResult(ActivityUtilities.CreateLocation(this.ArgumentType));
                    ActivityUtilities.Add<ValidationError>(ref validationErrors, new ValidationError(System.Activities.SR.ArgumentLocationExpressionTypeMismatch(type2.FullName, expression.GetType().FullName), false, this.RuntimeArgument.Name, owner));
                }
            }
        }

        public Type ArgumentType { get; internal set; }

        public ArgumentDirection Direction
        {
            get => 
                this.direction;
            internal set
            {
                ArgumentDirectionHelper.Validate(value, "value");
                this.direction = value;
            }
        }

        [DefaultValue(-1)]
        public int EvaluationOrder
        {
            get => 
                this.evaluationOrder;
            set
            {
                if ((value < 0) && (value != UnspecifiedEvaluationOrder))
                {
                    throw System.Activities.FxTrace.Exception.ArgumentOutOfRange("EvaluationOrder", value, System.Activities.SR.InvalidEvaluationOrderValue);
                }
                this.evaluationOrder = value;
            }
        }

        [IgnoreDataMember, DefaultValue((string) null)]
        public ActivityWithResult Expression
        {
            get => 
                this.ExpressionCore;
            set => 
                this.ExpressionCore = value;
        }

        internal abstract ActivityWithResult ExpressionCore { get; set; }

        internal System.Activities.RuntimeArgument RuntimeArgument
        {
            get => 
                this.runtimeArgument;
            set => 
                this.runtimeArgument = value;
        }

        internal bool IsInTree =>
            (this.runtimeArgument != null) && this.runtimeArgument.IsInTree;

        internal bool WasDesignTimeNull { get; set; }

        internal int Id =>
            this.runtimeArgument.Id;

        internal bool IsEmpty =>
            this.Expression == null;

        internal interface IExpressionWrapper
        {
            ActivityWithResult InnerExpression { get; }
        }
    }
}

