﻿namespace System.Activities
{
    using System;
    using System.Activities.Debugger;
    using System.Activities.XamlIntegration;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.Runtime.CompilerServices;
    using System.Windows.Markup;

    [ContentProperty("Implementation")]
    public sealed class ActivityBuilder<TResult> : IDebuggableWorkflowTree
    {
        private KeyedCollection<string, DynamicActivityProperty> properties;
        private Collection<Constraint> constraints;
        private Collection<Attribute> attributes;

        Activity IDebuggableWorkflowTree.GetWorkflowRoot() => 
            this.Implementation;

        public string Name { get; set; }

        [DependsOn("Name")]
        public Collection<Attribute> Attributes
        {
            get
            {
                if (this.attributes == null)
                {
                    this.attributes = new Collection<Attribute>();
                }
                return this.attributes;
            }
        }

        [Browsable(false), DependsOn("Attributes")]
        public KeyedCollection<string, DynamicActivityProperty> Properties
        {
            get
            {
                if (this.properties == null)
                {
                    this.properties = ActivityBuilder.CreateActivityPropertyCollection();
                }
                return this.properties;
            }
        }

        [DependsOn("Properties"), Browsable(false)]
        public Collection<Constraint> Constraints
        {
            get
            {
                if (this.constraints == null)
                {
                    this.constraints = new Collection<Constraint>();
                }
                return this.constraints;
            }
        }

        [TypeConverter(typeof(ImplementationVersionConverter)), DefaultValue((string) null), DependsOn("Name")]
        public Version ImplementationVersion { get; set; }

        [DefaultValue((string) null), Browsable(false), DependsOn("Constraints")]
        public Activity Implementation { get; set; }
    }
}

