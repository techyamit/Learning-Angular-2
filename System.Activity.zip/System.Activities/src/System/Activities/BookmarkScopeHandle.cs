﻿namespace System.Activities
{
    using System;
    using System.Runtime.DurableInstancing;
    using System.Runtime.Serialization;

    [DataContract]
    public sealed class BookmarkScopeHandle : Handle
    {
        private System.Activities.BookmarkScope bookmarkScope;
        private static BookmarkScopeHandle defaultBookmarkScopeHandle = new BookmarkScopeHandle(System.Activities.BookmarkScope.Default);

        public BookmarkScopeHandle()
        {
        }

        internal BookmarkScopeHandle(System.Activities.BookmarkScope bookmarkScope)
        {
            this.bookmarkScope = bookmarkScope;
            if (bookmarkScope != null)
            {
                this.bookmarkScope.IncrementHandleReferenceCount();
            }
        }

        public void CreateBookmarkScope(NativeActivityContext context)
        {
            this.ThrowIfContextIsNullOrDisposed(context);
            if (this.bookmarkScope != null)
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.CreateBookmarkScopeFailed));
            }
            base.ThrowIfUninitialized();
            this.bookmarkScope = context.CreateBookmarkScope(Guid.Empty, this);
            this.bookmarkScope.IncrementHandleReferenceCount();
        }

        public void CreateBookmarkScope(NativeActivityContext context, Guid scopeId)
        {
            this.ThrowIfContextIsNullOrDisposed(context);
            if (this.bookmarkScope != null)
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.CreateBookmarkScopeFailed));
            }
            base.ThrowIfUninitialized();
            this.bookmarkScope = context.CreateBookmarkScope(scopeId, this);
            this.bookmarkScope.IncrementHandleReferenceCount();
        }

        public void Initialize(NativeActivityContext context, Guid scope)
        {
            this.ThrowIfContextIsNullOrDisposed(context);
            base.ThrowIfUninitialized();
            this.bookmarkScope.Initialize(context, scope);
        }

        protected override void OnUninitialize(HandleInitializationContext context)
        {
            if (this.bookmarkScope != null)
            {
                int num = this.bookmarkScope.DecrementHandleReferenceCount();
                DisassociateInstanceKeysExtension extension = context.GetExtension<DisassociateInstanceKeysExtension>();
                if (((extension != null) && extension.AutomaticDisassociationEnabled) && (num == 0))
                {
                    context.UnregisterBookmarkScope(this.bookmarkScope);
                }
            }
            base.OnUninitialize(context);
        }

        private void ThrowIfContextIsNullOrDisposed(NativeActivityContext context)
        {
            if (context == null)
            {
                throw System.Activities.FxTrace.Exception.ArgumentNull("context");
            }
            context.ThrowIfDisposed();
        }

        public static BookmarkScopeHandle Default =>
            defaultBookmarkScopeHandle;

        public System.Activities.BookmarkScope BookmarkScope =>
            this.bookmarkScope;

        [DataMember(EmitDefaultValue=false, Name="bookmarkScope")]
        internal System.Activities.BookmarkScope SerializedBookmarkScope
        {
            get => 
                this.bookmarkScope;
            set
            {
                this.bookmarkScope = value;
                if (this.bookmarkScope != null)
                {
                    this.bookmarkScope.IncrementHandleReferenceCount();
                }
            }
        }
    }
}

