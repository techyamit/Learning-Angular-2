﻿namespace System.Activities
{
    using System;
    using System.Runtime;
    using System.Runtime.CompilerServices;
    using System.Threading;

    internal class AsyncInvokeOperation
    {
        private object thisLock;

        public AsyncInvokeOperation(SynchronizationContext syncContext)
        {
            this.SyncContext = syncContext;
            this.thisLock = new object();
        }

        public void OperationCompleted()
        {
            object thisLock = this.thisLock;
            lock (thisLock)
            {
                Fx.AssertAndThrowFatal(!this.Completed, "Async operation has already been completed");
                this.Completed = true;
            }
            this.SyncContext.OperationCompleted();
        }

        public void OperationStarted()
        {
            this.SyncContext.OperationStarted();
        }

        public void PostOperationCompleted(SendOrPostCallback callback, object arg)
        {
            object thisLock = this.thisLock;
            lock (thisLock)
            {
                Fx.AssertAndThrowFatal(!this.Completed, "Async operation has already been completed");
                this.Completed = true;
            }
            this.SyncContext.Post(callback, arg);
            this.SyncContext.OperationCompleted();
        }

        private SynchronizationContext SyncContext { get; set; }

        private bool Completed { get; set; }
    }
}

