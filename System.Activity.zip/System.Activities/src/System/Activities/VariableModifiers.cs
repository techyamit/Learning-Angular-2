﻿namespace System.Activities
{
    using System;

    [Flags]
    public enum VariableModifiers
    {
        None,
        ReadOnly,
        Mapped
    }
}

