﻿namespace System.Activities
{
    using System;
    using System.Activities.DynamicUpdate;
    using System.Activities.Runtime;
    using System.Activities.Tracking;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Globalization;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Runtime.Serialization;

    [DataContract(Name="ActivityInstance", Namespace="http://schemas.datacontract.org/2010/02/System.Activities")]
    public sealed class ActivityInstance : ActivityInstanceMap.IActivityReferenceWithEnvironment, ActivityInstanceMap.IActivityReference
    {
        private System.Activities.Activity activity;
        private ChildList childList;
        private ReadOnlyCollection<System.Activities.ActivityInstance> childCache;
        private System.Activities.Runtime.CompletionBookmark completionBookmark;
        private ActivityInstanceMap instanceMap;
        private System.Activities.ActivityInstance parent;
        private string ownerName;
        private int busyCount;
        private ExtendedData extendedData;
        private bool noSymbols;
        private ActivityInstanceState state;
        private bool isCancellationRequested;
        private bool performingDefaultCancelation;
        private Substate substate;
        private long id;
        private bool initializationIncomplete;
        private LocationEnvironment environment;
        private ExecutionPropertyManager propertyManager;

        internal ActivityInstance(System.Activities.Activity activity)
        {
            this.activity = activity;
            this.state = ActivityInstanceState.Executing;
            this.substate = Substate.Created;
            this.ImplementationVersion = activity.ImplementationVersion;
        }

        internal void Abort(ActivityExecutor executor, BookmarkManager bookmarkManager, Exception terminationReason, bool isTerminate)
        {
            AbortEnumerator enumerator = new AbortEnumerator(this);
            while (enumerator.MoveNext())
            {
                System.Activities.ActivityInstance current = enumerator.Current;
                if (!current.HasNotExecuted)
                {
                    current.Activity.InternalAbort(current, executor, terminationReason);
                    executor.DebugActivityCompleted(current);
                }
                if (current.PropertyManager != null)
                {
                    current.PropertyManager.UnregisterProperties(current, current.Activity.MemberOf, true);
                }
                executor.TerminateSpecialExecutionBlocks(current, terminationReason);
                executor.CancelPendingOperation(current);
                executor.HandleRootCompletion(current);
                current.MarkAsComplete(executor.RawBookmarkScopeManager, bookmarkManager);
                current.state = ActivityInstanceState.Faulted;
                current.FinalizeState(executor, false, !isTerminate);
            }
        }

        internal void AddActivityReference(ActivityInstanceReference reference)
        {
            this.EnsureExtendedData();
            this.extendedData.AddActivityReference(reference);
        }

        internal void AddBookmark(Bookmark bookmark, BookmarkOptions options)
        {
            bool affectsBusyCount = false;
            if (!BookmarkOptionsHelper.IsNonBlocking(options))
            {
                this.IncrementBusyCount();
                affectsBusyCount = true;
            }
            this.EnsureExtendedData();
            this.extendedData.AddBookmark(bookmark, affectsBusyCount);
        }

        internal void AddChild(System.Activities.ActivityInstance item)
        {
            if (this.childList == null)
            {
                this.childList = new ChildList();
            }
            this.childList.Add(item);
            this.childCache = null;
        }

        internal void AppendChildren(ActivityUtilities.TreeProcessingList nextInstanceList, ref Queue<IList<System.Activities.ActivityInstance>> instancesRemaining)
        {
            this.childList.AppendChildren(nextInstanceList, ref instancesRemaining);
        }

        internal void BaseCancel(NativeActivityContext context)
        {
            this.performingDefaultCancelation = true;
            this.CancelChildren(context);
        }

        internal void Cancel(ActivityExecutor executor, BookmarkManager bookmarkManager)
        {
            this.Activity.InternalCancel(this, executor, bookmarkManager);
        }

        internal void CancelChildren(NativeActivityContext context)
        {
            if (this.HasChildren)
            {
                foreach (System.Activities.ActivityInstance instance in this.GetChildren())
                {
                    context.CancelChild(instance);
                }
            }
        }

        internal static System.Activities.ActivityInstance CreateCanceledInstance(System.Activities.Activity activity) => 
            new System.Activities.ActivityInstance(activity) { state = ActivityInstanceState.Canceled };

        internal static System.Activities.ActivityInstance CreateCompletedInstance(System.Activities.Activity activity) => 
            new System.Activities.ActivityInstance(activity) { state = ActivityInstanceState.Closed };

        internal void DecrementBusyCount()
        {
            this.busyCount--;
        }

        internal void DecrementBusyCount(int amount)
        {
            this.busyCount -= amount;
        }

        private void EnqueueVariableDefault(ActivityExecutor executor, Variable variable, Location variableLocation)
        {
            if (variableLocation == null)
            {
                variableLocation = this.environment.GetSpecificLocation(variable.Id);
            }
            variable.SetIsWaitingOnDefaultValue(variableLocation);
            executor.ScheduleExpression(variable.Default, this, this.environment, variableLocation, null);
        }

        private void EnsureExtendedData()
        {
            if (this.extendedData == null)
            {
                this.extendedData = new ExtendedData();
            }
        }

        internal void Execute(ActivityExecutor executor, BookmarkManager bookmarkManager)
        {
            if (this.initializationIncomplete)
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.InitializationIncomplete));
            }
            this.MarkExecuted();
            this.Activity.InternalExecute(this, executor, bookmarkManager);
        }

        internal void FillInstanceMap(ActivityInstanceMap instanceMap)
        {
            if (!this.IsCompleted)
            {
                this.instanceMap = instanceMap;
                ActivityUtilities.ProcessActivityInstanceTree(this, null, new Func<System.Activities.ActivityInstance, ActivityExecutor, bool>(this.GenerateInstanceMapCallback));
            }
        }

        internal void FinalizeState(ActivityExecutor executor, bool faultActivity)
        {
            this.FinalizeState(executor, faultActivity, false);
        }

        internal void FinalizeState(ActivityExecutor executor, bool faultActivity, bool skipTracking)
        {
            if (faultActivity)
            {
                this.TryCancelParent();
                this.state = ActivityInstanceState.Faulted;
            }
            if (this.state == ActivityInstanceState.Closed)
            {
                if ((executor.ShouldTrackActivityStateRecordsClosedState && !skipTracking) && executor.ShouldTrackActivity(this.Activity.DisplayName))
                {
                    executor.AddTrackingRecord(new ActivityStateRecord(executor.WorkflowInstanceId, this, this.state));
                }
            }
            else if (executor.ShouldTrackActivityStateRecords && !skipTracking)
            {
                executor.AddTrackingRecord(new ActivityStateRecord(executor.WorkflowInstanceId, this, this.state));
            }
            if (TD.ActivityCompletedIsEnabled())
            {
                TD.ActivityCompleted(this.Activity.GetType().ToString(), this.Activity.DisplayName, this.Id, this.State.GetStateName());
            }
        }

        internal void FixupInstance(System.Activities.ActivityInstance parent, ActivityInstanceMap instanceMap, ActivityExecutor executor)
        {
            if (!this.IsCompleted)
            {
                if (this.Activity == null)
                {
                    throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.ActivityInstanceFixupFailed));
                }
                this.parent = parent;
                this.instanceMap = instanceMap;
                if (this.PropertyManager != null)
                {
                    this.PropertyManager.OnDeserialized(this, parent, this.Activity.MemberOf, executor);
                }
                else if (this.parent != null)
                {
                    this.PropertyManager = this.parent.PropertyManager;
                }
                else
                {
                    this.PropertyManager = executor.RootPropertyManager;
                }
                if (!this.noSymbols)
                {
                    this.environment.OnDeserialized(executor, this);
                }
            }
        }

        private bool GenerateInstanceMapCallback(System.Activities.ActivityInstance instance, ActivityExecutor executor)
        {
            this.instanceMap.AddEntry(instance);
            instance.instanceMap = this.instanceMap;
            if (instance.HasActivityReferences)
            {
                instance.extendedData.FillInstanceMap(instance.instanceMap);
            }
            return true;
        }

        internal ReadOnlyCollection<System.Activities.ActivityInstance> GetChildren()
        {
            if (!this.HasChildren)
            {
                return ChildList.Empty;
            }
            if (this.childCache == null)
            {
                this.childCache = this.childList.AsReadOnly();
            }
            return this.childCache;
        }

        internal HybridCollection<System.Activities.ActivityInstance> GetRawChildren() => 
            this.childList;

        internal void IncrementBusyCount()
        {
            this.busyCount++;
        }

        internal bool Initialize(System.Activities.ActivityInstance parent, ActivityInstanceMap instanceMap, LocationEnvironment parentEnvironment, long instanceId, ActivityExecutor executor) => 
            this.Initialize(parent, instanceMap, parentEnvironment, instanceId, executor, 0);

        internal bool Initialize(System.Activities.ActivityInstance parent, ActivityInstanceMap instanceMap, LocationEnvironment parentEnvironment, long instanceId, ActivityExecutor executor, int delegateParameterCount)
        {
            this.parent = parent;
            this.instanceMap = instanceMap;
            this.id = instanceId;
            if (this.instanceMap != null)
            {
                this.instanceMap.AddEntry(this);
            }
            if (this.parent != null)
            {
                if (this.parent.PropertyManager != null)
                {
                    this.PropertyManager = this.parent.PropertyManager;
                }
                if (parentEnvironment == null)
                {
                    parentEnvironment = this.parent.Environment;
                }
            }
            int capacity = this.Activity.SymbolCount + delegateParameterCount;
            if (capacity == 0)
            {
                if (parentEnvironment == null)
                {
                    this.environment = new LocationEnvironment(executor, this.Activity);
                }
                else
                {
                    this.noSymbols = true;
                    this.environment = parentEnvironment;
                }
                return false;
            }
            this.environment = new LocationEnvironment(executor, this.Activity, parentEnvironment, capacity);
            this.substate = Substate.ResolvingArguments;
            return true;
        }

        private bool InternalTryPopulateArgumentValueOrScheduleExpression(RuntimeArgument argument, int nextArgumentIndex, ActivityExecutor executor, IDictionary<string, object> argumentValueOverrides, Location resultLocation, bool isDynamicUpdate)
        {
            object obj2 = null;
            if (argumentValueOverrides != null)
            {
                argumentValueOverrides.TryGetValue(argument.Name, out obj2);
            }
            if (argument.TryPopulateValue(this.environment, this, executor, obj2, resultLocation, isDynamicUpdate))
            {
                return true;
            }
            ResolveNextArgumentWorkItem nextArgumentWorkItem = null;
            Location specificLocation = this.environment.GetSpecificLocation(argument.Id);
            if (isDynamicUpdate)
            {
                if (specificLocation.TemporaryResolutionEnvironment != null)
                {
                    executor.ScheduleItem(new CollapseTemporaryResolutionLocationWorkItem(specificLocation, this));
                }
            }
            else
            {
                nextArgumentIndex++;
                int count = this.Activity.RuntimeArguments.Count;
                if (nextArgumentIndex < count)
                {
                    nextArgumentWorkItem = executor.ResolveNextArgumentWorkItemPool.Acquire();
                    nextArgumentWorkItem.Initialize(this, nextArgumentIndex, argumentValueOverrides, resultLocation);
                }
            }
            executor.ScheduleExpression(argument.BoundArgument.Expression, this, this.Environment, specificLocation, nextArgumentWorkItem);
            return false;
        }

        internal void MarkAsComplete(BookmarkScopeManager bookmarkScopeManager, BookmarkManager bookmarkManager)
        {
            if (this.extendedData != null)
            {
                this.extendedData.PurgeBookmarks(bookmarkScopeManager, bookmarkManager, this);
                if (this.extendedData.DataContext != null)
                {
                    this.extendedData.DataContext.Dispose();
                }
            }
            if (this.instanceMap != null)
            {
                this.instanceMap.RemoveEntry(this);
                if (this.HasActivityReferences)
                {
                    this.extendedData.PurgeActivityReferences(this.instanceMap);
                }
            }
            if (this.Parent != null)
            {
                this.Parent.RemoveChild(this);
            }
        }

        internal void MarkCanceled()
        {
            this.substate = Substate.Canceling;
        }

        private void MarkExecuted()
        {
            this.substate = Substate.Executing;
        }

        internal void RemoveAllBookmarks(BookmarkScopeManager bookmarkScopeManager, BookmarkManager bookmarkManager)
        {
            if (this.extendedData != null)
            {
                this.extendedData.PurgeBookmarks(bookmarkScopeManager, bookmarkManager, this);
            }
        }

        internal void RemoveBookmark(Bookmark bookmark, BookmarkOptions options)
        {
            bool affectsBusyCount = false;
            if (!BookmarkOptionsHelper.IsNonBlocking(options))
            {
                this.DecrementBusyCount();
                affectsBusyCount = true;
            }
            this.extendedData.RemoveBookmark(bookmark, affectsBusyCount);
        }

        internal void RemoveChild(System.Activities.ActivityInstance item)
        {
            this.childList.Remove(item, true);
            this.childCache = null;
        }

        internal bool ResolveArguments(ActivityExecutor executor, IDictionary<string, object> argumentValueOverrides, Location resultLocation, int startIndex = 0)
        {
            bool flag = true;
            if (this.Activity.IsFastPath)
            {
                RuntimeArgument resultRuntimeArgument = ((ActivityWithResult) this.Activity).ResultRuntimeArgument;
                if (!resultRuntimeArgument.TryPopulateValue(this.environment, this, executor, null, resultLocation, false))
                {
                    flag = false;
                    Location specificLocation = this.environment.GetSpecificLocation(resultRuntimeArgument.Id);
                    executor.ScheduleExpression(resultRuntimeArgument.BoundArgument.Expression, this, this.Environment, specificLocation, null);
                }
            }
            else if (!this.Activity.SkipArgumentResolution)
            {
                IList<RuntimeArgument> runtimeArguments = this.Activity.RuntimeArguments;
                int count = runtimeArguments.Count;
                if (count > 0)
                {
                    for (int i = startIndex; i < count; i++)
                    {
                        RuntimeArgument argument = runtimeArguments[i];
                        if (!this.InternalTryPopulateArgumentValueOrScheduleExpression(argument, i, executor, argumentValueOverrides, resultLocation, false))
                        {
                            flag = false;
                            break;
                        }
                    }
                }
            }
            if (flag && (startIndex == 0))
            {
                this.substate = Substate.ResolvingVariables;
            }
            return flag;
        }

        internal void ResolveNewArgumentsDuringDynamicUpdate(ActivityExecutor executor, IList<int> dynamicUpdateArgumentIndexes)
        {
            if (!this.Activity.SkipArgumentResolution)
            {
                IList<RuntimeArgument> runtimeArguments = this.Activity.RuntimeArguments;
                for (int i = 0; i < dynamicUpdateArgumentIndexes.Count; i++)
                {
                    RuntimeArgument argument = runtimeArguments[dynamicUpdateArgumentIndexes[i]];
                    this.InternalTryPopulateArgumentValueOrScheduleExpression(argument, -1, executor, null, null, true);
                }
            }
        }

        internal void ResolveNewVariableDefaultsDuringDynamicUpdate(ActivityExecutor executor, IList<int> dynamicUpdateVariableIndexes, bool forImplementation)
        {
            IList<Variable> implementationVariables;
            if (forImplementation)
            {
                implementationVariables = this.Activity.ImplementationVariables;
            }
            else
            {
                implementationVariables = this.Activity.RuntimeVariables;
            }
            for (int i = 0; i < dynamicUpdateVariableIndexes.Count; i++)
            {
                Variable variable = implementationVariables[dynamicUpdateVariableIndexes[i]];
                if (variable.Default != null)
                {
                    this.EnqueueVariableDefault(executor, variable, null);
                }
            }
        }

        private bool ResolveVariable(Variable variable, ActivityExecutor executor)
        {
            bool flag = true;
            if (variable.Default == null)
            {
                return flag;
            }
            Location specificLocation = this.Environment.GetSpecificLocation(variable.Id);
            if (variable.Default.UseOldFastPath)
            {
                variable.PopulateDefault(executor, this, specificLocation);
                return flag;
            }
            this.EnqueueVariableDefault(executor, variable, specificLocation);
            return false;
        }

        internal bool ResolveVariables(ActivityExecutor executor)
        {
            this.substate = Substate.ResolvingVariables;
            bool flag = true;
            IList<Variable> implementationVariables = this.Activity.ImplementationVariables;
            IList<Variable> runtimeVariables = this.Activity.RuntimeVariables;
            int count = implementationVariables.Count;
            int num2 = runtimeVariables.Count;
            if ((count > 0) || (num2 > 0))
            {
                for (int i = 0; i < count; i++)
                {
                    implementationVariables[i].DeclareLocation(executor, this);
                }
                for (int j = 0; j < num2; j++)
                {
                    runtimeVariables[j].DeclareLocation(executor, this);
                }
                for (int k = 0; k < count; k++)
                {
                    flag &= this.ResolveVariable(implementationVariables[k], executor);
                }
                for (int m = 0; m < num2; m++)
                {
                    flag &= this.ResolveVariable(runtimeVariables[m], executor);
                }
            }
            return flag;
        }

        private void SetCanceled()
        {
            this.TryCancelParent();
            this.state = ActivityInstanceState.Canceled;
        }

        private void SetClosed()
        {
            this.state = ActivityInstanceState.Closed;
        }

        internal void SetInitializationIncomplete()
        {
            this.initializationIncomplete = true;
        }

        internal void SetInitializedSubstate(ActivityExecutor executor)
        {
            this.substate = Substate.Initialized;
            if (executor.ShouldTrackActivityStateRecordsExecutingState && executor.ShouldTrackActivity(this.Activity.DisplayName))
            {
                executor.AddTrackingRecord(new ActivityStateRecord(executor.WorkflowInstanceId, this, this.state));
            }
            if (TD.InArgumentBoundIsEnabled())
            {
                int count = this.Activity.RuntimeArguments.Count;
                if (count > 0)
                {
                    for (int i = 0; i < count; i++)
                    {
                        RuntimeArgument argument = this.Activity.RuntimeArguments[i];
                        if (ArgumentDirectionHelper.IsIn(argument.Direction) && this.environment.TryGetLocation(argument.Id, this.Activity, out Location location))
                        {
                            string str = null;
                            if (location.Value == null)
                            {
                                str = "<Null>";
                            }
                            else
                            {
                                str = "'" + location.Value.ToString() + "'";
                            }
                            TD.InArgumentBound(argument.Name, this.Activity.GetType().ToString(), this.Activity.DisplayName, this.Id, str);
                        }
                    }
                }
            }
        }

        void ActivityInstanceMap.IActivityReference.Load(System.Activities.Activity activity, ActivityInstanceMap instanceMap)
        {
            if (activity.GetType().Name != this.OwnerName)
            {
                throw System.Activities.FxTrace.Exception.AsError(new ValidationException(System.Activities.SR.ActivityTypeMismatch(activity.DisplayName, this.OwnerName)));
            }
            if (activity.ImplementationVersion != this.ImplementationVersion)
            {
                throw System.Activities.FxTrace.Exception.AsError(new VersionMismatchException(System.Activities.SR.ImplementationVersionMismatch(this.ImplementationVersion, activity.ImplementationVersion, activity)));
            }
            this.Activity = activity;
        }

        void ActivityInstanceMap.IActivityReferenceWithEnvironment.UpdateEnvironment(EnvironmentUpdateMap map, System.Activities.Activity activity)
        {
            if (this.noSymbols)
            {
                LocationEnvironment parent = this.environment;
                this.environment = new LocationEnvironment(parent, ((map.NewArgumentCount + map.NewVariableCount) + map.NewPrivateVariableCount) + map.RuntimeDelegateArgumentCount);
                this.noSymbols = false;
                UpdateLocationEnvironmentHierarchy(parent, this.environment, this);
            }
            this.Environment.Update(map, activity);
        }

        private void TryCancelParent()
        {
            if ((this.parent != null) && this.parent.IsPerformingDefaultCancelation)
            {
                this.parent.MarkCanceled();
            }
        }

        internal bool TryFixupChildren(ActivityInstanceMap instanceMap, ActivityExecutor executor)
        {
            if (!this.HasChildren)
            {
                return false;
            }
            this.childList.FixupList(this, instanceMap, executor);
            return true;
        }

        private static void UpdateLocationEnvironmentHierarchy(LocationEnvironment oldParentEnvironment, LocationEnvironment newEnvironment, System.Activities.ActivityInstance currentInstance)
        {
            Func<System.Activities.ActivityInstance, ActivityExecutor, bool> callback = delegate (System.Activities.ActivityInstance instance, ActivityExecutor executor) {
                if (instance != currentInstance)
                {
                    if (instance.IsEnvironmentOwner)
                    {
                        if (instance.environment.Parent == oldParentEnvironment)
                        {
                            instance.environment.Parent = newEnvironment;
                        }
                        return false;
                    }
                    if (instance.environment == oldParentEnvironment)
                    {
                        instance.environment = newEnvironment;
                    }
                }
                return true;
            };
            ActivityUtilities.ProcessActivityInstanceTree(currentInstance, null, callback);
        }

        internal bool UpdateState(ActivityExecutor executor)
        {
            bool flag = false;
            if (this.HasNotExecuted)
            {
                if (this.IsCancellationRequested)
                {
                    if (this.HasChildren)
                    {
                        foreach (System.Activities.ActivityInstance instance in this.GetChildren())
                        {
                            executor.CancelActivity(instance);
                        }
                        return flag;
                    }
                    this.SetCanceled();
                    return true;
                }
                if (!this.HasPendingWork)
                {
                    bool flag2 = false;
                    if (this.substate == Substate.ResolvingArguments)
                    {
                        this.Environment.CollapseTemporaryResolutionLocations();
                        this.substate = Substate.ResolvingVariables;
                        flag2 = this.ResolveVariables(executor);
                    }
                    else if (this.substate == Substate.ResolvingVariables)
                    {
                        flag2 = true;
                    }
                    if (flag2)
                    {
                        executor.ScheduleBody(this, false, null, null);
                    }
                }
                return flag;
            }
            if (!this.HasPendingWork)
            {
                if (!executor.IsCompletingTransaction(this))
                {
                    flag = true;
                    if (this.substate == Substate.Canceling)
                    {
                        this.SetCanceled();
                        return flag;
                    }
                    this.SetClosed();
                }
                return flag;
            }
            if (this.performingDefaultCancelation && this.OnlyHasOutstandingBookmarks)
            {
                this.RemoveAllBookmarks(executor.RawBookmarkScopeManager, executor.RawBookmarkManager);
                this.MarkCanceled();
                this.SetCanceled();
                flag = true;
            }
            return flag;
        }

        public System.Activities.Activity Activity
        {
            get => 
                this.activity;
            internal set => 
                this.activity = value;
        }

        System.Activities.Activity ActivityInstanceMap.IActivityReference.Activity =>
            this.Activity;

        internal Substate SubState =>
            this.substate;

        [DataMember(EmitDefaultValue=false)]
        internal LocationEnvironment SerializedEnvironment
        {
            get
            {
                if (this.IsCompleted)
                {
                    return null;
                }
                return this.environment;
            }
            set => 
                this.environment = value;
        }

        [DataMember(EmitDefaultValue=false, Name="busyCount")]
        internal int SerializedBusyCount
        {
            get => 
                this.busyCount;
            set => 
                this.busyCount = value;
        }

        [DataMember(EmitDefaultValue=false, Name="extendedData")]
        internal ExtendedData SerializedExtendedData
        {
            get => 
                this.extendedData;
            set => 
                this.extendedData = value;
        }

        [DataMember(EmitDefaultValue=false, Name="noSymbols")]
        internal bool SerializedNoSymbols
        {
            get => 
                this.noSymbols;
            set => 
                this.noSymbols = value;
        }

        [DataMember(EmitDefaultValue=false, Name="state")]
        internal ActivityInstanceState SerializedState
        {
            get => 
                this.state;
            set => 
                this.state = value;
        }

        [DataMember(EmitDefaultValue=false, Name="isCancellationRequested")]
        internal bool SerializedIsCancellationRequested
        {
            get => 
                this.isCancellationRequested;
            set => 
                this.isCancellationRequested = value;
        }

        [DataMember(EmitDefaultValue=false, Name="performingDefaultCancelation")]
        internal bool SerializedPerformingDefaultCancelation
        {
            get => 
                this.performingDefaultCancelation;
            set => 
                this.performingDefaultCancelation = value;
        }

        [DataMember(EmitDefaultValue=false, Name="substate")]
        internal Substate SerializedSubstate
        {
            get => 
                this.substate;
            set => 
                this.substate = value;
        }

        [DataMember(EmitDefaultValue=false, Name="id")]
        internal long SerializedId
        {
            get => 
                this.id;
            set => 
                this.id = value;
        }

        [DataMember(EmitDefaultValue=false, Name="initializationIncomplete")]
        internal bool SerializedInitializationIncomplete
        {
            get => 
                this.initializationIncomplete;
            set => 
                this.initializationIncomplete = value;
        }

        internal LocationEnvironment Environment =>
            this.environment;

        internal ActivityInstanceMap InstanceMap =>
            this.instanceMap;

        public bool IsCompleted =>
            ActivityUtilities.IsCompletedState(this.State);

        public ActivityInstanceState State =>
            this.state;

        internal bool IsCancellationRequested
        {
            get => 
                this.isCancellationRequested;
            set => 
                this.isCancellationRequested = value;
        }

        internal bool IsPerformingDefaultCancelation =>
            this.performingDefaultCancelation;

        public string Id =>
            this.id.ToString(CultureInfo.InvariantCulture);

        internal long InternalId =>
            this.id;

        internal bool IsEnvironmentOwner =>
            !this.noSymbols;

        internal bool IsResolvingArguments =>
            this.substate == Substate.ResolvingArguments;

        internal bool HasNotExecuted =>
            (this.substate & Substate.PreExecuting) > Substate.Executing;

        internal bool HasPendingWork =>
            this.HasChildren || (this.busyCount > 0);

        internal bool OnlyHasOutstandingBookmarks =>
            (!this.HasChildren && (this.extendedData != null)) && (this.extendedData.BlockingBookmarkCount == this.busyCount);

        internal System.Activities.ActivityInstance Parent =>
            this.parent;

        internal bool WaitingForTransactionContext
        {
            get
            {
                if (this.extendedData == null)
                {
                    return false;
                }
                return this.extendedData.WaitingForTransactionContext;
            }
            set
            {
                this.EnsureExtendedData();
                this.extendedData.WaitingForTransactionContext = value;
            }
        }

        [DataMember(EmitDefaultValue=false)]
        internal System.Activities.Runtime.CompletionBookmark CompletionBookmark
        {
            get => 
                this.completionBookmark;
            set => 
                this.completionBookmark = value;
        }

        internal System.Activities.Runtime.FaultBookmark FaultBookmark
        {
            get => 
                this.extendedData?.FaultBookmark;
            set
            {
                if (value != null)
                {
                    this.EnsureExtendedData();
                    this.extendedData.FaultBookmark = value;
                }
            }
        }

        internal bool HasChildren =>
            (this.childList != null) && (this.childList.Count > 0);

        internal ExecutionPropertyManager PropertyManager
        {
            get => 
                this.propertyManager;
            set => 
                this.propertyManager = value;
        }

        internal WorkflowDataContext DataContext
        {
            get
            {
                if (this.extendedData != null)
                {
                    return this.extendedData.DataContext;
                }
                return null;
            }
            set
            {
                this.EnsureExtendedData();
                this.extendedData.DataContext = value;
            }
        }

        internal object CompiledDataContexts { get; set; }

        internal object CompiledDataContextsForImplementation { get; set; }

        internal bool HasActivityReferences =>
            (this.extendedData != null) && this.extendedData.HasActivityReferences;

        [DataMember(Name="propertyManager", EmitDefaultValue=false)]
        internal ExecutionPropertyManager SerializedPropertyManager
        {
            get
            {
                if ((this.propertyManager != null) && this.propertyManager.ShouldSerialize(this))
                {
                    return this.propertyManager;
                }
                return null;
            }
            set => 
                this.propertyManager = value;
        }

        [DataMember(Name="children", EmitDefaultValue=false)]
        internal ChildList SerializedChildren
        {
            get
            {
                if (this.HasChildren)
                {
                    this.childList.Compress();
                    return this.childList;
                }
                return null;
            }
            set => 
                this.childList = value;
        }

        [DataMember(Name="owner", EmitDefaultValue=false)]
        internal string OwnerName
        {
            get
            {
                if (this.ownerName == null)
                {
                    this.ownerName = this.Activity.GetType().Name;
                }
                return this.ownerName;
            }
            set => 
                this.ownerName = value;
        }

        [DataMember(EmitDefaultValue=false)]
        public Version ImplementationVersion { get; internal set; }

        private class AbortEnumerator : IEnumerator<System.Activities.ActivityInstance>, IDisposable, IEnumerator
        {
            private System.Activities.ActivityInstance root;
            private System.Activities.ActivityInstance current;
            private bool initialized;

            public AbortEnumerator(System.Activities.ActivityInstance root)
            {
                this.root = root;
            }

            public void Dispose()
            {
            }

            public bool MoveNext()
            {
                if (!this.initialized)
                {
                    this.current = this.root;
                    while (this.current.HasChildren)
                    {
                        this.current = this.current.GetChildren()[0];
                    }
                    this.initialized = true;
                    return true;
                }
                if (this.current == this.root)
                {
                    return false;
                }
                this.current = this.current.Parent;
                while (this.current.HasChildren)
                {
                    this.current = this.current.GetChildren()[0];
                }
                return true;
            }

            public void Reset()
            {
                this.current = null;
                this.initialized = false;
            }

            public System.Activities.ActivityInstance Current =>
                this.current;

            object IEnumerator.Current =>
                this.Current;
        }

        [DataContract]
        internal class ChildList : HybridCollection<System.Activities.ActivityInstance>
        {
            private static ReadOnlyCollection<System.Activities.ActivityInstance> emptyChildren;

            public void AppendChildren(ActivityUtilities.TreeProcessingList nextInstanceList, ref Queue<IList<System.Activities.ActivityInstance>> instancesRemaining)
            {
                if (base.SingleItem != null)
                {
                    nextInstanceList.Add(base.SingleItem);
                }
                else if (nextInstanceList.Count == 0)
                {
                    nextInstanceList.Set(base.MultipleItems);
                }
                else
                {
                    if (instancesRemaining == null)
                    {
                        instancesRemaining = new Queue<IList<System.Activities.ActivityInstance>>();
                    }
                    instancesRemaining.Enqueue(base.MultipleItems);
                }
            }

            public void FixupList(System.Activities.ActivityInstance parent, ActivityInstanceMap instanceMap, ActivityExecutor executor)
            {
                if (base.SingleItem != null)
                {
                    base.SingleItem.FixupInstance(parent, instanceMap, executor);
                }
                else
                {
                    for (int i = 0; i < base.MultipleItems.Count; i++)
                    {
                        base.MultipleItems[i].FixupInstance(parent, instanceMap, executor);
                    }
                }
            }

            public static ReadOnlyCollection<System.Activities.ActivityInstance> Empty
            {
                get
                {
                    if (emptyChildren == null)
                    {
                        emptyChildren = new ReadOnlyCollection<System.Activities.ActivityInstance>(new System.Activities.ActivityInstance[0]);
                    }
                    return emptyChildren;
                }
            }
        }

        [DataContract]
        internal class ExtendedData
        {
            private BookmarkList bookmarks;
            private ActivityReferenceList activityReferences;
            private int blockingBookmarkCount;

            public void AddActivityReference(ActivityInstanceReference reference)
            {
                if (this.activityReferences == null)
                {
                    this.activityReferences = new ActivityReferenceList();
                }
                this.activityReferences.Add(reference);
            }

            public void AddBookmark(Bookmark bookmark, bool affectsBusyCount)
            {
                if (this.bookmarks == null)
                {
                    this.bookmarks = new BookmarkList();
                }
                if (affectsBusyCount)
                {
                    this.BlockingBookmarkCount++;
                }
                this.bookmarks.Add(bookmark);
            }

            public void FillInstanceMap(ActivityInstanceMap instanceMap)
            {
                this.activityReferences.FillInstanceMap(instanceMap);
            }

            public void PurgeActivityReferences(ActivityInstanceMap instanceMap)
            {
                this.activityReferences.PurgeActivityReferences(instanceMap);
            }

            public void PurgeBookmarks(BookmarkScopeManager bookmarkScopeManager, BookmarkManager bookmarkManager, System.Activities.ActivityInstance owningInstance)
            {
                if ((this.bookmarks != null) && (this.bookmarks.Count > 0))
                {
                    this.bookmarks.TransferBookmarks(out Bookmark bookmark, out IList<Bookmark> list);
                    this.bookmarks = null;
                    if (bookmarkScopeManager != null)
                    {
                        bookmarkScopeManager.PurgeBookmarks(bookmarkManager, bookmark, list);
                    }
                    else
                    {
                        bookmarkManager.PurgeBookmarks(bookmark, list);
                    }
                    owningInstance.DecrementBusyCount(this.BlockingBookmarkCount);
                    this.BlockingBookmarkCount = 0;
                }
            }

            public void RemoveBookmark(Bookmark bookmark, bool affectsBusyCount)
            {
                if (affectsBusyCount)
                {
                    this.BlockingBookmarkCount--;
                }
                this.bookmarks.Remove(bookmark);
            }

            public int BlockingBookmarkCount
            {
                get => 
                    this.blockingBookmarkCount;
                private set => 
                    this.blockingBookmarkCount = value;
            }

            [DataMember(Name="waitingForTransactionContext", EmitDefaultValue=false)]
            public bool WaitingForTransactionContext { get; set; }

            [DataMember(Name="faultBookmark", EmitDefaultValue=false)]
            public System.Activities.Runtime.FaultBookmark FaultBookmark { get; set; }

            public WorkflowDataContext DataContext { get; set; }

            [DataMember(Name="blockingBookmarkCount", EmitDefaultValue=false)]
            internal int SerializedBlockingBookmarkCount
            {
                get => 
                    this.BlockingBookmarkCount;
                set => 
                    this.BlockingBookmarkCount = value;
            }

            [DataMember(Name="bookmarks", EmitDefaultValue=false)]
            internal BookmarkList Bookmarks
            {
                get
                {
                    if ((this.bookmarks != null) && (this.bookmarks.Count != 0))
                    {
                        return this.bookmarks;
                    }
                    return null;
                }
                set => 
                    this.bookmarks = value;
            }

            [DataMember(Name="activityReferences", EmitDefaultValue=false)]
            internal ActivityReferenceList ActivityReferences
            {
                get
                {
                    if ((this.activityReferences != null) && (this.activityReferences.Count != 0))
                    {
                        return this.activityReferences;
                    }
                    return null;
                }
                set => 
                    this.activityReferences = value;
            }

            public bool HasActivityReferences =>
                (this.activityReferences != null) && (this.activityReferences.Count > 0);

            [DataContract]
            internal class ActivityReferenceList : HybridCollection<ActivityInstanceReference>
            {
                public void FillInstanceMap(ActivityInstanceMap instanceMap)
                {
                    if (base.SingleItem != null)
                    {
                        instanceMap.AddEntry(base.SingleItem);
                    }
                    else
                    {
                        for (int i = 0; i < base.MultipleItems.Count; i++)
                        {
                            ActivityInstanceReference reference = base.MultipleItems[i];
                            instanceMap.AddEntry(reference);
                        }
                    }
                }

                public void PurgeActivityReferences(ActivityInstanceMap instanceMap)
                {
                    if (base.SingleItem != null)
                    {
                        instanceMap.RemoveEntry(base.SingleItem);
                    }
                    else
                    {
                        for (int i = 0; i < base.MultipleItems.Count; i++)
                        {
                            instanceMap.RemoveEntry(base.MultipleItems[i]);
                        }
                    }
                }
            }
        }

        internal enum Substate : byte
        {
            Executing = 0,
            PreExecuting = 0x80,
            Created = 0x81,
            ResolvingArguments = 130,
            ResolvingVariables = 0x83,
            Initialized = 0x84,
            Canceling = 5
        }
    }
}

