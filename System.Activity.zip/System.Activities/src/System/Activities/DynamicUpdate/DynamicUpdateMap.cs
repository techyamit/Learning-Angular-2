﻿namespace System.Activities.DynamicUpdate
{
    using System;
    using System.Activities;
    using System.Activities.XamlIntegration;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.Globalization;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Runtime.Serialization;

    [DataContract, TypeConverter(typeof(DynamicUpdateMapConverter))]
    public class DynamicUpdateMap
    {
        private static DynamicUpdateMap noChanges = new DynamicUpdateMap();
        private static DynamicUpdateMap dummyMap = new DynamicUpdateMap();
        internal EntryCollection entries;
        private IList<ArgumentInfo> newArguments;
        private IList<ArgumentInfo> oldArguments;

        internal DynamicUpdateMap()
        {
        }

        internal void AddEntry(DynamicUpdateMapEntry entry)
        {
            this.Entries.Add(entry);
        }

        internal DynamicUpdateMap AsRootMap()
        {
            if (!ActivityComparer.ListEquals(this.NewArguments, this.OldArguments))
            {
                throw System.Activities.FxTrace.Exception.AsError(new InstanceUpdateException(System.Activities.SR.InvalidImplementationAsWorkflowRootForRuntimeStateBecauseArgumentsChanged));
            }
            DynamicUpdateMap map = new DynamicUpdateMap {
                IsImplementationAsRoot = true,
                NewDefinitionMemberCount = 1
            };
            DynamicUpdateMapEntry entry = new DynamicUpdateMapEntry(1, 1) {
                ImplementationUpdateMap = this
            };
            map.AddEntry(entry);
            return map;
        }

        public static IDictionary<object, DynamicUpdateMapItem> CalculateImplementationMapItems(Activity activityDefinitionToBeUpdated) => 
            CalculateImplementationMapItems(activityDefinitionToBeUpdated, null);

        public static IDictionary<object, DynamicUpdateMapItem> CalculateImplementationMapItems(Activity activityDefinitionToBeUpdated, LocationReferenceEnvironment environment) => 
            InternalCalculateMapItems(activityDefinitionToBeUpdated, environment, true);

        public static IDictionary<object, DynamicUpdateMapItem> CalculateMapItems(Activity workflowDefinitionToBeUpdated) => 
            CalculateMapItems(workflowDefinitionToBeUpdated, null);

        public static IDictionary<object, DynamicUpdateMapItem> CalculateMapItems(Activity workflowDefinitionToBeUpdated, LocationReferenceEnvironment environment) => 
            InternalCalculateMapItems(workflowDefinitionToBeUpdated, environment, false);

        internal static bool CanUseImplementationMapAsRoot(Activity workflowDefinition) => 
            (((workflowDefinition.Children.Count == 0) && (workflowDefinition.ImportedChildren.Count == 0)) && ((workflowDefinition.Delegates.Count == 0) && (workflowDefinition.ImportedDelegates.Count == 0))) && (workflowDefinition.RuntimeVariables.Count == 0);

        internal UpdatedActivity GetUpdatedActivity(QualifiedId oldQualifiedId, IdSpace rootIdSpace)
        {
            UpdatedActivity activity = new UpdatedActivity();
            int[] sourceArray = oldQualifiedId.AsIDArray();
            int[] destinationArray = null;
            IdSpace parentOf = rootIdSpace;
            DynamicUpdateMap implementationUpdateMap = this;
            for (int i = 0; i < sourceArray.Length; i++)
            {
                if ((implementationUpdateMap == null) || (implementationUpdateMap.Entries.Count == 0))
                {
                    break;
                }
                if (!implementationUpdateMap.TryGetUpdateEntry(sourceArray[i], out DynamicUpdateMapEntry entry))
                {
                    int[] numArray3 = new int[i + 1];
                    Array.Copy(sourceArray, numArray3, numArray3.Length);
                    throw System.Activities.FxTrace.Exception.AsError(new InstanceUpdateException(System.Activities.SR.InvalidUpdateMap(System.Activities.SR.MapEntryNotFound(new QualifiedId(numArray3)))));
                }
                if (entry.IsIdChange)
                {
                    if (destinationArray == null)
                    {
                        destinationArray = new int[sourceArray.Length];
                        Array.Copy(sourceArray, destinationArray, sourceArray.Length);
                    }
                    destinationArray[i] = entry.NewActivityId;
                }
                Activity activity2 = null;
                if ((parentOf != null) && !entry.IsRemoval)
                {
                    activity2 = parentOf[entry.NewActivityId];
                    if (activity2 == null)
                    {
                        string str = parentOf.Owner.Id + "." + entry.NewActivityId.ToString(CultureInfo.InvariantCulture);
                        throw System.Activities.FxTrace.Exception.AsError(new InstanceUpdateException(System.Activities.SR.InvalidUpdateMap(System.Activities.SR.ActivityNotFound(str))));
                    }
                    parentOf = activity2.ParentOf;
                }
                if (i == (sourceArray.Length - 1))
                {
                    activity.Map = implementationUpdateMap;
                    activity.MapEntry = entry;
                    activity.NewActivity = activity2;
                }
                else if (entry.IsRuntimeUpdateBlocked || entry.IsUpdateBlockedByUpdateAuthor)
                {
                    implementationUpdateMap = null;
                }
                else
                {
                    implementationUpdateMap = entry.ImplementationUpdateMap;
                }
            }
            activity.IdChanged = destinationArray > null;
            activity.NewId = activity.IdChanged ? new QualifiedId(destinationArray) : oldQualifiedId;
            return activity;
        }

        private static IDictionary<object, DynamicUpdateMapItem> InternalCalculateMapItems(Activity workflowDefinitionToBeUpdated, LocationReferenceEnvironment environment, bool forImplementation)
        {
            if (workflowDefinitionToBeUpdated == null)
            {
                throw System.Activities.FxTrace.Exception.ArgumentNull("workflowDefinitionToBeUpdated");
            }
            DynamicUpdateMapBuilder.Preparer preparer = new DynamicUpdateMapBuilder.Preparer(workflowDefinitionToBeUpdated, environment, forImplementation);
            return preparer.Prepare();
        }

        public static DynamicUpdateMap Merge(IEnumerable<DynamicUpdateMap> maps)
        {
            if (maps == null)
            {
                throw System.Activities.FxTrace.Exception.ArgumentNull("maps");
            }
            int num = 0;
            DynamicUpdateMap first = null;
            foreach (DynamicUpdateMap map2 in maps)
            {
                MergeErrorContext errorContext = new MergeErrorContext {
                    MapIndex = num
                };
                first = Merge(first, map2, errorContext);
                num++;
            }
            return first;
        }

        public static DynamicUpdateMap Merge(params DynamicUpdateMap[] maps) => 
            Merge((IEnumerable<DynamicUpdateMap>) maps);

        internal static DynamicUpdateMap Merge(DynamicUpdateMap first, DynamicUpdateMap second, MergeErrorContext errorContext)
        {
            if ((first == null) || (second == null))
            {
                return (first ?? second);
            }
            if (first.IsNoChanges || second.IsNoChanges)
            {
                if (!first.IsNoChanges)
                {
                    return first;
                }
                return second;
            }
            ThrowIfMapsIncompatible(first, second, errorContext);
            DynamicUpdateMap map = new DynamicUpdateMap {
                IsForImplementation = first.IsForImplementation,
                NewDefinitionMemberCount = second.NewDefinitionMemberCount,
                ArgumentsAreUnknown = first.ArgumentsAreUnknown && second.ArgumentsAreUnknown,
                oldArguments = first.ArgumentsAreUnknown ? second.oldArguments : first.oldArguments,
                newArguments = second.ArgumentsAreUnknown ? first.newArguments : second.newArguments
            };
            foreach (DynamicUpdateMapEntry entry in first.Entries)
            {
                DynamicUpdateMapEntry entry2 = null;
                if (entry.Parent != null)
                {
                    map.TryGetUpdateEntry(entry.Parent.OldActivityId, out entry2);
                }
                if (entry.IsRemoval)
                {
                    map.AddEntry(entry.Clone(entry2));
                }
                else
                {
                    DynamicUpdateMapEntry entry3 = second.entries[entry.NewActivityId];
                    map.AddEntry(DynamicUpdateMapEntry.Merge(entry, entry3, entry2, errorContext));
                }
            }
            return map;
        }

        public DynamicUpdateMapQuery Query(Activity updatedWorkflowDefinition, Activity originalWorkflowDefinition)
        {
            if (this.IsNoChanges)
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.NoChangesMapQueryNotSupported));
            }
            if (this.IsForImplementation)
            {
                ValidateDefinitionMatchesImplementationMap(updatedWorkflowDefinition, this.NewDefinitionMemberCount, "updatedWorkflowDefinition");
                ValidateDefinitionMatchesImplementationMap(originalWorkflowDefinition, this.OldDefinitionMemberCount, "originalWorkflowDefinition");
            }
            else
            {
                ValidateDefinitionMatchesMap(updatedWorkflowDefinition, this.NewDefinitionMemberCount, "updatedWorkflowDefinition");
                ValidateDefinitionMatchesMap(originalWorkflowDefinition, this.OldDefinitionMemberCount, "originalWorkflowDefinition");
            }
            return new DynamicUpdateMapQuery(this, updatedWorkflowDefinition, originalWorkflowDefinition);
        }

        internal void ThrowIfInvalid(Activity updatedDefinition)
        {
            this.ThrowIfInvalid(updatedDefinition.MemberOf);
        }

        private void ThrowIfInvalid(IdSpace updatedIdSpace)
        {
            if (!this.IsNoChanges)
            {
                if (this.NewDefinitionMemberCount != updatedIdSpace.MemberCount)
                {
                    throw System.Activities.FxTrace.Exception.AsError(new InstanceUpdateException(System.Activities.SR.InvalidUpdateMap(System.Activities.SR.WrongMemberCount(updatedIdSpace.Owner, updatedIdSpace.MemberCount, this.NewDefinitionMemberCount))));
                }
                foreach (DynamicUpdateMapEntry entry in this.Entries)
                {
                    if (entry.ImplementationUpdateMap != null)
                    {
                        Activity activity = updatedIdSpace[entry.NewActivityId];
                        if (activity == null)
                        {
                            string str = entry.NewActivityId.ToString(CultureInfo.InvariantCulture);
                            if (updatedIdSpace.Owner != null)
                            {
                                str = updatedIdSpace.Owner.Id + "." + str;
                            }
                            throw System.Activities.FxTrace.Exception.AsError(new InstanceUpdateException(System.Activities.SR.InvalidUpdateMap(System.Activities.SR.ActivityNotFound(str))));
                        }
                        if (activity.ParentOf == null)
                        {
                            throw System.Activities.FxTrace.Exception.AsError(new InstanceUpdateException(System.Activities.SR.InvalidUpdateMap(System.Activities.SR.ActivityHasNoImplementation(activity))));
                        }
                        entry.ImplementationUpdateMap.ThrowIfInvalid(activity.ParentOf);
                    }
                }
            }
        }

        private static void ThrowIfMapsIncompatible(DynamicUpdateMap first, DynamicUpdateMap second, MergeErrorContext errorContext)
        {
            if (first.IsForImplementation != second.IsForImplementation)
            {
                errorContext.Throw(System.Activities.SR.InvalidMergeMapForImplementation(first.IsForImplementation, second.IsForImplementation));
            }
            if (first.NewDefinitionMemberCount != second.OldDefinitionMemberCount)
            {
                errorContext.Throw(System.Activities.SR.InvalidMergeMapMemberCount(first.NewDefinitionMemberCount, second.OldDefinitionMemberCount));
            }
            if ((!first.ArgumentsAreUnknown && !second.ArgumentsAreUnknown) && (first.IsForImplementation && !ActivityComparer.ListEquals(first.newArguments, second.oldArguments)))
            {
                if (first.NewArguments.Count != second.OldArguments.Count)
                {
                    errorContext.Throw(System.Activities.SR.InvalidMergeMapArgumentCount(first.NewArguments.Count, second.OldArguments.Count));
                }
                else
                {
                    errorContext.Throw(System.Activities.SR.InvalidMergeMapArgumentsChanged);
                }
            }
        }

        internal bool TryGetUpdateEntry(int oldId, out DynamicUpdateMapEntry entry)
        {
            if (((this.entries != null) && (this.entries.Count > 0)) && this.entries.Contains(oldId))
            {
                entry = this.entries[oldId];
                return true;
            }
            entry = null;
            return false;
        }

        internal bool TryGetUpdateEntryByNewId(int newId, out DynamicUpdateMapEntry entry)
        {
            entry = null;
            for (int i = 0; i < this.Entries.Count; i++)
            {
                DynamicUpdateMapEntry entry2 = this.Entries[i];
                if (entry2.NewActivityId == newId)
                {
                    entry = entry2;
                    return true;
                }
            }
            return false;
        }

        private static void ValidateDefinitionMatchesImplementationMap(Activity activity, int memberCount, string parameterName)
        {
            if (activity == null)
            {
                throw System.Activities.FxTrace.Exception.ArgumentNull(parameterName);
            }
            if (activity.MemberOf == null)
            {
                throw System.Activities.FxTrace.Exception.Argument(parameterName, System.Activities.SR.ActivityIsUncached);
            }
            if (activity.Parent != null)
            {
                throw System.Activities.FxTrace.Exception.Argument(parameterName, System.Activities.SR.ActivityIsNotRoot);
            }
            if (activity.ParentOf == null)
            {
                throw System.Activities.FxTrace.Exception.Argument(parameterName, System.Activities.SR.InvalidUpdateMap(System.Activities.SR.ActivityHasNoImplementation(activity)));
            }
            if (activity.ParentOf.MemberCount != memberCount)
            {
                throw System.Activities.FxTrace.Exception.Argument(parameterName, System.Activities.SR.InvalidUpdateMap(System.Activities.SR.WrongMemberCount(activity.ParentOf.Owner, activity.ParentOf.MemberCount, memberCount)));
            }
            if (!CanUseImplementationMapAsRoot(activity))
            {
                throw System.Activities.FxTrace.Exception.Argument(parameterName, System.Activities.SR.InvalidImplementationAsWorkflowRoot);
            }
        }

        private static void ValidateDefinitionMatchesMap(Activity activity, int memberCount, string parameterName)
        {
            if (activity == null)
            {
                throw System.Activities.FxTrace.Exception.ArgumentNull(parameterName);
            }
            if (activity.MemberOf == null)
            {
                throw System.Activities.FxTrace.Exception.Argument(parameterName, System.Activities.SR.ActivityIsUncached);
            }
            if (activity.Parent != null)
            {
                throw System.Activities.FxTrace.Exception.Argument(parameterName, System.Activities.SR.ActivityIsNotRoot);
            }
            if (activity.MemberOf.MemberCount != memberCount)
            {
                throw System.Activities.FxTrace.Exception.Argument(parameterName, System.Activities.SR.InvalidUpdateMap(System.Activities.SR.WrongMemberCount(activity.MemberOf.Owner, activity.MemberOf.MemberCount, memberCount)));
            }
        }

        public static DynamicUpdateMap NoChanges =>
            noChanges;

        [DataMember(EmitDefaultValue=false, Name="entries")]
        internal EntryCollection SerializedEntries
        {
            get => 
                this.entries;
            set => 
                this.entries = value;
        }

        [DataMember(EmitDefaultValue=false, Name="newArguments")]
        internal IList<ArgumentInfo> SerializedNewArguments
        {
            get => 
                this.newArguments;
            set => 
                this.newArguments = value;
        }

        [DataMember(EmitDefaultValue=false, Name="oldArguments")]
        internal IList<ArgumentInfo> SerializedOldArguments
        {
            get => 
                this.oldArguments;
            set => 
                this.oldArguments = value;
        }

        internal static DynamicUpdateMap DummyMap =>
            dummyMap;

        internal IList<ArgumentInfo> NewArguments
        {
            get
            {
                if (this.newArguments == null)
                {
                    this.newArguments = new List<ArgumentInfo>();
                }
                return this.newArguments;
            }
            set => 
                this.newArguments = value;
        }

        internal IList<ArgumentInfo> OldArguments
        {
            get
            {
                if (this.oldArguments == null)
                {
                    this.oldArguments = new List<ArgumentInfo>();
                }
                return this.oldArguments;
            }
            set => 
                this.oldArguments = value;
        }

        [DataMember(EmitDefaultValue=false)]
        internal bool ArgumentsAreUnknown { get; set; }

        [DataMember(EmitDefaultValue=false)]
        internal bool IsImplementationAsRoot { get; set; }

        [DataMember(EmitDefaultValue=false)]
        internal int NewDefinitionMemberCount { get; set; }

        internal int OldDefinitionMemberCount =>
            this.Entries.Count;

        [DataMember(EmitDefaultValue=false)]
        internal bool IsForImplementation { get; set; }

        internal bool IsNoChanges =>
            this.NewDefinitionMemberCount == 0;

        private IList<DynamicUpdateMapEntry> Entries
        {
            get
            {
                if (this.entries == null)
                {
                    this.entries = new EntryCollection();
                }
                return this.entries;
            }
        }

        [CollectionDataContract]
        internal class EntryCollection : KeyedCollection<int, DynamicUpdateMapEntry>
        {
            protected override int GetKeyForItem(DynamicUpdateMapEntry item) => 
                item.OldActivityId;
        }

        internal class MergeErrorContext
        {
            private Stack<int> currentIdSpace;

            public void PopIdSpace()
            {
                this.currentIdSpace.Pop();
            }

            public void PushIdSpace(int id)
            {
                if (this.currentIdSpace == null)
                {
                    this.currentIdSpace = new Stack<int>();
                }
                this.currentIdSpace.Push(id);
            }

            public void Throw(string detail)
            {
                QualifiedId id = null;
                string str;
                if ((this.currentIdSpace != null) && (this.currentIdSpace.Count > 0))
                {
                    int[] idArray = new int[this.currentIdSpace.Count];
                    for (int i = idArray.Length - 1; i >= 0; i--)
                    {
                        idArray[i] = this.currentIdSpace.Pop();
                    }
                    id = new QualifiedId(idArray);
                }
                if (id == null)
                {
                    str = System.Activities.SR.InvalidRootMergeMap(this.MapIndex, detail);
                }
                else
                {
                    str = System.Activities.SR.InvalidMergeMap(this.MapIndex, id, detail);
                }
                throw System.Activities.FxTrace.Exception.Argument("maps", str);
            }

            public int MapIndex { get; set; }
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct UpdatedActivity
        {
            public bool IdChanged;
            public QualifiedId NewId;
            public DynamicUpdateMap Map;
            public DynamicUpdateMapEntry MapEntry;
            public Activity NewActivity;
        }
    }
}

