﻿namespace System.Activities.DynamicUpdate
{
    using System;
    using System.Activities;
    using System.Xaml;

    public static class DynamicUpdateInfo
    {
        private static AttachableMemberIdentifier mapItemProperty = new AttachableMemberIdentifier(typeof(DynamicUpdateInfo), "MapItem");
        private static AttachableMemberIdentifier originalDefinitionProperty = new AttachableMemberIdentifier(typeof(DynamicUpdateInfo), "OriginalDefinition");
        private static AttachableMemberIdentifier originalActivityBuilderProperty = new AttachableMemberIdentifier(typeof(DynamicUpdateInfo), "OriginalActivityBuilder");

        public static DynamicUpdateMapItem GetMapItem(object instance)
        {
            if (AttachablePropertyServices.TryGetProperty<DynamicUpdateMapItem>(instance, mapItemProperty, out DynamicUpdateMapItem item))
            {
                return item;
            }
            return null;
        }

        public static ActivityBuilder GetOriginalActivityBuilder(object instance)
        {
            if (AttachablePropertyServices.TryGetProperty<ActivityBuilder>(instance, originalActivityBuilderProperty, out ActivityBuilder builder))
            {
                return builder;
            }
            return null;
        }

        public static Activity GetOriginalDefinition(object instance)
        {
            if (AttachablePropertyServices.TryGetProperty<Activity>(instance, originalDefinitionProperty, out Activity activity))
            {
                return activity;
            }
            return null;
        }

        public static void SetMapItem(object instance, DynamicUpdateMapItem mapItem)
        {
            if (mapItem != null)
            {
                AttachablePropertyServices.SetProperty(instance, mapItemProperty, mapItem);
            }
            else
            {
                AttachablePropertyServices.RemoveProperty(instance, mapItemProperty);
            }
        }

        public static void SetOriginalActivityBuilder(object instance, ActivityBuilder originalActivityBuilder)
        {
            if (originalActivityBuilder != null)
            {
                AttachablePropertyServices.SetProperty(instance, originalActivityBuilderProperty, originalActivityBuilder);
            }
            else
            {
                AttachablePropertyServices.RemoveProperty(instance, originalActivityBuilderProperty);
            }
        }

        public static void SetOriginalDefinition(object instance, Activity originalDefinition)
        {
            if (originalDefinition != null)
            {
                AttachablePropertyServices.SetProperty(instance, originalDefinitionProperty, originalDefinition);
            }
            else
            {
                AttachablePropertyServices.RemoveProperty(instance, originalDefinitionProperty);
            }
        }
    }
}

