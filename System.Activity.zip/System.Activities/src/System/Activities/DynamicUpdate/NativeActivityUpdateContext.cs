﻿namespace System.Activities.DynamicUpdate
{
    using System;
    using System.Activities;
    using System.Activities.Runtime;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;

    public class NativeActivityUpdateContext
    {
        private bool isDisposed = false;
        private ActivityInstanceMap instanceMap;
        private ActivityExecutor activityExecutor;
        private System.Activities.ActivityInstance currentInstance;
        private NativeActivityContext innerContext;
        private DynamicUpdateMap updateMap;
        private DynamicUpdateMapEntry mapEntry;
        private DynamicUpdateMap rootMap;

        internal NativeActivityUpdateContext(ActivityInstanceMap instanceMap, ActivityExecutor activityExecutor, System.Activities.ActivityInstance currentInstance, DynamicUpdateMap updateMap, DynamicUpdateMapEntry mapEntry, DynamicUpdateMap rootMap)
        {
            this.instanceMap = instanceMap;
            this.activityExecutor = activityExecutor;
            this.currentInstance = currentInstance;
            this.updateMap = updateMap;
            this.mapEntry = mapEntry;
            this.rootMap = rootMap;
            this.innerContext = new NativeActivityContext(this.currentInstance, this.activityExecutor, this.activityExecutor.RawBookmarkManager);
        }

        public Bookmark CreateBookmark() => 
            this.CreateBookmark((BookmarkCallback) null);

        public Bookmark CreateBookmark(BookmarkCallback callback) => 
            this.CreateBookmark(callback, BookmarkOptions.None);

        public Bookmark CreateBookmark(string name)
        {
            this.ThrowIfDisposed();
            return this.innerContext.CreateBookmark(name);
        }

        public Bookmark CreateBookmark(BookmarkCallback callback, BookmarkOptions options)
        {
            this.ThrowIfDisposed();
            return this.innerContext.CreateBookmark(callback, options);
        }

        public Bookmark CreateBookmark(string name, BookmarkCallback callback) => 
            this.CreateBookmark(name, callback, BookmarkOptions.None);

        public Bookmark CreateBookmark(string name, BookmarkCallback callback, BookmarkOptions options)
        {
            this.ThrowIfDisposed();
            return this.innerContext.CreateBookmark(name, callback, options);
        }

        public Bookmark CreateBookmark(string name, BookmarkCallback callback, BookmarkScope scope) => 
            this.CreateBookmark(name, callback, scope, BookmarkOptions.None);

        public Bookmark CreateBookmark(string name, BookmarkCallback callback, BookmarkScope scope, BookmarkOptions options)
        {
            this.ThrowIfDisposed();
            return this.innerContext.CreateBookmark(name, callback, scope, options);
        }

        public void DisallowUpdate(string reason)
        {
            this.ThrowIfDisposed();
            this.DisallowedReason = reason;
            this.IsUpdateDisallowed = true;
        }

        internal void Dispose()
        {
            this.isDisposed = true;
            this.instanceMap = null;
            this.activityExecutor = null;
            this.currentInstance = null;
            if (this.innerContext != null)
            {
                this.innerContext.Dispose();
                this.innerContext = null;
            }
        }

        public object FindExecutionProperty(string name)
        {
            this.ThrowIfDisposed();
            ExecutionProperties properties = new ExecutionProperties(this.innerContext, this.currentInstance, this.currentInstance.PropertyManager);
            return properties.Find(name);
        }

        public Location<T> GetLocation<T>(Variable variable)
        {
            this.ThrowIfDisposed();
            return this.innerContext.GetLocation<T>(variable);
        }

        public object GetSavedOriginalValue(Activity childActivity)
        {
            this.ThrowIfDisposed();
            NativeActivityUpdateMapMetadata.ValidateOriginalValueAccess(this.CurrentActivity, childActivity, "childActivity", out bool flag);
            if ((!flag && !this.updateMap.IsNoChanges) && this.updateMap.TryGetUpdateEntryByNewId(childActivity.InternalId, out DynamicUpdateMapEntry entry))
            {
                return entry.SavedOriginalValueFromParent;
            }
            return null;
        }

        public object GetSavedOriginalValue(string propertyName)
        {
            this.ThrowIfDisposed();
            if (propertyName == null)
            {
                throw FxTrace.Exception.ArgumentNull("propertyName");
            }
            object obj2 = null;
            if (this.mapEntry.SavedOriginalValues != null)
            {
                this.mapEntry.SavedOriginalValues.TryGetValue(propertyName, out obj2);
            }
            return obj2;
        }

        public object GetValue(Argument argument)
        {
            this.ThrowIfDisposed();
            return this.innerContext.GetValue(argument);
        }

        public object GetValue(RuntimeArgument runtimeArgument)
        {
            this.ThrowIfDisposed();
            return this.innerContext.GetValue(runtimeArgument);
        }

        public object GetValue(Variable variable)
        {
            this.ThrowIfDisposed();
            return this.innerContext.GetValue(variable);
        }

        public T GetValue<T>(Variable<T> variable)
        {
            this.ThrowIfDisposed();
            return this.innerContext.GetValue<T>(variable);
        }

        public bool IsNewlyAdded(Activity childActivity)
        {
            DynamicUpdateMap rootMap;
            this.ThrowIfDisposed();
            NativeActivityUpdateMapMetadata.ValidateOriginalValueAccess(this.CurrentActivity, childActivity, "childActivity", out bool flag);
            if (flag)
            {
                rootMap = this.rootMap;
                int[] numArray = childActivity.QualifiedId.AsIDArray();
                for (int i = 0; i < (numArray.Length - 1); i++)
                {
                    rootMap.TryGetUpdateEntryByNewId(numArray[i], out DynamicUpdateMapEntry entry);
                    if (entry.ImplementationUpdateMap == null)
                    {
                        return false;
                    }
                    rootMap = entry.ImplementationUpdateMap;
                }
            }
            else
            {
                if (this.updateMap == DynamicUpdateMap.DummyMap)
                {
                    return false;
                }
                rootMap = this.updateMap;
            }
            return !rootMap.TryGetUpdateEntryByNewId(childActivity.InternalId, out entry);
        }

        public void RemoveAllBookmarks()
        {
            this.ThrowIfDisposed();
            this.innerContext.RemoveAllBookmarks();
        }

        public bool RemoveBookmark(Bookmark bookmark)
        {
            this.ThrowIfDisposed();
            return this.innerContext.RemoveBookmark(bookmark);
        }

        public bool RemoveBookmark(string name)
        {
            this.ThrowIfDisposed();
            return this.innerContext.RemoveBookmark(name);
        }

        public bool RemoveBookmark(string name, BookmarkScope scope)
        {
            this.ThrowIfDisposed();
            return this.innerContext.RemoveBookmark(name, scope);
        }

        public void ScheduleAction(ActivityAction activityAction, CompletionCallback onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleAction(activityAction, onCompleted, onFaulted);
        }

        public void ScheduleAction<T>(ActivityAction<T> activityAction, T argument, CompletionCallback onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleAction<T>(activityAction, argument, onCompleted, onFaulted);
        }

        public void ScheduleAction<T1, T2>(ActivityAction<T1, T2> activityAction, T1 argument1, T2 argument2, CompletionCallback onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleAction<T1, T2>(activityAction, argument1, argument2, onCompleted, onFaulted);
        }

        public void ScheduleAction<T1, T2, T3>(ActivityAction<T1, T2, T3> activityAction, T1 argument1, T2 argument2, T3 argument3, CompletionCallback onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleAction<T1, T2, T3>(activityAction, argument1, argument2, argument3, onCompleted, onFaulted);
        }

        public void ScheduleAction<T1, T2, T3, T4>(ActivityAction<T1, T2, T3, T4> activityAction, T1 argument1, T2 argument2, T3 argument3, T4 argument4, CompletionCallback onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleAction<T1, T2, T3, T4>(activityAction, argument1, argument2, argument3, argument4, onCompleted, onFaulted);
        }

        public void ScheduleAction<T1, T2, T3, T4, T5>(ActivityAction<T1, T2, T3, T4, T5> activityAction, T1 argument1, T2 argument2, T3 argument3, T4 argument4, T5 argument5, CompletionCallback onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleAction<T1, T2, T3, T4, T5>(activityAction, argument1, argument2, argument3, argument4, argument5, onCompleted, onFaulted);
        }

        public void ScheduleAction<T1, T2, T3, T4, T5, T6>(ActivityAction<T1, T2, T3, T4, T5, T6> activityAction, T1 argument1, T2 argument2, T3 argument3, T4 argument4, T5 argument5, T6 argument6, CompletionCallback onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleAction<T1, T2, T3, T4, T5, T6>(activityAction, argument1, argument2, argument3, argument4, argument5, argument6, onCompleted, onFaulted);
        }

        public void ScheduleAction<T1, T2, T3, T4, T5, T6, T7>(ActivityAction<T1, T2, T3, T4, T5, T6, T7> activityAction, T1 argument1, T2 argument2, T3 argument3, T4 argument4, T5 argument5, T6 argument6, T7 argument7, CompletionCallback onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleAction<T1, T2, T3, T4, T5, T6, T7>(activityAction, argument1, argument2, argument3, argument4, argument5, argument6, argument7, onCompleted, onFaulted);
        }

        public void ScheduleAction<T1, T2, T3, T4, T5, T6, T7, T8>(ActivityAction<T1, T2, T3, T4, T5, T6, T7, T8> activityAction, T1 argument1, T2 argument2, T3 argument3, T4 argument4, T5 argument5, T6 argument6, T7 argument7, T8 argument8, CompletionCallback onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleAction<T1, T2, T3, T4, T5, T6, T7, T8>(activityAction, argument1, argument2, argument3, argument4, argument5, argument6, argument7, argument8, onCompleted, onFaulted);
        }

        public void ScheduleAction<T1, T2, T3, T4, T5, T6, T7, T8, T9>(ActivityAction<T1, T2, T3, T4, T5, T6, T7, T8, T9> activityAction, T1 argument1, T2 argument2, T3 argument3, T4 argument4, T5 argument5, T6 argument6, T7 argument7, T8 argument8, T9 argument9, CompletionCallback onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleAction<T1, T2, T3, T4, T5, T6, T7, T8, T9>(activityAction, argument1, argument2, argument3, argument4, argument5, argument6, argument7, argument8, argument9, onCompleted, onFaulted);
        }

        public void ScheduleAction<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>(ActivityAction<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> activityAction, T1 argument1, T2 argument2, T3 argument3, T4 argument4, T5 argument5, T6 argument6, T7 argument7, T8 argument8, T9 argument9, T10 argument10, CompletionCallback onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleAction<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>(activityAction, argument1, argument2, argument3, argument4, argument5, argument6, argument7, argument8, argument9, argument10, onCompleted, onFaulted);
        }

        public void ScheduleAction<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11>(ActivityAction<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> activityAction, T1 argument1, T2 argument2, T3 argument3, T4 argument4, T5 argument5, T6 argument6, T7 argument7, T8 argument8, T9 argument9, T10 argument10, T11 argument11, CompletionCallback onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleAction<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11>(activityAction, argument1, argument2, argument3, argument4, argument5, argument6, argument7, argument8, argument9, argument10, argument11, onCompleted, onFaulted);
        }

        public void ScheduleAction<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>(ActivityAction<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> activityAction, T1 argument1, T2 argument2, T3 argument3, T4 argument4, T5 argument5, T6 argument6, T7 argument7, T8 argument8, T9 argument9, T10 argument10, T11 argument11, T12 argument12, CompletionCallback onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleAction<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>(activityAction, argument1, argument2, argument3, argument4, argument5, argument6, argument7, argument8, argument9, argument10, argument11, argument12, onCompleted, onFaulted);
        }

        public void ScheduleAction<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>(ActivityAction<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> activityAction, T1 argument1, T2 argument2, T3 argument3, T4 argument4, T5 argument5, T6 argument6, T7 argument7, T8 argument8, T9 argument9, T10 argument10, T11 argument11, T12 argument12, T13 argument13, CompletionCallback onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleAction<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>(activityAction, argument1, argument2, argument3, argument4, argument5, argument6, argument7, argument8, argument9, argument10, argument11, argument12, argument13, onCompleted, onFaulted);
        }

        public void ScheduleAction<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>(ActivityAction<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> activityAction, T1 argument1, T2 argument2, T3 argument3, T4 argument4, T5 argument5, T6 argument6, T7 argument7, T8 argument8, T9 argument9, T10 argument10, T11 argument11, T12 argument12, T13 argument13, T14 argument14, CompletionCallback onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleAction<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>(activityAction, argument1, argument2, argument3, argument4, argument5, argument6, argument7, argument8, argument9, argument10, argument11, argument12, argument13, argument14, onCompleted, onFaulted);
        }

        public void ScheduleAction<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>(ActivityAction<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> activityAction, T1 argument1, T2 argument2, T3 argument3, T4 argument4, T5 argument5, T6 argument6, T7 argument7, T8 argument8, T9 argument9, T10 argument10, T11 argument11, T12 argument12, T13 argument13, T14 argument14, T15 argument15, CompletionCallback onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleAction<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>(activityAction, argument1, argument2, argument3, argument4, argument5, argument6, argument7, argument8, argument9, argument10, argument11, argument12, argument13, argument14, argument15, onCompleted, onFaulted);
        }

        public void ScheduleAction<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>(ActivityAction<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> activityAction, T1 argument1, T2 argument2, T3 argument3, T4 argument4, T5 argument5, T6 argument6, T7 argument7, T8 argument8, T9 argument9, T10 argument10, T11 argument11, T12 argument12, T13 argument13, T14 argument14, T15 argument15, T16 argument16, CompletionCallback onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleAction<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>(activityAction, argument1, argument2, argument3, argument4, argument5, argument6, argument7, argument8, argument9, argument10, argument11, argument12, argument13, argument14, argument15, argument16, onCompleted, onFaulted);
        }

        public void ScheduleActivity(Activity activity)
        {
            this.ScheduleActivity(activity, null, null);
        }

        public void ScheduleActivity(Activity activity, CompletionCallback onCompleted)
        {
            this.ScheduleActivity(activity, onCompleted, null);
        }

        public void ScheduleActivity(Activity activity, FaultCallback onFaulted)
        {
            this.ScheduleActivity(activity, null, onFaulted);
        }

        public void ScheduleActivity(Activity activity, CompletionCallback onCompleted, FaultCallback onFaulted)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleActivity(activity, onCompleted, onFaulted);
        }

        public void ScheduleActivity<TResult>(Activity<TResult> activity, CompletionCallback<TResult> onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleActivity<TResult>(activity, onCompleted, onFaulted);
        }

        public void ScheduleDelegate(ActivityDelegate activityDelegate, IDictionary<string, object> inputParameters, DelegateCompletionCallback onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleDelegate(activityDelegate, inputParameters, onCompleted, onFaulted);
        }

        public void ScheduleFunc<TResult>(ActivityFunc<TResult> activityFunc, CompletionCallback<TResult> onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleFunc<TResult>(activityFunc, onCompleted, onFaulted);
        }

        public void ScheduleFunc<T, TResult>(ActivityFunc<T, TResult> activityFunc, T argument, CompletionCallback<TResult> onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleFunc<T, TResult>(activityFunc, argument, onCompleted, onFaulted);
        }

        public void ScheduleFunc<T1, T2, TResult>(ActivityFunc<T1, T2, TResult> activityFunc, T1 argument1, T2 argument2, CompletionCallback<TResult> onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleFunc<T1, T2, TResult>(activityFunc, argument1, argument2, onCompleted, onFaulted);
        }

        public void ScheduleFunc<T1, T2, T3, TResult>(ActivityFunc<T1, T2, T3, TResult> activityFunc, T1 argument1, T2 argument2, T3 argument3, CompletionCallback<TResult> onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleFunc<T1, T2, T3, TResult>(activityFunc, argument1, argument2, argument3, onCompleted, onFaulted);
        }

        public void ScheduleFunc<T1, T2, T3, T4, TResult>(ActivityFunc<T1, T2, T3, T4, TResult> activityFunc, T1 argument1, T2 argument2, T3 argument3, T4 argument4, CompletionCallback<TResult> onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleFunc<T1, T2, T3, T4, TResult>(activityFunc, argument1, argument2, argument3, argument4, onCompleted, onFaulted);
        }

        public void ScheduleFunc<T1, T2, T3, T4, T5, TResult>(ActivityFunc<T1, T2, T3, T4, T5, TResult> activityFunc, T1 argument1, T2 argument2, T3 argument3, T4 argument4, T5 argument5, CompletionCallback<TResult> onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleFunc<T1, T2, T3, T4, T5, TResult>(activityFunc, argument1, argument2, argument3, argument4, argument5, onCompleted, onFaulted);
        }

        public void ScheduleFunc<T1, T2, T3, T4, T5, T6, TResult>(ActivityFunc<T1, T2, T3, T4, T5, T6, TResult> activityFunc, T1 argument1, T2 argument2, T3 argument3, T4 argument4, T5 argument5, T6 argument6, CompletionCallback<TResult> onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleFunc<T1, T2, T3, T4, T5, T6, TResult>(activityFunc, argument1, argument2, argument3, argument4, argument5, argument6, onCompleted, onFaulted);
        }

        public void ScheduleFunc<T1, T2, T3, T4, T5, T6, T7, TResult>(ActivityFunc<T1, T2, T3, T4, T5, T6, T7, TResult> activityFunc, T1 argument1, T2 argument2, T3 argument3, T4 argument4, T5 argument5, T6 argument6, T7 argument7, CompletionCallback<TResult> onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleFunc<T1, T2, T3, T4, T5, T6, T7, TResult>(activityFunc, argument1, argument2, argument3, argument4, argument5, argument6, argument7, onCompleted, onFaulted);
        }

        public void ScheduleFunc<T1, T2, T3, T4, T5, T6, T7, T8, TResult>(ActivityFunc<T1, T2, T3, T4, T5, T6, T7, T8, TResult> activityFunc, T1 argument1, T2 argument2, T3 argument3, T4 argument4, T5 argument5, T6 argument6, T7 argument7, T8 argument8, CompletionCallback<TResult> onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleFunc<T1, T2, T3, T4, T5, T6, T7, T8, TResult>(activityFunc, argument1, argument2, argument3, argument4, argument5, argument6, argument7, argument8, onCompleted, onFaulted);
        }

        public void ScheduleFunc<T1, T2, T3, T4, T5, T6, T7, T8, T9, TResult>(ActivityFunc<T1, T2, T3, T4, T5, T6, T7, T8, T9, TResult> activityFunc, T1 argument1, T2 argument2, T3 argument3, T4 argument4, T5 argument5, T6 argument6, T7 argument7, T8 argument8, T9 argument9, CompletionCallback<TResult> onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleFunc<T1, T2, T3, T4, T5, T6, T7, T8, T9, TResult>(activityFunc, argument1, argument2, argument3, argument4, argument5, argument6, argument7, argument8, argument9, onCompleted, onFaulted);
        }

        public void ScheduleFunc<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, TResult>(ActivityFunc<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, TResult> activityFunc, T1 argument1, T2 argument2, T3 argument3, T4 argument4, T5 argument5, T6 argument6, T7 argument7, T8 argument8, T9 argument9, T10 argument10, CompletionCallback<TResult> onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleFunc<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, TResult>(activityFunc, argument1, argument2, argument3, argument4, argument5, argument6, argument7, argument8, argument9, argument10, onCompleted, onFaulted);
        }

        public void ScheduleFunc<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, TResult>(ActivityFunc<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, TResult> activityFunc, T1 argument1, T2 argument2, T3 argument3, T4 argument4, T5 argument5, T6 argument6, T7 argument7, T8 argument8, T9 argument9, T10 argument10, T11 argument11, CompletionCallback<TResult> onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleFunc<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, TResult>(activityFunc, argument1, argument2, argument3, argument4, argument5, argument6, argument7, argument8, argument9, argument10, argument11, onCompleted, onFaulted);
        }

        public void ScheduleFunc<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, TResult>(ActivityFunc<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, TResult> activityFunc, T1 argument1, T2 argument2, T3 argument3, T4 argument4, T5 argument5, T6 argument6, T7 argument7, T8 argument8, T9 argument9, T10 argument10, T11 argument11, T12 argument12, CompletionCallback<TResult> onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleFunc<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, TResult>(activityFunc, argument1, argument2, argument3, argument4, argument5, argument6, argument7, argument8, argument9, argument10, argument11, argument12, onCompleted, onFaulted);
        }

        public void ScheduleFunc<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, TResult>(ActivityFunc<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, TResult> activityFunc, T1 argument1, T2 argument2, T3 argument3, T4 argument4, T5 argument5, T6 argument6, T7 argument7, T8 argument8, T9 argument9, T10 argument10, T11 argument11, T12 argument12, T13 argument13, CompletionCallback<TResult> onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleFunc<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, TResult>(activityFunc, argument1, argument2, argument3, argument4, argument5, argument6, argument7, argument8, argument9, argument10, argument11, argument12, argument13, onCompleted, onFaulted);
        }

        public void ScheduleFunc<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, TResult>(ActivityFunc<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, TResult> activityFunc, T1 argument1, T2 argument2, T3 argument3, T4 argument4, T5 argument5, T6 argument6, T7 argument7, T8 argument8, T9 argument9, T10 argument10, T11 argument11, T12 argument12, T13 argument13, T14 argument14, CompletionCallback<TResult> onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleFunc<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, TResult>(activityFunc, argument1, argument2, argument3, argument4, argument5, argument6, argument7, argument8, argument9, argument10, argument11, argument12, argument13, argument14, onCompleted, onFaulted);
        }

        public void ScheduleFunc<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, TResult>(ActivityFunc<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, TResult> activityFunc, T1 argument1, T2 argument2, T3 argument3, T4 argument4, T5 argument5, T6 argument6, T7 argument7, T8 argument8, T9 argument9, T10 argument10, T11 argument11, T12 argument12, T13 argument13, T14 argument14, T15 argument15, CompletionCallback<TResult> onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleFunc<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, TResult>(activityFunc, argument1, argument2, argument3, argument4, argument5, argument6, argument7, argument8, argument9, argument10, argument11, argument12, argument13, argument14, argument15, onCompleted, onFaulted);
        }

        public void ScheduleFunc<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, TResult>(ActivityFunc<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, TResult> activityFunc, T1 argument1, T2 argument2, T3 argument3, T4 argument4, T5 argument5, T6 argument6, T7 argument7, T8 argument8, T9 argument9, T10 argument10, T11 argument11, T12 argument12, T13 argument13, T14 argument14, T15 argument15, T16 argument16, CompletionCallback<TResult> onCompleted = null, FaultCallback onFaulted = null)
        {
            this.ThrowIfDisposed();
            this.innerContext.ScheduleFunc<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, TResult>(activityFunc, argument1, argument2, argument3, argument4, argument5, argument6, argument7, argument8, argument9, argument10, argument11, argument12, argument13, argument14, argument15, argument16, onCompleted, onFaulted);
        }

        public void SetValue(Argument argument, object value)
        {
            this.ThrowIfDisposed();
            this.innerContext.SetValue(argument, value);
        }

        public void SetValue(Variable variable, object value)
        {
            this.ThrowIfDisposed();
            this.innerContext.SetValue(variable, value);
        }

        public void SetValue<T>(Variable<T> variable, T value)
        {
            this.ThrowIfDisposed();
            this.innerContext.SetValue<T>(variable, value);
        }

        internal void ThrowIfDisposed()
        {
            if (this.isDisposed)
            {
                throw FxTrace.Exception.AsError(new ObjectDisposedException(base.GetType().FullName, System.Activities.SR.NAUCDisposed));
            }
        }

        public string ActivityInstanceId
        {
            get
            {
                this.ThrowIfDisposed();
                return this.currentInstance.Id;
            }
        }

        public bool IsCancellationRequested
        {
            get
            {
                this.ThrowIfDisposed();
                return this.currentInstance.IsCancellationRequested;
            }
        }

        public BookmarkScope DefaultBookmarkScope
        {
            get
            {
                this.ThrowIfDisposed();
                return this.activityExecutor.BookmarkScopeManager.Default;
            }
        }

        internal Activity CurrentActivity =>
            this.currentInstance.Activity;

        internal bool IsUpdateDisallowed { get; private set; }

        internal string DisallowedReason { get; private set; }
    }
}

