﻿namespace System.Activities.DynamicUpdate
{
    using System;
    using System.Activities;
    using System.Activities.Validation;
    using System.Collections;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Linq;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;

    public class DynamicUpdateMapBuilder
    {
        private HashSet<Activity> disallowUpdateInside;

        private static void CacheMetadata(Activity workflowDefinition, LocationReferenceEnvironment environment, ActivityUtilities.ProcessActivityCallback callback, bool forImplementation)
        {
            IList<ValidationError> validationErrors = null;
            ActivityUtilities.CacheRootMetadata(workflowDefinition, environment, ProcessTreeOptions(forImplementation), callback, ref validationErrors);
            ActivityValidationServices.ThrowIfViolationsExist(validationErrors, ActivityValidationServices.ExceptionReason.InvalidTree);
        }

        public DynamicUpdateMap CreateMap() => 
            this.CreateMap(out _);

        public DynamicUpdateMap CreateMap(out IList<ActivityBlockingUpdate> activitiesBlockingUpdate)
        {
            RequireProperty(this.LookupMapItem, "LookupMapItem");
            RequireProperty(this.UpdatedWorkflowDefinition, "UpdatedWorkflowDefinition");
            RequireProperty(this.OriginalWorkflowDefinition, "OriginalWorkflowDefinition");
            Finalizer finalizer = new Finalizer(this);
            return finalizer.FinalizeUpdate(out activitiesBlockingUpdate);
        }

        private static DynamicUpdateMapEntry GetParentEntry(Activity originalActivity, DynamicUpdateMap updateMap)
        {
            if ((originalActivity.Parent != null) && (originalActivity.Parent.MemberOf == originalActivity.MemberOf))
            {
                updateMap.TryGetUpdateEntry(originalActivity.Parent.InternalId, out DynamicUpdateMapEntry entry);
                return entry;
            }
            return null;
        }

        private static IEnumerable<Activity> GetPublicDeclaredChildren(Activity activity, bool includeExpressions)
        {
            IEnumerable<Activity> first = activity.Children.Concat<Activity>(activity.ImportedChildren).Concat<Activity>((from d in activity.Delegates select d.Handler)).Concat<Activity>(from d in activity.ImportedDelegates select d.Handler);
            if (includeExpressions)
            {
                first = first.Concat<Activity>(((IEnumerable<Activity>) (from v in activity.RuntimeVariables select v.Default))).Concat<Activity>((IEnumerable<Activity>) activity.RuntimeArguments.Select<RuntimeArgument, ActivityWithResult>(delegate (RuntimeArgument a) {
                    if (!a.IsBound)
                    {
                        return null;
                    }
                    return a.BoundArgument.Expression;
                }));
            }
            return (from a in first
                where (a != null) && (a.Parent == activity)
                select a);
        }

        private static ProcessActivityTreeOptions ProcessTreeOptions(bool forImplementation)
        {
            if (!forImplementation)
            {
                return ProcessActivityTreeOptions.DynamicUpdateOptions;
            }
            return ProcessActivityTreeOptions.DynamicUpdateOptionsForImplementation;
        }

        private static void RequireProperty(object value, string name)
        {
            if (value == null)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.UpdateMapBuilderRequiredProperty(name)));
            }
        }

        public bool ForImplementation { get; set; }

        public ISet<Activity> DisallowUpdateInside
        {
            get
            {
                if (this.disallowUpdateInside == null)
                {
                    this.disallowUpdateInside = new HashSet<Activity>((IEqualityComparer<Activity>) ReferenceEqualityComparer.Instance);
                }
                return this.disallowUpdateInside;
            }
        }

        public Func<object, DynamicUpdateMapItem> LookupMapItem { get; set; }

        public Func<Activity, DynamicUpdateMap> LookupImplementationMap { get; set; }

        public LocationReferenceEnvironment UpdatedEnvironment { get; set; }

        public Activity UpdatedWorkflowDefinition { get; set; }

        public LocationReferenceEnvironment OriginalEnvironment { get; set; }

        public Activity OriginalWorkflowDefinition { get; set; }

        internal Func<Activity, Exception> OnInvalidActivityToBlockUpdate { get; set; }

        internal Func<Activity, Exception> OnInvalidImplementationMapAssociation { get; set; }

        [Serializable, CompilerGenerated]
        private sealed class <>c
        {
            public static readonly DynamicUpdateMapBuilder.<>c <>9 = new DynamicUpdateMapBuilder.<>c();
            public static Func<ActivityDelegate, Activity> <>9__44_0;
            public static Func<ActivityDelegate, Activity> <>9__44_1;
            public static Func<Variable, ActivityWithResult> <>9__44_2;
            public static Func<RuntimeArgument, ActivityWithResult> <>9__44_3;

            internal Activity <GetPublicDeclaredChildren>b__44_0(ActivityDelegate d) => 
                d.Handler;

            internal Activity <GetPublicDeclaredChildren>b__44_1(ActivityDelegate d) => 
                d.Handler;

            internal ActivityWithResult <GetPublicDeclaredChildren>b__44_2(Variable v) => 
                v.Default;

            internal ActivityWithResult <GetPublicDeclaredChildren>b__44_3(RuntimeArgument a)
            {
                if (!a.IsBound)
                {
                    return null;
                }
                return a.BoundArgument.Expression;
            }
        }

        internal class DefinitionMatcher : DynamicUpdateMapBuilder.IDefinitionMatcher
        {
            private Dictionary<object, object> newToOldMatches;
            private Func<object, DynamicUpdateMapItem> matchInfoLookup;

            internal DefinitionMatcher(Func<object, DynamicUpdateMapItem> matchInfoLookup)
            {
                this.matchInfoLookup = matchInfoLookup;
                this.newToOldMatches = new Dictionary<object, object>(DynamicUpdateMapBuilder.ReferenceEqualityComparer.Instance);
            }

            public void AddMatch(Activity newChild, Activity oldChild, Activity source)
            {
                if (newChild.Parent != source)
                {
                    throw FxTrace.Exception.Argument("newChild", System.Activities.SR.AddMatchActivityNewParentMismatch(source, newChild, newChild.Parent));
                }
                if (newChild.MemberOf != newChild.Parent.MemberOf)
                {
                    throw FxTrace.Exception.Argument("newChild", System.Activities.SR.AddMatchActivityPrivateChild(newChild));
                }
                if ((oldChild.Parent != null) && (oldChild.MemberOf != oldChild.Parent.MemberOf))
                {
                    throw FxTrace.Exception.Argument("oldChild", System.Activities.SR.AddMatchActivityPrivateChild(oldChild));
                }
                if (!this.ParentsMatch(newChild, oldChild))
                {
                    throw FxTrace.Exception.Argument("oldChild", System.Activities.SR.AddMatchActivityNewAndOldParentMismatch(newChild, oldChild, newChild.Parent, oldChild.Parent));
                }
                foreach (Activity activity in DynamicUpdateMapBuilder.GetPublicDeclaredChildren(newChild.Parent, true))
                {
                    if (this.GetMatch(activity) == oldChild)
                    {
                        this.newToOldMatches[activity] = null;
                        break;
                    }
                }
                this.newToOldMatches[newChild] = oldChild;
            }

            public void AddMatch(Variable newVariable, Variable oldVariable, Activity source)
            {
                if (!ActivityComparer.SignatureEquals(newVariable, oldVariable))
                {
                    throw FxTrace.Exception.Argument("newVariable", System.Activities.SR.AddMatchVariableSignatureMismatch(source, newVariable.Name, newVariable.Type, newVariable.Modifiers, oldVariable.Name, oldVariable.Type, oldVariable.Modifiers));
                }
                if (newVariable.Owner != source)
                {
                    throw FxTrace.Exception.Argument("newVariable", System.Activities.SR.AddMatchVariableNewParentMismatch(source, newVariable.Name, newVariable.Owner));
                }
                if (this.GetMatch(newVariable.Owner) != oldVariable.Owner)
                {
                    throw FxTrace.Exception.Argument("oldVariable", System.Activities.SR.AddMatchVariableNewAndOldParentMismatch(newVariable.Name, oldVariable.Name, newVariable.Owner, oldVariable.Owner));
                }
                if (!newVariable.IsPublic)
                {
                    throw FxTrace.Exception.Argument("newVariable", System.Activities.SR.AddMatchVariablePrivateChild(newVariable.Name));
                }
                if (!oldVariable.IsPublic)
                {
                    throw FxTrace.Exception.Argument("oldVariable", System.Activities.SR.AddMatchVariablePrivateChild(oldVariable.Name));
                }
                foreach (Variable variable in newVariable.Owner.RuntimeVariables)
                {
                    if (this.GetMatch(variable) == oldVariable)
                    {
                        this.newToOldMatches[variable] = -1;
                        break;
                    }
                }
                this.newToOldMatches[newVariable] = oldVariable.Owner.RuntimeVariables.IndexOf(oldVariable);
            }

            public Activity GetMatch(Activity newChild)
            {
                if (this.newToOldMatches.TryGetValue(newChild, out object obj2))
                {
                    return (Activity) obj2;
                }
                if (newChild.MemberOf == this.NewIdSpace)
                {
                    if ((newChild.Origin != null) && (newChild.RelationshipToParent == Activity.RelationshipType.VariableDefault))
                    {
                        foreach (Variable variable in newChild.Parent.RuntimeVariables)
                        {
                            if (variable.Default == newChild)
                            {
                                Variable match = this.GetMatch(variable);
                                if ((match != null) && (match.Origin != null))
                                {
                                    return match.Default;
                                }
                            }
                        }
                        return null;
                    }
                    DynamicUpdateMapItem item = this.matchInfoLookup(newChild.Origin ?? newChild);
                    if ((item == null) || item.IsVariableMapItem)
                    {
                        return null;
                    }
                    Activity originalActivity = this.OldIdSpace[item.OriginalId];
                    if ((originalActivity != null) && this.ParentsMatch(newChild, originalActivity))
                    {
                        this.newToOldMatches.Add(newChild, originalActivity);
                        return originalActivity;
                    }
                }
                return null;
            }

            public Variable GetMatch(Variable newVariable)
            {
                Activity match = this.GetMatch(newVariable.Owner);
                if (match != null)
                {
                    int num = this.GetMatchIndex(newVariable, match, false);
                    if (num >= 0)
                    {
                        return match.RuntimeVariables[num];
                    }
                }
                return null;
            }

            internal int GetMatchIndex(Variable newVariable, Activity matchingOwner, bool forImplementation)
            {
                IList<Variable> implementationVariables;
                if (this.newToOldMatches.TryGetValue(newVariable, out object obj2))
                {
                    return (int) obj2;
                }
                if (forImplementation)
                {
                    implementationVariables = matchingOwner.ImplementationVariables;
                }
                else
                {
                    implementationVariables = matchingOwner.RuntimeVariables;
                }
                int index = -1;
                if (string.IsNullOrEmpty(newVariable.Name))
                {
                    if (forImplementation)
                    {
                        index = newVariable.Owner.ImplementationVariables.IndexOf(newVariable);
                    }
                    else
                    {
                        DynamicUpdateMapItem item = this.matchInfoLookup(newVariable.Origin ?? newVariable);
                        if (((item != null) && item.IsVariableMapItem) && (matchingOwner.InternalId == item.OriginalVariableOwnerId))
                        {
                            index = item.OriginalId;
                        }
                    }
                }
                else
                {
                    for (int i = 0; i < implementationVariables.Count; i++)
                    {
                        if (ActivityComparer.SignatureEquals(newVariable, implementationVariables[i]))
                        {
                            index = i;
                            break;
                        }
                    }
                }
                if ((index >= 0) && (index < implementationVariables.Count))
                {
                    this.newToOldMatches.Add(newVariable, index);
                    return index;
                }
                return -1;
            }

            private bool ParentsMatch(Activity currentActivity, Activity originalActivity)
            {
                if (currentActivity.Parent == null)
                {
                    return (originalActivity.Parent == null);
                }
                if ((currentActivity.RelationshipToParent != originalActivity.RelationshipToParent) || ((currentActivity.HandlerOf != null) && (currentActivity.HandlerOf.ParentCollectionType != originalActivity.HandlerOf.ParentCollectionType)))
                {
                    return false;
                }
                if (currentActivity.Parent == currentActivity.MemberOf.Owner)
                {
                    return (originalActivity.Parent == this.OldIdSpace.Owner);
                }
                return ((originalActivity.Parent != null) && (this.GetMatch(currentActivity.Parent) == originalActivity.Parent));
            }

            internal IdSpace NewIdSpace { get; set; }

            internal IdSpace OldIdSpace { get; set; }
        }

        internal class Finalizer
        {
            private BitArray foundOriginalElements;
            private DynamicUpdateMapBuilder builder;
            private DynamicUpdateMap updateMap;
            private Dictionary<Activity, object> savedOriginalValues;
            private bool savedOriginalValuesForReferencedChildren;
            private IList<ActivityBlockingUpdate> blockList;
            private Dictionary<Activity, Activity> expressionRootsThatCanInduceIdle;

            public Finalizer(DynamicUpdateMapBuilder builder)
            {
                this.builder = builder;
                this.savedOriginalValues = new Dictionary<Activity, object>((IEqualityComparer<Activity>) DynamicUpdateMapBuilder.ReferenceEqualityComparer.Instance);
                this.Matcher = new DynamicUpdateMapBuilder.DefinitionMatcher(builder.LookupMapItem);
            }

            private void BlockUpdate(Activity activity, UpdateBlockedReason reason, DynamicUpdateMapEntry entry, string message = null)
            {
                this.BlockUpdate(activity, entry.OldActivityId.ToString(CultureInfo.InvariantCulture), reason, entry, message);
            }

            internal void BlockUpdate(Activity activity, string originalActivityId, UpdateBlockedReason reason, DynamicUpdateMapEntry entry, string message = null)
            {
                if (!entry.IsRuntimeUpdateBlocked)
                {
                    entry.BlockReason = reason;
                    if (reason == UpdateBlockedReason.Custom)
                    {
                        entry.BlockReasonMessage = message;
                    }
                    entry.ImplementationUpdateMap = null;
                    this.blockList.Add(new ActivityBlockingUpdate(activity, originalActivityId, message ?? UpdateBlockedReasonMessages.Get(reason)));
                }
            }

            private void CheckCanActivityInduceIdle(Activity activity, Activity expressionRoot)
            {
                if (activity.InternalCanInduceIdle)
                {
                    if (this.expressionRootsThatCanInduceIdle == null)
                    {
                        this.expressionRootsThatCanInduceIdle = new Dictionary<Activity, Activity>((IEqualityComparer<Activity>) DynamicUpdateMapBuilder.ReferenceEqualityComparer.Instance);
                    }
                    if (!this.expressionRootsThatCanInduceIdle.ContainsKey(expressionRoot))
                    {
                        this.expressionRootsThatCanInduceIdle.Add(expressionRoot, activity);
                    }
                }
            }

            private void CheckCanArgumentOrVariableDefaultInduceIdle(ActivityUtilities.ChildActivity childActivity, ActivityUtilities.ActivityCallStack parentChain)
            {
                Activity activity = childActivity.Activity;
                if (activity.IsExpressionRoot || (activity.RelationshipToParent == Activity.RelationshipType.VariableDefault))
                {
                    if (activity.HasNonEmptySubtree)
                    {
                        ActivityUtilities.FinishCachingSubtree(childActivity, parentChain, DynamicUpdateMapBuilder.ProcessTreeOptions(this.builder.ForImplementation), (a, c) => this.CheckCanActivityInduceIdle(activity, a.Activity));
                    }
                    else
                    {
                        this.CheckCanActivityInduceIdle(activity, activity);
                    }
                }
            }

            private void CheckForReusedActivity(Activity activity)
            {
                if (activity.RootActivity != this.builder.OriginalWorkflowDefinition)
                {
                    throw FxTrace.Exception.AsError(new InvalidWorkflowException(System.Activities.SR.OriginalActivityReusedInModifiedDefinition(activity)));
                }
                IList<Variable> runtimeVariables = activity.RuntimeVariables;
                for (int i = 0; i < runtimeVariables.Count; i++)
                {
                    if (runtimeVariables[i].Owner.RootActivity != this.builder.OriginalWorkflowDefinition)
                    {
                        throw FxTrace.Exception.AsError(new InvalidWorkflowException(System.Activities.SR.OriginalVariableReusedInModifiedDefinition(runtimeVariables[i].Name)));
                    }
                }
            }

            internal void CreateArgumentEntries(DynamicUpdateMapEntry mapEntry, IList<RuntimeArgument> newArguments, IList<ArgumentInfo> oldArguments)
            {
                if (!CreateArgumentEntries(mapEntry, newArguments, oldArguments, this.expressionRootsThatCanInduceIdle, out RuntimeArgument argument, out Activity activity))
                {
                    this.BlockUpdate(argument.Owner, UpdateBlockedReason.AddedIdleExpression, mapEntry, System.Activities.SR.AddedIdleArgumentBlockDU(argument.Name, activity));
                }
            }

            internal static bool CreateArgumentEntries(DynamicUpdateMapEntry mapEntry, IList<RuntimeArgument> newArguments, IList<ArgumentInfo> oldArguments, Dictionary<Activity, Activity> expressionRootsThatCanInduceIdle, out RuntimeArgument newIdleArgument, out Activity idleActivity)
            {
                newIdleArgument = null;
                idleActivity = null;
                if ((newArguments != null) && (newArguments.Count > 0))
                {
                    for (int i = 0; i < newArguments.Count; i++)
                    {
                        RuntimeArgument argument = newArguments[i];
                        int index = oldArguments.IndexOf(new ArgumentInfo(argument));
                        if (index != i)
                        {
                            EnsureEnvironmentUpdateMap(mapEntry);
                            EnvironmentUpdateMapEntry item = new EnvironmentUpdateMapEntry {
                                OldOffset = index,
                                NewOffset = i
                            };
                            mapEntry.EnvironmentUpdateMap.ArgumentEntries.Add(item);
                            if ((index == -1) && argument.IsBound)
                            {
                                Activity expression = argument.BoundArgument.Expression;
                                if (((expression != null) && (expressionRootsThatCanInduceIdle != null)) && expressionRootsThatCanInduceIdle.TryGetValue(expression, out idleActivity))
                                {
                                    newIdleArgument = argument;
                                    return false;
                                }
                            }
                        }
                    }
                }
                if ((oldArguments != null) && ((newArguments == null) || (newArguments.Count < oldArguments.Count)))
                {
                    EnsureEnvironmentUpdateMap(mapEntry);
                }
                return true;
            }

            private DynamicUpdateMapEntry CreateMapEntry(Activity currentActivity, Activity matchingOriginal)
            {
                this.foundOriginalElements[matchingOriginal.InternalId - 1] = true;
                DynamicUpdateMapEntry entry = new DynamicUpdateMapEntry(matchingOriginal.InternalId, currentActivity.InternalId);
                this.updateMap.AddEntry(entry);
                return entry;
            }

            private void CreateVariableEntries(bool forImplementationVariables, DynamicUpdateMapEntry mapEntry, IList<Variable> newVariables, IList<Variable> oldVariables, Activity originalElement)
            {
                if ((newVariables != null) && (newVariables.Count > 0))
                {
                    for (int i = 0; i < newVariables.Count; i++)
                    {
                        Variable newVariable = newVariables[i];
                        int num2 = this.Matcher.GetMatchIndex(newVariable, originalElement, forImplementationVariables);
                        if (num2 != i)
                        {
                            EnsureEnvironmentUpdateMap(mapEntry);
                            EnvironmentUpdateMapEntry item = new EnvironmentUpdateMapEntry {
                                OldOffset = num2,
                                NewOffset = i
                            };
                            if (forImplementationVariables)
                            {
                                mapEntry.EnvironmentUpdateMap.PrivateVariableEntries.Add(item);
                            }
                            else
                            {
                                mapEntry.EnvironmentUpdateMap.VariableEntries.Add(item);
                            }
                            if (num2 == -1)
                            {
                                Activity idleActivity = this.GetIdleActivity(newVariable.Default);
                                if (idleActivity != null)
                                {
                                    this.BlockUpdate(newVariable.Owner, UpdateBlockedReason.AddedIdleExpression, mapEntry, System.Activities.SR.AddedIdleVariableDefaultBlockDU(newVariable.Name, idleActivity));
                                }
                                else if (newVariable.IsHandle)
                                {
                                    this.BlockUpdate(newVariable.Owner, UpdateBlockedReason.NewHandle, mapEntry, null);
                                }
                                item.IsNewHandle = newVariable.IsHandle;
                            }
                        }
                    }
                }
                if ((oldVariables != null) && ((newVariables == null) || (newVariables.Count < oldVariables.Count)))
                {
                    EnsureEnvironmentUpdateMap(mapEntry);
                }
            }

            private bool DelegateArgumentsChanged(Activity newActivity, Activity oldActivity)
            {
                if (newActivity.HandlerOf == null)
                {
                    return false;
                }
                return !ActivityComparer.ListEquals(newActivity.HandlerOf.RuntimeDelegateArguments, oldActivity.HandlerOf.RuntimeDelegateArguments);
            }

            private static void EnsureEnvironmentUpdateMap(DynamicUpdateMapEntry mapEntry)
            {
                if (!mapEntry.HasEnvironmentUpdates)
                {
                    mapEntry.EnvironmentUpdateMap = new EnvironmentUpdateMap();
                }
            }

            internal static void FillEnvironmentMapMemberCounts(EnvironmentUpdateMap envMap, Activity currentElement, Activity originalElement, IList<ArgumentInfo> oldArguments)
            {
                envMap.NewVariableCount = (currentElement.RuntimeVariables != null) ? currentElement.RuntimeVariables.Count : 0;
                envMap.NewPrivateVariableCount = (currentElement.ImplementationVariables != null) ? currentElement.ImplementationVariables.Count : 0;
                envMap.NewArgumentCount = (currentElement.RuntimeArguments != null) ? currentElement.RuntimeArguments.Count : 0;
                envMap.OldVariableCount = originalElement.RuntimeVariables.Count;
                envMap.OldPrivateVariableCount = originalElement.ImplementationVariables.Count;
                envMap.OldArgumentCount = (oldArguments != null) ? oldArguments.Count : 0;
                envMap.RuntimeDelegateArgumentCount = (originalElement.HandlerOf == null) ? 0 : originalElement.HandlerOf.RuntimeDelegateArguments.Count;
            }

            public DynamicUpdateMap FinalizeUpdate(out IList<ActivityBlockingUpdate> blockList)
            {
                this.updateMap = new DynamicUpdateMap();
                this.blockList = new List<ActivityBlockingUpdate>();
                DynamicUpdateMapBuilder.CacheMetadata(this.builder.OriginalWorkflowDefinition, this.builder.OriginalEnvironment, null, this.builder.ForImplementation);
                IdSpace space = this.builder.ForImplementation ? this.builder.OriginalWorkflowDefinition.ParentOf : this.builder.OriginalWorkflowDefinition.MemberOf;
                if (space == null)
                {
                    throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.InvalidOriginalWorkflowDefinitionForImplementationMapCreation));
                }
                this.Matcher.OldIdSpace = space;
                this.foundOriginalElements = new BitArray(space.MemberCount);
                DynamicUpdateMapBuilder.CacheMetadata(this.builder.UpdatedWorkflowDefinition, this.builder.UpdatedEnvironment, new ActivityUtilities.ProcessActivityCallback(this.CheckCanArgumentOrVariableDefaultInduceIdle), this.builder.ForImplementation);
                IdSpace space2 = this.builder.ForImplementation ? this.builder.UpdatedWorkflowDefinition.ParentOf : this.builder.UpdatedWorkflowDefinition.MemberOf;
                if (space2 == null)
                {
                    throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.InvalidUpdatedWorkflowDefinitionForImplementationMapCreation));
                }
                this.Matcher.NewIdSpace = space2;
                for (int i = 1; i < (space.MemberCount + 1); i++)
                {
                    this.CheckForReusedActivity(space[i]);
                }
                for (int j = 1; j < (space2.MemberCount + 1); j++)
                {
                    this.ProcessElement(space2[j]);
                }
                for (int k = 0; k < this.foundOriginalElements.Count; k++)
                {
                    if (!this.foundOriginalElements[k])
                    {
                        DynamicUpdateMapEntry entry = new DynamicUpdateMapEntry(k + 1, 0);
                        Activity originalActivity = space[k + 1];
                        entry.Parent = DynamicUpdateMapBuilder.GetParentEntry(originalActivity, this.updateMap);
                        if (!entry.IsParentRemovedOrBlocked)
                        {
                            entry.DisplayName = originalActivity.DisplayName;
                        }
                        this.updateMap.AddEntry(entry);
                    }
                }
                if (this.builder.ForImplementation)
                {
                    this.updateMap.IsForImplementation = true;
                    this.updateMap.OldArguments = ArgumentInfo.List(this.builder.OriginalWorkflowDefinition);
                    this.updateMap.NewArguments = ArgumentInfo.List(this.builder.UpdatedWorkflowDefinition);
                }
                foreach (Activity activity2 in this.builder.DisallowUpdateInside)
                {
                    if ((activity2 != null) && (activity2.MemberOf != space2))
                    {
                        this.ThrowInvalidActivityToBlockUpdate(activity2);
                    }
                }
                this.updateMap.NewDefinitionMemberCount = space2.MemberCount;
                blockList = this.blockList;
                return this.updateMap;
            }

            private Activity GetIdleActivity(Activity expressionRoot)
            {
                Activity activity = null;
                if ((expressionRoot != null) && (this.expressionRootsThatCanInduceIdle != null))
                {
                    this.expressionRootsThatCanInduceIdle.TryGetValue(expressionRoot, out activity);
                }
                return activity;
            }

            private IList<ArgumentInfo> GetOriginalArguments(DynamicUpdateMapEntry mapEntry, DynamicUpdateMap implementationMap, Activity updatedActivity, Activity originalActivity)
            {
                bool flag = false;
                if ((implementationMap != null) && !implementationMap.ArgumentsAreUnknown)
                {
                    flag = !ActivityComparer.ListEquals(implementationMap.NewArguments, implementationMap.OldArguments);
                    bool flag2 = !ActivityComparer.ListEquals(ArgumentInfo.List(updatedActivity), implementationMap.NewArguments);
                    if (flag & flag2)
                    {
                        this.BlockUpdate(updatedActivity, UpdateBlockedReason.DynamicArguments, mapEntry, System.Activities.SR.NoDynamicArgumentsInActivityDefinitionChange);
                        return null;
                    }
                }
                if (!flag)
                {
                    return ArgumentInfo.List(originalActivity);
                }
                return implementationMap.OldArguments;
            }

            internal object GetSavedOriginalValueFromParent(Activity key)
            {
                object obj2 = null;
                this.savedOriginalValues.TryGetValue(key, out obj2);
                return obj2;
            }

            internal void OnCreateDynamicUpdateMap(Activity currentElement, Activity originalElement, DynamicUpdateMapEntry mapEntry, DynamicUpdateMapBuilder.IDefinitionMatcher matcher)
            {
                this.AllowUpdateInsideCurrentActivity = null;
                this.UpdateDisallowedReason = null;
                this.SavedOriginalValuesForCurrentActivity = null;
                this.savedOriginalValuesForReferencedChildren = false;
                currentElement.OnInternalCreateDynamicUpdateMap(this, matcher, originalElement);
                bool? allowUpdateInsideCurrentActivity = this.AllowUpdateInsideCurrentActivity;
                bool flag = false;
                if ((allowUpdateInsideCurrentActivity.GetValueOrDefault() == flag) ? allowUpdateInsideCurrentActivity.HasValue : false)
                {
                    this.BlockUpdate(currentElement, originalElement.Id, UpdateBlockedReason.Custom, mapEntry, this.UpdateDisallowedReason);
                }
                if ((this.SavedOriginalValuesForCurrentActivity != null) && (this.SavedOriginalValuesForCurrentActivity.Count > 0))
                {
                    mapEntry.SavedOriginalValues = this.SavedOriginalValuesForCurrentActivity;
                }
                if (this.savedOriginalValuesForReferencedChildren)
                {
                    this.BlockUpdate(currentElement, originalElement.Id, UpdateBlockedReason.SavedOriginalValuesForReferencedChildren, mapEntry, null);
                }
            }

            private void ProcessElement(Activity currentElement)
            {
                Activity match = this.Matcher.GetMatch(currentElement);
                if (match != null)
                {
                    DynamicUpdateMapEntry entry = this.CreateMapEntry(currentElement, match);
                    entry.Parent = DynamicUpdateMapBuilder.GetParentEntry(match, this.updateMap);
                    if (this.builder.DisallowUpdateInside.Contains(currentElement))
                    {
                        entry.IsUpdateBlockedByUpdateAuthor = true;
                    }
                    if (match.GetType() != currentElement.GetType())
                    {
                        this.BlockUpdate(currentElement, UpdateBlockedReason.TypeChange, entry, System.Activities.SR.DUActivityTypeMismatch(currentElement.GetType(), match.GetType()));
                    }
                    if (this.DelegateArgumentsChanged(currentElement, match))
                    {
                        this.BlockUpdate(currentElement, UpdateBlockedReason.DelegateArgumentChange, entry, null);
                    }
                    DynamicUpdateMap implementationMap = null;
                    if (this.builder.LookupImplementationMap != null)
                    {
                        implementationMap = this.builder.LookupImplementationMap(currentElement);
                    }
                    IList<ArgumentInfo> oldArguments = this.GetOriginalArguments(entry, implementationMap, currentElement, match);
                    if (oldArguments != null)
                    {
                        this.CreateArgumentEntries(entry, currentElement.RuntimeArguments, oldArguments);
                    }
                    entry.SavedOriginalValueFromParent = this.GetSavedOriginalValueFromParent(currentElement);
                    if (entry.IsRuntimeUpdateBlocked)
                    {
                        entry.EnvironmentUpdateMap = null;
                    }
                    else
                    {
                        this.OnCreateDynamicUpdateMap(currentElement, match, entry, this.Matcher);
                        if (entry.IsRuntimeUpdateBlocked)
                        {
                            entry.EnvironmentUpdateMap = null;
                        }
                        else
                        {
                            this.CreateVariableEntries(false, entry, currentElement.RuntimeVariables, match.RuntimeVariables, match);
                            this.CreateVariableEntries(true, entry, currentElement.ImplementationVariables, match.ImplementationVariables, match);
                            if (entry.HasEnvironmentUpdates)
                            {
                                FillEnvironmentMapMemberCounts(entry.EnvironmentUpdateMap, currentElement, match, oldArguments);
                            }
                            if (!entry.IsParentRemovedOrBlocked && !entry.IsUpdateBlockedByUpdateAuthor)
                            {
                                new DynamicUpdateMapBuilder.NestedIdSpaceFinalizer(this, implementationMap, currentElement, match, null).ValidateOrCreateImplementationMap(entry);
                            }
                        }
                    }
                }
            }

            internal void SetOriginalValue(Activity key, object value, bool isReferencedChild)
            {
                if (isReferencedChild)
                {
                    this.savedOriginalValuesForReferencedChildren = true;
                }
                else
                {
                    this.savedOriginalValues[key] = value;
                }
            }

            private void ThrowInvalidActivityToBlockUpdate(Activity activity)
            {
                Exception exception;
                if (this.builder.OnInvalidActivityToBlockUpdate != null)
                {
                    exception = this.builder.OnInvalidActivityToBlockUpdate(activity);
                }
                else
                {
                    exception = new InvalidOperationException(System.Activities.SR.InvalidActivityToBlockUpdate(activity));
                }
                throw FxTrace.Exception.AsError(exception);
            }

            internal void ThrowInvalidImplementationMapAssociation(Activity activity)
            {
                Exception exception;
                if (this.builder.OnInvalidImplementationMapAssociation != null)
                {
                    exception = this.builder.OnInvalidImplementationMapAssociation(activity);
                }
                else
                {
                    exception = new InvalidOperationException(System.Activities.SR.InvalidImplementationMapAssociation(activity));
                }
                throw FxTrace.Exception.AsError(exception);
            }

            internal bool? AllowUpdateInsideCurrentActivity { get; set; }

            internal string UpdateDisallowedReason { get; set; }

            internal Dictionary<string, object> SavedOriginalValuesForCurrentActivity { get; set; }

            internal DynamicUpdateMapBuilder.DefinitionMatcher Matcher { get; private set; }

            internal Dictionary<Activity, Activity> ExpressionRootsThatCanInduceIdle =>
                this.expressionRootsThatCanInduceIdle;
        }

        internal interface IDefinitionMatcher
        {
            void AddMatch(Activity newChild, Activity oldChild, Activity source);
            void AddMatch(Variable newVariable, Variable oldVariable, Activity source);
            Activity GetMatch(Activity newActivity);
            Variable GetMatch(Variable newVariable);
        }

        internal class NestedIdSpaceFinalizer : DynamicUpdateMapBuilder.IDefinitionMatcher
        {
            private DynamicUpdateMapBuilder.Finalizer finalizer;
            private DynamicUpdateMap userProvidedMap;
            private DynamicUpdateMap generatedMap;
            private Activity updatedActivity;
            private Activity originalActivity;
            private bool invalidMatchInCurrentActivity;
            private DynamicUpdateMapBuilder.NestedIdSpaceFinalizer parent;

            public NestedIdSpaceFinalizer(DynamicUpdateMapBuilder.Finalizer finalizer, DynamicUpdateMap implementationMap, Activity updatedActivity, Activity originalActivity, DynamicUpdateMapBuilder.NestedIdSpaceFinalizer parent)
            {
                this.finalizer = finalizer;
                this.userProvidedMap = implementationMap;
                this.updatedActivity = updatedActivity;
                this.originalActivity = originalActivity;
                this.parent = parent;
            }

            public void AddMatch(Activity newChild, Activity oldChild, Activity source)
            {
                if (((newChild.Parent != source) || (newChild.MemberOf != source.MemberOf)) || (this.GetMatch(newChild) != oldChild))
                {
                    this.invalidMatchInCurrentActivity = true;
                }
            }

            public void AddMatch(Variable newVariable, Variable oldVariable, Activity source)
            {
                if (((newVariable.Owner != source) || !newVariable.IsPublic) || (this.GetMatch(newVariable) != oldVariable))
                {
                    this.invalidMatchInCurrentActivity = true;
                }
            }

            private void BlockUpdate(Activity updatedActivity, UpdateBlockedReason reason, DynamicUpdateMapEntry entry, string message = null)
            {
                Activity match = this.GetMatch(updatedActivity);
                this.finalizer.BlockUpdate(updatedActivity, match.Id, reason, entry, message);
            }

            public void CreateArgumentEntries(DynamicUpdateMapEntry mapEntry, IList<RuntimeArgument> newArguments, IList<ArgumentInfo> oldArguments)
            {
                if (!DynamicUpdateMapBuilder.Finalizer.CreateArgumentEntries(mapEntry, newArguments, oldArguments, this.finalizer.ExpressionRootsThatCanInduceIdle, out RuntimeArgument argument, out Activity activity))
                {
                    this.BlockUpdate(argument.Owner, UpdateBlockedReason.AddedIdleExpression, mapEntry, System.Activities.SR.AddedIdleArgumentBlockDU(argument.Name, activity));
                }
            }

            private void EnsureGeneratedMap()
            {
                if (this.generatedMap == null)
                {
                    DynamicUpdateMap map1 = new DynamicUpdateMap {
                        IsForImplementation = true,
                        NewDefinitionMemberCount = this.updatedActivity.ParentOf.MemberCount
                    };
                    this.generatedMap = map1;
                }
            }

            private void FillGeneratedMap()
            {
                this.generatedMap.ArgumentsAreUnknown = true;
                for (int i = 1; i <= this.originalActivity.ParentOf.MemberCount; i++)
                {
                    if (!this.generatedMap.TryGetUpdateEntry(i, out DynamicUpdateMapEntry entry))
                    {
                        entry = new DynamicUpdateMapEntry(i, i);
                        this.generatedMap.AddEntry(entry);
                    }
                    entry.Parent = DynamicUpdateMapBuilder.GetParentEntry(this.originalActivity.ParentOf[i], this.generatedMap);
                }
            }

            private DynamicUpdateMapEntry GenerateEntry(DynamicUpdateMapEntry argumentChangesMapEntry, DynamicUpdateMapEntry providedEntry, int id)
            {
                DynamicUpdateMapEntry entry;
                Activity activity;
                Activity activity2;
                if (argumentChangesMapEntry == null)
                {
                    int oldActivityId = (providedEntry != null) ? providedEntry.OldActivityId : id;
                    entry = new DynamicUpdateMapEntry(oldActivityId, id);
                    activity = this.updatedActivity.ParentOf[id];
                    activity2 = this.originalActivity.ParentOf[id];
                }
                else
                {
                    entry = argumentChangesMapEntry;
                    activity = this.updatedActivity.ParentOf[argumentChangesMapEntry.NewActivityId];
                    activity2 = this.originalActivity.ParentOf[argumentChangesMapEntry.OldActivityId];
                }
                this.invalidMatchInCurrentActivity = false;
                this.finalizer.OnCreateDynamicUpdateMap(activity, activity2, entry, this);
                if (this.invalidMatchInCurrentActivity && !entry.IsRuntimeUpdateBlocked)
                {
                    this.BlockUpdate(activity, UpdateBlockedReason.ChangeMatchesInImplementation, entry, null);
                }
                entry.SavedOriginalValueFromParent = this.finalizer.GetSavedOriginalValueFromParent(activity);
                DynamicUpdateMap implementationUpdateMap = providedEntry?.ImplementationUpdateMap;
                if (!entry.IsRuntimeUpdateBlocked)
                {
                    new DynamicUpdateMapBuilder.NestedIdSpaceFinalizer(this.finalizer, implementationUpdateMap, activity, activity2, this).ValidateOrCreateImplementationMap(entry);
                }
                return entry;
            }

            private void GenerateMap(DynamicUpdateMap argumentChangesMap)
            {
                IdSpace parentOf = this.updatedActivity.ParentOf;
                IdSpace space2 = this.originalActivity.ParentOf;
                for (int i = 1; i <= parentOf.MemberCount; i++)
                {
                    DynamicUpdateMapEntry entry = null;
                    if (((this.userProvidedMap == null) || this.userProvidedMap.IsNoChanges) || ((this.userProvidedMap.TryGetUpdateEntryByNewId(i, out entry) && !entry.IsRuntimeUpdateBlocked) && (!entry.IsUpdateBlockedByUpdateAuthor && !entry.IsParentRemovedOrBlocked)))
                    {
                        DynamicUpdateMapEntry entry2 = null;
                        if ((argumentChangesMap == null) || argumentChangesMap.TryGetUpdateEntryByNewId(i, out entry2))
                        {
                            DynamicUpdateMapEntry entry3 = this.GenerateEntry(entry2, entry, i);
                            DynamicUpdateMap implementationUpdateMap = entry?.ImplementationUpdateMap;
                            if (((entry3.IsRuntimeUpdateBlocked || (entry3.SavedOriginalValues != null)) || ((entry3.SavedOriginalValueFromParent != null) || (entry3.ImplementationUpdateMap != implementationUpdateMap))) || (entry3.IsIdChange || entry3.HasEnvironmentUpdates))
                            {
                                this.EnsureGeneratedMap();
                                this.generatedMap.AddEntry(entry3);
                            }
                        }
                    }
                }
                if ((argumentChangesMap != null) && (argumentChangesMap.entries != null))
                {
                    foreach (DynamicUpdateMapEntry entry4 in argumentChangesMap.entries)
                    {
                        if (entry4.IsRemoval)
                        {
                            this.EnsureGeneratedMap();
                            this.generatedMap.AddEntry(entry4);
                        }
                    }
                }
            }

            public Activity GetMatch(Activity newActivity)
            {
                DynamicUpdateMapBuilder.NestedIdSpaceFinalizer parent = this;
                do
                {
                    if (newActivity.MemberOf == parent.updatedActivity.ParentOf)
                    {
                        return parent.originalActivity.ParentOf[newActivity.InternalId];
                    }
                    parent = parent.parent;
                }
                while (parent != null);
                return this.finalizer.Matcher.GetMatch(newActivity);
            }

            public Variable GetMatch(Variable newVariable)
            {
                int index = newVariable.Owner.RuntimeVariables.IndexOf(newVariable);
                if (index >= 0)
                {
                    Activity match = this.GetMatch(newVariable.Owner);
                    if ((match != null) && (match.RuntimeVariables.Count > index))
                    {
                        return match.RuntimeVariables[index];
                    }
                }
                return null;
            }

            private DynamicUpdateMapEntry GetOrCreateGeneratedEntry(DynamicUpdateMapEntry providedEntry)
            {
                if (!this.generatedMap.TryGetUpdateEntry(providedEntry.OldActivityId, out DynamicUpdateMapEntry entry))
                {
                    entry = new DynamicUpdateMapEntry(providedEntry.OldActivityId, providedEntry.NewActivityId) {
                        DisplayName = providedEntry.DisplayName,
                        BlockReason = providedEntry.BlockReason,
                        BlockReasonMessage = providedEntry.BlockReasonMessage,
                        IsUpdateBlockedByUpdateAuthor = providedEntry.IsUpdateBlockedByUpdateAuthor
                    };
                    this.generatedMap.AddEntry(entry);
                }
                entry.EnvironmentUpdateMap = providedEntry.EnvironmentUpdateMap;
                if (providedEntry.Parent != null)
                {
                    this.generatedMap.TryGetUpdateEntry(providedEntry.Parent.OldActivityId, out DynamicUpdateMapEntry entry2);
                    entry.Parent = entry2;
                }
                if (entry.SavedOriginalValueFromParent == null)
                {
                    entry.SavedOriginalValueFromParent = providedEntry.SavedOriginalValueFromParent;
                }
                if (entry.ImplementationUpdateMap == null)
                {
                    entry.ImplementationUpdateMap = providedEntry.ImplementationUpdateMap;
                }
                return entry;
            }

            private bool HasOverlap(IDictionary<string, object> providedValues, IDictionary<string, object> generatedValues) => 
                ((providedValues != null) && (generatedValues != null)) && providedValues.Keys.Any<string>(k => generatedValues.ContainsKey(k));

            private bool HasSavedOriginalValuesForChildren(int parentNewActivityId, DynamicUpdateMap map)
            {
                foreach (Activity activity in DynamicUpdateMapBuilder.GetPublicDeclaredChildren(this.updatedActivity.ParentOf[parentNewActivityId], false))
                {
                    if (map.TryGetUpdateEntryByNewId(activity.InternalId, out DynamicUpdateMapEntry entry) && (entry.SavedOriginalValueFromParent != null))
                    {
                        return true;
                    }
                }
                return false;
            }

            private void MergeProvidedMapIntoGeneratedMap()
            {
                this.generatedMap.OldArguments = this.userProvidedMap.OldArguments;
                this.generatedMap.NewArguments = this.userProvidedMap.NewArguments;
                for (int i = 1; i <= this.userProvidedMap.OldDefinitionMemberCount; i++)
                {
                    this.userProvidedMap.TryGetUpdateEntry(i, out DynamicUpdateMapEntry entry);
                    DynamicUpdateMapEntry orCreateGeneratedEntry = this.GetOrCreateGeneratedEntry(entry);
                    if ((!orCreateGeneratedEntry.IsRemoval && !orCreateGeneratedEntry.IsRuntimeUpdateBlocked) && (!orCreateGeneratedEntry.IsUpdateBlockedByUpdateAuthor && !orCreateGeneratedEntry.IsParentRemovedOrBlocked))
                    {
                        int newActivityId = entry.NewActivityId;
                        if (this.HasOverlap(entry.SavedOriginalValues, orCreateGeneratedEntry.SavedOriginalValues) || (this.HasSavedOriginalValuesForChildren(newActivityId, this.userProvidedMap) && this.HasSavedOriginalValuesForChildren(newActivityId, this.generatedMap)))
                        {
                            Activity updatedActivity = this.updatedActivity.ParentOf[orCreateGeneratedEntry.NewActivityId];
                            this.BlockUpdate(updatedActivity, UpdateBlockedReason.GeneratedAndProvidedMapConflict, orCreateGeneratedEntry, System.Activities.SR.GeneratedAndProvidedMapConflict);
                        }
                        else
                        {
                            orCreateGeneratedEntry.SavedOriginalValues = DynamicUpdateMapEntry.Merge(orCreateGeneratedEntry.SavedOriginalValues, entry.SavedOriginalValues);
                        }
                    }
                }
            }

            public void ValidateOrCreateImplementationMap(DynamicUpdateMapEntry mapEntry)
            {
                if (this.userProvidedMap != null)
                {
                    IdSpace parentOf = this.updatedActivity.ParentOf;
                    if (parentOf == null)
                    {
                        this.finalizer.ThrowInvalidImplementationMapAssociation(this.updatedActivity);
                    }
                    if (!this.userProvidedMap.IsNoChanges && (parentOf.MemberCount != this.userProvidedMap.NewDefinitionMemberCount))
                    {
                        this.BlockUpdate(this.updatedActivity, UpdateBlockedReason.InvalidImplementationMap, mapEntry, System.Activities.SR.InvalidImplementationMap(this.userProvidedMap.NewDefinitionMemberCount, parentOf.MemberCount));
                        return;
                    }
                }
                if (ActivityComparer.HasPrivateMemberOtherThanArgumentsChanged(this, this.updatedActivity, this.originalActivity, this.parent == null, out DynamicUpdateMap map) || ((map != null) && (this.userProvidedMap != null)))
                {
                    this.BlockUpdate(this.updatedActivity, UpdateBlockedReason.PrivateMembersHaveChanged, mapEntry, null);
                }
                else if (this.updatedActivity.ParentOf != null)
                {
                    this.GenerateMap(map);
                    if (this.generatedMap == null)
                    {
                        mapEntry.ImplementationUpdateMap = this.userProvidedMap;
                    }
                    else
                    {
                        if ((this.userProvidedMap == null) || this.userProvidedMap.IsNoChanges)
                        {
                            this.FillGeneratedMap();
                        }
                        else
                        {
                            this.MergeProvidedMapIntoGeneratedMap();
                        }
                        mapEntry.ImplementationUpdateMap = this.generatedMap;
                    }
                }
            }
        }

        internal class Preparer
        {
            private Dictionary<object, DynamicUpdateMapItem> updateableObjects;
            private Activity originalProgram;
            private LocationReferenceEnvironment originalEnvironment;
            private bool forImplementation;

            public Preparer(Activity originalProgram, LocationReferenceEnvironment originalEnvironment, bool forImplementation)
            {
                this.originalProgram = originalProgram;
                this.originalEnvironment = originalEnvironment;
                this.forImplementation = forImplementation;
            }

            private Activity GetActivity(DynamicUpdateMapItem mapItem) => 
                this.GetIdSpace()[mapItem.OriginalId];

            private IdSpace GetIdSpace()
            {
                if (!this.forImplementation)
                {
                    return this.originalProgram.MemberOf;
                }
                return this.originalProgram.ParentOf;
            }

            private Variable GetVariable(DynamicUpdateMapItem mapItem) => 
                this.GetIdSpace()[mapItem.OriginalVariableOwnerId].RuntimeVariables[mapItem.OriginalId];

            public Dictionary<object, DynamicUpdateMapItem> Prepare()
            {
                this.updateableObjects = new Dictionary<object, DynamicUpdateMapItem>(DynamicUpdateMapBuilder.ReferenceEqualityComparer.Instance);
                DynamicUpdateMapBuilder.CacheMetadata(this.originalProgram, this.originalEnvironment, null, this.forImplementation);
                IdSpace idSpace = this.GetIdSpace();
                if (idSpace != null)
                {
                    for (int i = 1; i <= idSpace.MemberCount; i++)
                    {
                        this.ProcessElement(idSpace[i]);
                    }
                }
                return this.updateableObjects;
            }

            private void ProcessElement(Activity currentElement)
            {
                if ((currentElement.RelationshipToParent != Activity.RelationshipType.VariableDefault) || (currentElement.Origin == null))
                {
                    this.ValidateOrigin(currentElement.Origin, currentElement);
                    this.updateableObjects[currentElement.Origin ?? currentElement] = new DynamicUpdateMapItem(currentElement.InternalId);
                }
                IList<Variable> runtimeVariables = currentElement.RuntimeVariables;
                for (int i = 0; i < runtimeVariables.Count; i++)
                {
                    Variable element = runtimeVariables[i];
                    if (string.IsNullOrEmpty(element.Name))
                    {
                        this.ValidateOrigin(element.Origin, element);
                        this.updateableObjects[element.Origin ?? element] = new DynamicUpdateMapItem(currentElement.InternalId, i);
                    }
                }
            }

            private void ValidateOrigin(object origin, object element)
            {
                if ((origin != null) && this.updateableObjects.TryGetValue(origin, out DynamicUpdateMapItem item))
                {
                    string message = null;
                    if (item.IsVariableMapItem)
                    {
                        Variable variable = this.GetVariable(item);
                        Variable variable2 = element as Variable;
                        if (variable2 != null)
                        {
                            message = System.Activities.SR.DuplicateOriginVariableVariable(origin, variable.Name, variable2.Name);
                        }
                        else
                        {
                            message = System.Activities.SR.DuplicateOriginActivityVariable(origin, element, variable.Name);
                        }
                    }
                    else
                    {
                        Activity activity = this.GetActivity(item);
                        Variable variable3 = element as Variable;
                        if (variable3 != null)
                        {
                            message = System.Activities.SR.DuplicateOriginActivityVariable(origin, activity, variable3.Name);
                        }
                        else
                        {
                            message = System.Activities.SR.DuplicateOriginActivityActivity(origin, activity, element);
                        }
                    }
                    throw FxTrace.Exception.AsError(new InvalidWorkflowException(message));
                }
            }
        }

        internal class ReferenceEqualityComparer : IEqualityComparer<object>
        {
            public static readonly IEqualityComparer<object> Instance = new DynamicUpdateMapBuilder.ReferenceEqualityComparer();

            private ReferenceEqualityComparer()
            {
            }

            public bool Equals(object x, object y) => 
                x == y;

            public int GetHashCode(object obj) => 
                RuntimeHelpers.GetHashCode(obj);
        }
    }
}

