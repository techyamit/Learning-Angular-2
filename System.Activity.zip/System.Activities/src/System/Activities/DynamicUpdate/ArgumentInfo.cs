﻿namespace System.Activities.DynamicUpdate
{
    using System;
    using System.Activities;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using System.Runtime.CompilerServices;
    using System.Runtime.Serialization;
    using System.Text;

    [DataContract]
    internal class ArgumentInfo
    {
        private System.Type type;
        private bool HasGetTypeBeenAttempted;
        private string versionlessAssemblyQualifiedTypeName;
        private string name;
        private string fullAssemblyQualifiedTypeName;
        private ArgumentDirection direction;

        public ArgumentInfo(RuntimeArgument argument)
        {
            this.Name = argument.Name;
            this.Type = argument.Type;
            this.HasGetTypeBeenAttempted = true;
            this.FullAssemblyQualifiedTypeName = this.Type.AssemblyQualifiedName;
            this.versionlessAssemblyQualifiedTypeName = GenerateVersionlessAssemblyQualifiedTypeName(argument.Type);
            this.Direction = argument.Direction;
        }

        private static void BuildArrayTypeSpec(StringBuilder sb, System.Type type)
        {
            BuildSimpleTypeSpec(sb, type.GetElementType());
            int arrayRank = type.GetArrayRank();
            sb.Append('[');
            for (int i = 1; i < arrayRank; i++)
            {
                sb.Append(',');
            }
            sb.Append(']');
        }

        private static void BuildAssemblyNameSpec(StringBuilder sb, System.Type type)
        {
            AssemblyName name = new AssemblyName(type.Assembly.FullName);
            sb.Append(name.Name);
        }

        private static void BuildNamespaceTypeName(StringBuilder sb, System.Type type)
        {
            if (!string.IsNullOrEmpty(type.Namespace))
            {
                sb.Append(type.Namespace);
                sb.Append('.');
            }
            BuildNestedTypeName(sb, type);
        }

        private static void BuildNestedTypeName(StringBuilder sb, System.Type type)
        {
            if (type.IsNested)
            {
                BuildNestedTypeName(sb, type.DeclaringType);
                sb.Append('+');
            }
            BuildSimpleName(sb, type);
        }

        private static void BuildPointerTypeSpec(StringBuilder sb, System.Type type)
        {
            BuildSimpleTypeSpec(sb, type.GetElementType());
            sb.Append('*');
        }

        private static void BuildReferenceTypeSpec(StringBuilder sb, System.Type type)
        {
            BuildSimpleTypeSpec(sb, type.GetElementType());
            sb.Append('&');
        }

        private static void BuildSimpleName(StringBuilder sb, System.Type type)
        {
            sb.Append(type.Name);
            if (type.IsGenericType && !type.IsGenericTypeDefinition)
            {
                sb.Append('[');
                System.Type[] genericArguments = type.GetGenericArguments();
                sb.Append('[');
                BuildTypeSpec(sb, genericArguments[0]);
                sb.Append(']');
                for (int i = 1; i < genericArguments.Length; i++)
                {
                    sb.Append(',');
                    sb.Append('[');
                    BuildTypeSpec(sb, genericArguments[i]);
                    sb.Append(']');
                }
                sb.Append(']');
            }
        }

        private static void BuildSimpleTypeSpec(StringBuilder sb, System.Type type)
        {
            if (type.IsPointer)
            {
                BuildPointerTypeSpec(sb, type);
            }
            else if (type.IsArray)
            {
                BuildArrayTypeSpec(sb, type);
            }
            else
            {
                BuildTypeName(sb, type);
            }
        }

        private static void BuildTypeName(StringBuilder sb, System.Type type)
        {
            BuildNamespaceTypeName(sb, type);
            sb.Append(", ");
            BuildAssemblyNameSpec(sb, type);
        }

        private static void BuildTypeSpec(StringBuilder sb, System.Type type)
        {
            if (type.IsByRef)
            {
                BuildReferenceTypeSpec(sb, type);
            }
            else
            {
                BuildSimpleTypeSpec(sb, type);
            }
        }

        public override bool Equals(object obj)
        {
            ArgumentInfo right = obj as ArgumentInfo;
            return Equals(this, right);
        }

        public static bool Equals(ArgumentInfo left, ArgumentInfo right)
        {
            if (left == null)
            {
                return (right == null);
            }
            return ((((right != null) && (left.Name == right.Name)) && TypeEquals(left, right)) && (left.Direction == right.Direction));
        }

        private static string GenerateVersionlessAssemblyQualifiedTypeName(System.Type type)
        {
            StringBuilder sb = new StringBuilder();
            BuildTypeSpec(sb, type);
            return sb.ToString();
        }

        public override int GetHashCode() => 
            base.GetHashCode();

        public static IList<ArgumentInfo> List(Activity activity)
        {
            if (activity.RuntimeArguments == null)
            {
                return new List<ArgumentInfo>();
            }
            return (from r in activity.RuntimeArguments select new ArgumentInfo(r)).ToList<ArgumentInfo>();
        }

        private static bool TypeEquals(ArgumentInfo left, ArgumentInfo right) => 
            (left.versionlessAssemblyQualifiedTypeName == right.versionlessAssemblyQualifiedTypeName) || (((left.Type != null) && (right.Type != null)) && (left.Type == right.Type));

        private System.Type Type
        {
            get
            {
                if ((this.type == null) && !this.HasGetTypeBeenAttempted)
                {
                    this.HasGetTypeBeenAttempted = true;
                    try
                    {
                        this.type = System.Type.GetType(this.FullAssemblyQualifiedTypeName, false);
                    }
                    catch (Exception exception)
                    {
                        if ((!(exception is TypeLoadException) && !(exception is FileNotFoundException)) && (!(exception is FileLoadException) && !(exception is ArgumentException)))
                        {
                            throw;
                        }
                        this.type = null;
                        System.Activities.FxTrace.Exception.AsWarning(exception);
                    }
                }
                return this.type;
            }
            set => 
                this.type = value;
        }

        public string Name
        {
            get => 
                this.name;
            private set => 
                this.name = value;
        }

        public string FullAssemblyQualifiedTypeName
        {
            get => 
                this.fullAssemblyQualifiedTypeName;
            private set => 
                this.fullAssemblyQualifiedTypeName = value;
        }

        public ArgumentDirection Direction
        {
            get => 
                this.direction;
            private set => 
                this.direction = value;
        }

        [DataMember(EmitDefaultValue=false, Name="VersionlessAssemblyQualifiedTypeName")]
        internal string SerializedVersionlessAssemblyQualifiedTypeName
        {
            get => 
                this.versionlessAssemblyQualifiedTypeName;
            set => 
                this.versionlessAssemblyQualifiedTypeName = value;
        }

        [DataMember(EmitDefaultValue=false, Name="Name")]
        internal string SerializedName
        {
            get => 
                this.Name;
            set => 
                this.Name = value;
        }

        [DataMember(EmitDefaultValue=false, Name="FullAssemblyQualifiedTypeName")]
        internal string SerializedFullAssemblyQualifiedTypeName
        {
            get => 
                this.FullAssemblyQualifiedTypeName;
            set => 
                this.FullAssemblyQualifiedTypeName = value;
        }

        [DataMember(EmitDefaultValue=false, Name="Direction")]
        internal ArgumentDirection SerializedDirection
        {
            get => 
                this.Direction;
            set => 
                this.Direction = value;
        }

        [Serializable, CompilerGenerated]
        private sealed class <>c
        {
            public static readonly ArgumentInfo.<>c <>9 = new ArgumentInfo.<>c();
            public static Func<RuntimeArgument, ArgumentInfo> <>9__33_0;

            internal ArgumentInfo <List>b__33_0(RuntimeArgument r) => 
                new ArgumentInfo(r);
        }
    }
}

