﻿namespace System.Activities.DynamicUpdate
{
    using System;

    internal enum UpdateBlockedReason
    {
        NotBlocked,
        Custom,
        TypeChange,
        PublicChildrenChange,
        InvalidImplementationMap,
        PrivateMembersHaveChanged,
        ChangeMatchesInImplementation,
        GeneratedAndProvidedMapConflict,
        SavedOriginalValuesForReferencedChildren,
        AddedIdleExpression,
        DelegateArgumentChange,
        DynamicArguments,
        NewHandle
    }
}

