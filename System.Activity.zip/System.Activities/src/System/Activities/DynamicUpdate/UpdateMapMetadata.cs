﻿namespace System.Activities.DynamicUpdate
{
    using System;
    using System.Activities;
    using System.Runtime.InteropServices;

    public class UpdateMapMetadata
    {
        private System.Activities.DynamicUpdate.DynamicUpdateMapBuilder.Finalizer finalizer;
        private DynamicUpdateMapBuilder.IDefinitionMatcher matcher;
        private Activity targetActivity;
        private bool isDisposed;

        internal UpdateMapMetadata(System.Activities.DynamicUpdate.DynamicUpdateMapBuilder.Finalizer finalizer, DynamicUpdateMapBuilder.IDefinitionMatcher matcher, Activity targetActivity)
        {
            this.finalizer = finalizer;
            this.matcher = matcher;
            this.targetActivity = targetActivity;
            this.isDisposed = false;
        }

        public void AddMatch(Activity updatedChild, Activity originalChild)
        {
            this.ThrowIfDisposed();
            if ((updatedChild != null) && (originalChild != null))
            {
                this.matcher.AddMatch(updatedChild, originalChild, this.targetActivity);
            }
        }

        public void AddMatch(Variable updatedVariable, Variable originalVariable)
        {
            this.ThrowIfDisposed();
            if ((updatedVariable != null) && (originalVariable != null))
            {
                this.matcher.AddMatch(updatedVariable, originalVariable, this.targetActivity);
            }
        }

        public void AllowUpdateInsideThisActivity()
        {
            this.ThrowIfDisposed();
            this.finalizer.AllowUpdateInsideCurrentActivity = true;
            this.finalizer.UpdateDisallowedReason = null;
        }

        internal bool AreMatch(Activity updatedActivity, Activity originalActivity) => 
            this.matcher.GetMatch(updatedActivity) == originalActivity;

        internal bool AreMatch(ActivityDelegate updatedDelegate, ActivityDelegate originalDelegate)
        {
            if ((updatedDelegate.Handler != null) && (originalDelegate.Handler != null))
            {
                return (this.matcher.GetMatch(updatedDelegate.Handler) == originalDelegate.Handler);
            }
            return ((updatedDelegate.Handler == null) && (originalDelegate.Handler == null));
        }

        public void DisallowUpdateInsideThisActivity(string reason)
        {
            this.ThrowIfDisposed();
            this.finalizer.AllowUpdateInsideCurrentActivity = false;
            this.finalizer.UpdateDisallowedReason = reason;
        }

        internal void Dispose()
        {
            this.isDisposed = true;
        }

        public Activity GetMatch(Activity updatedChild)
        {
            this.ThrowIfDisposed();
            if (updatedChild != null)
            {
                Activity match = this.matcher.GetMatch(updatedChild);
                if (updatedChild.MemberOf == this.targetActivity.MemberOf)
                {
                    return match;
                }
                if (match != null)
                {
                    bool flag2 = IsChild(this.TargetActivity, updatedChild, out bool flag);
                    bool flag3 = updatedChild.HandlerOf > null;
                    bool flag5 = IsChild(this.GetMatch(this.TargetActivity), match, out bool flag4);
                    bool flag6 = match.HandlerOf > null;
                    if (((flag2 & flag5) && (flag == flag4)) && (flag3 == flag6))
                    {
                        return match;
                    }
                }
            }
            return null;
        }

        public Variable GetMatch(Variable updatedVariable)
        {
            this.ThrowIfDisposed();
            if ((updatedVariable != null) && (updatedVariable.Owner == this.TargetActivity))
            {
                return this.matcher.GetMatch(updatedVariable);
            }
            return null;
        }

        internal static bool IsChild(Activity parent, Activity child, out bool isImport)
        {
            if (child.HandlerOf == null)
            {
                isImport = parent.ImportedChildren.Contains(child);
                if (!isImport)
                {
                    return parent.Children.Contains(child);
                }
                return true;
            }
            isImport = parent.ImportedDelegates.Contains(child.HandlerOf);
            if (!isImport)
            {
                return parent.Delegates.Contains(child.HandlerOf);
            }
            return true;
        }

        public bool IsReferenceToImportedChild(Activity childActivity)
        {
            this.ThrowIfDisposed();
            if (childActivity == null)
            {
                return false;
            }
            Activity parent = (childActivity.RootActivity == this.TargetActivity.RootActivity) ? this.TargetActivity : this.GetMatch(this.TargetActivity);
            return IsReferenceToImportedChild(parent, childActivity);
        }

        private static bool IsReferenceToImportedChild(Activity parent, Activity child)
        {
            if ((child != null) && (child.MemberOf != parent.MemberOf))
            {
                for (IdSpace space = parent.MemberOf.Parent; space != null; space = space.Parent)
                {
                    if (space == child.MemberOf)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        internal void ThrowIfDisposed()
        {
            if (this.isDisposed)
            {
                throw FxTrace.Exception.AsError(new ObjectDisposedException(this.ToString()));
            }
        }

        internal bool IsUpdateExplicitlyAllowedOrDisallowed =>
            this.finalizer.AllowUpdateInsideCurrentActivity.HasValue;

        internal System.Activities.DynamicUpdate.DynamicUpdateMapBuilder.Finalizer Finalizer =>
            this.finalizer;

        internal Activity TargetActivity =>
            this.targetActivity;
    }
}

