﻿namespace System.Activities.DynamicUpdate
{
    using System;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;
    using System.Runtime.Serialization;

    [DataContract(IsReference=true)]
    internal class DynamicUpdateMapEntry
    {
        private static DynamicUpdateMapEntry dummyMapEntry = new DynamicUpdateMapEntry(-1, -1);
        private DynamicUpdateMap implementationUpdateMap;
        private int oldActivityId;
        private int newActivityId;

        public DynamicUpdateMapEntry(int oldActivityId, int newActivityId)
        {
            this.OldActivityId = oldActivityId;
            this.NewActivityId = newActivityId;
        }

        internal DynamicUpdateMapEntry Clone(DynamicUpdateMapEntry newParent) => 
            new DynamicUpdateMapEntry(this.OldActivityId, this.NewActivityId) { 
                DisplayName = this.DisplayName,
                EnvironmentUpdateMap = this.EnvironmentUpdateMap,
                ImplementationUpdateMap = this.ImplementationUpdateMap,
                BlockReason = this.BlockReason,
                BlockReasonMessage = this.BlockReasonMessage,
                IsUpdateBlockedByUpdateAuthor = this.IsUpdateBlockedByUpdateAuthor,
                Parent = newParent,
                SavedOriginalValues = this.SavedOriginalValues,
                SavedOriginalValueFromParent = this.SavedOriginalValueFromParent
            };

        internal static IDictionary<string, object> Merge(IDictionary<string, object> first, IDictionary<string, object> second)
        {
            if ((first == null) || (second == null))
            {
                return (first ?? second);
            }
            Dictionary<string, object> dictionary = new Dictionary<string, object>(first);
            foreach (KeyValuePair<string, object> pair in second)
            {
                if (!dictionary.ContainsKey(pair.Key))
                {
                    dictionary.Add(pair.Key, pair.Value);
                }
            }
            return dictionary;
        }

        internal static DynamicUpdateMapEntry Merge(DynamicUpdateMapEntry first, DynamicUpdateMapEntry second, DynamicUpdateMapEntry newParent, DynamicUpdateMap.MergeErrorContext errorContext)
        {
            DynamicUpdateMapEntry entry = new DynamicUpdateMapEntry(first.OldActivityId, second.NewActivityId) {
                Parent = newParent
            };
            if (second.IsRemoval)
            {
                if (!entry.IsParentRemovedOrBlocked)
                {
                    entry.DisplayName = second.DisplayName;
                }
                return entry;
            }
            entry.SavedOriginalValues = Merge(first.SavedOriginalValues, second.SavedOriginalValues);
            entry.SavedOriginalValueFromParent = first.SavedOriginalValueFromParent ?? second.SavedOriginalValueFromParent;
            if (first.BlockReason == UpdateBlockedReason.NotBlocked)
            {
                entry.BlockReason = second.BlockReason;
                entry.BlockReasonMessage = second.BlockReasonMessage;
            }
            else
            {
                entry.BlockReason = first.BlockReason;
                entry.BlockReasonMessage = second.BlockReasonMessage;
            }
            entry.IsUpdateBlockedByUpdateAuthor = first.IsUpdateBlockedByUpdateAuthor || second.IsUpdateBlockedByUpdateAuthor;
            errorContext.PushIdSpace(entry.NewActivityId);
            entry.EnvironmentUpdateMap = System.Activities.DynamicUpdate.EnvironmentUpdateMap.Merge(first.EnvironmentUpdateMap, second.EnvironmentUpdateMap, errorContext);
            if ((!entry.IsRuntimeUpdateBlocked && !entry.IsUpdateBlockedByUpdateAuthor) && !entry.IsParentRemovedOrBlocked)
            {
                entry.ImplementationUpdateMap = DynamicUpdateMap.Merge(first.ImplementationUpdateMap, second.ImplementationUpdateMap, errorContext);
            }
            errorContext.PopIdSpace();
            return entry;
        }

        internal static DynamicUpdateMapEntry DummyMapEntry =>
            dummyMapEntry;

        public int OldActivityId
        {
            get => 
                this.oldActivityId;
            private set => 
                this.oldActivityId = value;
        }

        public int NewActivityId
        {
            get => 
                this.newActivityId;
            private set => 
                this.newActivityId = value;
        }

        [DataMember(EmitDefaultValue=false)]
        public DynamicUpdateMapEntry Parent { get; set; }

        [DataMember(EmitDefaultValue=false)]
        public string DisplayName { get; set; }

        [DataMember(EmitDefaultValue=false)]
        public UpdateBlockedReason BlockReason { get; set; }

        [DataMember(EmitDefaultValue=false)]
        public string BlockReasonMessage { get; set; }

        public bool IsRuntimeUpdateBlocked =>
            this.BlockReason > UpdateBlockedReason.NotBlocked;

        [DataMember(EmitDefaultValue=false)]
        public bool IsUpdateBlockedByUpdateAuthor { get; set; }

        public bool IsParentRemovedOrBlocked
        {
            get
            {
                for (DynamicUpdateMapEntry entry = this.Parent; entry != null; entry = entry.Parent)
                {
                    if ((entry.IsRemoval || entry.IsRuntimeUpdateBlocked) || entry.IsUpdateBlockedByUpdateAuthor)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        [DataMember(EmitDefaultValue=false)]
        public IDictionary<string, object> SavedOriginalValues { get; set; }

        [DataMember(EmitDefaultValue=false)]
        public object SavedOriginalValueFromParent { get; set; }

        [DataMember(EmitDefaultValue=false)]
        public System.Activities.DynamicUpdate.EnvironmentUpdateMap EnvironmentUpdateMap { get; set; }

        public DynamicUpdateMap ImplementationUpdateMap
        {
            get => 
                this.implementationUpdateMap;
            internal set => 
                this.implementationUpdateMap = value;
        }

        [DataMember(EmitDefaultValue=false, Name="implementationUpdateMap")]
        internal DynamicUpdateMap SerializedImplementationUpdateMap
        {
            get => 
                this.implementationUpdateMap;
            set => 
                this.implementationUpdateMap = value;
        }

        [DataMember(EmitDefaultValue=false, Name="OldActivityId")]
        internal int SerializedOldActivityId
        {
            get => 
                this.OldActivityId;
            set => 
                this.OldActivityId = value;
        }

        [DataMember(EmitDefaultValue=false, Name="NewActivityId")]
        internal int SerializedNewActivityId
        {
            get => 
                this.NewActivityId;
            set => 
                this.NewActivityId = value;
        }

        internal bool IsIdChange =>
            ((this.NewActivityId > 0) && (this.OldActivityId > 0)) && (this.NewActivityId != this.OldActivityId);

        internal bool IsRemoval =>
            (this.NewActivityId <= 0) && (this.OldActivityId > 0);

        internal bool HasEnvironmentUpdates =>
            this.EnvironmentUpdateMap > null;
    }
}

