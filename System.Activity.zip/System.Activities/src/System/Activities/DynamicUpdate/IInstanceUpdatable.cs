﻿namespace System.Activities.DynamicUpdate
{
    using System;

    internal interface IInstanceUpdatable
    {
        void InternalUpdateInstance(NativeActivityUpdateContext updateContext);
    }
}

