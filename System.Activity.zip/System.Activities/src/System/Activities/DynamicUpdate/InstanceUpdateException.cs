﻿namespace System.Activities.DynamicUpdate
{
    using System;
    using System.Activities;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Runtime.Serialization;
    using System.Security;
    using System.Text;

    [Serializable]
    public class InstanceUpdateException : Exception
    {
        private ReadOnlyCollection<ActivityBlockingUpdate> blockingActivities;

        public InstanceUpdateException()
        {
        }

        public InstanceUpdateException(IList<ActivityBlockingUpdate> blockingActivities) : this(BuildMessage(blockingActivities), blockingActivities)
        {
        }

        public InstanceUpdateException(string message) : base(message)
        {
        }

        protected InstanceUpdateException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
            this.blockingActivities = (ReadOnlyCollection<ActivityBlockingUpdate>) info.GetValue("blockingActivities", typeof(ReadOnlyCollection<ActivityBlockingUpdate>));
        }

        public InstanceUpdateException(string message, IList<ActivityBlockingUpdate> blockingActivities) : base(message)
        {
            if (blockingActivities != null)
            {
                this.blockingActivities = new ReadOnlyCollection<ActivityBlockingUpdate>(blockingActivities);
            }
        }

        public InstanceUpdateException(string message, Exception innerException) : base(message, innerException)
        {
        }

        public InstanceUpdateException(string message, IList<ActivityBlockingUpdate> blockingActivities, Exception innerException) : base(message, innerException)
        {
            if (blockingActivities != null)
            {
                this.blockingActivities = new ReadOnlyCollection<ActivityBlockingUpdate>(blockingActivities);
            }
        }

        private static string BuildMessage(IList<ActivityBlockingUpdate> blockingActivities)
        {
            if ((blockingActivities == null) || (blockingActivities.Count <= 0))
            {
                return null;
            }
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < (blockingActivities.Count - 1); i++)
            {
                builder.AppendLine(GetMessage(blockingActivities[i]));
            }
            builder.Append(GetMessage(blockingActivities[blockingActivities.Count - 1]));
            return builder.ToString();
        }

        private static string GetMessage(ActivityBlockingUpdate blockingActivity)
        {
            object obj2 = blockingActivity.Activity ?? blockingActivity.UpdatedActivityId;
            if (obj2 != null)
            {
                return System.Activities.SR.ActivityBlockingUpdate(obj2, blockingActivity.Reason);
            }
            return blockingActivity.Reason;
        }

        [SecurityCritical]
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);
            info.AddValue("blockingActivities", this.blockingActivities);
        }

        public IList<ActivityBlockingUpdate> BlockingActivities
        {
            get
            {
                if (this.blockingActivities == null)
                {
                    this.blockingActivities = new ReadOnlyCollection<ActivityBlockingUpdate>(new ActivityBlockingUpdate[0]);
                }
                return this.blockingActivities;
            }
        }
    }
}

