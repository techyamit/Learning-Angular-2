﻿namespace System.Activities.DynamicUpdate
{
    using System;
    using System.Activities;

    internal static class UpdateBlockedReasonMessages
    {
        public static string Get(UpdateBlockedReason reason)
        {
            switch (reason)
            {
                case UpdateBlockedReason.Custom:
                    return System.Activities.SR.BlockedUpdateInsideActivityUpdateError;

                case UpdateBlockedReason.TypeChange:
                    return System.Activities.SR.DUActivityTypeMismatchRuntime;

                case UpdateBlockedReason.PublicChildrenChange:
                    return System.Activities.SR.PublicChildrenChangeBlockDU;

                case UpdateBlockedReason.InvalidImplementationMap:
                    return System.Activities.SR.InvalidImplementationMapRuntime;

                case UpdateBlockedReason.PrivateMembersHaveChanged:
                    return System.Activities.SR.PrivateMembersHaveChanged;

                case UpdateBlockedReason.ChangeMatchesInImplementation:
                    return System.Activities.SR.CannotChangeMatchesInImplementation;

                case UpdateBlockedReason.GeneratedAndProvidedMapConflict:
                    return System.Activities.SR.GeneratedAndProvidedMapConflictRuntime;

                case UpdateBlockedReason.SavedOriginalValuesForReferencedChildren:
                    return System.Activities.SR.CannotSaveOriginalValuesForReferencedChildren;

                case UpdateBlockedReason.AddedIdleExpression:
                    return System.Activities.SR.AddedIdleExpressionBlockDU;

                case UpdateBlockedReason.DelegateArgumentChange:
                    return System.Activities.SR.DelegateArgumentChangeBlockDU;

                case UpdateBlockedReason.DynamicArguments:
                    return System.Activities.SR.NoDynamicArgumentsInActivityDefinitionChangeRuntime;

                case UpdateBlockedReason.NewHandle:
                    return System.Activities.SR.CannotAddHandlesUpdateError;
            }
            return null;
        }
    }
}

