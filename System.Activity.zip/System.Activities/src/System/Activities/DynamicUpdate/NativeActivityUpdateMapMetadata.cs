﻿namespace System.Activities.DynamicUpdate
{
    using System;
    using System.Activities;
    using System.Collections.Generic;
    using System.Runtime.InteropServices;

    public class NativeActivityUpdateMapMetadata : UpdateMapMetadata
    {
        internal NativeActivityUpdateMapMetadata(DynamicUpdateMapBuilder.Finalizer finalizer, DynamicUpdateMapBuilder.IDefinitionMatcher matcher, Activity targetActivity) : base(finalizer, matcher, targetActivity)
        {
        }

        private static bool IsPublicOrImportedDelegateOrChild(Activity parent, Activity child, out bool isReferencedChild)
        {
            isReferencedChild = false;
            if (child.Parent == parent)
            {
                if (child.HandlerOf == null)
                {
                    if (child.RelationshipToParent != Activity.RelationshipType.Child)
                    {
                        return (child.RelationshipToParent == Activity.RelationshipType.ImportedChild);
                    }
                    return true;
                }
                if (child.HandlerOf.ParentCollectionType != ActivityCollectionType.Public)
                {
                    return (child.HandlerOf.ParentCollectionType == ActivityCollectionType.Imports);
                }
                return true;
            }
            if (parent.MemberOf != child.MemberOf)
            {
                isReferencedChild = true;
                return IsChild(parent, child, out _);
            }
            return false;
        }

        public void SaveOriginalValue(Activity updatedChildActivity, object originalValue)
        {
            base.ThrowIfDisposed();
            ValidateOriginalValueAccess(base.TargetActivity, updatedChildActivity, "updatedChildActivity", out bool flag);
            if (base.GetMatch(updatedChildActivity) == null)
            {
                throw FxTrace.Exception.Argument("updatedChildActivity", System.Activities.SR.CannotSaveOriginalValueForNewActivity(updatedChildActivity));
            }
            base.Finalizer.SetOriginalValue(updatedChildActivity, originalValue, flag);
        }

        public void SaveOriginalValue(string propertyName, object originalValue)
        {
            base.ThrowIfDisposed();
            if (propertyName == null)
            {
                throw FxTrace.Exception.ArgumentNull("propertyName");
            }
            if (base.Finalizer.SavedOriginalValuesForCurrentActivity == null)
            {
                base.Finalizer.SavedOriginalValuesForCurrentActivity = new Dictionary<string, object>();
            }
            base.Finalizer.SavedOriginalValuesForCurrentActivity[propertyName] = originalValue;
        }

        internal static void ValidateOriginalValueAccess(Activity parent, Activity child, string paramName, out bool isReferencedChild)
        {
            if (child == null)
            {
                throw FxTrace.Exception.ArgumentNull(paramName);
            }
            if (!IsPublicOrImportedDelegateOrChild(parent, child, out isReferencedChild))
            {
                throw FxTrace.Exception.Argument(paramName, System.Activities.SR.CannotSaveOriginalValueForActivity);
            }
        }
    }
}

