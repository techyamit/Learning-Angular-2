﻿namespace System.Activities.DynamicUpdate
{
    using System;
    using System.Activities;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;

    internal static class ActivityComparer
    {
        private static bool AreVariableNamesIdentical(string leftName, string rightName) => 
            (string.IsNullOrEmpty(leftName) && string.IsNullOrEmpty(rightName)) || (leftName == rightName);

        private static bool CompareArgumentEquality(RuntimeArgument currentArgument, RuntimeArgument originalArgument)
        {
            if (((currentArgument.Name != originalArgument.Name) || (currentArgument.Type != originalArgument.Type)) || (currentArgument.Direction != originalArgument.Direction))
            {
                return false;
            }
            return (((currentArgument.BoundArgument == null) && (originalArgument.BoundArgument == null)) || ((((currentArgument.BoundArgument == null) || (originalArgument.BoundArgument != null)) && ((currentArgument.BoundArgument != null) || (originalArgument.BoundArgument == null))) && CompareChildEquality(currentArgument.BoundArgument.Expression, currentArgument.Owner.MemberOf, originalArgument.BoundArgument.Expression, originalArgument.Owner.MemberOf)));
        }

        private static bool CompareChildEquality(Activity currentChild, IdSpace currentIdSpace, Activity originalChild, IdSpace originalIdSpace)
        {
            if ((currentChild == null) && (originalChild == null))
            {
                return true;
            }
            if (((currentChild == null) && (originalChild != null)) || ((currentChild != null) && (originalChild == null)))
            {
                return false;
            }
            return (((currentChild.MemberOf != currentIdSpace) || (originalChild.MemberOf == originalIdSpace)) && ((currentChild.MemberOf == currentIdSpace) || (originalChild.MemberOf != originalIdSpace)));
        }

        private static bool CompareDelegateArgumentEquality(DelegateArgument newBoundArgument, DelegateArgument oldBoundArgument)
        {
            if (newBoundArgument == null)
            {
                return (oldBoundArgument == null);
            }
            if (oldBoundArgument == null)
            {
                return false;
            }
            return (((newBoundArgument.Name == oldBoundArgument.Name) && (newBoundArgument.Type == oldBoundArgument.Type)) && (newBoundArgument.Direction == oldBoundArgument.Direction));
        }

        private static bool CompareDelegateEquality(ActivityDelegate currentDelegate, ActivityDelegate originalDelegate)
        {
            if (!ListEquals(currentDelegate.RuntimeDelegateArguments, originalDelegate.RuntimeDelegateArguments))
            {
                return false;
            }
            bool flag = currentDelegate.ParentCollectionType == ActivityCollectionType.Implementation;
            IdSpace currentIdSpace = flag ? currentDelegate.Owner.ParentOf : currentDelegate.Owner.MemberOf;
            IdSpace originalIdSpace = flag ? originalDelegate.Owner.ParentOf : originalDelegate.Owner.MemberOf;
            return CompareChildEquality(currentDelegate.Handler, currentIdSpace, originalDelegate.Handler, originalIdSpace);
        }

        private static bool CompareRuntimeDelegateArgumentEquality(RuntimeDelegateArgument newRuntimeDelegateArgument, RuntimeDelegateArgument oldRuntimeDelegateArgument) => 
            ((newRuntimeDelegateArgument.Name.Equals(oldRuntimeDelegateArgument.Name) && !(newRuntimeDelegateArgument.Type != oldRuntimeDelegateArgument.Type)) && (newRuntimeDelegateArgument.Direction == oldRuntimeDelegateArgument.Direction)) && CompareDelegateArgumentEquality(newRuntimeDelegateArgument.BoundArgument, oldRuntimeDelegateArgument.BoundArgument);

        private static bool CompareVariableEquality(Variable currentVariable, Variable originalVariable)
        {
            if (!SignatureEquals(currentVariable, originalVariable))
            {
                return false;
            }
            IdSpace currentIdSpace = currentVariable.IsPublic ? currentVariable.Owner.MemberOf : currentVariable.Owner.ParentOf;
            IdSpace originalIdSpace = originalVariable.IsPublic ? originalVariable.Owner.MemberOf : originalVariable.Owner.ParentOf;
            return CompareChildEquality(currentVariable.Default, currentIdSpace, originalVariable.Default, originalIdSpace);
        }

        private static IList<Activity> GetDeclaredChildren(IList<Activity> collection, Activity parent) => 
            (from a in collection
                where a.Parent == parent
                select a).ToList<Activity>();

        private static IList<ActivityDelegate> GetDeclaredDelegates(IList<ActivityDelegate> collection, Activity parentActivity) => 
            (from d in collection
                where d.Owner == parentActivity
                select d).ToList<ActivityDelegate>();

        public static bool HasPrivateMemberOtherThanArgumentsChanged(DynamicUpdateMapBuilder.NestedIdSpaceFinalizer nestedFinalizer, Activity currentElement, Activity originalElement, bool isMemberOfUpdatedIdSpace, out DynamicUpdateMap argumentChangesMap)
        {
            argumentChangesMap = null;
            IdSpace parentOf = currentElement.ParentOf;
            IdSpace originalPrivateIdSpace = originalElement.ParentOf;
            if (((!isMemberOfUpdatedIdSpace || IsAnyNameless(currentElement.ImplementationVariables)) || IsAnyNameless(originalElement.ImplementationVariables)) && !ListEquals<Variable>(currentElement.ImplementationVariables, originalElement.ImplementationVariables, new Func<Variable, Variable, bool>(ActivityComparer.CompareVariableEquality)))
            {
                return true;
            }
            if ((parentOf == null) && (originalPrivateIdSpace == null))
            {
                return false;
            }
            if (((parentOf != null) && (originalPrivateIdSpace == null)) || ((parentOf == null) && (originalPrivateIdSpace != null)))
            {
                return true;
            }
            if (!ListEquals<ActivityDelegate>(currentElement.ImplementationDelegates, originalElement.ImplementationDelegates, new Func<ActivityDelegate, ActivityDelegate, bool>(ActivityComparer.CompareDelegateEquality)))
            {
                return true;
            }
            PrivateIdSpaceMatcher matcher = new PrivateIdSpaceMatcher(nestedFinalizer, originalPrivateIdSpace, parentOf);
            return !matcher.Match(out argumentChangesMap);
        }

        private static bool IsAnyNameless(IEnumerable<Variable> variables) => 
            variables.Any<Variable>(v => string.IsNullOrEmpty(v.Name));

        public static bool ListEquals(IList<ArgumentInfo> currentArguments, IList<ArgumentInfo> originalArguments) => 
            ListEquals<ArgumentInfo>(currentArguments, originalArguments, new Func<ArgumentInfo, ArgumentInfo, bool>(ArgumentInfo.Equals));

        public static bool ListEquals(IList<RuntimeDelegateArgument> currentArguments, IList<RuntimeDelegateArgument> originalArguments) => 
            ListEquals<RuntimeDelegateArgument>(currentArguments, originalArguments, new Func<RuntimeDelegateArgument, RuntimeDelegateArgument, bool>(ActivityComparer.CompareRuntimeDelegateArgumentEquality));

        public static bool ListEquals<T>(IList<T> currentMembers, IList<T> originalMembers, Func<T, T, bool> comparer)
        {
            if (currentMembers == null)
            {
                if (originalMembers != null)
                {
                    return (originalMembers.Count == 0);
                }
                return true;
            }
            if (originalMembers == null)
            {
                return (currentMembers.Count == 0);
            }
            if (currentMembers.Count != originalMembers.Count)
            {
                return false;
            }
            if (comparer != null)
            {
                for (int i = 0; i < currentMembers.Count; i++)
                {
                    if (!comparer(currentMembers[i], originalMembers[i]))
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        public static bool SignatureEquals(Variable leftVar, Variable rightVar) => 
            (AreVariableNamesIdentical(leftVar.Name, rightVar.Name) && (leftVar.Type == rightVar.Type)) && (leftVar.Modifiers == rightVar.Modifiers);

        [Serializable, CompilerGenerated]
        private sealed class <>c
        {
            public static readonly ActivityComparer.<>c <>9 = new ActivityComparer.<>c();
            public static Func<Variable, bool> <>9__6_0;

            internal bool <IsAnyNameless>b__6_0(Variable v) => 
                string.IsNullOrEmpty(v.Name);
        }

        private class PrivateIdSpaceMatcher
        {
            private DynamicUpdateMap privateMap;
            private DynamicUpdateMapBuilder.NestedIdSpaceFinalizer nestedFinalizer;
            private IdSpace originalPrivateIdSpace;
            private IdSpace updatedPrivateIdSpace;
            private Queue<Tuple<Activity, Activity>> matchedActivities;
            private bool argumentChangeDetected;

            public PrivateIdSpaceMatcher(DynamicUpdateMapBuilder.NestedIdSpaceFinalizer nestedFinalizer, IdSpace originalPrivateIdSpace, IdSpace updatedPrivateIdSpace)
            {
                DynamicUpdateMap map1 = new DynamicUpdateMap {
                    IsForImplementation = true,
                    NewDefinitionMemberCount = updatedPrivateIdSpace.MemberCount
                };
                this.privateMap = map1;
                this.nestedFinalizer = nestedFinalizer;
                this.argumentChangeDetected = false;
                this.originalPrivateIdSpace = originalPrivateIdSpace;
                this.updatedPrivateIdSpace = updatedPrivateIdSpace;
                this.matchedActivities = new Queue<Tuple<Activity, Activity>>();
            }

            private bool AddEqualChildren(Activity currentActivity, Activity originalActivity)
            {
                this.PrepareToMatchSubtree(currentActivity, originalActivity);
                return true;
            }

            private bool CompareDelegateEqualityAndAddActivitiesPair(ActivityDelegate currentDelegate, ActivityDelegate originalDelegate)
            {
                if (!ActivityComparer.CompareDelegateEquality(currentDelegate, originalDelegate))
                {
                    return false;
                }
                if (currentDelegate.Handler != null)
                {
                    this.PrepareToMatchSubtree(currentDelegate.Handler, originalDelegate.Handler);
                }
                return true;
            }

            private bool CompareVariableEqualityAndAddActivitiesPair(Variable currentVariable, Variable originalVariable)
            {
                if (!ActivityComparer.CompareVariableEquality(currentVariable, originalVariable))
                {
                    return false;
                }
                if (currentVariable.Default != null)
                {
                    this.PrepareToMatchSubtree(currentVariable.Default, originalVariable.Default);
                }
                return true;
            }

            private static int GetIndexOfNextSubtreeRoot(IdSpace idspace, int previousIndex)
            {
                for (int i = previousIndex + 1; i <= idspace.MemberCount; i++)
                {
                    if (idspace[i].Parent == idspace.Owner)
                    {
                        return i;
                    }
                }
                return -1;
            }

            public bool Match(out DynamicUpdateMap argumentChangesMap)
            {
                argumentChangesMap = null;
                int previousIndex = 0;
                int indexOfNextSubtreeRoot = 0;
                bool flag = false;
                while (!flag)
                {
                    previousIndex = GetIndexOfNextSubtreeRoot(this.originalPrivateIdSpace, previousIndex);
                    indexOfNextSubtreeRoot = GetIndexOfNextSubtreeRoot(this.updatedPrivateIdSpace, indexOfNextSubtreeRoot);
                    if ((previousIndex != -1) && (indexOfNextSubtreeRoot != -1))
                    {
                        this.PrepareToMatchSubtree(this.updatedPrivateIdSpace[indexOfNextSubtreeRoot], this.originalPrivateIdSpace[previousIndex]);
                    }
                    else
                    {
                        if ((previousIndex == -1) && (indexOfNextSubtreeRoot == -1))
                        {
                            flag = true;
                            continue;
                        }
                        return false;
                    }
                }
                while (this.matchedActivities.Count > 0)
                {
                    Tuple<Activity, Activity> tuple = this.matchedActivities.Dequeue();
                    Activity parent = tuple.Item1;
                    Activity activity2 = tuple.Item2;
                    if ((activity2.GetType() != parent.GetType()) || (activity2.RelationshipToParent != parent.RelationshipToParent))
                    {
                        return false;
                    }
                    if (!ActivityComparer.ListEquals<Activity>(ActivityComparer.GetDeclaredChildren(activity2.Children, activity2), ActivityComparer.GetDeclaredChildren(parent.Children, parent), new Func<Activity, Activity, bool>(this.AddEqualChildren)))
                    {
                        return false;
                    }
                    if (!ActivityComparer.ListEquals<Activity>(ActivityComparer.GetDeclaredChildren(activity2.ImportedChildren, activity2), ActivityComparer.GetDeclaredChildren(parent.ImportedChildren, parent), new Func<Activity, Activity, bool>(this.AddEqualChildren)))
                    {
                        return false;
                    }
                    if (!ActivityComparer.ListEquals<ActivityDelegate>(ActivityComparer.GetDeclaredDelegates(activity2.Delegates, activity2), ActivityComparer.GetDeclaredDelegates(parent.Delegates, parent), new Func<ActivityDelegate, ActivityDelegate, bool>(this.CompareDelegateEqualityAndAddActivitiesPair)))
                    {
                        return false;
                    }
                    if (!ActivityComparer.ListEquals<ActivityDelegate>(ActivityComparer.GetDeclaredDelegates(activity2.ImportedDelegates, activity2), ActivityComparer.GetDeclaredDelegates(parent.ImportedDelegates, parent), new Func<ActivityDelegate, ActivityDelegate, bool>(this.CompareDelegateEqualityAndAddActivitiesPair)))
                    {
                        return false;
                    }
                    if (!ActivityComparer.ListEquals<Variable>(activity2.RuntimeVariables, parent.RuntimeVariables, new Func<Variable, Variable, bool>(this.CompareVariableEqualityAndAddActivitiesPair)))
                    {
                        return false;
                    }
                    DynamicUpdateMapEntry entry = new DynamicUpdateMapEntry(parent.InternalId, activity2.InternalId);
                    this.privateMap.AddEntry(entry);
                    if (!this.TryMatchingArguments(entry, parent, activity2))
                    {
                        return false;
                    }
                }
                if (this.argumentChangeDetected)
                {
                    argumentChangesMap = this.privateMap;
                }
                return true;
            }

            private void PrepareToMatchSubtree(Activity currentActivity, Activity originalActivity)
            {
                if ((originalActivity.MemberOf == this.originalPrivateIdSpace) || (currentActivity.MemberOf == this.updatedPrivateIdSpace))
                {
                    this.matchedActivities.Enqueue(new Tuple<Activity, Activity>(originalActivity, currentActivity));
                }
            }

            private bool TryMatchingArguments(DynamicUpdateMapEntry entry, Activity originalActivity, Activity currentActivity)
            {
                IList<ArgumentInfo> oldArguments = ArgumentInfo.List(originalActivity);
                this.nestedFinalizer.CreateArgumentEntries(entry, currentActivity.RuntimeArguments, oldArguments);
                if (entry.HasEnvironmentUpdates)
                {
                    if (entry.EnvironmentUpdateMap.HasArgumentEntries)
                    {
                        foreach (EnvironmentUpdateMapEntry entry2 in entry.EnvironmentUpdateMap.ArgumentEntries)
                        {
                            if (!entry2.IsAddition)
                            {
                                RuntimeArgument originalArg = originalActivity.RuntimeArguments[entry2.OldOffset];
                                RuntimeArgument updatedArg = currentActivity.RuntimeArguments[entry2.NewOffset];
                                if (!this.TryPreparingArgumentExpressions(originalArg, updatedArg))
                                {
                                    return false;
                                }
                            }
                        }
                    }
                    IList<ArgumentInfo> list2 = ArgumentInfo.List(currentActivity);
                    foreach (RuntimeArgument argument3 in originalActivity.RuntimeArguments)
                    {
                        if (((list2.IndexOf(new ArgumentInfo(argument3)) == -1) && argument3.IsBound) && ((argument3.BoundArgument.Expression != null) && (argument3.BoundArgument.Expression.MemberOf == originalActivity.MemberOf)))
                        {
                            this.privateMap.AddEntry(new DynamicUpdateMapEntry(argument3.BoundArgument.Expression.InternalId, 0));
                        }
                    }
                    DynamicUpdateMapBuilder.Finalizer.FillEnvironmentMapMemberCounts(entry.EnvironmentUpdateMap, currentActivity, originalActivity, oldArguments);
                    this.argumentChangeDetected = true;
                }
                else if ((currentActivity.RuntimeArguments != null) && (currentActivity.RuntimeArguments.Count > 0))
                {
                    for (int i = 0; i < currentActivity.RuntimeArguments.Count; i++)
                    {
                        if (!this.TryPreparingArgumentExpressions(originalActivity.RuntimeArguments[i], currentActivity.RuntimeArguments[i]))
                        {
                            return false;
                        }
                    }
                }
                if (entry.IsRuntimeUpdateBlocked)
                {
                    entry.EnvironmentUpdateMap = null;
                }
                return true;
            }

            private bool TryPreparingArgumentExpressions(RuntimeArgument originalArg, RuntimeArgument updatedArg)
            {
                if (!ActivityComparer.CompareArgumentEquality(updatedArg, originalArg))
                {
                    return false;
                }
                if ((updatedArg.BoundArgument != null) && (updatedArg.BoundArgument.Expression != null))
                {
                    this.PrepareToMatchSubtree(updatedArg.BoundArgument.Expression, originalArg.BoundArgument.Expression);
                }
                return true;
            }
        }
    }
}

