﻿namespace System.Activities.DynamicUpdate
{
    using System;
    using System.Runtime.CompilerServices;
    using System.Runtime.Serialization;

    [DataContract]
    internal class EnvironmentUpdateMapEntry
    {
        internal const int NonExistent = -1;

        internal static EnvironmentUpdateMapEntry Merge(EnvironmentUpdateMapEntry first, EnvironmentUpdateMapEntry second)
        {
            if ((first == null) || (second == null))
            {
                return (first ?? second);
            }
            if (first.OldOffset == second.NewOffset)
            {
                return null;
            }
            return new EnvironmentUpdateMapEntry { 
                OldOffset = first.OldOffset,
                NewOffset = second.NewOffset,
                IsNewHandle = first.IsNewHandle
            };
        }

        [DataMember(EmitDefaultValue=false)]
        public int OldOffset { get; set; }

        [DataMember(EmitDefaultValue=false)]
        public int NewOffset { get; set; }

        [DataMember(EmitDefaultValue=false)]
        public bool IsNewHandle { get; set; }

        internal bool IsAddition =>
            this.OldOffset == -1;
    }
}

