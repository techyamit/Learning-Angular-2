﻿namespace System.Activities.DynamicUpdate
{
    using Microsoft.VisualBasic.Activities;
    using System;
    using System.Activities;
    using System.Activities.Expressions;
    using System.Activities.Validation;
    using System.Collections.Generic;
    using System.Runtime.InteropServices;
    using System.Xaml;

    public static class DynamicUpdateServices
    {
        private static Func<Activity, Exception> onInvalidActivityToBlockUpdate = new Func<Activity, Exception>(DynamicUpdateServices.OnInvalidActivityToBlockUpdate);
        private static Func<Activity, Exception> onInvalidImplementationMapAssociation = new Func<Activity, Exception>(DynamicUpdateServices.OnInvalidImplementationMapAssociation);
        private static AttachableMemberIdentifier implementationMapProperty = new AttachableMemberIdentifier(typeof(DynamicUpdateServices), "ImplementationMap");

        public static DynamicUpdateMap CreateUpdateMap(Activity updatedWorkflowDefinition) => 
            CreateUpdateMap(updatedWorkflowDefinition, null);

        public static DynamicUpdateMap CreateUpdateMap(ActivityBuilder updatedActivityDefinition) => 
            CreateUpdateMap(updatedActivityDefinition, null);

        public static DynamicUpdateMap CreateUpdateMap(Activity updatedWorkflowDefinition, IEnumerable<Activity> disallowUpdateInsideActivities) => 
            CreateUpdateMap(updatedWorkflowDefinition, disallowUpdateInsideActivities, out _);

        public static DynamicUpdateMap CreateUpdateMap(ActivityBuilder updatedActivityDefinition, IEnumerable<Activity> disallowUpdateInsideActivities) => 
            CreateUpdateMap(updatedActivityDefinition, disallowUpdateInsideActivities, out _);

        public static DynamicUpdateMap CreateUpdateMap(Activity updatedWorkflowDefinition, IEnumerable<Activity> disallowUpdateInsideActivities, out IList<ActivityBlockingUpdate> activitiesBlockingUpdate)
        {
            if (updatedWorkflowDefinition == null)
            {
                throw FxTrace.Exception.ArgumentNull("updatedWorkflowDefinition");
            }
            Activity originalDefinition = DynamicUpdateInfo.GetOriginalDefinition(updatedWorkflowDefinition);
            if (originalDefinition == null)
            {
                throw FxTrace.Exception.Argument("updatedWorkflowDefinition", System.Activities.SR.MustCallPrepareBeforeFinalize);
            }
            DynamicUpdateMap map = InternalTryCreateUpdateMap(updatedWorkflowDefinition, originalDefinition, disallowUpdateInsideActivities, false, out activitiesBlockingUpdate);
            DynamicUpdateInfo.SetOriginalDefinition(updatedWorkflowDefinition, null);
            foreach (object obj2 in DynamicUpdateMap.CalculateMapItems(updatedWorkflowDefinition).Keys)
            {
                DynamicUpdateInfo.SetMapItem(obj2, null);
            }
            return map;
        }

        public static DynamicUpdateMap CreateUpdateMap(ActivityBuilder updatedActivityDefinition, IEnumerable<Activity> disallowUpdateInsideActivities, out IList<ActivityBlockingUpdate> activitiesBlockingUpdate)
        {
            if (updatedActivityDefinition == null)
            {
                throw FxTrace.Exception.ArgumentNull("updatedActivityDefinition");
            }
            ActivityBuilder originalActivityBuilder = DynamicUpdateInfo.GetOriginalActivityBuilder(updatedActivityDefinition);
            if (originalActivityBuilder == null)
            {
                throw FxTrace.Exception.Argument("updatedActivityDefinition", System.Activities.SR.MustCallPrepareBeforeFinalize);
            }
            Activity dynamicActivity = GetDynamicActivity(originalActivityBuilder);
            Activity updatedDefinition = GetDynamicActivity(updatedActivityDefinition);
            DynamicUpdateMap map = InternalTryCreateUpdateMap(updatedDefinition, dynamicActivity, disallowUpdateInsideActivities, true, out activitiesBlockingUpdate);
            DynamicUpdateInfo.SetOriginalActivityBuilder(updatedActivityDefinition, null);
            foreach (object obj2 in DynamicUpdateMap.CalculateImplementationMapItems(updatedDefinition).Keys)
            {
                DynamicUpdateInfo.SetMapItem(obj2, null);
            }
            return map;
        }

        private static DynamicActivity GetDynamicActivity(ActivityBuilder activityDefinition)
        {
            DynamicActivity target = new DynamicActivity {
                Name = activityDefinition.Name
            };
            foreach (DynamicActivityProperty property in activityDefinition.Properties)
            {
                target.Properties.Add(property);
            }
            foreach (Attribute attribute in activityDefinition.Attributes)
            {
                target.Attributes.Add(attribute);
            }
            foreach (Constraint constraint in activityDefinition.Constraints)
            {
                target.Constraints.Add(constraint);
            }
            target.Implementation = () => activityDefinition.Implementation;
            VisualBasicSettings settings = VisualBasic.GetSettings(activityDefinition);
            if (settings != null)
            {
                VisualBasic.SetSettings(target, settings);
            }
            IList<string> namespacesForImplementation = TextExpression.GetNamespacesForImplementation(activityDefinition);
            if (namespacesForImplementation.Count > 0)
            {
                TextExpression.SetNamespacesForImplementation(target, namespacesForImplementation);
            }
            IList<AssemblyReference> referencesForImplementation = TextExpression.GetReferencesForImplementation(activityDefinition);
            if (referencesForImplementation.Count > 0)
            {
                TextExpression.SetReferencesForImplementation(target, referencesForImplementation);
            }
            return target;
        }

        public static DynamicUpdateMap GetImplementationMap(Activity targetActivity)
        {
            if (AttachablePropertyServices.TryGetProperty<DynamicUpdateMap>(targetActivity, implementationMapProperty, out DynamicUpdateMap map))
            {
                return map;
            }
            return null;
        }

        private static void InternalPrepareForUpdate(object definitionToBeUpdated, bool forImplementation)
        {
            object result;
            IDictionary<object, DynamicUpdateMapItem> dictionary;
            using (XamlObjectReader reader = new XamlObjectReader(definitionToBeUpdated))
            {
                using (XamlObjectWriter writer = new XamlObjectWriter(reader.SchemaContext))
                {
                    XamlServices.Transform(reader, writer);
                    result = writer.Result;
                }
            }
            if (!forImplementation)
            {
                DynamicUpdateInfo.SetOriginalDefinition(definitionToBeUpdated, (Activity) result);
                dictionary = DynamicUpdateMap.CalculateMapItems((Activity) definitionToBeUpdated);
            }
            else
            {
                DynamicUpdateInfo.SetOriginalActivityBuilder(definitionToBeUpdated, (ActivityBuilder) result);
                dictionary = DynamicUpdateMap.CalculateImplementationMapItems(GetDynamicActivity((ActivityBuilder) definitionToBeUpdated));
            }
            foreach (KeyValuePair<object, DynamicUpdateMapItem> pair in dictionary)
            {
                DynamicUpdateInfo.SetMapItem(pair.Key, pair.Value);
            }
        }

        private static DynamicUpdateMap InternalTryCreateUpdateMap(Activity updatedDefinition, Activity originalDefinition, IEnumerable<Activity> disallowUpdateInsideActivities, bool forImplementation, out IList<ActivityBlockingUpdate> activitiesBlockingUpdate)
        {
            DynamicUpdateMapBuilder builder = new DynamicUpdateMapBuilder {
                ForImplementation = forImplementation,
                LookupMapItem = new Func<object, DynamicUpdateMapItem>(DynamicUpdateInfo.GetMapItem),
                LookupImplementationMap = new Func<Activity, DynamicUpdateMap>(DynamicUpdateServices.GetImplementationMap),
                UpdatedWorkflowDefinition = updatedDefinition,
                OriginalWorkflowDefinition = originalDefinition,
                OnInvalidActivityToBlockUpdate = onInvalidActivityToBlockUpdate,
                OnInvalidImplementationMapAssociation = onInvalidImplementationMapAssociation
            };
            if (disallowUpdateInsideActivities != null)
            {
                foreach (Activity activity in disallowUpdateInsideActivities)
                {
                    builder.DisallowUpdateInside.Add(activity);
                }
            }
            return builder.CreateMap(out activitiesBlockingUpdate);
        }

        private static Exception OnInvalidActivityToBlockUpdate(Activity activity) => 
            new ArgumentException(System.Activities.SR.InvalidActivityToBlockUpdateServices(activity), "disallowUpdateInsideActivities");

        private static Exception OnInvalidImplementationMapAssociation(Activity activity) => 
            new InvalidOperationException(System.Activities.SR.InvalidImplementationMapAssociationServices(activity));

        public static void PrepareForUpdate(Activity workflowDefinitionToBeUpdated)
        {
            if (workflowDefinitionToBeUpdated == null)
            {
                throw FxTrace.Exception.ArgumentNull("workflowDefinitionToBeUpdated");
            }
            InternalPrepareForUpdate(workflowDefinitionToBeUpdated, false);
        }

        public static void PrepareForUpdate(ActivityBuilder activityDefinitionToBeUpdated)
        {
            if (activityDefinitionToBeUpdated == null)
            {
                throw FxTrace.Exception.ArgumentNull("activityDefinitionToBeUpdated");
            }
            InternalPrepareForUpdate(activityDefinitionToBeUpdated, true);
        }

        public static void SetImplementationMap(Activity targetActivity, DynamicUpdateMap implementationMap)
        {
            if (implementationMap != null)
            {
                AttachablePropertyServices.SetProperty(targetActivity, implementationMapProperty, implementationMap);
            }
            else
            {
                AttachablePropertyServices.RemoveProperty(targetActivity, implementationMapProperty);
            }
        }
    }
}

