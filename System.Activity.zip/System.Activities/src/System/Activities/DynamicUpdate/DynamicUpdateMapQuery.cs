﻿namespace System.Activities.DynamicUpdate
{
    using System;
    using System.Activities;
    using System.Runtime.InteropServices;

    public class DynamicUpdateMapQuery
    {
        private DynamicUpdateMap map;
        private Activity updatedWorkflowDefinition;
        private Activity originalWorkflowDefinition;

        internal DynamicUpdateMapQuery(DynamicUpdateMap map, Activity updatedWorkflowDefinition, Activity originalWorkflowDefinition)
        {
            this.map = map;
            this.updatedWorkflowDefinition = updatedWorkflowDefinition;
            this.originalWorkflowDefinition = originalWorkflowDefinition;
        }

        public bool CanApplyUpdateWhileRunning(Activity activity)
        {
            if (activity == null)
            {
                throw FxTrace.Exception.ArgumentNull("activity");
            }
            return this.CanApplyUpdateWhileRunning(activity, this.IsInNewDefinition(activity, false));
        }

        private bool CanApplyUpdateWhileRunning(Activity activity, bool isInNewDefinition)
        {
            Activity parent = activity;
            IdSpace memberOf = activity.MemberOf;
            do
            {
                DynamicUpdateMapEntry entry = null;
                if (isInNewDefinition)
                {
                    this.map.TryGetUpdateEntryByNewId(parent.InternalId, out entry);
                }
                else if (parent.MemberOf == memberOf)
                {
                    this.map.TryGetUpdateEntry(parent.InternalId, out entry);
                }
                if ((entry != null) && (((entry.NewActivityId < 1) || entry.IsRuntimeUpdateBlocked) || entry.IsUpdateBlockedByUpdateAuthor))
                {
                    return false;
                }
                parent = parent.Parent;
            }
            while ((parent != null) && (parent.MemberOf == memberOf));
            return true;
        }

        public Activity FindMatch(Activity activity)
        {
            if (activity == null)
            {
                throw FxTrace.Exception.ArgumentNull("activity");
            }
            if (this.IsInNewDefinition(activity, false))
            {
                return this.MatchNewToOld(activity);
            }
            return this.MatchOldToNew(activity);
        }

        public Variable FindMatch(Variable variable)
        {
            if (variable == null)
            {
                throw FxTrace.Exception.ArgumentNull("variable");
            }
            if (this.IsInNewDefinition(variable))
            {
                return this.MatchNewToOld(variable);
            }
            return this.MatchOldToNew(variable);
        }

        private bool IsInNewDefinition(Variable variable)
        {
            if (variable.Owner == null)
            {
                throw FxTrace.Exception.Argument("variable", System.Activities.SR.QueryVariableIsNotInDefinition);
            }
            if (!variable.IsPublic)
            {
                throw FxTrace.Exception.Argument("variable", System.Activities.SR.QueryVariableIsNotPublic);
            }
            return this.IsInNewDefinition(variable.Owner, true);
        }

        private bool IsInNewDefinition(Activity activity, bool isVariableOwner = false)
        {
            bool flag = false;
            if (activity.RootActivity == this.updatedWorkflowDefinition)
            {
                flag = true;
            }
            else if (activity.RootActivity == this.originalWorkflowDefinition)
            {
                flag = false;
            }
            else
            {
                this.ThrowNotInDefinition(isVariableOwner, System.Activities.SR.QueryVariableIsNotInDefinition, System.Activities.SR.QueryActivityIsNotInDefinition);
            }
            if (this.map.IsForImplementation)
            {
                if (activity.MemberOf.Owner != activity.RootActivity)
                {
                    this.ThrowNotInDefinition(isVariableOwner, System.Activities.SR.QueryVariableIsPublic(activity.RootActivity), System.Activities.SR.QueryActivityIsPublic(activity.RootActivity));
                }
                return flag;
            }
            if (activity.MemberOf != activity.RootActivity.MemberOf)
            {
                this.ThrowNotInDefinition(isVariableOwner, System.Activities.SR.QueryVariableIsInImplementation(activity.MemberOf.Owner), System.Activities.SR.QueryActivityIsInImplementation(activity.MemberOf.Owner));
            }
            return flag;
        }

        private Activity MatchNewToOld(Activity newActivity) => 
            this.MatchNewToOld(newActivity, out _);

        private Variable MatchNewToOld(Variable newVariable)
        {
            if (!newVariable.IsPublic)
            {
                return null;
            }
            Activity activity = this.MatchNewToOld(newVariable.Owner, out DynamicUpdateMapEntry entry);
            if (activity == null)
            {
                return null;
            }
            int index = newVariable.Owner.RuntimeVariables.IndexOf(newVariable);
            int? nullable = entry.HasEnvironmentUpdates ? entry.EnvironmentUpdateMap.GetOldVariableIndex(index) : new int?(index);
            if (!nullable.HasValue)
            {
                return null;
            }
            return activity.RuntimeVariables[nullable.Value];
        }

        private Activity MatchNewToOld(Activity newActivity, out DynamicUpdateMapEntry entry)
        {
            entry = null;
            if (this.map.TryGetUpdateEntryByNewId(newActivity.InternalId, out entry))
            {
                IdSpace parentOf;
                if (this.map.IsForImplementation)
                {
                    parentOf = this.originalWorkflowDefinition.ParentOf;
                }
                else
                {
                    parentOf = this.originalWorkflowDefinition.MemberOf;
                }
                if (parentOf != null)
                {
                    return parentOf[entry.OldActivityId];
                }
            }
            return null;
        }

        private Activity MatchOldToNew(Activity oldActivity) => 
            this.MatchOldToNew(oldActivity, out _);

        private Variable MatchOldToNew(Variable oldVariable)
        {
            if (!oldVariable.IsPublic)
            {
                return null;
            }
            Activity activity = this.MatchOldToNew(oldVariable.Owner, out DynamicUpdateMapEntry entry);
            if (activity == null)
            {
                return null;
            }
            int index = oldVariable.Owner.RuntimeVariables.IndexOf(oldVariable);
            int? nullable = entry.HasEnvironmentUpdates ? entry.EnvironmentUpdateMap.GetNewVariableIndex(index) : new int?(index);
            if (!nullable.HasValue)
            {
                return null;
            }
            return activity.RuntimeVariables[nullable.Value];
        }

        private Activity MatchOldToNew(Activity oldActivity, out DynamicUpdateMapEntry entry)
        {
            entry = null;
            if (this.map.TryGetUpdateEntry(oldActivity.InternalId, out entry) && (entry.NewActivityId > 0))
            {
                IdSpace parentOf;
                if (this.map.IsForImplementation)
                {
                    parentOf = this.updatedWorkflowDefinition.ParentOf;
                }
                else
                {
                    parentOf = this.updatedWorkflowDefinition.MemberOf;
                }
                if (parentOf != null)
                {
                    return parentOf[entry.NewActivityId];
                }
            }
            return null;
        }

        private void ThrowNotInDefinition(bool isVariableOwner, string variableMessage, string activityMessage)
        {
            if (isVariableOwner)
            {
                throw FxTrace.Exception.Argument("variable", variableMessage);
            }
            throw FxTrace.Exception.Argument("activity", activityMessage);
        }
    }
}

