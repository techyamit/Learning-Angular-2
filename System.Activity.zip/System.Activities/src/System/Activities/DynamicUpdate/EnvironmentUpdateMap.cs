﻿namespace System.Activities.DynamicUpdate
{
    using System;
    using System.Activities;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;
    using System.Runtime.Serialization;

    [DataContract]
    internal class EnvironmentUpdateMap
    {
        private IList<EnvironmentUpdateMapEntry> variableEntries;
        private IList<EnvironmentUpdateMapEntry> privateVariableEntries;
        private IList<EnvironmentUpdateMapEntry> argumentEntries;

        private static EnvironmentUpdateMapEntry FindByNewIndex(IList<EnvironmentUpdateMapEntry> entries, int newIndex)
        {
            foreach (EnvironmentUpdateMapEntry entry in entries)
            {
                if (entry.NewOffset == newIndex)
                {
                    return entry;
                }
            }
            return null;
        }

        internal int? GetNewPrivateVariableIndex(int oldIndex)
        {
            foreach (EnvironmentUpdateMapEntry entry in this.PrivateVariableEntries)
            {
                if (entry.OldOffset == oldIndex)
                {
                    return new int?(entry.NewOffset);
                }
            }
            return null;
        }

        internal int? GetNewVariableIndex(int oldIndex)
        {
            foreach (EnvironmentUpdateMapEntry entry in this.VariableEntries)
            {
                if (entry.OldOffset == oldIndex)
                {
                    return new int?(entry.NewOffset);
                }
            }
            return null;
        }

        internal int? GetOldVariableIndex(int newIndex)
        {
            EnvironmentUpdateMapEntry entry = FindByNewIndex(this.VariableEntries, newIndex);
            if ((entry != null) && !entry.IsAddition)
            {
                return new int?(entry.OldOffset);
            }
            return null;
        }

        internal static EnvironmentUpdateMap Merge(EnvironmentUpdateMap first, EnvironmentUpdateMap second, DynamicUpdateMap.MergeErrorContext errorContext)
        {
            if ((first == null) || (second == null))
            {
                return (first ?? second);
            }
            ThrowIfMapsIncompatible(first, second, errorContext);
            EnvironmentUpdateMap map = new EnvironmentUpdateMap {
                OldArgumentCount = first.OldArgumentCount,
                NewArgumentCount = second.NewArgumentCount,
                OldVariableCount = first.OldVariableCount,
                NewVariableCount = second.NewVariableCount,
                OldPrivateVariableCount = first.OldPrivateVariableCount,
                NewPrivateVariableCount = second.NewPrivateVariableCount
            };
            map.variableEntries = Merge(map.NewVariableCount, first.VariableEntries, second.VariableEntries);
            map.privateVariableEntries = Merge(map.NewPrivateVariableCount, first.PrivateVariableEntries, second.PrivateVariableEntries);
            map.argumentEntries = Merge(map.NewArgumentCount, first.ArgumentEntries, second.ArgumentEntries);
            if ((((map.OldArgumentCount == map.NewArgumentCount) && (map.OldVariableCount == map.NewVariableCount)) && ((map.OldPrivateVariableCount == map.NewPrivateVariableCount) && !map.HasArgumentEntries)) && (!map.HasVariableEntries && !map.HasPrivateVariableEntries))
            {
                return null;
            }
            return map;
        }

        private static IList<EnvironmentUpdateMapEntry> Merge(int finalCount, IList<EnvironmentUpdateMapEntry> first, IList<EnvironmentUpdateMapEntry> second)
        {
            List<EnvironmentUpdateMapEntry> list = new List<EnvironmentUpdateMapEntry>();
            for (int i = 0; i < finalCount; i++)
            {
                EnvironmentUpdateMapEntry item = MergeEntry(i, first, second);
                if (item != null)
                {
                    list.Add(item);
                }
            }
            if (list.Count <= 0)
            {
                return null;
            }
            return list;
        }

        private static EnvironmentUpdateMapEntry MergeEntry(int finalIndex, IList<EnvironmentUpdateMapEntry> first, IList<EnvironmentUpdateMapEntry> second)
        {
            EnvironmentUpdateMapEntry entry2;
            EnvironmentUpdateMapEntry entry = FindByNewIndex(second, finalIndex);
            if (entry != null)
            {
                entry2 = entry.IsAddition ? null : FindByNewIndex(first, entry.OldOffset);
            }
            else
            {
                entry2 = FindByNewIndex(first, finalIndex);
            }
            return EnvironmentUpdateMapEntry.Merge(entry2, entry);
        }

        private static void ThrowIfMapsIncompatible(EnvironmentUpdateMap first, EnvironmentUpdateMap second, DynamicUpdateMap.MergeErrorContext errorContext)
        {
            if (((first.NewArgumentCount != second.OldArgumentCount) || (first.NewVariableCount != second.OldVariableCount)) || (first.NewPrivateVariableCount != second.OldPrivateVariableCount))
            {
                errorContext.Throw(System.Activities.SR.InvalidMergeMapEnvironmentCount(first.NewArgumentCount, first.NewVariableCount, first.NewPrivateVariableCount, second.OldArgumentCount, second.OldVariableCount, second.OldPrivateVariableCount));
            }
        }

        [DataMember(EmitDefaultValue=false)]
        public int NewArgumentCount { get; set; }

        [DataMember(EmitDefaultValue=false)]
        public int OldArgumentCount { get; set; }

        [DataMember(EmitDefaultValue=false)]
        public int NewVariableCount { get; set; }

        [DataMember(EmitDefaultValue=false)]
        public int OldVariableCount { get; set; }

        [DataMember(EmitDefaultValue=false)]
        public int NewPrivateVariableCount { get; set; }

        [DataMember(EmitDefaultValue=false)]
        public int OldPrivateVariableCount { get; set; }

        [DataMember(EmitDefaultValue=false)]
        public int RuntimeDelegateArgumentCount { get; set; }

        [DataMember(EmitDefaultValue=false, Name="variableEntries")]
        internal IList<EnvironmentUpdateMapEntry> SerializedVariableEntries
        {
            get => 
                this.variableEntries;
            set => 
                this.variableEntries = value;
        }

        [DataMember(EmitDefaultValue=false, Name="privateVariableEntries")]
        internal IList<EnvironmentUpdateMapEntry> SerializedPrivateVariableEntries
        {
            get => 
                this.privateVariableEntries;
            set => 
                this.privateVariableEntries = value;
        }

        [DataMember(EmitDefaultValue=false, Name="argumentEntries")]
        internal IList<EnvironmentUpdateMapEntry> SerializedArgumentEntries
        {
            get => 
                this.argumentEntries;
            set => 
                this.argumentEntries = value;
        }

        internal bool IsAdditionToNoSymbols =>
            ((((this.OldArgumentCount + this.OldVariableCount) + this.OldPrivateVariableCount) + this.RuntimeDelegateArgumentCount) == 0) && ((((this.NewArgumentCount + this.NewVariableCount) + this.NewPrivateVariableCount) + this.RuntimeDelegateArgumentCount) > 0);

        internal bool HasVariableEntries =>
            (this.variableEntries != null) && (this.variableEntries.Count > 0);

        internal bool HasPrivateVariableEntries =>
            (this.privateVariableEntries != null) && (this.privateVariableEntries.Count > 0);

        internal bool HasArgumentEntries =>
            (this.argumentEntries != null) && (this.argumentEntries.Count > 0);

        public IList<EnvironmentUpdateMapEntry> VariableEntries
        {
            get
            {
                if (this.variableEntries == null)
                {
                    this.variableEntries = new List<EnvironmentUpdateMapEntry>();
                }
                return this.variableEntries;
            }
        }

        public IList<EnvironmentUpdateMapEntry> PrivateVariableEntries
        {
            get
            {
                if (this.privateVariableEntries == null)
                {
                    this.privateVariableEntries = new List<EnvironmentUpdateMapEntry>();
                }
                return this.privateVariableEntries;
            }
        }

        public IList<EnvironmentUpdateMapEntry> ArgumentEntries
        {
            get
            {
                if (this.argumentEntries == null)
                {
                    this.argumentEntries = new List<EnvironmentUpdateMapEntry>();
                }
                return this.argumentEntries;
            }
        }
    }
}

