﻿namespace System.Activities
{
    using System;
    using System.Collections.Generic;

    public class WorkflowApplicationCompletedEventArgs : WorkflowApplicationEventArgs
    {
        private ActivityInstanceState completionState;
        private Exception terminationException;
        private IDictionary<string, object> outputs;

        internal WorkflowApplicationCompletedEventArgs(System.Activities.WorkflowApplication application, Exception terminationException, ActivityInstanceState completionState, IDictionary<string, object> outputs) : base(application)
        {
            this.terminationException = terminationException;
            this.completionState = completionState;
            this.outputs = outputs;
        }

        public ActivityInstanceState CompletionState =>
            this.completionState;

        public IDictionary<string, object> Outputs
        {
            get
            {
                if (this.outputs == null)
                {
                    this.outputs = ActivityUtilities.EmptyParameters;
                }
                return this.outputs;
            }
        }

        public Exception TerminationException =>
            this.terminationException;
    }
}

