﻿namespace System.Activities
{
    using System;

    public enum UnhandledExceptionAction
    {
        Abort,
        Cancel,
        Terminate
    }
}

