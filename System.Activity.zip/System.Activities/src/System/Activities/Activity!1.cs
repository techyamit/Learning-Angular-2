﻿namespace System.Activities
{
    using System;
    using System.Activities.Expressions;
    using System.Activities.Validation;
    using System.Activities.XamlIntegration;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Runtime;
    using System.Runtime.CompilerServices;
    using System.Windows.Markup;

    [TypeConverter(typeof(ActivityWithResultConverter)), ValueSerializer(typeof(ActivityWithResultValueSerializer))]
    public abstract class Activity<TResult> : ActivityWithResult
    {
        protected Activity()
        {
        }

        public static Activity<TResult> FromValue(TResult constValue) => 
            new Literal<TResult> { Value = constValue };

        public static Activity<TResult> FromVariable(Variable variable)
        {
            if (variable == null)
            {
                throw FxTrace.Exception.ArgumentNull("variable");
            }
            if (TypeHelper.AreTypesCompatible(variable.Type, typeof(TResult)))
            {
                return new VariableValue<TResult> { Variable = variable };
            }
            if (!ActivityUtilities.IsLocationGenericType(typeof(TResult), out Type type) || (type != variable.Type))
            {
                throw FxTrace.Exception.Argument("variable", System.Activities.SR.ConvertVariableToValueExpressionFailed(variable.GetType().FullName, typeof(Activity<TResult>).FullName));
            }
            return (Activity<TResult>) ActivityUtilities.CreateVariableReference(variable);
        }

        public static Activity<TResult> FromVariable(Variable<TResult> variable)
        {
            if (variable == null)
            {
                throw FxTrace.Exception.ArgumentNull("variable");
            }
            return new VariableValue<TResult>(variable);
        }

        internal virtual TResult InternalExecuteInResolutionContext(CodeActivityContext resolutionContext)
        {
            throw Fx.AssertAndThrow("This should only be called on CodeActivity<T>");
        }

        internal override object InternalExecuteInResolutionContextUntyped(CodeActivityContext resolutionContext) => 
            this.InternalExecuteInResolutionContext(resolutionContext);

        private bool IsBoundArgumentCorrect(RuntimeArgument argument, bool createEmptyBindings)
        {
            if (createEmptyBindings)
            {
                return (argument.BoundArgument == this.Result);
            }
            if (this.Result != null)
            {
                return (argument.BoundArgument == this.Result);
            }
            return true;
        }

        internal override bool IsResultArgument(RuntimeArgument argument) => 
            argument == base.ResultRuntimeArgument;

        internal sealed override void OnInternalCacheMetadata(bool createEmptyBindings)
        {
            this.OnInternalCacheMetadataExceptResult(createEmptyBindings);
            bool flag = false;
            IList<RuntimeArgument> runtimeArguments = base.RuntimeArguments;
            int count = 0;
            if (runtimeArguments != null)
            {
                count = runtimeArguments.Count;
                for (int i = 0; i < count; i++)
                {
                    RuntimeArgument argument = runtimeArguments[i];
                    if (argument.Name == "Result")
                    {
                        flag = true;
                        if ((argument.Type != typeof(TResult)) || (argument.Direction != ArgumentDirection.Out))
                        {
                            base.AddTempValidationError(new ValidationError(System.Activities.SR.ResultArgumentHasRequiredTypeAndDirection(typeof(TResult), argument.Direction, argument.Type)));
                        }
                        else if (!this.IsBoundArgumentCorrect(argument, createEmptyBindings))
                        {
                            base.AddTempValidationError(new ValidationError(System.Activities.SR.ResultArgumentMustBeBoundToResultProperty));
                        }
                        else
                        {
                            base.ResultRuntimeArgument = argument;
                        }
                        break;
                    }
                }
            }
            if (!flag)
            {
                base.ResultRuntimeArgument = new RuntimeArgument("Result", typeof(TResult), ArgumentDirection.Out);
                if (this.Result == null)
                {
                    if (createEmptyBindings)
                    {
                        this.Result = new OutArgument<TResult>();
                        Argument.Bind(this.Result, base.ResultRuntimeArgument);
                    }
                    else
                    {
                        OutArgument<TResult> binding = new OutArgument<TResult>();
                        Argument.Bind(binding, base.ResultRuntimeArgument);
                    }
                }
                else
                {
                    Argument.Bind(this.Result, base.ResultRuntimeArgument);
                }
                base.AddArgument(base.ResultRuntimeArgument, createEmptyBindings);
            }
        }

        internal virtual void OnInternalCacheMetadataExceptResult(bool createEmptyBindings)
        {
            base.OnInternalCacheMetadata(createEmptyBindings);
        }

        public static implicit operator Activity<TResult>(TResult constValue) => 
            Activity<TResult>.FromValue(constValue);

        public static implicit operator Activity<TResult>(Variable variable) => 
            Activity<TResult>.FromVariable(variable);

        public static implicit operator Activity<TResult>(Variable<TResult> variable) => 
            Activity<TResult>.FromVariable(variable);

        [DefaultValue((string) null)]
        public OutArgument<TResult> Result { get; set; }

        internal override Type InternalResultType =>
            typeof(TResult);

        internal override OutArgument ResultCore
        {
            get => 
                this.Result;
            set
            {
                this.Result = value as OutArgument<TResult>;
                if ((this.Result == null) && (value != null))
                {
                    throw FxTrace.Exception.Argument("value", System.Activities.SR.ResultArgumentMustBeSpecificType(typeof(TResult)));
                }
            }
        }
    }
}

