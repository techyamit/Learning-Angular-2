﻿namespace System.Activities
{
    using System;
    using System.Activities.Debugger;
    using System.Activities.XamlIntegration;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.Runtime.CompilerServices;
    using System.Windows.Markup;
    using System.Xaml;

    [ContentProperty("Implementation")]
    public sealed class ActivityBuilder : IDebuggableWorkflowTree
    {
        private static AttachableMemberIdentifier propertyReferencePropertyID = new AttachableMemberIdentifier(typeof(ActivityBuilder), "PropertyReference");
        private static AttachableMemberIdentifier propertyReferencesPropertyID = new AttachableMemberIdentifier(typeof(ActivityBuilder), "PropertyReferences");
        private KeyedCollection<string, DynamicActivityProperty> properties;
        private Collection<Constraint> constraints;
        private Collection<Attribute> attributes;

        internal static KeyedCollection<string, DynamicActivityProperty> CreateActivityPropertyCollection() => 
            new ActivityPropertyCollection();

        public static ActivityPropertyReference GetPropertyReference(object target) => 
            GetPropertyReferenceCollection(target).SingleItem;

        private static PropertyReferenceCollection GetPropertyReferenceCollection(object target)
        {
            if (!AttachablePropertyServices.TryGetProperty<PropertyReferenceCollection>(target, propertyReferencesPropertyID, out PropertyReferenceCollection references))
            {
                references = new PropertyReferenceCollection(target);
                AttachablePropertyServices.SetProperty(target, propertyReferencesPropertyID, references);
            }
            return references;
        }

        public static IList<ActivityPropertyReference> GetPropertyReferences(object target) => 
            GetPropertyReferenceCollection(target);

        internal static bool HasPropertyReferences(object target) => 
            AttachablePropertyServices.TryGetProperty<PropertyReferenceCollection>(target, propertyReferencesPropertyID, out PropertyReferenceCollection references) && (references.Count > 0);

        public static void SetPropertyReference(object target, ActivityPropertyReference value)
        {
            GetPropertyReferenceCollection(target).SingleItem = value;
        }

        public static bool ShouldSerializePropertyReference(object target)
        {
            PropertyReferenceCollection propertyReferenceCollection = GetPropertyReferenceCollection(target);
            return ((propertyReferenceCollection.Count == 1) && (propertyReferenceCollection.SingleItem > null));
        }

        public static bool ShouldSerializePropertyReferences(object target)
        {
            PropertyReferenceCollection propertyReferenceCollection = GetPropertyReferenceCollection(target);
            if (propertyReferenceCollection.Count <= 1)
            {
                return (propertyReferenceCollection.SingleItem == null);
            }
            return true;
        }

        Activity IDebuggableWorkflowTree.GetWorkflowRoot() => 
            this.Implementation;

        public string Name { get; set; }

        [DependsOn("Name")]
        public Collection<Attribute> Attributes
        {
            get
            {
                if (this.attributes == null)
                {
                    this.attributes = new Collection<Attribute>();
                }
                return this.attributes;
            }
        }

        [Browsable(false), DependsOn("Attributes")]
        public KeyedCollection<string, DynamicActivityProperty> Properties
        {
            get
            {
                if (this.properties == null)
                {
                    this.properties = new ActivityPropertyCollection();
                }
                return this.properties;
            }
        }

        [DependsOn("Properties"), Browsable(false)]
        public Collection<Constraint> Constraints
        {
            get
            {
                if (this.constraints == null)
                {
                    this.constraints = new Collection<Constraint>();
                }
                return this.constraints;
            }
        }

        [TypeConverter(typeof(ImplementationVersionConverter)), DefaultValue((string) null), DependsOn("Name")]
        public Version ImplementationVersion { get; set; }

        [DefaultValue((string) null), Browsable(false), DependsOn("Constraints")]
        public Activity Implementation { get; set; }

        private class ActivityPropertyCollection : KeyedCollection<string, DynamicActivityProperty>
        {
            protected override string GetKeyForItem(DynamicActivityProperty item) => 
                item.Name;
        }

        private class PropertyReferenceCollection : Collection<ActivityPropertyReference>
        {
            private WeakReference targetObject;
            private int singleItemIndex = -1;

            public PropertyReferenceCollection(object target)
            {
                this.targetObject = new WeakReference(target);
            }

            protected override void ClearItems()
            {
                this.singleItemIndex = -1;
                this.UpdateAttachedProperty();
            }

            protected override void InsertItem(int index, ActivityPropertyReference item)
            {
                base.InsertItem(index, item);
                if (index <= this.singleItemIndex)
                {
                    this.singleItemIndex++;
                }
                else if (base.Count == 1)
                {
                    this.singleItemIndex = 0;
                    this.UpdateAttachedProperty();
                }
            }

            protected override void RemoveItem(int index)
            {
                base.RemoveItem(index);
                if (index < this.singleItemIndex)
                {
                    this.singleItemIndex--;
                }
                else if (index == this.singleItemIndex)
                {
                    this.singleItemIndex = -1;
                    this.UpdateAttachedProperty();
                }
            }

            protected override void SetItem(int index, ActivityPropertyReference item)
            {
                base.SetItem(index, item);
                if (index == this.singleItemIndex)
                {
                    this.UpdateAttachedProperty();
                }
            }

            private void UpdateAttachedProperty()
            {
                object target = this.targetObject.Target;
                if (target != null)
                {
                    if (this.singleItemIndex >= 0)
                    {
                        AttachablePropertyServices.SetProperty(target, ActivityBuilder.propertyReferencePropertyID, base[this.singleItemIndex]);
                    }
                    else
                    {
                        AttachablePropertyServices.RemoveProperty(target, ActivityBuilder.propertyReferencePropertyID);
                    }
                }
            }

            public ActivityPropertyReference SingleItem
            {
                get
                {
                    if (this.singleItemIndex < 0)
                    {
                        return null;
                    }
                    return base[this.singleItemIndex];
                }
                set
                {
                    if (this.singleItemIndex >= 0)
                    {
                        if (value != null)
                        {
                            this.SetItem(this.singleItemIndex, value);
                        }
                        else
                        {
                            this.RemoveItem(this.singleItemIndex);
                        }
                    }
                    else if (value != null)
                    {
                        base.Add(value);
                        if (base.Count > 1)
                        {
                            this.singleItemIndex = base.Count - 1;
                            this.UpdateAttachedProperty();
                        }
                    }
                }
            }
        }
    }
}

