﻿namespace System.Activities.DurableInstancing
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime;
    using System.Runtime.CompilerServices;
    using System.Runtime.DurableInstancing;

    public sealed class ActivatableWorkflowsQueryResult : InstanceStoreQueryResult
    {
        private static readonly ReadOnlyDictionaryInternal<XName, object> emptyDictionary = new ReadOnlyDictionaryInternal<XName, object>(new Dictionary<XName, object>(0));

        public ActivatableWorkflowsQueryResult()
        {
            this.ActivationParameters = new List<IDictionary<XName, object>>(0);
        }

        public ActivatableWorkflowsQueryResult(IDictionary<XName, object> parameters)
        {
            List<IDictionary<XName, object>> list1 = new List<IDictionary<XName, object>> {
                (parameters == null) ? emptyDictionary : new ReadOnlyDictionaryInternal<XName, object>(new Dictionary<XName, object>(parameters))
            };
            this.ActivationParameters = list1;
        }

        public ActivatableWorkflowsQueryResult(IEnumerable<IDictionary<XName, object>> parameters)
        {
            if (parameters == null)
            {
                this.ActivationParameters = new List<IDictionary<XName, object>>(0);
            }
            else
            {
                this.ActivationParameters = new List<IDictionary<XName, object>>((IEnumerable<IDictionary<XName, object>>) parameters.Select<IDictionary<XName, object>, ReadOnlyDictionaryInternal<XName, object>>(delegate (IDictionary<XName, object> dictionary) {
                    if (dictionary != null)
                    {
                        return new ReadOnlyDictionaryInternal<XName, object>(new Dictionary<XName, object>(dictionary));
                    }
                    return emptyDictionary;
                }));
            }
        }

        public List<IDictionary<XName, object>> ActivationParameters { get; private set; }

        [Serializable, CompilerGenerated]
        private sealed class <>c
        {
            public static readonly ActivatableWorkflowsQueryResult.<>c <>9 = new ActivatableWorkflowsQueryResult.<>c();
            public static Func<IDictionary<XName, object>, ReadOnlyDictionaryInternal<XName, object>> <>9__3_0;

            internal ReadOnlyDictionaryInternal<XName, object> <.ctor>b__3_0(IDictionary<XName, object> dictionary)
            {
                if (dictionary != null)
                {
                    return new ReadOnlyDictionaryInternal<XName, object>(new Dictionary<XName, object>(dictionary));
                }
                return ActivatableWorkflowsQueryResult.emptyDictionary;
            }
        }
    }
}

