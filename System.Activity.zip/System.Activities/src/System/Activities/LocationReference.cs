﻿namespace System.Activities
{
    using System;
    using System.Runtime.CompilerServices;

    public abstract class LocationReference
    {
        protected LocationReference()
        {
        }

        public abstract Location GetLocation(ActivityContext context);
        internal virtual Location GetLocationForRead(ActivityContext context) => 
            this.GetLocation(context);

        internal virtual Location GetLocationForWrite(ActivityContext context) => 
            this.GetLocation(context);

        public string Name =>
            this.NameCore;

        public System.Type Type =>
            this.TypeCore;

        internal int Id { get; set; }

        protected abstract string NameCore { get; }

        protected abstract System.Type TypeCore { get; }
    }
}

