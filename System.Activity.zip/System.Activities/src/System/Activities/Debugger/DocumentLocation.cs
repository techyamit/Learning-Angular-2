﻿namespace System.Activities.Debugger
{
    using System;
    using System.Diagnostics;

    [DebuggerDisplay("({LineNumber.Value}:{LinePosition.Value})")]
    internal class DocumentLocation : IEquatable<DocumentLocation>, IComparable<DocumentLocation>
    {
        private OneBasedCounter lineNumber;
        private OneBasedCounter linePosition;

        internal DocumentLocation(OneBasedCounter lineNumber, OneBasedCounter linePosition)
        {
            UnitTestUtility.Assert(lineNumber > null, "lineNumber should not be null.");
            UnitTestUtility.Assert(linePosition > null, "linePosition should not be null.");
            this.lineNumber = lineNumber;
            this.linePosition = linePosition;
        }

        internal DocumentLocation(int lineNumber, int linePosition) : this(new OneBasedCounter(lineNumber), new OneBasedCounter(linePosition))
        {
        }

        public int CompareTo(DocumentLocation that)
        {
            if (that == null)
            {
                return 1;
            }
            if (this.lineNumber.Value == that.lineNumber.Value)
            {
                return (this.linePosition.Value - that.linePosition.Value);
            }
            return (this.lineNumber.Value - that.lineNumber.Value);
        }

        public bool Equals(DocumentLocation that)
        {
            if (that == null)
            {
                return false;
            }
            return ((this.lineNumber.Value == that.lineNumber.Value) && (this.linePosition.Value == that.linePosition.Value));
        }

        public override int GetHashCode() => 
            this.lineNumber.Value.GetHashCode() ^ this.linePosition.Value.GetHashCode();

        internal OneBasedCounter LineNumber =>
            this.lineNumber;

        internal OneBasedCounter LinePosition =>
            this.linePosition;
    }
}

