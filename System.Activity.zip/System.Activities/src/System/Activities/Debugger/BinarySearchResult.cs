﻿namespace System.Activities.Debugger
{
    using System;
    using System.Diagnostics;

    [DebuggerDisplay("{this.ToString()}")]
    internal class BinarySearchResult
    {
        private int result;
        private int count;

        internal BinarySearchResult(int resultFromBinarySearch, int count)
        {
            this.result = resultFromBinarySearch;
            this.count = count;
        }

        public override string ToString()
        {
            if (this.IsFound)
            {
                return $"Data is found at index {this.FoundIndex}.";
            }
            if (this.IsNextIndexAvailable)
            {
                return $"Data is not found, the next index is {this.NextIndex}.";
            }
            return "Data is not found and there is no next index.";
        }

        internal bool IsFound =>
            this.result >= 0;

        [DebuggerBrowsable(DebuggerBrowsableState.Never)]
        internal int FoundIndex
        {
            get
            {
                UnitTestUtility.Assert(this.IsFound, "We should not call FoundIndex if we cannot find the element.");
                return this.result;
            }
        }

        [DebuggerBrowsable(DebuggerBrowsableState.Never)]
        internal int NextIndex
        {
            get
            {
                UnitTestUtility.Assert(!this.IsFound, "We should not call NextIndex if we found the element.");
                UnitTestUtility.Assert(this.IsNextIndexAvailable, "We should not call NextIndex if next index is not available.");
                return this.NextIndexValue;
            }
        }

        [DebuggerBrowsable(DebuggerBrowsableState.Never)]
        internal bool IsNextIndexAvailable
        {
            get
            {
                UnitTestUtility.Assert(!this.IsFound, "We should not call IsNextIndexAvailable if we found the element.");
                return (this.NextIndexValue != this.count);
            }
        }

        private int NextIndexValue =>
            ~this.result;
    }
}

