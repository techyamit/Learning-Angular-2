﻿namespace System.Activities.Debugger
{
    using System;
    using System.Activities;
    using System.Activities.Debugger.Symbol;
    using System.Activities.XamlIntegration;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.IO;
    using System.Reflection;
    using System.Runtime;
    using System.Runtime.InteropServices;
    using System.Runtime.Serialization;
    using System.Security;
    using System.Security.Permissions;
    using System.Xaml;

    [DebuggerNonUserCode]
    public static class SourceLocationProvider
    {
        public static void CollectMapping(Activity rootActivity1, Activity rootActivity2, Dictionary<object, SourceLocation> mapping, string path)
        {
            CollectMapping(rootActivity1, rootActivity2, mapping, path, null, true);
        }

        private static void CollectMapping(Activity rootActivity1, Activity rootActivity2, Dictionary<object, SourceLocation> mapping, string path, byte[] checksum)
        {
            CollectMapping(rootActivity1, rootActivity2, mapping, path, checksum, true);
        }

        private static void CollectMapping(Activity rootActivity1, Activity rootActivity2, Dictionary<object, SourceLocation> mapping, string path, byte[] checksum, bool requirePrepareForRuntime)
        {
            Activity activity = (rootActivity1.RootActivity != null) ? rootActivity1.RootActivity : rootActivity1;
            if ((requirePrepareForRuntime && !activity.IsRuntimeReady) || (!requirePrepareForRuntime && !activity.IsMetadataFullyCached))
            {
                IList<ValidationError> validationErrors = null;
                ActivityUtilities.CacheRootMetadata(activity, new ActivityLocationReferenceEnvironment(), ProcessActivityTreeOptions.ValidationOptions, null, ref validationErrors);
            }
            Activity activity2 = (rootActivity2.RootActivity != null) ? rootActivity2.RootActivity : rootActivity2;
            if ((((rootActivity1 != rootActivity2) && requirePrepareForRuntime) && !activity2.IsRuntimeReady) || (!requirePrepareForRuntime && !activity2.IsMetadataFullyCached))
            {
                IList<ValidationError> validationErrors = null;
                ActivityUtilities.CacheRootMetadata(activity2, new ActivityLocationReferenceEnvironment(), ProcessActivityTreeOptions.ValidationOptions, null, ref validationErrors);
            }
            Queue<KeyValuePair<Activity, Activity>> queue = new Queue<KeyValuePair<Activity, Activity>>();
            queue.Enqueue(new KeyValuePair<Activity, Activity>(rootActivity1, rootActivity2));
            System.Collections.Generic.HashSet<Activity> set = new System.Collections.Generic.HashSet<Activity>();
            while (queue.Count > 0)
            {
                KeyValuePair<Activity, Activity> pair = queue.Dequeue();
                Activity key = pair.Key;
                Activity activity4 = pair.Value;
                set.Add(key);
                if (TryGetSourceLocation(activity4, path, checksum, out SourceLocation location))
                {
                    mapping.Add(key, location);
                }
                else if (!(activity4 is IExpressionContainer) && !(activity4 is IValueSerializableExpression))
                {
                    Trace.WriteLine("WorkflowDebugger: Does not have corresponding Xaml node for: " + activity4.DisplayName + "\n");
                }
                if ((!(key is IExpressionContainer) && !(activity4 is IExpressionContainer)) && (!(key is IValueSerializableExpression) && !(activity4 is IValueSerializableExpression)))
                {
                    IEnumerator<Activity> enumerator = WorkflowInspectionServices.GetActivities(key).GetEnumerator();
                    IEnumerator<Activity> enumerator2 = WorkflowInspectionServices.GetActivities(activity4).GetEnumerator();
                    bool flag = enumerator.MoveNext();
                    bool flag2 = enumerator2.MoveNext();
                    while (flag & flag2)
                    {
                        if (!set.Contains(enumerator.Current))
                        {
                            if (enumerator.Current.GetType() != enumerator2.Current.GetType())
                            {
                                Trace.WriteLine("Unmatched type: " + enumerator.Current.GetType().FullName + " vs " + enumerator2.Current.GetType().FullName + "\n");
                            }
                            queue.Enqueue(new KeyValuePair<Activity, Activity>(enumerator.Current, enumerator2.Current));
                        }
                        flag = enumerator.MoveNext();
                        flag2 = enumerator2.MoveNext();
                    }
                    if (flag | flag2)
                    {
                        Trace.WriteLine("Unmatched number of children\n");
                    }
                }
            }
        }

        internal static object Deserialize(byte[] buffer, Assembly localAssembly)
        {
            object obj2;
            using (MemoryStream stream = new MemoryStream(buffer))
            {
                using (TextReader reader = new StreamReader(stream))
                {
                    using (XamlDebuggerXmlReader reader2 = new XamlDebuggerXmlReader(reader, new XamlSchemaContext(), localAssembly))
                    {
                        reader2.SourceLocationFound += new EventHandler<SourceLocationFoundEventArgs>(XamlDebuggerXmlReader.SetSourceLocation);
                        using (XamlReader reader3 = ActivityXamlServices.CreateBuilderReader(reader2))
                        {
                            obj2 = XamlServices.Load(reader3);
                        }
                    }
                }
            }
            return obj2;
        }

        public static Dictionary<object, SourceLocation> GetSourceLocations(Activity rootActivity, WorkflowSymbol symbol) => 
            GetSourceLocations(rootActivity, symbol, true);

        internal static Dictionary<object, SourceLocation> GetSourceLocations(Activity rootActivity, WorkflowSymbol symbol, bool translateInternalActivityToOrigin)
        {
            Activity activity = rootActivity.RootActivity ?? rootActivity;
            if (!activity.IsMetadataFullyCached)
            {
                IList<ValidationError> validationErrors = null;
                ActivityUtilities.CacheRootMetadata(activity, new ActivityLocationReferenceEnvironment(), ProcessActivityTreeOptions.ValidationOptions, null, ref validationErrors);
            }
            Dictionary<object, SourceLocation> dictionary = new Dictionary<object, SourceLocation>();
            int[] numArray = rootActivity.QualifiedId.AsIDArray();
            int num = numArray[numArray.Length - 1] - 1;
            foreach (ActivitySymbol symbol2 in symbol.Symbols)
            {
                QualifiedId id = new QualifiedId(symbol2.QualifiedId);
                if (num != 0)
                {
                    int[] idArray = id.AsIDArray();
                    idArray[0] += num;
                    id = new QualifiedId(idArray);
                }
                if (QualifiedId.TryGetElementFromRoot(rootActivity, id, out Activity activity2))
                {
                    object key = activity2;
                    if (translateInternalActivityToOrigin && (activity2.Origin != null))
                    {
                        key = activity2.Origin;
                    }
                    dictionary.Add(key, new SourceLocation(symbol.FileName, symbol.GetChecksum(), symbol2.StartLine, symbol2.StartColumn, symbol2.EndLine, symbol2.EndColumn));
                }
            }
            return dictionary;
        }

        [SecuritySafeCritical]
        internal static Dictionary<object, SourceLocation> GetSourceLocations(Activity rootActivity, out string sourcePath, out bool isTemporaryFile, out byte[] checksum)
        {
            Dictionary<object, SourceLocation> dictionary;
            isTemporaryFile = false;
            checksum = null;
            string str = DebugSymbol.GetSymbol(rootActivity) as string;
            if ((string.IsNullOrEmpty(str) && (rootActivity.Children != null)) && (rootActivity.Children.Count > 0))
            {
                Activity instance = rootActivity.Children[0];
                string symbol = DebugSymbol.GetSymbol(instance) as string;
                if (!string.IsNullOrEmpty(symbol))
                {
                    rootActivity = instance;
                    str = symbol;
                }
            }
            if (!string.IsNullOrEmpty(str))
            {
                try
                {
                    WorkflowSymbol symbol = WorkflowSymbol.Decode(str);
                    if (symbol != null)
                    {
                        sourcePath = symbol.FileName;
                        checksum = symbol.GetChecksum();
                        if (rootActivity.RootActivity != rootActivity)
                        {
                            rootActivity = rootActivity.Parent;
                        }
                        return GetSourceLocations(rootActivity, symbol, false);
                    }
                }
                catch (SerializationException)
                {
                }
            }
            sourcePath = XamlDebuggerXmlReader.GetFileName(rootActivity) as string;
            bool flag = false;
            Assembly localAssembly = rootActivity.GetType().Assembly;
            if (rootActivity.Parent != null)
            {
                localAssembly = rootActivity.Parent.GetType().Assembly;
            }
            if ((rootActivity.Children != null) && (rootActivity.Children.Count > 0))
            {
                Activity instance = rootActivity.Children[0];
                string fileName = XamlDebuggerXmlReader.GetFileName(instance) as string;
                if (!string.IsNullOrEmpty(fileName))
                {
                    rootActivity = instance;
                    sourcePath = fileName;
                }
            }
            try
            {
                Activity workflowRoot;
                checksum = SymbolHelper.CalculateChecksum(sourcePath);
                if (TryGetSourceLocation(rootActivity, sourcePath, checksum, out _))
                {
                    workflowRoot = rootActivity;
                }
                else
                {
                    byte[] buffer;
                    if (Debugger.IsAttached)
                    {
                        flag = true;
                        new FileIOPermission(FileIOPermissionAccess.Read, sourcePath).Assert();
                    }
                    try
                    {
                        FileInfo info = new FileInfo(sourcePath);
                        buffer = new byte[info.Length];
                        using (FileStream stream = new FileStream(sourcePath, FileMode.Open, FileAccess.Read))
                        {
                            stream.Read(buffer, 0, buffer.Length);
                        }
                    }
                    finally
                    {
                        if (flag)
                        {
                            CodeAccessPermission.RevertAssert();
                            flag = false;
                        }
                    }
                    object obj2 = Deserialize(buffer, localAssembly);
                    IDebuggableWorkflowTree tree = obj2 as IDebuggableWorkflowTree;
                    if (tree != null)
                    {
                        workflowRoot = tree.GetWorkflowRoot();
                    }
                    else
                    {
                        workflowRoot = obj2 as Activity;
                    }
                }
                dictionary = new Dictionary<object, SourceLocation>();
                if (workflowRoot != null)
                {
                    CollectMapping(rootActivity, workflowRoot, dictionary, sourcePath, checksum);
                }
            }
            catch (Exception)
            {
                if (PartialTrustHelpers.AppDomainFullyTrusted)
                {
                    throw;
                }
                return new Dictionary<object, SourceLocation>();
            }
            return dictionary;
        }

        public static ICollection<ActivitySymbol> GetSymbols(Activity rootActivity, Dictionary<object, SourceLocation> sourceLocations)
        {
            List<ActivitySymbol> list = new List<ActivitySymbol>();
            Activity activity = (rootActivity.RootActivity != null) ? rootActivity.RootActivity : rootActivity;
            if (!activity.IsMetadataFullyCached)
            {
                IList<ValidationError> validationErrors = null;
                ActivityUtilities.CacheRootMetadata(activity, new ActivityLocationReferenceEnvironment(), ProcessActivityTreeOptions.ValidationOptions, null, ref validationErrors);
            }
            Queue<Activity> queue = new Queue<Activity>();
            queue.Enqueue(activity);
            System.Collections.Generic.HashSet<Activity> set = new System.Collections.Generic.HashSet<Activity>();
            while (queue.Count > 0)
            {
                Activity item = queue.Dequeue();
                object key = (item.Origin == null) ? item : item.Origin;
                if (!set.Contains(item) && sourceLocations.TryGetValue(key, out SourceLocation location))
                {
                    ActivitySymbol symbol1 = new ActivitySymbol {
                        QualifiedId = item.QualifiedId.AsByteArray(),
                        StartLine = location.StartLine,
                        StartColumn = location.StartColumn,
                        EndLine = location.EndLine,
                        EndColumn = location.EndColumn
                    };
                    list.Add(symbol1);
                }
                set.Add(item);
                foreach (Activity activity3 in WorkflowInspectionServices.GetActivities(item))
                {
                    queue.Enqueue(activity3);
                }
            }
            return list;
        }

        private static bool TryGetSourceLocation(object obj, string path, byte[] checksum, out SourceLocation sourceLocation)
        {
            sourceLocation = null;
            if (((AttachablePropertyServices.TryGetProperty<int>(obj, XamlDebuggerXmlReader.StartLineName, out int num) && AttachablePropertyServices.TryGetProperty<int>(obj, XamlDebuggerXmlReader.StartColumnName, out int num2)) && (AttachablePropertyServices.TryGetProperty<int>(obj, XamlDebuggerXmlReader.EndLineName, out int num3) && AttachablePropertyServices.TryGetProperty<int>(obj, XamlDebuggerXmlReader.EndColumnName, out int num4))) && SourceLocation.IsValidRange(num, num2, num3, num4))
            {
                sourceLocation = new SourceLocation(path, checksum, num, num2, num3, num4);
                return true;
            }
            return false;
        }
    }
}

