﻿namespace System.Activities.Debugger
{
    using System;

    internal class OneBasedCounter
    {
        private int value;

        internal OneBasedCounter(int value)
        {
            UnitTestUtility.Assert(value > 0, "value cannot less than one for OneBasedCounter");
            this.value = value;
        }

        internal int Value =>
            this.value;
    }
}

