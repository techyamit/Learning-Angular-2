﻿namespace System.Activities.Debugger
{
    using System;

    internal enum SourceLocationMemberType
    {
        StartLine,
        StartColumn,
        EndLine,
        EndColumn
    }
}

