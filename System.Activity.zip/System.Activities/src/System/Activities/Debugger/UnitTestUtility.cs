﻿namespace System.Activities.Debugger
{
    using System;
    using System.Activities;
    using System.Runtime.CompilerServices;

    internal static class UnitTestUtility
    {
        internal static void Assert(bool condition, string assertionMessage)
        {
            if ((AssertionExceptionFactory != null) && !condition)
            {
                throw FxTrace.Exception.AsError(AssertionExceptionFactory(assertionMessage));
            }
        }

        internal static void TestCleanup()
        {
            AssertionExceptionFactory = null;
        }

        internal static void TestInitialize(Func<string, Exception> createAssertionException)
        {
            AssertionExceptionFactory = createAssertionException;
        }

        internal static Func<string, Exception> AssertionExceptionFactory { get; set; }
    }
}

