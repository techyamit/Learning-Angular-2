﻿namespace System.Activities.Debugger
{
    using System;
    using System.Activities;
    using System.Activities.Debugger.Symbol;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Diagnostics.SymbolStore;
    using System.Globalization;
    using System.Reflection;
    using System.Reflection.Emit;
    using System.Runtime;
    using System.Runtime.CompilerServices;
    using System.Security;
    using System.Security.Permissions;

    [DebuggerNonUserCode]
    public sealed class StateManager : IDisposable
    {
        private static readonly Guid WorkflowLanguageGuid = new Guid("1F1149BB-9732-4EB8-9ED4-FA738768919C");
        private static readonly LocalsItemDescription[] debugInfoDescriptions = new LocalsItemDescription[] { new LocalsItemDescription("debugInfo", typeof(DebugInfo)) };
        private static Type threadWorkerControllerType = typeof(ThreadWorkerController);
        private static MethodInfo islandWorkerMethodInfo = threadWorkerControllerType.GetMethod("IslandWorker", BindingFlags.Public | BindingFlags.Static);
        internal const string MethodWithPrimingPrefix = "_";
        private List<LogicalThread> threads;
        private DynamicModuleManager dynamicModuleManager;
        private Properties properties;
        private bool debugStartedAtRoot;

        internal StateManager() : this(new Properties(), true, null)
        {
        }

        internal StateManager(Properties properties, bool debugStartedAtRoot, DynamicModuleManager dynamicModuleManager)
        {
            this.properties = properties;
            this.debugStartedAtRoot = debugStartedAtRoot;
            this.threads = new List<LogicalThread>();
            if (dynamicModuleManager == null)
            {
                dynamicModuleManager = new DynamicModuleManager(this.properties.ModuleNamePrefix);
            }
            this.dynamicModuleManager = dynamicModuleManager;
        }

        internal void Bake()
        {
            this.Bake(this.properties.TypeNamePrefix, null);
        }

        internal void Bake(string typeName, Dictionary<string, byte[]> checksumCache)
        {
            this.dynamicModuleManager.Bake(typeName, this.properties.TypeNamePrefix, checksumCache);
        }

        internal int CreateLogicalThread(string threadName)
        {
            int threadId = -1;
            for (int i = 1; i < this.threads.Count; i++)
            {
                if (this.threads[i] == null)
                {
                    this.threads[i] = new LogicalThread(i, threadName, this);
                    threadId = i;
                    break;
                }
            }
            if (threadId < 0)
            {
                threadId = this.threads.Count;
                this.threads.Add(new LogicalThread(threadId, threadName, this));
            }
            return threadId;
        }

        internal System.Activities.Debugger.State DefineState(SourceLocation location) => 
            this.DefineState(location, string.Empty, null, 0);

        internal System.Activities.Debugger.State DefineState(SourceLocation location, string name) => 
            this.DefineState(location, name, null, 0);

        internal System.Activities.Debugger.State DefineState(SourceLocation location, string name, LocalsItemDescription[] earlyLocals, int numberOfEarlyLocals) => 
            this.dynamicModuleManager.DefineState(location, name, earlyLocals, numberOfEarlyLocals);

        internal System.Activities.Debugger.State DefineStateWithDebugInfo(SourceLocation location, string name) => 
            this.DefineState(location, name, debugInfoDescriptions, debugInfoDescriptions.Length);

        public void Dispose()
        {
            this.ExitThreads();
        }

        internal void EnterState(int threadIndex, VirtualStackFrame stackFrame)
        {
            this.threads[threadIndex].EnterState(stackFrame);
        }

        internal void EnterState(int threadIndex, System.Activities.Debugger.State state, IDictionary<string, object> locals)
        {
            this.EnterState(threadIndex, new VirtualStackFrame(state, locals));
        }

        public void Exit(int threadIndex)
        {
            this.threads[threadIndex].Exit();
            this.threads[threadIndex] = null;
        }

        internal void ExitThreads()
        {
            foreach (LogicalThread thread in this.threads)
            {
                if (thread != null)
                {
                    thread.Exit();
                }
            }
            this.threads.Clear();
        }

        internal void InvokeWorker(object islandArguments, VirtualStackFrame stackFrame)
        {
            System.Activities.Debugger.State state = stackFrame.State;
            if (!state.DebuggingEnabled)
            {
                ThreadWorkerController.IslandWorker((ThreadWorkerController) islandArguments);
            }
            else
            {
                MethodInfo island = this.dynamicModuleManager.GetIsland(state, this.IsPriming);
                IDictionary<string, object> locals = stackFrame.Locals;
                int numberOfEarlyLocals = state.NumberOfEarlyLocals;
                object[] parameters = new object[2 + numberOfEarlyLocals];
                parameters[0] = this.IsPriming;
                parameters[1] = islandArguments;
                if (numberOfEarlyLocals > 0)
                {
                    int index = 2;
                    foreach (LocalsItemDescription description in state.EarlyLocals)
                    {
                        string name = description.Name;
                        if (!locals.TryGetValue(name, out object obj2))
                        {
                            obj2 = Activator.CreateInstance(description.Type);
                        }
                        parameters[index] = obj2;
                        index++;
                    }
                }
                island.Invoke(null, parameters);
            }
        }

        internal void LeaveState(int threadIndex, System.Activities.Debugger.State state)
        {
            this.threads[threadIndex].LeaveState(state);
        }

        internal Properties ManagerProperties =>
            this.properties;

        internal bool IsPriming { get; set; }

        internal bool DebugStartedAtRoot =>
            this.debugStartedAtRoot;

        internal class DynamicModuleManager
        {
            private List<System.Activities.Debugger.State> states = new List<System.Activities.Debugger.State>();
            private Dictionary<SourceLocation, System.Activities.Debugger.State> stateMap = new Dictionary<SourceLocation, System.Activities.Debugger.State>();
            private int indexLastBaked;
            [SecurityCritical]
            private Dictionary<System.Activities.Debugger.State, MethodInfo> islands = new Dictionary<System.Activities.Debugger.State, MethodInfo>();
            [SecurityCritical]
            private Dictionary<System.Activities.Debugger.State, MethodInfo> islandsWithPriming = new Dictionary<System.Activities.Debugger.State, MethodInfo>();
            [SecurityCritical]
            private ModuleBuilder dynamicModule;
            [SecurityCritical]
            private Dictionary<string, ISymbolDocumentWriter> sourceDocuments = new Dictionary<string, ISymbolDocumentWriter>();

            [SecuritySafeCritical]
            public DynamicModuleManager(string moduleNamePrefix)
            {
                if (!PartialTrustHelpers.AppDomainFullyTrusted)
                {
                    moduleNamePrefix = System.Activities.Debugger.State.ValidateIdentifierString(moduleNamePrefix);
                }
                this.InitDynamicModule(moduleNamePrefix);
            }

            [SecuritySafeCritical]
            public void Bake(string typeName, string typeNamePrefix, Dictionary<string, byte[]> checksumCache)
            {
                if (!PartialTrustHelpers.AppDomainFullyTrusted)
                {
                    typeName = System.Activities.Debugger.State.ValidateIdentifierString(typeName);
                    typeNamePrefix = System.Activities.Debugger.State.ValidateIdentifierString(typeNamePrefix);
                    if (checksumCache != null)
                    {
                        bool flag = false;
                        foreach (KeyValuePair<string, byte[]> pair in checksumCache)
                        {
                            if (!SymbolHelper.ValidateChecksum(pair.Value))
                            {
                                flag = true;
                                Trace.WriteLine(System.Activities.SR.DebugSymbolChecksumValueInvalid);
                                break;
                            }
                        }
                        if (flag)
                        {
                            checksumCache = null;
                        }
                    }
                }
                StateManager.DynamicModuleManager manager = this;
                lock (manager)
                {
                    if (this.indexLastBaked < this.states.Count)
                    {
                        for (int i = 1; this.dynamicModule.GetType(typeName) != null; i++)
                        {
                            typeName = typeNamePrefix + "_" + i.ToString(CultureInfo.InvariantCulture);
                        }
                        TypeBuilder typeBuilder = this.dynamicModule.DefineType(typeName, TypeAttributes.Public);
                        for (int j = this.indexLastBaked; j < this.states.Count; j++)
                        {
                            if (this.states[j].DebuggingEnabled)
                            {
                                MethodBuilder builder2 = this.CreateIsland(typeBuilder, this.states[j], false, checksumCache);
                                MethodBuilder builder3 = this.CreateIsland(typeBuilder, this.states[j], true, checksumCache);
                                this.states[j].CacheMethodInfo(typeBuilder, builder2.Name);
                            }
                        }
                        typeBuilder.CreateType();
                        this.indexLastBaked = this.states.Count;
                    }
                }
            }

            [SecurityCritical]
            private MethodBuilder CreateIsland(TypeBuilder typeBuilder, System.Activities.Debugger.State state, bool withPrimingTest, Dictionary<string, byte[]> checksumCache)
            {
                MethodBuilder builder = this.CreateMethodBuilder(typeBuilder, StateManager.threadWorkerControllerType, state, withPrimingTest);
                ILGenerator iLGenerator = builder.GetILGenerator();
                SourceLocation location = state.Location;
                ISymbolDocumentWriter document = this.GetSourceDocument(location.FileName, location.Checksum, checksumCache);
                Label label = iLGenerator.DefineLabel();
                if (withPrimingTest)
                {
                    iLGenerator.MarkSequencePoint(document, 0xfeefee, 1, 0xfeefee, 100);
                    iLGenerator.Emit(OpCodes.Ldarg_0);
                    iLGenerator.Emit(OpCodes.Brtrue, label);
                }
                iLGenerator.MarkSequencePoint(document, location.StartLine, location.StartColumn, location.EndLine, location.EndColumn);
                iLGenerator.Emit(OpCodes.Nop);
                iLGenerator.MarkLabel(label);
                iLGenerator.Emit(OpCodes.Ldarg_1);
                iLGenerator.EmitCall(OpCodes.Call, StateManager.islandWorkerMethodInfo, null);
                iLGenerator.Emit(OpCodes.Ret);
                return builder;
            }

            [SecurityCritical]
            internal MethodBuilder CreateMethodBuilder(TypeBuilder typeBuilder, Type typeIslandArguments, System.Activities.Debugger.State state, bool withPriming)
            {
                string name = (state.Name != null) ? state.Name : ("Line_" + state.Location.StartLine);
                if (withPriming)
                {
                    name = "_" + name;
                }
                IEnumerable<LocalsItemDescription> earlyLocals = state.EarlyLocals;
                int numberOfEarlyLocals = state.NumberOfEarlyLocals;
                Type[] parameterTypes = new Type[2 + numberOfEarlyLocals];
                parameterTypes[0] = typeof(bool);
                parameterTypes[1] = typeIslandArguments;
                if (numberOfEarlyLocals > 0)
                {
                    int index = 2;
                    foreach (LocalsItemDescription description in earlyLocals)
                    {
                        parameterTypes[index] = description.Type;
                        index++;
                    }
                }
                Type returnType = typeof(void);
                MethodBuilder builder = typeBuilder.DefineMethod(name, MethodAttributes.Static | MethodAttributes.Public, returnType, parameterTypes);
                builder.DefineParameter(1, ParameterAttributes.None, "isPriming");
                builder.DefineParameter(2, ParameterAttributes.None, "typeIslandArguments");
                if (numberOfEarlyLocals > 0)
                {
                    int position = 3;
                    foreach (LocalsItemDescription description2 in earlyLocals)
                    {
                        builder.DefineParameter(position, ParameterAttributes.None, description2.Name);
                        position++;
                    }
                }
                return builder;
            }

            public System.Activities.Debugger.State DefineState(SourceLocation location, string name, LocalsItemDescription[] earlyLocals, int numberOfEarlyLocals)
            {
                StateManager.DynamicModuleManager manager = this;
                lock (manager)
                {
                    if (this.stateMap.TryGetValue(location, out System.Activities.Debugger.State state))
                    {
                        return state;
                    }
                    StateManager.DynamicModuleManager manager2 = this;
                    lock (manager2)
                    {
                        state = new System.Activities.Debugger.State(location, name, earlyLocals, numberOfEarlyLocals);
                        this.stateMap.Add(location, state);
                        this.states.Add(state);
                        return state;
                    }
                }
                return state;
            }

            [SecuritySafeCritical]
            public MethodInfo GetIsland(System.Activities.Debugger.State state, bool isPriming)
            {
                MethodInfo methodInfo = null;
                if (isPriming)
                {
                    Dictionary<System.Activities.Debugger.State, MethodInfo> islandsWithPriming = this.islandsWithPriming;
                    lock (islandsWithPriming)
                    {
                        if (!this.islandsWithPriming.TryGetValue(state, out methodInfo))
                        {
                            methodInfo = state.GetMethodInfo(true);
                            this.islandsWithPriming[state] = methodInfo;
                        }
                        return methodInfo;
                    }
                }
                Dictionary<System.Activities.Debugger.State, MethodInfo> islands = this.islands;
                lock (islands)
                {
                    if (!this.islands.TryGetValue(state, out methodInfo))
                    {
                        methodInfo = state.GetMethodInfo(false);
                        this.islands[state] = methodInfo;
                    }
                }
                return methodInfo;
            }

            [SecurityCritical]
            private ISymbolDocumentWriter GetSourceDocument(string fileName, byte[] checksum, Dictionary<string, byte[]> checksumCache)
            {
                string key = fileName + SymbolHelper.GetHexStringFromChecksum(checksum);
                if (!this.sourceDocuments.TryGetValue(key, out ISymbolDocumentWriter writer))
                {
                    writer = this.dynamicModule.DefineDocument(fileName, StateManager.WorkflowLanguageGuid, SymLanguageVendor.Microsoft, SymDocumentType.Text);
                    this.sourceDocuments.Add(key, writer);
                    if ((checksumCache == null) || !checksumCache.TryGetValue(fileName.ToUpperInvariant(), out byte[] buffer))
                    {
                        buffer = SymbolHelper.CalculateChecksum(fileName);
                    }
                    if (buffer != null)
                    {
                        writer.SetCheckSum(SymbolHelper.ChecksumProviderId, buffer);
                    }
                }
                return writer;
            }

            [SecurityCritical]
            private void InitDynamicModule(string asmName)
            {
                AssemblyName name = new AssemblyName {
                    Name = asmName
                };
                CustomAttributeBuilder builder2 = new CustomAttributeBuilder(typeof(SecurityTransparentAttribute).GetConstructor(Type.EmptyTypes), new object[0]);
                CustomAttributeBuilder[] assemblyAttributes = new CustomAttributeBuilder[] { builder2 };
                AssemblyBuilder builder = AppDomain.CurrentDomain.DefineDynamicAssembly(name, AssemblyBuilderAccess.Run, null, true, assemblyAttributes);
                Type type = typeof(DebuggableAttribute);
                Type[] types = new Type[] { typeof(DebuggableAttribute.DebuggingModes) };
                object[] constructorArgs = new object[] { DebuggableAttribute.DebuggingModes.DisableOptimizations | DebuggableAttribute.DebuggingModes.Default };
                CustomAttributeBuilder customBuilder = new CustomAttributeBuilder(type.GetConstructor(types), constructorArgs);
                builder.SetCustomAttribute(customBuilder);
                PermissionSet set = new PermissionSet(PermissionState.None);
                set.AddPermission(new SecurityPermission(SecurityPermissionFlag.UnmanagedCode));
                set.Assert();
                try
                {
                    this.dynamicModule = builder.DefineDynamicModule(asmName, true);
                }
                finally
                {
                    CodeAccessPermission.RevertAssert();
                }
            }
        }

        [DebuggerNonUserCode]
        private class LogicalThread
        {
            private int threadId;
            private Stack<VirtualStackFrame> callStack;
            private ThreadWorkerController controller;

            public LogicalThread(int threadId, string threadName, StateManager stateManager)
            {
                this.threadId = threadId;
                this.callStack = new Stack<VirtualStackFrame>();
                this.controller = new ThreadWorkerController();
                this.controller.Initialize(threadName + "." + threadId.ToString(CultureInfo.InvariantCulture), stateManager);
            }

            public void EnterState(VirtualStackFrame stackFrame)
            {
                if ((stackFrame != null) && (stackFrame.State != null))
                {
                    this.callStack.Push(stackFrame);
                    this.controller.EnterState(stackFrame);
                }
                else
                {
                    this.callStack.Push(null);
                }
            }

            public void Exit()
            {
                this.UnwindCallStack();
                this.controller.Exit();
            }

            public void LeaveState(System.Activities.Debugger.State state)
            {
                if ((this.callStack.Count > 0) && (this.callStack.Pop() != null))
                {
                    this.controller.LeaveState();
                }
            }

            private void UnwindCallStack()
            {
                while (this.callStack.Count > 0)
                {
                    this.LeaveState(this.callStack.Peek().State);
                }
            }
        }

        [DebuggerNonUserCode]
        internal class Properties
        {
            public Properties() : this("Locals", "Script", "States", "WorkflowDebuggerThread", true)
            {
            }

            public Properties(string defaultLocalsName, string moduleNamePrefix, string typeNamePrefix, string auxiliaryThreadName, bool breakOnStartup)
            {
                this.DefaultLocalsName = defaultLocalsName;
                this.ModuleNamePrefix = moduleNamePrefix;
                this.TypeNamePrefix = typeNamePrefix;
                this.AuxiliaryThreadName = auxiliaryThreadName;
                this.BreakOnStartup = breakOnStartup;
            }

            public string DefaultLocalsName { get; set; }

            public string ModuleNamePrefix { get; set; }

            public string TypeNamePrefix { get; set; }

            public string AuxiliaryThreadName { get; set; }

            public bool BreakOnStartup { get; set; }
        }
    }
}

