﻿namespace System.Activities.Debugger
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Xml;

    internal class XmlReaderWithSourceLocation : System.Activities.Debugger.XmlWrappingReader
    {
        private Dictionary<DocumentLocation, DocumentRange> attributeValueRanges;
        private Dictionary<DocumentLocation, DocumentRange> emptyElementRanges;
        private Dictionary<DocumentLocation, DocumentRange> contentValueRanges;
        private Dictionary<DocumentLocation, DocumentLocation> startElementLocations;
        private Dictionary<DocumentLocation, DocumentLocation> endElementLocations;
        private CharacterSpottingTextReader characterSpottingTextReader;
        private Stack<DocumentLocation> contentStartLocationStack;

        public XmlReaderWithSourceLocation(TextReader underlyingTextReader)
        {
            UnitTestUtility.Assert(underlyingTextReader > null, "CharacterSpottingTextReader cannot be null and should be ensured by caller.");
            CharacterSpottingTextReader input = new CharacterSpottingTextReader(underlyingTextReader);
            XmlReaderSettings settings = new XmlReaderSettings {
                XmlResolver = null
            };
            base.BaseReader = Create(input, settings);
            UnitTestUtility.Assert(base.BaseReaderAsLineInfo > null, "The XmlReader created by XmlReader.Create should ensure this.");
            UnitTestUtility.Assert(base.BaseReaderAsLineInfo.HasLineInfo(), "The XmlReader created by XmlReader.Create should ensure this.");
            this.characterSpottingTextReader = input;
            this.contentStartLocationStack = new Stack<DocumentLocation>();
        }

        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
            if (disposing)
            {
                if (this.characterSpottingTextReader != null)
                {
                    this.characterSpottingTextReader.Dispose();
                }
                this.characterSpottingTextReader = null;
            }
        }

        private DocumentRange FindAttributeValueLocation(DocumentLocation memberLocation)
        {
            UnitTestUtility.Assert(this.characterSpottingTextReader > null, "Ensured by constructor.");
            DocumentLocation afterLocation = this.characterSpottingTextReader.FindCharacterStrictlyAfter(this.QuoteChar, memberLocation);
            UnitTestUtility.Assert(afterLocation > null, "Read should ensure the two quote characters exists");
            DocumentLocation end = this.characterSpottingTextReader.FindCharacterStrictlyAfter(this.QuoteChar, afterLocation);
            UnitTestUtility.Assert(end > null, "Read should ensure the two quote characters exists");
            return new DocumentRange(afterLocation, end);
        }

        private DocumentLocation FindContentEndBefore(DocumentLocation location)
        {
            DocumentLocation documentLocation = this.FindStartElementBracket(location);
            int linePosition = documentLocation.LinePosition.Value - 1;
            if (linePosition < 1)
            {
                return this.characterSpottingTextReader.FindCharacterStrictlyBefore('\n', documentLocation);
            }
            return new DocumentLocation(documentLocation.LineNumber.Value, linePosition);
        }

        private DocumentRange FindEmptyElementRange(DocumentLocation elementLocation)
        {
            DocumentLocation start = this.FindStartElementBracket(elementLocation);
            DocumentLocation end = this.FindEndElementBracket(elementLocation);
            UnitTestUtility.Assert(start > null, "XmlReader should guarantee there must be a start angle bracket.");
            UnitTestUtility.Assert(end > null, "XmlReader should guarantee there must be an end angle bracket.");
            return new DocumentRange(start, end);
        }

        private DocumentLocation FindEndElementBracket(DocumentLocation elementLocation) => 
            this.characterSpottingTextReader.FindCharacterStrictlyAfter('>', elementLocation);

        private DocumentLocation FindStartElementBracket(DocumentLocation elementLocation) => 
            this.characterSpottingTextReader.FindCharacterStrictlyBefore('<', elementLocation);

        public override bool Read()
        {
            bool flag = base.Read();
            if (this.NodeType == XmlNodeType.Element)
            {
                DocumentLocation currentLocation = this.CurrentLocation;
                if (this.IsEmptyElement)
                {
                    DocumentRange range = this.FindEmptyElementRange(currentLocation);
                    this.EmptyElementRanges.Add(currentLocation, range);
                }
                else
                {
                    DocumentLocation location2 = this.FindStartElementBracket(currentLocation);
                    this.StartElementLocations.Add(currentLocation, location2);
                    this.contentStartLocationStack.Push(null);
                }
                int attributeCount = this.AttributeCount;
                if (attributeCount > 0)
                {
                    for (int i = 0; i < attributeCount; i++)
                    {
                        this.MoveToAttribute(i);
                        DocumentLocation memberLocation = this.CurrentLocation;
                        DocumentRange range2 = this.FindAttributeValueLocation(memberLocation);
                        this.AttributeValueRanges.Add(memberLocation, range2);
                    }
                    this.MoveToElement();
                }
                return flag;
            }
            if (this.NodeType == XmlNodeType.EndElement)
            {
                DocumentLocation currentLocation = this.CurrentLocation;
                DocumentLocation location5 = this.FindEndElementBracket(currentLocation);
                this.EndElementLocations.Add(currentLocation, location5);
                UnitTestUtility.Assert(this.contentStartLocationStack.Count > 0, "The stack should contain at least a null we pushed in StartElement.");
                DocumentLocation start = this.contentStartLocationStack.Pop();
                if (start != null)
                {
                    DocumentLocation end = this.FindContentEndBefore(currentLocation);
                    this.ContentValueRanges.Add(currentLocation, new DocumentRange(start, end));
                }
                return flag;
            }
            if (this.NodeType == XmlNodeType.Text)
            {
                UnitTestUtility.Assert(this.contentStartLocationStack.Count > 0, "Adding Text with out StartElement?");
                if (this.contentStartLocationStack.Peek() == null)
                {
                    this.contentStartLocationStack.Pop();
                    this.contentStartLocationStack.Push(this.CurrentLocation);
                }
            }
            return flag;
        }

        public Dictionary<DocumentLocation, DocumentRange> AttributeValueRanges
        {
            get
            {
                if (this.attributeValueRanges == null)
                {
                    this.attributeValueRanges = new Dictionary<DocumentLocation, DocumentRange>();
                }
                return this.attributeValueRanges;
            }
        }

        public Dictionary<DocumentLocation, DocumentRange> ContentValueRanges
        {
            get
            {
                if (this.contentValueRanges == null)
                {
                    this.contentValueRanges = new Dictionary<DocumentLocation, DocumentRange>();
                }
                return this.contentValueRanges;
            }
        }

        public Dictionary<DocumentLocation, DocumentRange> EmptyElementRanges
        {
            get
            {
                if (this.emptyElementRanges == null)
                {
                    this.emptyElementRanges = new Dictionary<DocumentLocation, DocumentRange>();
                }
                return this.emptyElementRanges;
            }
        }

        public Dictionary<DocumentLocation, DocumentLocation> StartElementLocations
        {
            get
            {
                if (this.startElementLocations == null)
                {
                    this.startElementLocations = new Dictionary<DocumentLocation, DocumentLocation>();
                }
                return this.startElementLocations;
            }
        }

        public Dictionary<DocumentLocation, DocumentLocation> EndElementLocations
        {
            get
            {
                if (this.endElementLocations == null)
                {
                    this.endElementLocations = new Dictionary<DocumentLocation, DocumentLocation>();
                }
                return this.endElementLocations;
            }
        }

        private DocumentLocation CurrentLocation =>
            new DocumentLocation(base.BaseReaderAsLineInfo.LineNumber, base.BaseReaderAsLineInfo.LinePosition);
    }
}

