﻿namespace System.Activities.Debugger
{
    using System;
    using System.Activities;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Globalization;
    using System.IO;
    using System.Reflection;
    using System.Runtime;
    using System.Security;
    using System.Text;

    [DebuggerNonUserCode]
    public class State
    {
        [SecurityCritical]
        private SourceLocation location;
        [SecurityCritical]
        private string name;
        private IEnumerable<LocalsItemDescription> earlyLocals;
        private int numberOfEarlyLocals;
        private Type type;
        [SecurityCritical]
        private string methodName;
        [SecurityCritical]
        private bool debuggingEnabled = true;

        [SecuritySafeCritical]
        internal State(SourceLocation location, string name, IEnumerable<LocalsItemDescription> earlyLocals, int numberOfEarlyLocals)
        {
            if (!PartialTrustHelpers.AppDomainFullyTrusted)
            {
                this.name = ValidateIdentifierString(name);
                this.location = this.ValidateSourceLocation(location);
            }
            else
            {
                this.location = location;
                this.name = name;
            }
            this.earlyLocals = earlyLocals;
            this.numberOfEarlyLocals = (earlyLocals == null) ? 0 : numberOfEarlyLocals;
        }

        [SecurityCritical]
        internal void CacheMethodInfo(Type type, string methodName)
        {
            this.type = type;
            this.methodName = methodName;
        }

        [SecurityCritical]
        internal MethodInfo GetMethodInfo(bool withPriming) => 
            this.type.GetMethod(withPriming ? ("_" + this.methodName) : this.methodName);

        private static bool ReplaceInvalidCharactersWithUnderscore(ref string input, char[] invalidChars)
        {
            bool flag = false;
            int index = 0;
            while ((index = input.IndexOfAny(invalidChars)) != -1)
            {
                char[] chArray = input.ToCharArray();
                chArray[index] = '_';
                input = new string(chArray);
                flag = true;
            }
            return flag;
        }

        internal static string ValidateIdentifierString(string input)
        {
            string str = input.Normalize(NormalizationForm.FormC);
            if (str.Length > 0xff)
            {
                str = str.Substring(0, 0xff);
            }
            char[] chArray = str.ToCharArray();
            for (int i = 0; i < chArray.Length; i++)
            {
                UnicodeCategory unicodeCategory = char.GetUnicodeCategory(chArray[i]);
                if (((((unicodeCategory != UnicodeCategory.UppercaseLetter) && (unicodeCategory != UnicodeCategory.LowercaseLetter)) && ((unicodeCategory != UnicodeCategory.TitlecaseLetter) && (unicodeCategory != UnicodeCategory.ModifierLetter))) && ((unicodeCategory != UnicodeCategory.OtherLetter) && (unicodeCategory != UnicodeCategory.LetterNumber))) && ((i == 0) || ((((unicodeCategory != UnicodeCategory.NonSpacingMark) && (unicodeCategory != UnicodeCategory.SpacingCombiningMark)) && ((unicodeCategory != UnicodeCategory.DecimalDigitNumber) && (unicodeCategory != UnicodeCategory.ConnectorPunctuation))) && (unicodeCategory != UnicodeCategory.Format))))
                {
                    chArray[i] = '_';
                }
            }
            return new string(chArray);
        }

        [SecurityCritical]
        private SourceLocation ValidateSourceLocation(SourceLocation input)
        {
            bool flag = false;
            string fileName = input.FileName;
            if (string.IsNullOrWhiteSpace(fileName))
            {
                this.DebuggingEnabled = false;
                Trace.WriteLine(System.Activities.SR.DebugInstrumentationFailed(System.Activities.SR.InvalidFileName(this.name)));
                return input;
            }
            if ((input.StartLine > 0x7fff) || (input.EndLine > 0x7fff))
            {
                this.DebuggingEnabled = false;
                Trace.WriteLine(System.Activities.SR.DebugInstrumentationFailed(System.Activities.SR.LineNumberTooLarge(this.name)));
                return input;
            }
            if ((input.StartColumn > 0x7fff) || (input.EndColumn > 0x7fff))
            {
                this.DebuggingEnabled = false;
                Trace.WriteLine(System.Activities.SR.DebugInstrumentationFailed(System.Activities.SR.ColumnNumberTooLarge(this.name)));
                return input;
            }
            if (fileName.Length > 0xff)
            {
                fileName = fileName.Substring(0, 0xff);
                flag = true;
            }
            if (ReplaceInvalidCharactersWithUnderscore(ref fileName, Path.GetInvalidPathChars()))
            {
                flag = true;
            }
            string str2 = Path.GetFileName(fileName);
            if (ReplaceInvalidCharactersWithUnderscore(ref str2, Path.GetInvalidFileNameChars()))
            {
                fileName = Path.GetDirectoryName(fileName) + @"\" + str2;
                flag = true;
            }
            if (flag)
            {
                return new SourceLocation(fileName, input.StartLine, input.StartColumn, input.EndLine, input.EndColumn);
            }
            return input;
        }

        internal SourceLocation Location =>
            this.location;

        internal string Name =>
            this.name;

        internal IEnumerable<LocalsItemDescription> EarlyLocals =>
            this.earlyLocals;

        internal int NumberOfEarlyLocals =>
            this.numberOfEarlyLocals;

        internal bool DebuggingEnabled
        {
            [SecuritySafeCritical]
            get => 
                this.debuggingEnabled;
            [SecuritySafeCritical]
            set => 
                this.debuggingEnabled = value;
        }
    }
}

