﻿namespace System.Activities.Debugger.Symbol
{
    using System;
    using System.Activities;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Runtime.CompilerServices;
    using System.Runtime.Serialization;
    using System.Text;

    public class WorkflowSymbol
    {
        private byte[] checksum;
        internal const EncodingFormat DefaultEncodingFormat = EncodingFormat.Binary;

        public WorkflowSymbol()
        {
        }

        private WorkflowSymbol(BinaryReader reader, byte[] checksum)
        {
            this.FileName = reader.ReadString();
            int capacity = SymbolHelper.ReadEncodedInt32(reader);
            this.Symbols = new List<ActivitySymbol>(capacity);
            for (int i = 0; i < capacity; i++)
            {
                this.Symbols.Add(new ActivitySymbol(reader));
            }
            this.checksum = checksum;
        }

        public bool CalculateChecksum()
        {
            this.checksum = null;
            if (!string.IsNullOrEmpty(this.FileName))
            {
                this.checksum = SymbolHelper.CalculateChecksum(this.FileName);
            }
            return (this.checksum > null);
        }

        public static WorkflowSymbol Decode(string symbolString)
        {
            byte[] buffer = Convert.FromBase64String(symbolString);
            using (BinaryReader reader = new BinaryReader(new MemoryStream(buffer)))
            {
                byte[] checksum = null;
                EncodingFormat format = (EncodingFormat) reader.ReadByte();
                int count = buffer.Length - 1;
                if (((int) (format & EncodingFormat.Checksum)) != 0)
                {
                    int num2 = SymbolHelper.ReadEncodedInt32(reader);
                    checksum = reader.ReadBytes(num2);
                    count -= SymbolHelper.GetEncodedSize(num2);
                    format = ((EncodingFormat) ((int) format)) & ((EncodingFormat) 0x7f);
                }
                if (format == EncodingFormat.String)
                {
                    return ParseStringRepresentation(reader.ReadString(), checksum);
                }
                else if (format == EncodingFormat.Binary)
                {
                    return ParseBinary(reader.ReadBytes(count), checksum);
                }
            }
            throw System.Activities.FxTrace.Exception.AsError(new SerializationException());
        }

        public string Encode() => 
            this.Encode(EncodingFormat.Binary);

        internal string Encode(EncodingFormat encodingFormat)
        {
            string str;
            using (MemoryStream stream = new MemoryStream())
            {
                using (BinaryWriter writer = new BinaryWriter(stream))
                {
                    if (this.checksum != null)
                    {
                        writer.Write((byte) (encodingFormat | EncodingFormat.Checksum));
                        SymbolHelper.WriteEncodedInt32(writer, this.checksum.Length);
                        writer.Write(this.checksum);
                    }
                    else
                    {
                        writer.Write((byte) encodingFormat);
                    }
                    if (encodingFormat != EncodingFormat.String)
                    {
                        if (encodingFormat != EncodingFormat.Binary)
                        {
                            throw System.Activities.FxTrace.Exception.AsError(new SerializationException());
                        }
                        this.Write(writer);
                    }
                    else
                    {
                        writer.Write(this.ToString());
                    }
                    byte[] destinationArray = new byte[stream.Length];
                    Array.Copy(stream.GetBuffer(), destinationArray, stream.Length);
                    str = Convert.ToBase64String(destinationArray);
                }
            }
            return str;
        }

        public byte[] GetChecksum()
        {
            if (this.checksum == null)
            {
                return null;
            }
            return (byte[]) this.checksum.Clone();
        }

        private static WorkflowSymbol ParseBinary(byte[] bytes, byte[] checksum)
        {
            using (BinaryReader reader = new BinaryReader(new MemoryStream(bytes)))
            {
                return new WorkflowSymbol(reader, checksum);
            }
        }

        private static WorkflowSymbol ParseStringRepresentation(string symbolString, byte[] checksum)
        {
            char[] separator = new char[] { ';' };
            string[] strArray = symbolString.Split(separator);
            int num = strArray.Length - 1;
            ActivitySymbol[] symbolArray = new ActivitySymbol[num];
            for (int i = 0; i < num; i++)
            {
                char[] chArray2 = new char[] { ',' };
                string[] strArray2 = strArray[i + 1].Split(chArray2);
                symbolArray[i] = new ActivitySymbol { 
                    QualifiedId = QualifiedId.Parse(strArray2[0]).AsByteArray(),
                    StartLine = int.Parse(strArray2[1], CultureInfo.InvariantCulture),
                    StartColumn = int.Parse(strArray2[2], CultureInfo.InvariantCulture),
                    EndLine = int.Parse(strArray2[3], CultureInfo.InvariantCulture),
                    EndColumn = int.Parse(strArray2[4], CultureInfo.InvariantCulture)
                };
            }
            return new WorkflowSymbol { 
                FileName = strArray[0],
                Symbols = symbolArray,
                checksum = checksum
            };
        }

        public override string ToString()
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendFormat("{0}", this.FileName ?? string.Empty);
            if (this.Symbols != null)
            {
                foreach (ActivitySymbol symbol in this.Symbols)
                {
                    builder.AppendFormat(";{0}", symbol.ToString());
                }
            }
            return builder.ToString();
        }

        private void Write(BinaryWriter writer)
        {
            writer.Write(this.FileName ?? string.Empty);
            if (this.Symbols != null)
            {
                SymbolHelper.WriteEncodedInt32(writer, this.Symbols.Count);
                foreach (ActivitySymbol symbol in this.Symbols)
                {
                    symbol.Write(writer);
                }
            }
            else
            {
                SymbolHelper.WriteEncodedInt32(writer, 0);
            }
        }

        public string FileName { get; set; }

        public ICollection<ActivitySymbol> Symbols { get; set; }

        [Flags]
        internal enum EncodingFormat : byte
        {
            String = 0x76,
            Binary = 0x77,
            Checksum = 0x80
        }
    }
}

