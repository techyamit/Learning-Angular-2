﻿namespace System.Activities.Debugger.Symbol
{
    using System;
    using System.Xaml;

    public static class DebugSymbol
    {
        private static Type attachingTypeName = typeof(DebugSymbol);
        public static readonly AttachableMemberIdentifier SymbolName = new AttachableMemberIdentifier(attachingTypeName, "Symbol");

        public static object GetSymbol(object instance)
        {
            if (AttachablePropertyServices.TryGetProperty<string>(instance, SymbolName, out string str))
            {
                return str;
            }
            return string.Empty;
        }

        public static void SetSymbol(object instance, object value)
        {
            AttachablePropertyServices.SetProperty(instance, SymbolName, value);
        }
    }
}

