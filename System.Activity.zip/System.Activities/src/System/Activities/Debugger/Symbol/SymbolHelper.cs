﻿namespace System.Activities.Debugger.Symbol
{
    using System;
    using System.Activities;
    using System.IO;
    using System.Linq;
    using System.Runtime.CompilerServices;
    using System.Security;
    using System.Security.Cryptography;

    internal static class SymbolHelper
    {
        private static readonly Guid Md5IdentifierGuid = new Guid("406ea660-64cf-4c82-b6f0-42d48172a799");
        private static readonly int Md5HashLength = 0x10;
        private static readonly Guid Sha1IdentifierGuid = new Guid("ff1816ec-aa5e-4d10-87f7-6f4963833460");
        private static readonly int Sha1HashLength = 20;
        private static readonly Guid Sha256IdentifierGuid = new Guid("8829d00f-11b8-4213-878b-770e8597ac16");
        private static readonly int Sha256HashLength = 0x20;

        public static byte[] CalculateChecksum(string fileName)
        {
            byte[] buffer;
            try
            {
                using (StreamReader reader = new StreamReader(fileName))
                {
                    using (HashAlgorithm algorithm = CreateHashProvider())
                    {
                        return algorithm.ComputeHash(reader.BaseStream);
                    }
                }
            }
            catch (IOException)
            {
                buffer = null;
            }
            catch (UnauthorizedAccessException)
            {
                buffer = null;
            }
            catch (SecurityException)
            {
                buffer = null;
            }
            return buffer;
        }

        private static HashAlgorithm CreateHashProvider()
        {
            if (System.Activities.LocalAppContextSwitches.UseMD5ForWFDebugger)
            {
                return new MD5CryptoServiceProvider();
            }
            if (System.Activities.LocalAppContextSwitches.UseSHA1HashForDebuggerSymbols)
            {
                return new SHA1CryptoServiceProvider();
            }
            return new SHA256CryptoServiceProvider();
        }

        public static int GetEncodedSize(int value)
        {
            int num = 1;
            while ((value & 0xffffff80UL) != 0)
            {
                num++;
                value = value >> 7;
            }
            return num;
        }

        [SecuritySafeCritical]
        public static string GetHexStringFromChecksum(byte[] checksum)
        {
            if (checksum != null)
            {
                return string.Join(string.Empty, (from x in checksum select x.ToString("X2")).ToArray<string>());
            }
            return string.Empty;
        }

        public static int ReadEncodedInt32(BinaryReader reader)
        {
            int num3;
            int num = 0;
            int num2 = 0;
            do
            {
                num3 = reader.ReadByte();
                num |= (num3 & 0x7f) << (num2 * 7);
                num2++;
            }
            while ((num3 & 0x80) != 0);
            return num;
        }

        [SecuritySafeCritical]
        internal static bool ValidateChecksum(byte[] checksumToValidate)
        {
            if (System.Activities.LocalAppContextSwitches.UseMD5ForWFDebugger)
            {
                return (checksumToValidate.Length == Md5HashLength);
            }
            if (System.Activities.LocalAppContextSwitches.UseSHA1HashForDebuggerSymbols)
            {
                return (checksumToValidate.Length == Sha1HashLength);
            }
            return (checksumToValidate.Length == Sha256HashLength);
        }

        public static void WriteEncodedInt32(BinaryWriter writer, int value)
        {
            while ((value & 0xffffff80UL) != 0)
            {
                writer.Write((byte) ((value & 0x7f) | 0x80));
                value = value >> 7;
            }
            writer.Write((byte) value);
        }

        public static Guid ChecksumProviderId
        {
            get
            {
                if (System.Activities.LocalAppContextSwitches.UseMD5ForWFDebugger)
                {
                    return Md5IdentifierGuid;
                }
                if (System.Activities.LocalAppContextSwitches.UseSHA1HashForDebuggerSymbols)
                {
                    return Sha1IdentifierGuid;
                }
                return Sha256IdentifierGuid;
            }
        }

        [Serializable, CompilerGenerated]
        private sealed class <>c
        {
            public static readonly SymbolHelper.<>c <>9 = new SymbolHelper.<>c();
            public static Func<byte, string> <>9__12_0;

            internal string <GetHexStringFromChecksum>b__12_0(byte x) => 
                x.ToString("X2");
        }
    }
}

