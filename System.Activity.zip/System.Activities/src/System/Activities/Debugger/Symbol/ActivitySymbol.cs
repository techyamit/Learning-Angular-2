﻿namespace System.Activities.Debugger.Symbol
{
    using System;
    using System.Activities;
    using System.Globalization;
    using System.IO;
    using System.Runtime.CompilerServices;

    public class ActivitySymbol
    {
        private string id;

        internal ActivitySymbol()
        {
        }

        internal ActivitySymbol(BinaryReader reader)
        {
            this.StartLine = SymbolHelper.ReadEncodedInt32(reader);
            this.StartColumn = SymbolHelper.ReadEncodedInt32(reader);
            this.EndLine = SymbolHelper.ReadEncodedInt32(reader);
            this.EndColumn = SymbolHelper.ReadEncodedInt32(reader);
            int count = SymbolHelper.ReadEncodedInt32(reader);
            if (count > 0)
            {
                this.QualifiedId = reader.ReadBytes(count);
            }
        }

        public override string ToString()
        {
            object[] args = new object[] { this.Id, this.StartLine, this.StartColumn, this.EndLine, this.EndColumn };
            return string.Format(CultureInfo.InvariantCulture, "{0},{1},{2},{3},{4}", args);
        }

        internal void Write(BinaryWriter writer)
        {
            SymbolHelper.WriteEncodedInt32(writer, this.StartLine);
            SymbolHelper.WriteEncodedInt32(writer, this.StartColumn);
            SymbolHelper.WriteEncodedInt32(writer, this.EndLine);
            SymbolHelper.WriteEncodedInt32(writer, this.EndColumn);
            if (this.QualifiedId != null)
            {
                SymbolHelper.WriteEncodedInt32(writer, this.QualifiedId.Length);
                writer.Write(this.QualifiedId, 0, this.QualifiedId.Length);
            }
            else
            {
                SymbolHelper.WriteEncodedInt32(writer, 0);
            }
        }

        public int StartLine { get; internal set; }

        public int StartColumn { get; internal set; }

        public int EndLine { get; internal set; }

        public int EndColumn { get; internal set; }

        internal byte[] QualifiedId { get; set; }

        public string Id
        {
            get
            {
                if (this.id == null)
                {
                    if (this.QualifiedId != null)
                    {
                        this.id = new System.Activities.QualifiedId(this.QualifiedId).ToString();
                    }
                    else
                    {
                        this.id = string.Empty;
                    }
                }
                return this.id;
            }
        }
    }
}

