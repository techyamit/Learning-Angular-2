﻿namespace System.Activities.Debugger
{
    using System;
    using System.Collections.Generic;
    using System.Reflection;
    using System.Xml;
    using System.Xml.Schema;

    internal class XmlWrappingReader : XmlReader, IXmlLineInfo, IXmlNamespaceResolver
    {
        private XmlReader baseReader;
        private IXmlLineInfo baseReaderAsLineInfo;
        private IXmlNamespaceResolver baseReaderAsNamespaceResolver;

        public override void Close()
        {
            this.baseReader.Close();
        }

        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
            if (disposing)
            {
                if (this.baseReader != null)
                {
                    this.baseReader.Dispose();
                }
                this.baseReader = null;
            }
        }

        public override string GetAttribute(int i) => 
            this.baseReader.GetAttribute(i);

        public override string GetAttribute(string name) => 
            this.baseReader.GetAttribute(name);

        public override string GetAttribute(string name, string namespaceURI) => 
            this.baseReader.GetAttribute(name, namespaceURI);

        public virtual bool HasLineInfo() => 
            (this.baseReaderAsLineInfo != null) && this.baseReaderAsLineInfo.HasLineInfo();

        public override string LookupNamespace(string prefix) => 
            this.baseReader.LookupNamespace(prefix);

        public override void MoveToAttribute(int i)
        {
            this.baseReader.MoveToAttribute(i);
        }

        public override bool MoveToAttribute(string name) => 
            this.baseReader.MoveToAttribute(name);

        public override bool MoveToAttribute(string name, string ns) => 
            this.baseReader.MoveToAttribute(name, ns);

        public override bool MoveToElement() => 
            this.baseReader.MoveToElement();

        public override bool MoveToFirstAttribute() => 
            this.baseReader.MoveToFirstAttribute();

        public override bool MoveToNextAttribute() => 
            this.baseReader.MoveToNextAttribute();

        public override bool Read() => 
            this.baseReader.Read();

        public override bool ReadAttributeValue() => 
            this.baseReader.ReadAttributeValue();

        public override void ResolveEntity()
        {
            this.baseReader.ResolveEntity();
        }

        public override void Skip()
        {
            this.baseReader.Skip();
        }

        IDictionary<string, string> IXmlNamespaceResolver.GetNamespacesInScope(XmlNamespaceScope scope)
        {
            if (this.baseReaderAsNamespaceResolver != null)
            {
                return this.baseReaderAsNamespaceResolver.GetNamespacesInScope(scope);
            }
            return null;
        }

        string IXmlNamespaceResolver.LookupPrefix(string namespaceName)
        {
            if (this.baseReaderAsNamespaceResolver != null)
            {
                return this.baseReaderAsNamespaceResolver.LookupPrefix(namespaceName);
            }
            return null;
        }

        public override XmlReaderSettings Settings =>
            this.baseReader.Settings;

        public override XmlNodeType NodeType =>
            this.baseReader.NodeType;

        public override string Name =>
            this.baseReader.Name;

        public override string LocalName =>
            this.baseReader.LocalName;

        public override string NamespaceURI =>
            this.baseReader.NamespaceURI;

        public override string Prefix =>
            this.baseReader.Prefix;

        public override bool HasValue =>
            this.baseReader.HasValue;

        public override string Value =>
            this.baseReader.Value;

        public override int Depth =>
            this.baseReader.Depth;

        public override string BaseURI =>
            this.baseReader.BaseURI;

        public override bool IsEmptyElement =>
            this.baseReader.IsEmptyElement;

        public override bool IsDefault =>
            this.baseReader.IsDefault;

        public override char QuoteChar =>
            this.baseReader.QuoteChar;

        public override System.Xml.XmlSpace XmlSpace =>
            this.baseReader.XmlSpace;

        public override string XmlLang =>
            this.baseReader.XmlLang;

        public override IXmlSchemaInfo SchemaInfo =>
            this.baseReader.SchemaInfo;

        public override Type ValueType =>
            this.baseReader.ValueType;

        public override int AttributeCount =>
            this.baseReader.AttributeCount;

        public override bool CanResolveEntity =>
            this.baseReader.CanResolveEntity;

        public override bool EOF =>
            this.baseReader.EOF;

        public override System.Xml.ReadState ReadState =>
            this.baseReader.ReadState;

        public override bool HasAttributes =>
            this.baseReader.HasAttributes;

        public override XmlNameTable NameTable =>
            this.baseReader.NameTable;

        public virtual int LineNumber
        {
            get
            {
                if (this.baseReaderAsLineInfo != null)
                {
                    return this.baseReaderAsLineInfo.LineNumber;
                }
                return 0;
            }
        }

        public virtual int LinePosition
        {
            get
            {
                if (this.baseReaderAsLineInfo != null)
                {
                    return this.baseReaderAsLineInfo.LinePosition;
                }
                return 0;
            }
        }

        protected XmlReader BaseReader
        {
            set
            {
                this.baseReader = value;
                this.baseReaderAsLineInfo = value as IXmlLineInfo;
                this.baseReaderAsNamespaceResolver = value as IXmlNamespaceResolver;
            }
        }

        protected IXmlLineInfo BaseReaderAsLineInfo =>
            this.baseReaderAsLineInfo;

        public override string this[int i] =>
            this.baseReader[i];

        public override string this[string name] =>
            this.baseReader[name];

        public override string this[string name, string namespaceURI] =>
            this.baseReader[name, namespaceURI];
    }
}

