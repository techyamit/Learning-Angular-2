﻿namespace System.Activities.Debugger
{
    using System;
    using System.Reflection;
    using System.Runtime.CompilerServices;
    using System.Xaml;
    using System.Xaml.Schema;

    internal static class XamlMemberExtensions
    {
        internal static XamlMember ReplaceXamlMemberInvoker(this XamlMember originalXamlMember, XamlSchemaContext schemaContext, XamlMemberInvoker newInvoker)
        {
            if (originalXamlMember.IsEvent)
            {
                if (originalXamlMember.IsAttachable)
                {
                    UnitTestUtility.Assert(originalXamlMember.UnderlyingMember is MethodInfo, "Guaranteed by XamlMember.");
                    return new XamlMember(originalXamlMember.Name, originalXamlMember.UnderlyingMember as MethodInfo, schemaContext, newInvoker);
                }
                UnitTestUtility.Assert(originalXamlMember.UnderlyingMember is EventInfo, "Guaranteed by XamlMember.");
                return new XamlMember(originalXamlMember.UnderlyingMember as EventInfo, schemaContext, newInvoker);
            }
            if (!originalXamlMember.IsDirective)
            {
                if (originalXamlMember.IsUnknown)
                {
                    return originalXamlMember;
                }
                if (originalXamlMember.IsAttachable)
                {
                    MethodInfo info = originalXamlMember.UnderlyingMember as MethodInfo;
                    if (info.ReturnType == typeof(void))
                    {
                        return new XamlMember(originalXamlMember.Name, null, originalXamlMember.UnderlyingMember as MethodInfo, schemaContext, newInvoker);
                    }
                    return new XamlMember(originalXamlMember.Name, originalXamlMember.UnderlyingMember as MethodInfo, null, schemaContext, newInvoker);
                }
                PropertyInfo underlyingMember = originalXamlMember.UnderlyingMember as PropertyInfo;
                if (underlyingMember != null)
                {
                    return new XamlMember(underlyingMember, schemaContext, newInvoker);
                }
            }
            return originalXamlMember;
        }
    }
}

