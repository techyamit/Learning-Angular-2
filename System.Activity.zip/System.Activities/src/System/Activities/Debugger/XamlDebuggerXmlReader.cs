﻿namespace System.Activities.Debugger
{
    using System;
    using System.Activities;
    using System.Activities.XamlIntegration;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Reflection;
    using System.Runtime.CompilerServices;
    using System.Threading;
    using System.Xaml;
    using System.Xaml.Schema;

    public class XamlDebuggerXmlReader : XamlReader, IXamlLineInfo
    {
        public static readonly AttachableMemberIdentifier StartLineName = new AttachableMemberIdentifier(typeof(XamlDebuggerXmlReader), "StartLine");
        public static readonly AttachableMemberIdentifier StartColumnName = new AttachableMemberIdentifier(typeof(XamlDebuggerXmlReader), "StartColumn");
        public static readonly AttachableMemberIdentifier EndLineName = new AttachableMemberIdentifier(typeof(XamlDebuggerXmlReader), "EndLine");
        public static readonly AttachableMemberIdentifier EndColumnName = new AttachableMemberIdentifier(typeof(XamlDebuggerXmlReader), "EndColumn");
        public static readonly AttachableMemberIdentifier FileNameName = new AttachableMemberIdentifier(typeof(XamlDebuggerXmlReader), "FileName");
        private const string StartLineMemberName = "StartLine";
        private const string StartColumnMemberName = "StartColumn";
        private const string EndLineMemberName = "EndLine";
        private const string EndColumnMemberName = "EndColumn";
        private const string FileNameMemberName = "FileName";
        private static readonly System.Type attachingType = typeof(XamlDebuggerXmlReader);
        private static readonly MethodInfo startLineGetterMethodInfo = attachingType.GetMethod("GetStartLine", BindingFlags.Public | BindingFlags.Static);
        private static readonly MethodInfo startLineSetterMethodInfo = attachingType.GetMethod("SetStartLine", BindingFlags.Public | BindingFlags.Static);
        private static readonly MethodInfo startColumnGetterMethodInfo = attachingType.GetMethod("GetStartColumn", BindingFlags.Public | BindingFlags.Static);
        private static readonly MethodInfo startColumnSetterMethodInfo = attachingType.GetMethod("SetStartColumn", BindingFlags.Public | BindingFlags.Static);
        private static readonly MethodInfo endLineGetterMethodInfo = attachingType.GetMethod("GetEndLine", BindingFlags.Public | BindingFlags.Static);
        private static readonly MethodInfo endLineSetterMethodInfo = attachingType.GetMethod("SetEndLine", BindingFlags.Public | BindingFlags.Static);
        private static readonly MethodInfo endColumnGetterMethodInfo = attachingType.GetMethod("GetEndColumn", BindingFlags.Public | BindingFlags.Static);
        private static readonly MethodInfo endColumnSetterMethodInfo = attachingType.GetMethod("SetEndColumn", BindingFlags.Public | BindingFlags.Static);
        private XamlMember startLineMember;
        private XamlMember startColumnMember;
        private XamlMember endLineMember;
        private XamlMember endColumnMember;
        private XamlSchemaContext schemaContext;
        private IXamlLineInfo xamlLineInfo;
        private XmlReaderWithSourceLocation xmlReaderWithSourceLocation;
        private XamlReader underlyingReader;
        private Stack<System.Activities.Debugger.XamlNode> objectDeclarationRecords;
        private Dictionary<System.Activities.Debugger.XamlNode, DocumentRange> initializationValueRanges;
        private Queue<System.Activities.Debugger.XamlNode> bufferedXamlNodes;
        private XamlSourceLocationCollector sourceLocationCollector;
        private System.Activities.Debugger.XamlNode current;
        private bool collectNonActivitySourceLocation;
        private int suppressMarkupExtensionLevel;

        [field: CompilerGenerated]
        private event EventHandler<SourceLocationFoundEventArgs> _sourceLocationFound;

        public event EventHandler<SourceLocationFoundEventArgs> SourceLocationFound
        {
            add
            {
                this._sourceLocationFound += value;
            }
            remove
            {
                this._sourceLocationFound -= value;
            }
        }

        public XamlDebuggerXmlReader(TextReader underlyingTextReader) : this(underlyingTextReader, new XamlSchemaContext())
        {
        }

        public XamlDebuggerXmlReader(TextReader underlyingTextReader, XamlSchemaContext schemaContext) : this(underlyingTextReader, schemaContext, null)
        {
        }

        [Obsolete("Don't use this constructor. Use \"public XamlDebuggerXmlReader(TextReader underlyingTextReader)\" or \"public XamlDebuggerXmlReader(TextReader underlyingTextReader, XamlSchemaContext schemaContext)\" instead.")]
        public XamlDebuggerXmlReader(XamlReader underlyingReader, TextReader textReader) : this(underlyingReader, underlyingReader as IXamlLineInfo, textReader)
        {
        }

        internal XamlDebuggerXmlReader(TextReader underlyingTextReader, XamlSchemaContext schemaContext, Assembly localAssembly)
        {
            UnitTestUtility.Assert(underlyingTextReader > null, "underlyingTextReader should not be null and is ensured by caller.");
            this.xmlReaderWithSourceLocation = new XmlReaderWithSourceLocation(underlyingTextReader);
            XamlXmlReaderSettings settings = new XamlXmlReaderSettings {
                ProvideLineInfo = true,
                LocalAssembly = localAssembly
            };
            this.underlyingReader = new XamlXmlReader(this.xmlReaderWithSourceLocation, schemaContext, settings);
            this.xamlLineInfo = (IXamlLineInfo) this.underlyingReader;
            UnitTestUtility.Assert(this.xamlLineInfo.HasLineInfo, "underlyingReader is constructed with the ProvideLineInfo option above.");
            this.schemaContext = schemaContext;
            this.objectDeclarationRecords = new Stack<System.Activities.Debugger.XamlNode>();
            this.initializationValueRanges = new Dictionary<System.Activities.Debugger.XamlNode, DocumentRange>();
            this.bufferedXamlNodes = new Queue<System.Activities.Debugger.XamlNode>();
            this.current = this.CreateCurrentNode();
            this.SourceLocationFound += new EventHandler<SourceLocationFoundEventArgs>(XamlDebuggerXmlReader.SetSourceLocation);
        }

        [Obsolete("Don't use this constructor. Use \"public XamlDebuggerXmlReader(TextReader underlyingTextReader)\" or \"public XamlDebuggerXmlReader(TextReader underlyingTextReader, XamlSchemaContext schemaContext)\" instead.")]
        public XamlDebuggerXmlReader(XamlReader underlyingReader, IXamlLineInfo xamlLineInfo, TextReader textReader)
        {
            this.underlyingReader = underlyingReader;
            this.xamlLineInfo = xamlLineInfo;
            this.xmlReaderWithSourceLocation = new XmlReaderWithSourceLocation(textReader);
            this.initializationValueRanges = new Dictionary<System.Activities.Debugger.XamlNode, DocumentRange>();
            while (this.xmlReaderWithSourceLocation.Read())
            {
            }
            this.schemaContext = underlyingReader.SchemaContext;
            this.objectDeclarationRecords = new Stack<System.Activities.Debugger.XamlNode>();
            this.bufferedXamlNodes = new Queue<System.Activities.Debugger.XamlNode>();
            this.current = this.CreateCurrentNode();
            this.SourceLocationFound += new EventHandler<SourceLocationFoundEventArgs>(XamlDebuggerXmlReader.SetSourceLocation);
        }

        public static void CopyAttachedSourceLocation(object source, object destination)
        {
            if ((AttachablePropertyServices.TryGetProperty<int>(source, StartLineName, out int num) && AttachablePropertyServices.TryGetProperty<int>(source, StartColumnName, out int num2)) && (AttachablePropertyServices.TryGetProperty<int>(source, EndLineName, out int num3) && AttachablePropertyServices.TryGetProperty<int>(source, EndColumnName, out int num4)))
            {
                SetStartLine(destination, num);
                SetStartColumn(destination, num2);
                SetEndLine(destination, num3);
                SetEndColumn(destination, num4);
            }
        }

        private XamlMember CreateAttachableMember(MethodInfo getter, MethodInfo setter, SourceLocationMemberType memberType)
        {
            string attachablePropertyName = memberType.ToString();
            return new XamlMember(attachablePropertyName, getter, setter, this.schemaContext, new SourceLocationMemberInvoker(this.SourceLocationCollector, memberType));
        }

        private System.Activities.Debugger.XamlNode CreateCurrentNode() => 
            CreateCurrentNode(this.underlyingReader, this.xamlLineInfo);

        private static System.Activities.Debugger.XamlNode CreateCurrentNode(XamlReader xamlReader, IXamlLineInfo xamlLineInfo) => 
            new System.Activities.Debugger.XamlNode { 
                Namespace = xamlReader.Namespace,
                NodeType = xamlReader.NodeType,
                Type = xamlReader.Type,
                Member = xamlReader.Member,
                Value = xamlReader.Value,
                LineNumber = xamlLineInfo.LineNumber,
                LinePosition = xamlLineInfo.LinePosition
            };

        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
            if (disposing)
            {
                if (this.underlyingReader != null)
                {
                    ((IDisposable) this.underlyingReader).Dispose();
                }
                this.underlyingReader = null;
                if (this.xmlReaderWithSourceLocation != null)
                {
                    this.xmlReaderWithSourceLocation.Dispose();
                }
                this.xmlReaderWithSourceLocation = null;
            }
        }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public static object GetEndColumn(object instance) => 
            GetIntegerAttachedProperty(instance, EndColumnName);

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public static object GetEndLine(object instance) => 
            GetIntegerAttachedProperty(instance, EndLineName);

        public static object GetFileName(object instance)
        {
            if (AttachablePropertyServices.TryGetProperty<string>(instance, FileNameName, out string str))
            {
                return str;
            }
            return string.Empty;
        }

        private static int GetIntegerAttachedProperty(object instance, AttachableMemberIdentifier memberIdentifier)
        {
            if (AttachablePropertyServices.TryGetProperty<int>(instance, memberIdentifier, out int num))
            {
                return num;
            }
            return -1;
        }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public static object GetStartColumn(object instance) => 
            GetIntegerAttachedProperty(instance, StartColumnName);

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public static object GetStartLine(object instance) => 
            GetIntegerAttachedProperty(instance, StartLineName);

        private void InjectLineInfoMembersToBuffer(DocumentLocation startPosition, DocumentLocation endPosition)
        {
            this.InjectLineInfoMemberToBuffer(this.StartLineMember, startPosition.LineNumber.Value);
            this.InjectLineInfoMemberToBuffer(this.StartColumnMember, startPosition.LinePosition.Value);
            this.InjectLineInfoMemberToBuffer(this.EndLineMember, endPosition.LineNumber.Value);
            this.InjectLineInfoMemberToBuffer(this.EndColumnMember, endPosition.LinePosition.Value);
        }

        private void InjectLineInfoMemberToBuffer(XamlMember member, int value)
        {
            System.Activities.Debugger.XamlNode item = new System.Activities.Debugger.XamlNode {
                NodeType = XamlNodeType.StartMember,
                Member = member
            };
            this.bufferedXamlNodes.Enqueue(item);
            System.Activities.Debugger.XamlNode node2 = new System.Activities.Debugger.XamlNode {
                NodeType = XamlNodeType.Value,
                Value = value
            };
            this.bufferedXamlNodes.Enqueue(node2);
            System.Activities.Debugger.XamlNode node3 = new System.Activities.Debugger.XamlNode {
                NodeType = XamlNodeType.EndMember,
                Member = member
            };
            this.bufferedXamlNodes.Enqueue(node3);
        }

        private void InjectLineInfoXamlNodesToBuffer()
        {
            System.Activities.Debugger.XamlNode key = this.objectDeclarationRecords.Pop();
            if ((!this.SuppressingMarkupExtension() && (key.Type != null)) && (!key.Type.IsUnknown && !key.Type.IsMarkupExtension))
            {
                DocumentLocation start = null;
                DocumentLocation end = null;
                DocumentLocation location3 = new DocumentLocation(key.LineNumber, key.LinePosition);
                if (this.xmlReaderWithSourceLocation.EmptyElementRanges.TryGetValue(location3, out DocumentRange range))
                {
                    start = range.Start;
                    end = range.End;
                }
                else
                {
                    DocumentLocation location5 = new DocumentLocation(this.Current.LineNumber, this.Current.LinePosition);
                    this.xmlReaderWithSourceLocation.StartElementLocations.TryGetValue(location3, out start);
                    this.xmlReaderWithSourceLocation.EndElementLocations.TryGetValue(location5, out end);
                }
                DocumentLocation endPosition = new DocumentLocation(end.LineNumber.Value, end.LinePosition.Value + 1);
                this.bufferedXamlNodes.Clear();
                this.InjectLineInfoMembersToBuffer(start, endPosition);
                if (this.initializationValueRanges.TryGetValue(key, out DocumentRange range2))
                {
                    DocumentRange valueRange = new DocumentRange(range2.Start, new DocumentLocation(range2.End.LineNumber.Value, range2.End.LinePosition.Value + 1));
                    this.SourceLocationCollector.AddValueRange(new DocumentRange(start, endPosition), valueRange);
                }
            }
            if (IsMarkupExtension(key))
            {
                this.suppressMarkupExtensionLevel--;
            }
            this.bufferedXamlNodes.Enqueue(this.Current);
        }

        private static bool IsMarkupExtension(System.Activities.Debugger.XamlNode node) => 
            (node.Type != null) && node.Type.IsMarkupExtension;

        private void NotifySourceLocationFound(object instance, SourceLocation currentLocation, bool isValueNode)
        {
            Argument argument = instance as Argument;
            if (((argument != null) && (argument.Expression is IValueSerializableExpression)) & isValueNode)
            {
                instance = argument.Expression;
            }
            if (this._sourceLocationFound != null)
            {
                this._sourceLocationFound(this, new SourceLocationFoundEventArgs(instance, currentLocation, isValueNode));
            }
        }

        private void OnValueNodeDeserialized(object value, DocumentRange attributeValueLocation)
        {
            int startLine = attributeValueLocation.Start.LineNumber.Value;
            int startColumn = attributeValueLocation.Start.LinePosition.Value;
            int endLine = attributeValueLocation.End.LineNumber.Value;
            int num4 = attributeValueLocation.End.LinePosition.Value;
            SourceLocation currentLocation = new SourceLocation(null, startLine, startColumn, endLine, num4 + 1);
            this.NotifySourceLocationFound(value, currentLocation, true);
        }

        private void PushObjectDeclarationNodeIfApplicable()
        {
            if ((((int) this.Current.NodeType) - 1) <= ((int) XamlNodeType.StartObject))
            {
                this.objectDeclarationRecords.Push(this.Current);
                if (IsMarkupExtension(this.Current))
                {
                    this.suppressMarkupExtensionLevel++;
                }
            }
        }

        public override bool Read()
        {
            if (this.bufferedXamlNodes.Count > 0)
            {
                this.Current = this.bufferedXamlNodes.Dequeue();
                return (this.Current > null);
            }
            bool flag = this.underlyingReader.Read();
            if (flag)
            {
                this.Current = CreateCurrentNode(this.underlyingReader, this.xamlLineInfo);
                this.PushObjectDeclarationNodeIfApplicable();
                switch (this.Current.NodeType)
                {
                    case XamlNodeType.EndObject:
                        this.InjectLineInfoXamlNodesToBuffer();
                        this.StartAccessingBuffer();
                        return flag;

                    case XamlNodeType.StartMember:
                    {
                        UnitTestUtility.Assert(this.bufferedXamlNodes.Count == 0, "this.bufferedXamlNodes should be empty when we reach this code path.");
                        this.bufferedXamlNodes.Enqueue(this.Current);
                        bool flag2 = this.Current.Member == XamlLanguage.Initialization;
                        UnitTestUtility.Assert(this.underlyingReader.Read(), "Start Member must followed by some other nodes.");
                        this.Current = this.CreateCurrentNode();
                        this.bufferedXamlNodes.Enqueue(this.Current);
                        this.PushObjectDeclarationNodeIfApplicable();
                        if (!this.SuppressingMarkupExtension() && (this.Current.NodeType == XamlNodeType.Value))
                        {
                            DocumentLocation key = new DocumentLocation(this.Current.LineNumber, this.Current.LinePosition);
                            bool flag4 = this.xmlReaderWithSourceLocation.AttributeValueRanges.TryGetValue(key, out DocumentRange range);
                            bool flag5 = !flag4 && this.xmlReaderWithSourceLocation.ContentValueRanges.TryGetValue(key, out range);
                            if (flag4 || (flag5 && !flag2))
                            {
                                System.Activities.Debugger.XamlNode node = this.bufferedXamlNodes.Peek();
                                XamlMember originalXamlMember = node.Member;
                                XamlMemberInvoker newInvoker = new ValueNodeXamlMemberInvoker(this, originalXamlMember.Invoker, range);
                                node.Member = originalXamlMember.ReplaceXamlMemberInvoker(this.schemaContext, newInvoker);
                            }
                            else if (flag5 & flag2)
                            {
                                System.Activities.Debugger.XamlNode node2 = this.objectDeclarationRecords.Peek();
                                if (!this.initializationValueRanges.ContainsKey(node2))
                                {
                                    this.initializationValueRanges.Add(node2, range);
                                }
                                else
                                {
                                    UnitTestUtility.Assert(false, "I assume it is impossible for an object  to have more than one initialization member");
                                }
                            }
                        }
                        this.StartAccessingBuffer();
                        return flag;
                    }
                    case XamlNodeType.EndMember:
                    case XamlNodeType.Value:
                        return flag;
                }
            }
            return flag;
        }

        public static void SetEndColumn(object instance, object value)
        {
            AttachablePropertyServices.SetProperty(instance, EndColumnName, value);
        }

        public static void SetEndLine(object instance, object value)
        {
            AttachablePropertyServices.SetProperty(instance, EndLineName, value);
        }

        public static void SetFileName(object instance, object value)
        {
            AttachablePropertyServices.SetProperty(instance, FileNameName, value);
        }

        internal static void SetSourceLocation(object sender, SourceLocationFoundEventArgs args)
        {
            object target = args.Target;
            System.Type c = target.GetType();
            XamlDebuggerXmlReader reader = (XamlDebuggerXmlReader) sender;
            bool flag = false;
            if (reader.CollectNonActivitySourceLocation)
            {
                flag = !c.Equals(typeof(string));
            }
            else if ((typeof(Activity).IsAssignableFrom(c) && !typeof(IExpressionContainer).IsAssignableFrom(c)) && !typeof(IValueSerializableExpression).IsAssignableFrom(c))
            {
                flag = true;
            }
            if (flag && !args.IsValueNode)
            {
                SourceLocation sourceLocation = args.SourceLocation;
                SetStartLine(target, sourceLocation.StartLine);
                SetStartColumn(target, sourceLocation.StartColumn);
                SetEndLine(target, sourceLocation.EndLine);
                SetEndColumn(target, sourceLocation.EndColumn);
            }
        }

        public static void SetStartColumn(object instance, object value)
        {
            AttachablePropertyServices.SetProperty(instance, StartColumnName, value);
        }

        public static void SetStartLine(object instance, object value)
        {
            AttachablePropertyServices.SetProperty(instance, StartLineName, value);
        }

        private void StartAccessingBuffer()
        {
            this.Current = this.bufferedXamlNodes.Dequeue();
        }

        private bool SuppressingMarkupExtension() => 
            this.suppressMarkupExtensionLevel != 0;

        public bool CollectNonActivitySourceLocation
        {
            get => 
                this.collectNonActivitySourceLocation;
            set => 
                this.collectNonActivitySourceLocation = value;
        }

        public bool HasLineInfo =>
            true;

        public int LineNumber =>
            this.Current.LineNumber;

        public int LinePosition =>
            this.Current.LinePosition;

        public override XamlNodeType NodeType =>
            this.Current.NodeType;

        public override XamlType Type =>
            this.Current.Type;

        public override XamlMember Member =>
            this.Current.Member;

        public override object Value =>
            this.Current.Value;

        public override bool IsEof =>
            this.underlyingReader.IsEof;

        public override NamespaceDeclaration Namespace =>
            this.Current.Namespace;

        public override XamlSchemaContext SchemaContext =>
            this.schemaContext;

        internal XamlMember StartLineMember
        {
            get
            {
                if (this.startLineMember == null)
                {
                    this.startLineMember = this.CreateAttachableMember(startLineGetterMethodInfo, startLineSetterMethodInfo, SourceLocationMemberType.StartLine);
                }
                return this.startLineMember;
            }
        }

        internal XamlMember StartColumnMember
        {
            get
            {
                if (this.startColumnMember == null)
                {
                    this.startColumnMember = this.CreateAttachableMember(startColumnGetterMethodInfo, startColumnSetterMethodInfo, SourceLocationMemberType.StartColumn);
                }
                return this.startColumnMember;
            }
        }

        internal XamlMember EndLineMember
        {
            get
            {
                if (this.endLineMember == null)
                {
                    this.endLineMember = this.CreateAttachableMember(endLineGetterMethodInfo, endLineSetterMethodInfo, SourceLocationMemberType.EndLine);
                }
                return this.endLineMember;
            }
        }

        internal XamlMember EndColumnMember
        {
            get
            {
                if (this.endColumnMember == null)
                {
                    this.endColumnMember = this.CreateAttachableMember(endColumnGetterMethodInfo, endColumnSetterMethodInfo, SourceLocationMemberType.EndColumn);
                }
                return this.endColumnMember;
            }
        }

        private System.Activities.Debugger.XamlNode Current
        {
            get => 
                this.current;
            set => 
                this.current = value;
        }

        private XamlSourceLocationCollector SourceLocationCollector
        {
            get
            {
                if (this.sourceLocationCollector == null)
                {
                    this.sourceLocationCollector = new XamlSourceLocationCollector(this);
                }
                return this.sourceLocationCollector;
            }
        }

        private class SourceLocationMemberInvoker : XamlMemberInvoker
        {
            private XamlDebuggerXmlReader.XamlSourceLocationCollector sourceLocationCollector;
            private SourceLocationMemberType sourceLocationMember;

            public SourceLocationMemberInvoker(XamlDebuggerXmlReader.XamlSourceLocationCollector sourceLocationCollector, SourceLocationMemberType sourceLocationMember)
            {
                this.sourceLocationCollector = sourceLocationCollector;
                this.sourceLocationMember = sourceLocationMember;
            }

            public override object GetValue(object instance)
            {
                UnitTestUtility.Assert(false, "This method should not be called within framework code.");
                return null;
            }

            public override void SetValue(object instance, object propertyValue)
            {
                UnitTestUtility.Assert(propertyValue is int, "The value for this attachable property should be an integer and is ensured by the emitter.");
                int num = (int) propertyValue;
                switch (this.sourceLocationMember)
                {
                    case SourceLocationMemberType.StartLine:
                        this.sourceLocationCollector.OnStartLineFound(instance, num);
                        return;

                    case SourceLocationMemberType.StartColumn:
                        this.sourceLocationCollector.OnStartColumnFound(instance, num);
                        return;

                    case SourceLocationMemberType.EndLine:
                        this.sourceLocationCollector.OnEndLineFound(instance, num);
                        return;

                    case SourceLocationMemberType.EndColumn:
                        this.sourceLocationCollector.OnEndColumnFound(instance, num);
                        return;
                }
                UnitTestUtility.Assert(false, "All possible SourceLocationMember are exhausted.");
            }
        }

        private class ValueNodeXamlMemberInvoker : XamlMemberInvoker
        {
            private XamlDebuggerXmlReader parent;
            private XamlMemberInvoker wrapped;
            private DocumentRange attributeValueRange;

            internal ValueNodeXamlMemberInvoker(XamlDebuggerXmlReader parent, XamlMemberInvoker wrapped, DocumentRange attributeValueRange)
            {
                this.parent = parent;
                this.wrapped = wrapped;
                this.attributeValueRange = attributeValueRange;
            }

            public override object GetValue(object instance) => 
                this.wrapped.GetValue(instance);

            public override void SetValue(object instance, object value)
            {
                this.parent.OnValueNodeDeserialized(value, this.attributeValueRange);
                this.wrapped.SetValue(instance, value);
            }

            public override ShouldSerializeResult ShouldSerializeValue(object instance) => 
                this.wrapped.ShouldSerializeValue(instance);
        }

        private class XamlSourceLocationCollector
        {
            private XamlDebuggerXmlReader parent;
            private object currentObject;
            private int startLine;
            private int startColumn;
            private int endLine;
            private int endColumn;
            private Dictionary<DocumentRange, DocumentRange> objRgnToInitValueRgnMapping;

            internal XamlSourceLocationCollector(XamlDebuggerXmlReader parent)
            {
                this.parent = parent;
                this.objRgnToInitValueRgnMapping = new Dictionary<DocumentRange, DocumentRange>();
            }

            internal void AddValueRange(DocumentRange startNodeRange, DocumentRange valueRange)
            {
                this.objRgnToInitValueRgnMapping.Add(startNodeRange, valueRange);
            }

            private void NotifyValueIfNeeded(object instance)
            {
                if (ShouldReportValue(instance) && this.objRgnToInitValueRgnMapping.TryGetValue(new DocumentRange(this.startLine, this.startColumn, this.endLine, this.endColumn), out DocumentRange range))
                {
                    this.parent.NotifySourceLocationFound(instance, new SourceLocation(null, range.Start.LineNumber.Value, range.Start.LinePosition.Value, range.End.LineNumber.Value, range.End.LinePosition.Value), true);
                }
            }

            internal void OnEndColumnFound(object instance, int value)
            {
                UnitTestUtility.Assert(instance == this.currentObject, "This should be ensured by the XamlSourceLocationObjectReader to emit attachable property in proper order");
                this.endColumn = value;
                this.NotifyValueIfNeeded(instance);
                this.parent.NotifySourceLocationFound(instance, new SourceLocation(null, this.startLine, this.startColumn, this.endLine, this.endColumn), false);
                this.currentObject = null;
            }

            internal void OnEndLineFound(object instance, int value)
            {
                UnitTestUtility.Assert(instance == this.currentObject, "This should be ensured by the XamlSourceLocationObjectReader to emit attachable property in proper order");
                this.endLine = value;
            }

            internal void OnStartColumnFound(object instance, int value)
            {
                UnitTestUtility.Assert(instance == this.currentObject, "This should be ensured by the XamlSourceLocationObjectReader to emit attachable property in proper order");
                this.startColumn = value;
            }

            internal void OnStartLineFound(object instance, int value)
            {
                UnitTestUtility.Assert(this.currentObject == null, "This should be ensured by the XamlSourceLocationObjectReader to emit attachable property in proper order");
                this.currentObject = instance;
                this.startLine = value;
            }

            private static bool ShouldReportValue(object instance) => 
                instance is Argument;
        }
    }
}

