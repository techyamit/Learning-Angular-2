﻿namespace System.Activities.Debugger
{
    using System;

    public sealed class SourceLocationFoundEventArgs : EventArgs
    {
        private object target;
        private System.Activities.Debugger.SourceLocation sourceLocation;
        private bool isValueNode;

        public SourceLocationFoundEventArgs(object target, System.Activities.Debugger.SourceLocation sourceLocation)
        {
            UnitTestUtility.Assert(target > null, "Target cannot be null and is ensured by caller");
            UnitTestUtility.Assert(sourceLocation > null, "Target cannot be null and is ensured by caller");
            this.target = target;
            this.sourceLocation = sourceLocation;
        }

        internal SourceLocationFoundEventArgs(object target, System.Activities.Debugger.SourceLocation sourceLocation, bool isValueNode) : this(target, sourceLocation)
        {
            this.isValueNode = isValueNode;
        }

        public object Target =>
            this.target;

        public System.Activities.Debugger.SourceLocation SourceLocation =>
            this.sourceLocation;

        internal bool IsValueNode =>
            this.isValueNode;
    }
}

