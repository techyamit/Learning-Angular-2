﻿namespace System.Activities.Debugger
{
    using System;
    using System.Collections.Generic;
    using System.IO;

    internal class CharacterSpottingTextReader : TextReader, ICharacterSpottingTextReaderForUnitTest
    {
        private const char StartAngleBracket = '<';
        private const char EndAngleBracket = '>';
        private const char SingleQuote = '\'';
        private const char DoubleQuote = '"';
        private const char EndLine = '\n';
        private const char CarriageReturn = '\r';
        private TextReader underlyingReader;
        private int currentLine;
        private int currentPosition;
        private List<DocumentLocation> startAngleBrackets;
        private List<DocumentLocation> endAngleBrackets;
        private List<DocumentLocation> singleQuotes;
        private List<DocumentLocation> doubleQuotes;
        private List<DocumentLocation> endLines;

        public CharacterSpottingTextReader(TextReader underlyingReader)
        {
            UnitTestUtility.Assert(underlyingReader > null, "underlyingReader should not be null and should be ensured by caller.");
            this.underlyingReader = underlyingReader;
            this.currentLine = 1;
            this.currentPosition = 1;
            this.startAngleBrackets = new List<DocumentLocation>();
            this.endAngleBrackets = new List<DocumentLocation>();
            this.singleQuotes = new List<DocumentLocation>();
            this.doubleQuotes = new List<DocumentLocation>();
            this.endLines = new List<DocumentLocation>();
        }

        private char AnalyzeReadData(char lastCharacterRead)
        {
            if ((lastCharacterRead == '\r') && (this.underlyingReader.Peek() == 10))
            {
                lastCharacterRead = (char) this.underlyingReader.Read();
            }
            if ((lastCharacterRead == '\n') || (lastCharacterRead == '\r'))
            {
                this.endLines.Add(this.CurrentLocation);
                this.currentLine++;
                this.currentPosition = 1;
                return '\n';
            }
            List<DocumentLocation> locationList = this.GetLocationList(lastCharacterRead);
            if (locationList != null)
            {
                locationList.Add(this.CurrentLocation);
            }
            this.currentPosition++;
            return lastCharacterRead;
        }

        public override void Close()
        {
            this.underlyingReader.Close();
        }

        internal DocumentLocation FindCharacterStrictlyAfter(char c, DocumentLocation afterLocation)
        {
            List<DocumentLocation> locationList = this.GetLocationList(c);
            UnitTestUtility.Assert(locationList > null, "We should always find character for special characters only");
            DocumentLocation item = new DocumentLocation(afterLocation.LineNumber, new OneBasedCounter(afterLocation.LinePosition.Value + 1));
            BinarySearchResult result = locationList.MyBinarySearch<DocumentLocation>(item);
            if (result.IsFound)
            {
                return item;
            }
            if (result.IsNextIndexAvailable)
            {
                return locationList[result.NextIndex];
            }
            return null;
        }

        internal DocumentLocation FindCharacterStrictlyBefore(char c, DocumentLocation documentLocation)
        {
            List<DocumentLocation> locationList = this.GetLocationList(c);
            UnitTestUtility.Assert(locationList > null, "We should always find character for special characters only");
            BinarySearchResult result = locationList.MyBinarySearch<DocumentLocation>(documentLocation);
            if (result.IsFound)
            {
                if (result.FoundIndex > 0)
                {
                    return locationList[result.FoundIndex - 1];
                }
                return null;
            }
            if (result.IsNextIndexAvailable)
            {
                if (result.NextIndex > 0)
                {
                    return locationList[result.NextIndex - 1];
                }
                return null;
            }
            if (locationList.Count > 0)
            {
                return locationList[locationList.Count - 1];
            }
            return null;
        }

        private List<DocumentLocation> GetLocationList(char c)
        {
            if (c <= '"')
            {
                if (c == '\n')
                {
                    return this.endLines;
                }
                if (c == '"')
                {
                    return this.doubleQuotes;
                }
            }
            else
            {
                if (c == '\'')
                {
                    return this.singleQuotes;
                }
                if (c != '<')
                {
                    if (c == '>')
                    {
                        return this.endAngleBrackets;
                    }
                }
                else
                {
                    return this.startAngleBrackets;
                }
            }
            return null;
        }

        public override int Peek() => 
            this.underlyingReader.Peek();

        public override int Read()
        {
            int num = this.underlyingReader.Read();
            if (num != -1)
            {
                num = this.AnalyzeReadData((char) num);
            }
            return num;
        }

        private DocumentLocation CurrentLocation =>
            new DocumentLocation(this.currentLine, this.currentPosition);

        int ICharacterSpottingTextReaderForUnitTest.CurrentLine =>
            this.currentLine;

        int ICharacterSpottingTextReaderForUnitTest.CurrentPosition =>
            this.currentPosition;

        List<DocumentLocation> ICharacterSpottingTextReaderForUnitTest.StartBrackets =>
            this.startAngleBrackets;

        List<DocumentLocation> ICharacterSpottingTextReaderForUnitTest.EndBrackets =>
            this.endAngleBrackets;

        List<DocumentLocation> ICharacterSpottingTextReaderForUnitTest.SingleQuotes =>
            this.singleQuotes;

        List<DocumentLocation> ICharacterSpottingTextReaderForUnitTest.DoubleQuotes =>
            this.doubleQuotes;
    }
}

