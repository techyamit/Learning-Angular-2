﻿namespace System.Activities.Debugger
{
    using System;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;

    internal static class ListExtensions
    {
        internal static BinarySearchResult MyBinarySearch<T>(this List<T> input, T item) => 
            new BinarySearchResult(input.BinarySearch(item), input.Count);
    }
}

