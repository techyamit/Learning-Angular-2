﻿namespace System.Activities.Debugger
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;

    [DebuggerNonUserCode]
    public class VirtualStackFrame
    {
        private System.Activities.Debugger.State state;
        private IDictionary<string, object> locals;

        public VirtualStackFrame(System.Activities.Debugger.State state) : this(state, null)
        {
        }

        public VirtualStackFrame(System.Activities.Debugger.State state, IDictionary<string, object> locals)
        {
            this.state = state;
            this.locals = locals;
        }

        public override string ToString() => 
            this.state.ToString();

        public System.Activities.Debugger.State State =>
            this.state;

        public IDictionary<string, object> Locals =>
            this.locals;
    }
}

