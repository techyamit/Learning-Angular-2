﻿namespace System.Activities
{
    using System;
    using System.Diagnostics;
    using System.Runtime.InteropServices;

    [StructLayout(LayoutKind.Sequential)]
    public struct CodeActivityPublicEnvironmentAccessor
    {
        private CodeActivityMetadata metadata;
        private bool withoutArgument;
        public CodeActivityMetadata ActivityMetadata =>
            this.metadata;
        public static CodeActivityPublicEnvironmentAccessor Create(CodeActivityMetadata metadata)
        {
            metadata.ThrowIfDisposed();
            return new CodeActivityPublicEnvironmentAccessor { metadata = metadata };
        }

        internal static CodeActivityPublicEnvironmentAccessor CreateWithoutArgument(CodeActivityMetadata metadata)
        {
            CodeActivityPublicEnvironmentAccessor accessor = Create(metadata);
            accessor.withoutArgument = true;
            return accessor;
        }

        public static bool operator ==(CodeActivityPublicEnvironmentAccessor left, CodeActivityPublicEnvironmentAccessor right) => 
            left.Equals(right);

        public static bool operator !=(CodeActivityPublicEnvironmentAccessor left, CodeActivityPublicEnvironmentAccessor right) => 
            !left.Equals(right);

        public bool TryGetAccessToPublicLocation(LocationReference publicLocation, ArgumentDirection accessDirection, out LocationReference equivalentLocation)
        {
            if (publicLocation == null)
            {
                throw FxTrace.Exception.ArgumentNull("publicLocation");
            }
            this.ThrowIfUninitialized();
            return this.TryGetAccessToPublicLocation(publicLocation, accessDirection, false, out equivalentLocation);
        }

        public bool TryGetReferenceToPublicLocation(LocationReference publicReference, out LocationReference equivalentReference)
        {
            if (publicReference == null)
            {
                throw FxTrace.Exception.ArgumentNull("publicReference");
            }
            this.ThrowIfUninitialized();
            return this.TryGetReferenceToPublicLocation(publicReference, false, out equivalentReference);
        }

        public override bool Equals(object obj)
        {
            if (!(obj is CodeActivityPublicEnvironmentAccessor))
            {
                return false;
            }
            CodeActivityPublicEnvironmentAccessor accessor = (CodeActivityPublicEnvironmentAccessor) obj;
            return (accessor.metadata == this.metadata);
        }

        public override int GetHashCode() => 
            this.metadata.GetHashCode();

        internal bool TryGetAccessToPublicLocation(LocationReference publicLocation, ArgumentDirection accessDirection, bool useLocationReferenceValue, out LocationReference equivalentLocation)
        {
            if (this.metadata.Environment.IsVisible(publicLocation))
            {
                if (!this.withoutArgument)
                {
                    this.CreateArgument(publicLocation, accessDirection, useLocationReferenceValue);
                }
                equivalentLocation = new InlinedLocationReference(publicLocation, this.metadata.CurrentActivity, accessDirection);
                return true;
            }
            equivalentLocation = null;
            return false;
        }

        internal bool TryGetReferenceToPublicLocation(LocationReference publicReference, bool useLocationReferenceValue, out LocationReference equivalentReference)
        {
            if (this.metadata.Environment.IsVisible(publicReference))
            {
                if (!this.withoutArgument)
                {
                    this.CreateLocationArgument(publicReference, useLocationReferenceValue);
                }
                equivalentReference = new InlinedLocationReference(publicReference, this.metadata.CurrentActivity);
                return true;
            }
            equivalentReference = null;
            return false;
        }

        internal void CreateArgument(LocationReference sourceReference, ArgumentDirection accessDirection, bool useLocationReferenceValue = false)
        {
            ActivityWithResult expression = ActivityUtilities.CreateLocationAccessExpression(sourceReference, accessDirection > ArgumentDirection.In, useLocationReferenceValue);
            this.AddGeneratedArgument(sourceReference.Type, accessDirection, expression);
        }

        internal void CreateLocationArgument(LocationReference sourceReference, bool useLocationReferenceValue = false)
        {
            ActivityWithResult expression = ActivityUtilities.CreateLocationAccessExpression(sourceReference, true, useLocationReferenceValue);
            this.AddGeneratedArgument(expression.ResultType, ArgumentDirection.In, expression);
        }

        private void AddGeneratedArgument(Type argumentType, ArgumentDirection direction, ActivityWithResult expression)
        {
            Argument binding = ActivityUtilities.CreateArgument(argumentType, direction);
            binding.Expression = expression;
            RuntimeArgument argument = this.metadata.CurrentActivity.AddTempAutoGeneratedArgument(argumentType, direction);
            Argument.TryBind(binding, argument, this.metadata.CurrentActivity);
        }

        private void ThrowIfUninitialized()
        {
            if (this.metadata.CurrentActivity == null)
            {
                throw FxTrace.Exception.AsError(new ObjectDisposedException(this.ToString()));
            }
        }

        [Conditional("DEBUG")]
        private static void AssertIsCodeActivity(Activity activity)
        {
            Type type = null;
            ActivityWithResult result = activity as ActivityWithResult;
            if (result != null)
            {
                Type[] typeArguments = new Type[] { result.ResultType };
                type = typeof(CodeActivity<>).MakeGenericType(typeArguments);
            }
        }
    }
}

