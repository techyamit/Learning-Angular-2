﻿namespace System.Activities
{
    using System;
    using System.Activities.Runtime;
    using System.Activities.Tracking;
    using System.Globalization;
    using System.Runtime;
    using System.Runtime.CompilerServices;

    public class ActivityContext
    {
        private System.Activities.ActivityInstance instance;
        private ActivityExecutor executor;
        private bool isDisposed;
        private long instanceId;

        internal ActivityContext()
        {
        }

        internal ActivityContext(System.Activities.ActivityInstance instance, ActivityExecutor executor)
        {
            this.instance = instance;
            this.executor = executor;
            this.Activity = this.instance.Activity;
            this.instanceId = instance.InternalId;
        }

        internal void Dispose()
        {
            this.isDisposed = true;
            this.instance = null;
            this.executor = null;
            this.Activity = null;
            this.instanceId = 0L;
        }

        internal void DisposeDataContext()
        {
            if (this.instance.DataContext != null)
            {
                this.instance.DataContext.DisposeEnvironment();
                this.instance.DataContext = null;
            }
        }

        public T GetExtension<T>() where T: class
        {
            this.ThrowIfDisposed();
            return this.executor.GetExtension<T>();
        }

        internal System.Activities.Location GetIgnorableResultLocation(RuntimeArgument resultArgument) => 
            this.executor.GetIgnorableResultLocation(resultArgument);

        public Location<T> GetLocation<T>(LocationReference locationReference)
        {
            this.ThrowIfDisposed();
            if (locationReference == null)
            {
                throw FxTrace.Exception.ArgumentNull("locationReference");
            }
            System.Activities.Location innerLocation = locationReference.GetLocation(this);
            Location<T> location2 = innerLocation as Location<T>;
            if (location2 != null)
            {
                return location2;
            }
            if (locationReference.Type != typeof(T))
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.LocationTypeMismatch(locationReference.Name, typeof(T), locationReference.Type)));
            }
            return new TypedLocationWrapper<T>(innerLocation);
        }

        public object GetValue(Argument argument)
        {
            this.ThrowIfDisposed();
            if (argument == null)
            {
                throw FxTrace.Exception.ArgumentNull("argument");
            }
            argument.ThrowIfNotInTree();
            return this.GetValueCore<object>(argument.RuntimeArgument);
        }

        public T GetValue<T>(InArgument<T> argument)
        {
            this.ThrowIfDisposed();
            if (argument == null)
            {
                throw FxTrace.Exception.ArgumentNull("argument");
            }
            argument.ThrowIfNotInTree();
            return this.GetValueCore<T>(argument.RuntimeArgument);
        }

        public T GetValue<T>(InOutArgument<T> argument)
        {
            this.ThrowIfDisposed();
            if (argument == null)
            {
                throw FxTrace.Exception.ArgumentNull("argument");
            }
            argument.ThrowIfNotInTree();
            return this.GetValueCore<T>(argument.RuntimeArgument);
        }

        public T GetValue<T>(LocationReference locationReference)
        {
            this.ThrowIfDisposed();
            if (locationReference == null)
            {
                throw FxTrace.Exception.ArgumentNull("locationReference");
            }
            return this.GetValueCore<T>(locationReference);
        }

        public T GetValue<T>(OutArgument<T> argument)
        {
            this.ThrowIfDisposed();
            if (argument == null)
            {
                throw FxTrace.Exception.ArgumentNull("argument");
            }
            argument.ThrowIfNotInTree();
            return this.GetValueCore<T>(argument.RuntimeArgument);
        }

        public object GetValue(RuntimeArgument runtimeArgument)
        {
            this.ThrowIfDisposed();
            if (runtimeArgument == null)
            {
                throw FxTrace.Exception.ArgumentNull("runtimeArgument");
            }
            return this.GetValueCore<object>(runtimeArgument);
        }

        internal T GetValueCore<T>(LocationReference locationReference)
        {
            System.Activities.Location locationForRead = locationReference.GetLocationForRead(this);
            Location<T> location2 = locationForRead as Location<T>;
            if (location2 != null)
            {
                return location2.Value;
            }
            return TypeHelper.Convert<T>(locationForRead.Value);
        }

        internal void Reinitialize(System.Activities.ActivityInstance instance, ActivityExecutor executor)
        {
            this.Reinitialize(instance, executor, instance.Activity, instance.InternalId);
        }

        internal void Reinitialize(System.Activities.ActivityInstance instance, ActivityExecutor executor, System.Activities.Activity activity, long instanceId)
        {
            this.isDisposed = false;
            this.instance = instance;
            this.executor = executor;
            this.Activity = activity;
            this.instanceId = instanceId;
        }

        public void SetValue(Argument argument, object value)
        {
            this.ThrowIfDisposed();
            if (argument == null)
            {
                throw FxTrace.Exception.ArgumentNull("argument");
            }
            argument.ThrowIfNotInTree();
            this.SetValueCore<object>(argument.RuntimeArgument, value);
        }

        public void SetValue<T>(InArgument<T> argument, T value)
        {
            this.ThrowIfDisposed();
            if (argument != null)
            {
                argument.ThrowIfNotInTree();
                this.SetValueCore<T>(argument.RuntimeArgument, value);
            }
        }

        public void SetValue<T>(InOutArgument<T> argument, T value)
        {
            this.ThrowIfDisposed();
            if (argument != null)
            {
                argument.ThrowIfNotInTree();
                this.SetValueCore<T>(argument.RuntimeArgument, value);
            }
        }

        public void SetValue<T>(LocationReference locationReference, T value)
        {
            this.ThrowIfDisposed();
            if (locationReference == null)
            {
                throw FxTrace.Exception.ArgumentNull("locationReference");
            }
            this.SetValueCore<T>(locationReference, value);
        }

        public void SetValue<T>(OutArgument<T> argument, T value)
        {
            this.ThrowIfDisposed();
            if (argument != null)
            {
                argument.ThrowIfNotInTree();
                this.SetValueCore<T>(argument.RuntimeArgument, value);
            }
        }

        internal void SetValueCore<T>(LocationReference locationReference, T value)
        {
            System.Activities.Location locationForWrite = locationReference.GetLocationForWrite(this);
            Location<T> location2 = locationForWrite as Location<T>;
            if (location2 != null)
            {
                location2.Value = value;
            }
            else
            {
                if (!TypeHelper.AreTypesCompatible(value, locationReference.Type))
                {
                    throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.CannotSetValueToLocation((value != null) ? value.GetType() : typeof(T), locationReference.Name, locationReference.Type)));
                }
                locationForWrite.Value = value;
            }
        }

        internal void ThrowIfDisposed()
        {
            if (this.isDisposed)
            {
                throw FxTrace.Exception.AsError(new ObjectDisposedException(base.GetType().FullName, System.Activities.SR.AECDisposed));
            }
        }

        internal void TrackCore(CustomTrackingRecord record)
        {
            if (this.executor.ShouldTrack)
            {
                record.Activity = new ActivityInfo(this.instance);
                record.InstanceId = this.WorkflowInstanceId;
                this.executor.AddTrackingRecord(record);
            }
        }

        internal LocationEnvironment Environment
        {
            get
            {
                this.ThrowIfDisposed();
                return this.instance.Environment;
            }
        }

        internal bool AllowChainedEnvironmentAccess { get; set; }

        internal System.Activities.Activity Activity { get; private set; }

        internal System.Activities.ActivityInstance CurrentInstance =>
            this.instance;

        internal ActivityExecutor CurrentExecutor =>
            this.executor;

        public string ActivityInstanceId
        {
            get
            {
                this.ThrowIfDisposed();
                return this.instanceId.ToString(CultureInfo.InvariantCulture);
            }
        }

        public Guid WorkflowInstanceId
        {
            get
            {
                this.ThrowIfDisposed();
                return this.executor.WorkflowInstanceId;
            }
        }

        public WorkflowDataContext DataContext
        {
            get
            {
                this.ThrowIfDisposed();
                bool includeLocalVariables = !this.instance.IsResolvingArguments;
                if ((this.instance.DataContext == null) || (this.instance.DataContext.IncludesLocalVariables != includeLocalVariables))
                {
                    this.instance.DataContext = new WorkflowDataContext(this.executor, this.instance, includeLocalVariables);
                }
                return this.instance.DataContext;
            }
        }

        internal bool IsDisposed =>
            this.isDisposed;
    }
}

