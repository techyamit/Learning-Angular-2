﻿namespace System.Activities
{
    using System;

    public enum PersistableIdleAction
    {
        None,
        Unload,
        Persist
    }
}

