﻿namespace System.Activities.Tracking
{
    using System;
    using System.Activities;
    using System.Diagnostics;
    using System.Globalization;
    using System.Runtime.Serialization;

    [DataContract]
    public sealed class WorkflowInstanceTerminatedRecord : WorkflowInstanceRecord
    {
        private string reason;

        private WorkflowInstanceTerminatedRecord(WorkflowInstanceTerminatedRecord record) : base(record)
        {
            this.Reason = record.Reason;
        }

        public WorkflowInstanceTerminatedRecord(Guid instanceId, string activityDefinitionId, string reason) : base(instanceId, activityDefinitionId, "Terminated")
        {
            if (string.IsNullOrEmpty(reason))
            {
                throw System.Activities.FxTrace.Exception.ArgumentNullOrEmpty("reason");
            }
            this.Reason = reason;
            base.Level = TraceLevel.Error;
        }

        public WorkflowInstanceTerminatedRecord(Guid instanceId, long recordNumber, string activityDefinitionId, string reason) : base(instanceId, recordNumber, activityDefinitionId, "Terminated")
        {
            if (string.IsNullOrEmpty(reason))
            {
                throw System.Activities.FxTrace.Exception.ArgumentNullOrEmpty("reason");
            }
            this.Reason = reason;
            base.Level = TraceLevel.Error;
        }

        public WorkflowInstanceTerminatedRecord(Guid instanceId, string activityDefinitionId, string reason, WorkflowIdentity workflowDefinitionIdentity) : this(instanceId, activityDefinitionId, reason)
        {
            base.WorkflowDefinitionIdentity = workflowDefinitionIdentity;
        }

        public WorkflowInstanceTerminatedRecord(Guid instanceId, long recordNumber, string activityDefinitionId, string reason, WorkflowIdentity workflowDefinitionIdentity) : this(instanceId, recordNumber, activityDefinitionId, reason)
        {
            base.WorkflowDefinitionIdentity = workflowDefinitionIdentity;
        }

        protected internal override TrackingRecord Clone() => 
            new WorkflowInstanceTerminatedRecord(this);

        public override string ToString()
        {
            if (base.WorkflowDefinitionIdentity == null)
            {
                object[] objArray1 = new object[] { base.InstanceId, base.RecordNumber, base.EventTime, base.ActivityDefinitionId, this.Reason };
                return string.Format(CultureInfo.CurrentCulture, "WorkflowInstanceTerminatedRecord {{ InstanceId = {0}, RecordNumber = {1}, EventTime = {2}, ActivityDefinitionId = {3}, Reason = {4} }} ", objArray1);
            }
            object[] args = new object[] { base.InstanceId, base.RecordNumber, base.EventTime, base.ActivityDefinitionId, this.Reason, base.WorkflowDefinitionIdentity };
            return string.Format(CultureInfo.CurrentCulture, "WorkflowInstanceTerminatedRecord {{ InstanceId = {0}, RecordNumber = {1}, EventTime = {2}, ActivityDefinitionId = {3}, Reason = {4}, WorkflowDefinitionIdentity = {5} }} ", args);
        }

        public string Reason
        {
            get => 
                this.reason;
            private set => 
                this.reason = value;
        }

        [DataMember(Name="Reason")]
        internal string SerializedReason
        {
            get => 
                this.Reason;
            set => 
                this.Reason = value;
        }
    }
}

