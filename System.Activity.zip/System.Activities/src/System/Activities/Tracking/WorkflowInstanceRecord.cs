﻿namespace System.Activities.Tracking
{
    using System;
    using System.Activities;
    using System.Globalization;
    using System.Runtime.Serialization;

    [DataContract]
    public class WorkflowInstanceRecord : TrackingRecord
    {
        private WorkflowIdentity workflowDefinitionIdentity;
        private string state;
        private string activityDefinitionId;

        protected WorkflowInstanceRecord(WorkflowInstanceRecord record) : base(record)
        {
            this.ActivityDefinitionId = record.ActivityDefinitionId;
            this.State = record.State;
            this.WorkflowDefinitionIdentity = record.WorkflowDefinitionIdentity;
        }

        public WorkflowInstanceRecord(Guid instanceId, string activityDefinitionId, string state) : base(instanceId)
        {
            if (string.IsNullOrEmpty(activityDefinitionId))
            {
                throw System.Activities.FxTrace.Exception.ArgumentNullOrEmpty("activityDefinitionId");
            }
            if (string.IsNullOrEmpty(state))
            {
                throw System.Activities.FxTrace.Exception.ArgumentNullOrEmpty("state");
            }
            this.ActivityDefinitionId = activityDefinitionId;
            this.State = state;
        }

        public WorkflowInstanceRecord(Guid instanceId, long recordNumber, string activityDefinitionId, string state) : base(instanceId, recordNumber)
        {
            if (string.IsNullOrEmpty(activityDefinitionId))
            {
                throw System.Activities.FxTrace.Exception.ArgumentNullOrEmpty("activityDefinitionId");
            }
            if (string.IsNullOrEmpty(state))
            {
                throw System.Activities.FxTrace.Exception.ArgumentNullOrEmpty("state");
            }
            this.ActivityDefinitionId = activityDefinitionId;
            this.State = state;
        }

        public WorkflowInstanceRecord(Guid instanceId, string activityDefinitionId, string state, WorkflowIdentity workflowDefinitionIdentity) : this(instanceId, activityDefinitionId, state)
        {
            this.WorkflowDefinitionIdentity = workflowDefinitionIdentity;
        }

        public WorkflowInstanceRecord(Guid instanceId, long recordNumber, string activityDefinitionId, string state, WorkflowIdentity workflowDefinitionIdentity) : this(instanceId, recordNumber, activityDefinitionId, state)
        {
            this.WorkflowDefinitionIdentity = workflowDefinitionIdentity;
        }

        protected internal override TrackingRecord Clone() => 
            new WorkflowInstanceRecord(this);

        public override string ToString()
        {
            if (this.WorkflowDefinitionIdentity == null)
            {
                object[] objArray1 = new object[] { base.ToString(), this.ActivityDefinitionId, this.State };
                return string.Format(CultureInfo.CurrentCulture, "WorkflowInstanceRecord {{ {0}, ActivityDefinitionId = {1}, State = {2} }}", objArray1);
            }
            object[] args = new object[] { base.ToString(), this.ActivityDefinitionId, this.State, this.WorkflowDefinitionIdentity };
            return string.Format(CultureInfo.CurrentCulture, "WorkflowInstanceRecord {{ {0}, ActivityDefinitionId = {1}, State = {2}, WorkflowDefinitionIdentity = {3} }}", args);
        }

        public WorkflowIdentity WorkflowDefinitionIdentity
        {
            get => 
                this.workflowDefinitionIdentity;
            protected set => 
                this.workflowDefinitionIdentity = value;
        }

        public string State
        {
            get => 
                this.state;
            private set => 
                this.state = value;
        }

        public string ActivityDefinitionId
        {
            get => 
                this.activityDefinitionId;
            private set => 
                this.activityDefinitionId = value;
        }

        [DataMember(Name="WorkflowDefinitionIdentity")]
        internal WorkflowIdentity SerializedWorkflowDefinitionIdentity
        {
            get => 
                this.WorkflowDefinitionIdentity;
            set => 
                this.WorkflowDefinitionIdentity = value;
        }

        [DataMember(Name="State")]
        internal string SerializedState
        {
            get => 
                this.State;
            set => 
                this.State = value;
        }

        [DataMember(Name="ActivityDefinitionId")]
        internal string SerializedActivityDefinitionId
        {
            get => 
                this.ActivityDefinitionId;
            set => 
                this.ActivityDefinitionId = value;
        }
    }
}

