﻿namespace System.Activities.Tracking
{
    using System;
    using System.Activities;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Globalization;
    using System.Runtime.Serialization;

    [DataContract]
    public class CustomTrackingRecord : TrackingRecord
    {
        private IDictionary<string, object> data;
        private string name;
        private ActivityInfo activity;

        protected CustomTrackingRecord(CustomTrackingRecord record) : base(record)
        {
            this.Name = record.Name;
            this.Activity = record.Activity;
            if ((record.data != null) && (record.data.Count > 0))
            {
                foreach (KeyValuePair<string, object> pair in record.data)
                {
                    this.Data.Add(pair);
                }
            }
        }

        public CustomTrackingRecord(string name) : this(name, TraceLevel.Info)
        {
        }

        public CustomTrackingRecord(string name, TraceLevel level) : this(Guid.Empty, name, level)
        {
        }

        public CustomTrackingRecord(Guid instanceId, string name, TraceLevel level) : base(instanceId)
        {
            if (string.IsNullOrEmpty(name))
            {
                throw System.Activities.FxTrace.Exception.ArgumentNull("name");
            }
            this.Name = name;
            base.Level = level;
        }

        protected internal override TrackingRecord Clone() => 
            new CustomTrackingRecord(this);

        public override string ToString()
        {
            object[] args = new object[] { base.ToString(), this.Name, (this.Activity == null) ? "<null>" : this.Activity.ToString(), base.Level };
            return string.Format(CultureInfo.InvariantCulture, "CustomTrackingRecord {{ {0}, Name={1}, Activity {{ {2} }}, Level = {3} }}", args);
        }

        public string Name
        {
            get => 
                this.name;
            private set => 
                this.name = value;
        }

        public ActivityInfo Activity
        {
            get => 
                this.activity;
            internal set => 
                this.activity = value;
        }

        public IDictionary<string, object> Data
        {
            get
            {
                if (this.data == null)
                {
                    this.data = new Dictionary<string, object>();
                }
                return this.data;
            }
        }

        [DataMember(EmitDefaultValue=false, Name="data")]
        internal IDictionary<string, object> SerializedData
        {
            get => 
                this.data;
            set => 
                this.data = value;
        }

        [DataMember(Name="Name")]
        internal string SerializedName
        {
            get => 
                this.Name;
            set => 
                this.Name = value;
        }

        [DataMember(Name="Activity")]
        internal ActivityInfo SerializedActivity
        {
            get => 
                this.Activity;
            set => 
                this.Activity = value;
        }
    }
}

