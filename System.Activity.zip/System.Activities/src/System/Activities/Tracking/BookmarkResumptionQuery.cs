﻿namespace System.Activities.Tracking
{
    using System;
    using System.Runtime.CompilerServices;

    public sealed class BookmarkResumptionQuery : TrackingQuery
    {
        public string Name { get; set; }
    }
}

