﻿namespace System.Activities.Tracking
{
    using System;
    using System.Activities;
    using System.Diagnostics;
    using System.Globalization;
    using System.Runtime.Serialization;

    [DataContract]
    public sealed class WorkflowInstanceUnhandledExceptionRecord : WorkflowInstanceRecord
    {
        private Exception unhandledException;
        private ActivityInfo faultSource;

        private WorkflowInstanceUnhandledExceptionRecord(WorkflowInstanceUnhandledExceptionRecord record) : base(record)
        {
            this.FaultSource = record.FaultSource;
            this.UnhandledException = record.UnhandledException;
        }

        public WorkflowInstanceUnhandledExceptionRecord(Guid instanceId, string activityDefinitionId, ActivityInfo faultSource, Exception exception) : this(instanceId, 0L, activityDefinitionId, faultSource, exception)
        {
        }

        public WorkflowInstanceUnhandledExceptionRecord(Guid instanceId, long recordNumber, string activityDefinitionId, ActivityInfo faultSource, Exception exception) : base(instanceId, recordNumber, activityDefinitionId, "UnhandledException")
        {
            if (string.IsNullOrEmpty(activityDefinitionId))
            {
                throw System.Activities.FxTrace.Exception.ArgumentNullOrEmpty("activityDefinitionId");
            }
            if (exception == null)
            {
                throw System.Activities.FxTrace.Exception.ArgumentNull("exception");
            }
            if (faultSource == null)
            {
                throw System.Activities.FxTrace.Exception.ArgumentNull("faultSource");
            }
            this.FaultSource = faultSource;
            this.UnhandledException = exception;
            base.Level = TraceLevel.Error;
        }

        public WorkflowInstanceUnhandledExceptionRecord(Guid instanceId, string activityDefinitionId, ActivityInfo faultSource, Exception exception, WorkflowIdentity workflowDefinitionIdentity) : this(instanceId, activityDefinitionId, faultSource, exception)
        {
            base.WorkflowDefinitionIdentity = workflowDefinitionIdentity;
        }

        public WorkflowInstanceUnhandledExceptionRecord(Guid instanceId, long recordNumber, string activityDefinitionId, ActivityInfo faultSource, Exception exception, WorkflowIdentity workflowDefinitionIdentity) : this(instanceId, recordNumber, activityDefinitionId, faultSource, exception)
        {
            base.WorkflowDefinitionIdentity = workflowDefinitionIdentity;
        }

        protected internal override TrackingRecord Clone() => 
            new WorkflowInstanceUnhandledExceptionRecord(this);

        public override string ToString()
        {
            if (base.WorkflowDefinitionIdentity == null)
            {
                object[] objArray1 = new object[] { base.InstanceId, base.RecordNumber, base.EventTime, base.ActivityDefinitionId, this.FaultSource.ToString(), this.UnhandledException };
                return string.Format(CultureInfo.CurrentCulture, "WorkflowInstanceUnhandledExceptionRecord {{ InstanceId = {0}, RecordNumber = {1}, EventTime = {2}, ActivityDefinitionId = {3}, FaultSource {{ {4} }}, UnhandledException = {5} }} ", objArray1);
            }
            object[] args = new object[] { base.InstanceId, base.RecordNumber, base.EventTime, base.ActivityDefinitionId, this.FaultSource.ToString(), this.UnhandledException, base.WorkflowDefinitionIdentity };
            return string.Format(CultureInfo.CurrentCulture, "WorkflowInstanceUnhandledExceptionRecord {{ InstanceId = {0}, RecordNumber = {1}, EventTime = {2}, ActivityDefinitionId = {3}, FaultSource {{ {4} }}, UnhandledException = {5}, WorkflowDefinitionIdentity = {6} }} ", args);
        }

        public Exception UnhandledException
        {
            get => 
                this.unhandledException;
            private set => 
                this.unhandledException = value;
        }

        public ActivityInfo FaultSource
        {
            get => 
                this.faultSource;
            private set => 
                this.faultSource = value;
        }

        [DataMember(Name="UnhandledException")]
        internal Exception SerializedUnhandledException
        {
            get => 
                this.UnhandledException;
            set => 
                this.UnhandledException = value;
        }

        [DataMember(Name="FaultSource")]
        internal ActivityInfo SerializedFaultSource
        {
            get => 
                this.FaultSource;
            set => 
                this.FaultSource = value;
        }
    }
}

