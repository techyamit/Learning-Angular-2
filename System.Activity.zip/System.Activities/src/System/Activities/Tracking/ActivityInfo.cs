﻿namespace System.Activities.Tracking
{
    using System;
    using System.Activities;
    using System.Globalization;
    using System.Runtime.CompilerServices;
    using System.Runtime.Serialization;

    [DataContract]
    public sealed class ActivityInfo
    {
        private string name;
        private string id;
        private string instanceId;
        private long instanceIdInternal;
        private string typeName;

        internal ActivityInfo(System.Activities.ActivityInstance instance) : this(instance.Activity, instance.InternalId)
        {
            this.Instance = instance;
        }

        internal ActivityInfo(System.Activities.Activity activity, long instanceId)
        {
            this.Activity = activity;
            this.instanceIdInternal = instanceId;
        }

        public ActivityInfo(string name, string id, string instanceId, string typeName)
        {
            if (string.IsNullOrEmpty(name))
            {
                throw System.Activities.FxTrace.Exception.ArgumentNullOrEmpty("name");
            }
            if (string.IsNullOrEmpty(id))
            {
                throw System.Activities.FxTrace.Exception.ArgumentNullOrEmpty("id");
            }
            if (string.IsNullOrEmpty(instanceId))
            {
                throw System.Activities.FxTrace.Exception.ArgumentNullOrEmpty("instanceId");
            }
            if (string.IsNullOrEmpty(typeName))
            {
                throw System.Activities.FxTrace.Exception.ArgumentNullOrEmpty("typeName");
            }
            this.Name = name;
            this.Id = id;
            this.InstanceId = instanceId;
            this.TypeName = typeName;
        }

        public override string ToString()
        {
            object[] args = new object[] { this.Name, this.Id, this.InstanceId, this.TypeName };
            return string.Format(CultureInfo.CurrentCulture, "Name={0}, ActivityId = {1}, ActivityInstanceId = {2}, TypeName={3}", args);
        }

        internal System.Activities.ActivityInstance Instance { get; private set; }

        [DataMember]
        public string Name
        {
            get
            {
                if (string.IsNullOrEmpty(this.name))
                {
                    this.name = this.Activity.DisplayName;
                }
                return this.name;
            }
            internal set => 
                this.name = value;
        }

        [DataMember]
        public string Id
        {
            get
            {
                if (string.IsNullOrEmpty(this.id))
                {
                    this.id = this.Activity.Id;
                }
                return this.id;
            }
            internal set => 
                this.id = value;
        }

        [DataMember]
        public string InstanceId
        {
            get
            {
                if (string.IsNullOrEmpty(this.instanceId))
                {
                    this.instanceId = this.instanceIdInternal.ToString(CultureInfo.InvariantCulture);
                }
                return this.instanceId;
            }
            internal set => 
                this.instanceId = value;
        }

        [DataMember]
        public string TypeName
        {
            get
            {
                if (string.IsNullOrEmpty(this.typeName))
                {
                    this.typeName = this.Activity.GetType().FullName;
                }
                return this.typeName;
            }
            internal set => 
                this.typeName = value;
        }

        internal System.Activities.Activity Activity { get; private set; }
    }
}

