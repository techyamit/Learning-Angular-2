﻿namespace System.Activities.Tracking
{
    using System;
    using System.Activities;
    using System.Globalization;
    using System.Runtime.Serialization;

    [DataContract]
    public sealed class BookmarkResumptionRecord : TrackingRecord
    {
        private Guid bookmarkScope;
        private string bookmarkName;
        private object payload;
        private ActivityInfo owner;

        private BookmarkResumptionRecord(BookmarkResumptionRecord record) : base(record)
        {
            this.BookmarkScope = record.BookmarkScope;
            this.Owner = record.Owner;
            this.BookmarkName = record.BookmarkName;
            this.Payload = record.Payload;
        }

        internal BookmarkResumptionRecord(Guid instanceId, Bookmark bookmark, System.Activities.ActivityInstance ownerInstance, object payload) : base(instanceId)
        {
            if (bookmark.Scope != null)
            {
                this.BookmarkScope = bookmark.Scope.Id;
            }
            if (bookmark.IsNamed)
            {
                this.BookmarkName = bookmark.Name;
            }
            this.Owner = new ActivityInfo(ownerInstance);
            this.Payload = payload;
        }

        public BookmarkResumptionRecord(Guid instanceId, long recordNumber, Guid bookmarkScope, string bookmarkName, ActivityInfo owner) : base(instanceId, recordNumber)
        {
            if (owner == null)
            {
                throw System.Activities.FxTrace.Exception.ArgumentNull("owner");
            }
            this.BookmarkScope = bookmarkScope;
            this.BookmarkName = bookmarkName;
            this.Owner = owner;
        }

        protected internal override TrackingRecord Clone() => 
            new BookmarkResumptionRecord(this);

        public override string ToString()
        {
            object[] args = new object[] { base.ToString(), this.BookmarkName ?? "<null>", this.BookmarkScope, this.Owner.ToString() };
            return string.Format(CultureInfo.CurrentCulture, "BookmarkResumptionRecord {{ {0}, BookmarkName = {1}, BookmarkScope = {2}, OwnerActivity {{ {3} }} }}", args);
        }

        public Guid BookmarkScope
        {
            get => 
                this.bookmarkScope;
            private set => 
                this.bookmarkScope = value;
        }

        public string BookmarkName
        {
            get => 
                this.bookmarkName;
            private set => 
                this.bookmarkName = value;
        }

        public object Payload
        {
            get => 
                this.payload;
            internal set => 
                this.payload = value;
        }

        public ActivityInfo Owner
        {
            get => 
                this.owner;
            private set => 
                this.owner = value;
        }

        [DataMember(EmitDefaultValue=false, Name="BookmarkScope")]
        internal Guid SerializedBookmarkScope
        {
            get => 
                this.BookmarkScope;
            set => 
                this.BookmarkScope = value;
        }

        [DataMember(EmitDefaultValue=false, Name="BookmarkName")]
        internal string SerializedBookmarkName
        {
            get => 
                this.BookmarkName;
            set => 
                this.BookmarkName = value;
        }

        [DataMember(Name="Payload")]
        internal object SerializedPayload
        {
            get => 
                this.Payload;
            set => 
                this.Payload = value;
        }

        [DataMember(Name="Owner")]
        internal ActivityInfo SerializedOwner
        {
            get => 
                this.Owner;
            set => 
                this.Owner = value;
        }
    }
}

