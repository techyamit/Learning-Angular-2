﻿namespace System.Activities.Tracking
{
    using System;
    using System.Activities;
    using System.Globalization;
    using System.Runtime.Serialization;

    [DataContract]
    public sealed class CancelRequestedRecord : TrackingRecord
    {
        private ActivityInfo activity;
        private ActivityInfo child;

        private CancelRequestedRecord(CancelRequestedRecord record) : base(record)
        {
            this.Activity = record.Activity;
            this.Child = record.Child;
        }

        internal CancelRequestedRecord(Guid instanceId, System.Activities.ActivityInstance instance, System.Activities.ActivityInstance child) : base(instanceId)
        {
            if (instance != null)
            {
                this.Activity = new ActivityInfo(instance);
            }
            this.Child = new ActivityInfo(child);
        }

        public CancelRequestedRecord(Guid instanceId, long recordNumber, ActivityInfo activity, ActivityInfo child) : base(instanceId, recordNumber)
        {
            if (child == null)
            {
                throw System.Activities.FxTrace.Exception.ArgumentNullOrEmpty("child");
            }
            this.Activity = activity;
            this.Child = child;
        }

        protected internal override TrackingRecord Clone() => 
            new CancelRequestedRecord(this);

        public override string ToString()
        {
            object[] args = new object[] { base.ToString(), (this.Activity != null) ? this.Activity.ToString() : "<null>", this.Child.ToString() };
            return string.Format(CultureInfo.CurrentCulture, "CancelRequestedRecord {{ {0}, Activity {{ {1} }}, ChildActivity {{ {2} }} }}", args);
        }

        public ActivityInfo Activity
        {
            get => 
                this.activity;
            private set => 
                this.activity = value;
        }

        public ActivityInfo Child
        {
            get => 
                this.child;
            private set => 
                this.child = value;
        }

        [DataMember(Name="Activity")]
        internal ActivityInfo SerializedActivity
        {
            get => 
                this.Activity;
            set => 
                this.Activity = value;
        }

        [DataMember(Name="Child")]
        internal ActivityInfo SerializedChild
        {
            get => 
                this.Child;
            set => 
                this.Child = value;
        }
    }
}

