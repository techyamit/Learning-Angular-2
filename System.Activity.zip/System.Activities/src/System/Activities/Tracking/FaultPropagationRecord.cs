﻿namespace System.Activities.Tracking
{
    using System;
    using System.Activities;
    using System.Diagnostics;
    using System.Globalization;
    using System.Runtime.Serialization;

    [DataContract]
    public sealed class FaultPropagationRecord : TrackingRecord
    {
        private ActivityInfo faultSource;
        private ActivityInfo faultHandler;
        private bool isFaultSource;
        private Exception fault;

        private FaultPropagationRecord(FaultPropagationRecord record) : base(record)
        {
            this.FaultSource = record.FaultSource;
            this.FaultHandler = record.FaultHandler;
            this.Fault = record.Fault;
            this.IsFaultSource = record.IsFaultSource;
        }

        internal FaultPropagationRecord(Guid instanceId, System.Activities.ActivityInstance source, System.Activities.ActivityInstance faultHandler, bool isFaultSource, Exception fault) : base(instanceId)
        {
            this.FaultSource = new ActivityInfo(source);
            if (faultHandler != null)
            {
                this.FaultHandler = new ActivityInfo(faultHandler);
            }
            this.IsFaultSource = isFaultSource;
            this.Fault = fault;
            base.Level = TraceLevel.Warning;
        }

        public FaultPropagationRecord(Guid instanceId, long recordNumber, ActivityInfo faultSource, ActivityInfo faultHandler, bool isFaultSource, Exception fault) : base(instanceId, recordNumber)
        {
            if (faultSource == null)
            {
                throw System.Activities.FxTrace.Exception.ArgumentNullOrEmpty("faultSource");
            }
            this.FaultSource = faultSource;
            this.FaultHandler = faultHandler;
            this.IsFaultSource = isFaultSource;
            this.Fault = fault;
            base.Level = TraceLevel.Warning;
        }

        protected internal override TrackingRecord Clone() => 
            new FaultPropagationRecord(this);

        public override string ToString()
        {
            object[] args = new object[] { base.ToString(), this.FaultSource.ToString(), (this.FaultHandler != null) ? this.FaultHandler.ToString() : "<null>", this.IsFaultSource };
            return string.Format(CultureInfo.CurrentCulture, "FaultPropagationRecord {{ {0}, FaultSource {{ {1} }}, FaultHandler {{ {2} }}, IsFaultSource = {3} }}", args);
        }

        public ActivityInfo FaultSource
        {
            get => 
                this.faultSource;
            private set => 
                this.faultSource = value;
        }

        public ActivityInfo FaultHandler
        {
            get => 
                this.faultHandler;
            private set => 
                this.faultHandler = value;
        }

        public bool IsFaultSource
        {
            get => 
                this.isFaultSource;
            private set => 
                this.isFaultSource = value;
        }

        public Exception Fault
        {
            get => 
                this.fault;
            private set => 
                this.fault = value;
        }

        [DataMember(Name="FaultSource")]
        internal ActivityInfo SerializedFaultSource
        {
            get => 
                this.FaultSource;
            set => 
                this.FaultSource = value;
        }

        [DataMember(Name="FaultHandler")]
        internal ActivityInfo SerializedFaultHandler
        {
            get => 
                this.FaultHandler;
            set => 
                this.FaultHandler = value;
        }

        [DataMember(EmitDefaultValue=false, Name="IsFaultSource")]
        internal bool SerializedIsFaultSource
        {
            get => 
                this.IsFaultSource;
            set => 
                this.IsFaultSource = value;
        }

        [DataMember(Name="Fault")]
        internal Exception SerializedFault
        {
            get => 
                this.Fault;
            set => 
                this.Fault = value;
        }
    }
}

