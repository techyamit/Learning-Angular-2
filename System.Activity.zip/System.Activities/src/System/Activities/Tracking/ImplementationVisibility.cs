﻿namespace System.Activities.Tracking
{
    using System;

    public enum ImplementationVisibility
    {
        RootScope,
        All
    }
}

