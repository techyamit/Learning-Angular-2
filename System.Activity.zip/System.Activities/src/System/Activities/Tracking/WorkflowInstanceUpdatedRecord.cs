﻿namespace System.Activities.Tracking
{
    using System;
    using System.Activities;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Runtime.Serialization;

    [DataContract]
    public sealed class WorkflowInstanceUpdatedRecord : WorkflowInstanceRecord
    {
        private WorkflowIdentity originalDefinitionIdentity;
        private IList<ActivityBlockingUpdate> blockingActivities;

        private WorkflowInstanceUpdatedRecord(WorkflowInstanceUpdatedRecord record) : base(record)
        {
            this.OriginalDefinitionIdentity = record.OriginalDefinitionIdentity;
            this.BlockingActivities = record.BlockingActivities;
        }

        public WorkflowInstanceUpdatedRecord(Guid instanceId, string activityDefinitionId, WorkflowIdentity originalDefinitionIdentity, WorkflowIdentity updatedDefinitionIdentity) : base(instanceId, activityDefinitionId, "Updated", updatedDefinitionIdentity)
        {
            this.OriginalDefinitionIdentity = originalDefinitionIdentity;
        }

        public WorkflowInstanceUpdatedRecord(Guid instanceId, long recordNumber, string activityDefinitionId, WorkflowIdentity originalDefinitionIdentity, WorkflowIdentity updatedDefinitionIdentity) : base(instanceId, recordNumber, activityDefinitionId, "Updated", updatedDefinitionIdentity)
        {
            this.OriginalDefinitionIdentity = originalDefinitionIdentity;
        }

        public WorkflowInstanceUpdatedRecord(Guid instanceId, string activityDefinitionId, WorkflowIdentity originalDefinitionIdentity, WorkflowIdentity updatedDefinitionIdentity, IList<ActivityBlockingUpdate> blockingActivities) : base(instanceId, activityDefinitionId, "UpdateFailed", updatedDefinitionIdentity)
        {
            this.OriginalDefinitionIdentity = originalDefinitionIdentity;
            this.BlockingActivities = new List<ActivityBlockingUpdate>(blockingActivities).AsReadOnly();
        }

        public WorkflowInstanceUpdatedRecord(Guid instanceId, long recordNumber, string activityDefinitionId, WorkflowIdentity originalDefinitionIdentity, WorkflowIdentity updatedDefinitionIdentity, IList<ActivityBlockingUpdate> blockingActivities) : base(instanceId, recordNumber, activityDefinitionId, "UpdateFailed", updatedDefinitionIdentity)
        {
            this.OriginalDefinitionIdentity = originalDefinitionIdentity;
            this.BlockingActivities = new List<ActivityBlockingUpdate>(blockingActivities).AsReadOnly();
        }

        protected internal override TrackingRecord Clone() => 
            new WorkflowInstanceUpdatedRecord(this);

        public override string ToString()
        {
            object[] args = new object[] { base.InstanceId, base.RecordNumber, base.EventTime, base.ActivityDefinitionId, base.State, this.OriginalDefinitionIdentity, base.WorkflowDefinitionIdentity, this.IsSuccessful };
            return string.Format(CultureInfo.CurrentCulture, "WorkflowInstanceUpdatedRecord {{ InstanceId = {0}, RecordNumber = {1}, EventTime = {2}, ActivityDefinitionId = {3}, State = {4}, OriginalDefinitionIdentity = {5}, UpdatedDefinitionIdentity = {6}, IsSuccessful = {7} }} ", args);
        }

        public WorkflowIdentity OriginalDefinitionIdentity
        {
            get => 
                this.originalDefinitionIdentity;
            private set => 
                this.originalDefinitionIdentity = value;
        }

        public bool IsSuccessful =>
            this.BlockingActivities == null;

        public IList<ActivityBlockingUpdate> BlockingActivities
        {
            get => 
                this.blockingActivities;
            private set => 
                this.blockingActivities = value;
        }

        [DataMember(Name="OriginalDefinitionIdentity")]
        internal WorkflowIdentity SerializedOriginalDefinitionIdentity
        {
            get => 
                this.OriginalDefinitionIdentity;
            set => 
                this.OriginalDefinitionIdentity = value;
        }

        [DataMember(Name="BlockingActivities")]
        internal IList<ActivityBlockingUpdate> SerializedBlockingActivities
        {
            get => 
                this.BlockingActivities;
            set => 
                this.BlockingActivities = value;
        }
    }
}

