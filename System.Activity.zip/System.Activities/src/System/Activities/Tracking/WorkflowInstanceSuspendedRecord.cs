﻿namespace System.Activities.Tracking
{
    using System;
    using System.Activities;
    using System.Globalization;
    using System.Runtime.Serialization;

    [DataContract]
    public sealed class WorkflowInstanceSuspendedRecord : WorkflowInstanceRecord
    {
        private string reason;

        private WorkflowInstanceSuspendedRecord(WorkflowInstanceSuspendedRecord record) : base(record)
        {
            this.Reason = record.Reason;
        }

        public WorkflowInstanceSuspendedRecord(Guid instanceId, string activityDefinitionId, string reason) : base(instanceId, activityDefinitionId, "Suspended")
        {
            if (string.IsNullOrEmpty(reason))
            {
                throw System.Activities.FxTrace.Exception.ArgumentNullOrEmpty("reason");
            }
            this.Reason = reason;
        }

        public WorkflowInstanceSuspendedRecord(Guid instanceId, long recordNumber, string activityDefinitionId, string reason) : base(instanceId, recordNumber, activityDefinitionId, "Suspended")
        {
            if (string.IsNullOrEmpty(reason))
            {
                throw System.Activities.FxTrace.Exception.ArgumentNullOrEmpty("reason");
            }
            this.Reason = reason;
        }

        public WorkflowInstanceSuspendedRecord(Guid instanceId, string activityDefinitionId, string reason, WorkflowIdentity workflowDefinitionIdentity) : this(instanceId, activityDefinitionId, reason)
        {
            base.WorkflowDefinitionIdentity = workflowDefinitionIdentity;
        }

        public WorkflowInstanceSuspendedRecord(Guid instanceId, long recordNumber, string activityDefinitionId, string reason, WorkflowIdentity workflowDefinitionIdentity) : this(instanceId, recordNumber, activityDefinitionId, reason)
        {
            base.WorkflowDefinitionIdentity = workflowDefinitionIdentity;
        }

        protected internal override TrackingRecord Clone() => 
            new WorkflowInstanceSuspendedRecord(this);

        public override string ToString()
        {
            if (base.WorkflowDefinitionIdentity == null)
            {
                object[] objArray1 = new object[] { base.InstanceId, base.RecordNumber, base.EventTime, base.ActivityDefinitionId, this.Reason };
                return string.Format(CultureInfo.CurrentCulture, "WorkflowInstanceSuspendedRecord {{ InstanceId = {0}, RecordNumber = {1}, EventTime = {2}, ActivityDefinitionId = {3}, Reason = {4} }} ", objArray1);
            }
            object[] args = new object[] { base.InstanceId, base.RecordNumber, base.EventTime, base.ActivityDefinitionId, this.Reason, base.WorkflowDefinitionIdentity };
            return string.Format(CultureInfo.CurrentCulture, "WorkflowInstanceSuspendedRecord {{ InstanceId = {0}, RecordNumber = {1}, EventTime = {2}, ActivityDefinitionId = {3}, Reason = {4}, WorkflowDefinitionIdentity = {5} }} ", args);
        }

        public string Reason
        {
            get => 
                this.reason;
            private set => 
                this.reason = value;
        }

        [DataMember(Name="Reason")]
        internal string SerializedReason
        {
            get => 
                this.Reason;
            set => 
                this.Reason = value;
        }
    }
}

