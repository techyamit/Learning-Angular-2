﻿namespace System.Activities.Tracking
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Globalization;
    using System.Runtime;
    using System.Runtime.CompilerServices;
    using System.Runtime.Diagnostics;
    using System.Runtime.Serialization;

    [DataContract]
    public abstract class TrackingRecord
    {
        private IDictionary<string, string> annotations;
        private DateTime eventTime;
        private TraceLevel level;
        private System.Runtime.Diagnostics.EventTraceActivity eventTraceActivity;
        private static ReadOnlyDictionaryInternal<string, string> readonlyEmptyAnnotations;

        protected TrackingRecord(TrackingRecord record)
        {
            this.InstanceId = record.InstanceId;
            this.RecordNumber = record.RecordNumber;
            this.EventTime = record.EventTime;
            this.Level = record.Level;
            if (record.HasAnnotations)
            {
                Dictionary<string, string> dictionary = new Dictionary<string, string>(record.annotations);
                this.annotations = new ReadOnlyDictionaryInternal<string, string>(dictionary);
            }
        }

        protected TrackingRecord(Guid instanceId)
        {
            this.InstanceId = instanceId;
            this.EventTime = DateTime.UtcNow;
            this.Level = TraceLevel.Info;
            this.eventTraceActivity = new System.Runtime.Diagnostics.EventTraceActivity(instanceId, false);
        }

        protected TrackingRecord(Guid instanceId, long recordNumber) : this(instanceId)
        {
            this.RecordNumber = recordNumber;
        }

        protected internal abstract TrackingRecord Clone();
        public override string ToString()
        {
            object[] args = new object[] { this.InstanceId, this.RecordNumber, this.EventTime };
            return string.Format(CultureInfo.CurrentCulture, "InstanceId = {0}, RecordNumber = {1}, EventTime = {2}", args);
        }

        [DataMember]
        public Guid InstanceId { get; internal set; }

        [DataMember]
        public long RecordNumber { get; internal set; }

        public DateTime EventTime
        {
            get => 
                this.eventTime;
            private set => 
                this.eventTime = value;
        }

        public TraceLevel Level
        {
            get => 
                this.level;
            protected set => 
                this.level = value;
        }

        public IDictionary<string, string> Annotations
        {
            get
            {
                if (this.annotations == null)
                {
                    this.annotations = ReadOnlyEmptyAnnotations;
                }
                return this.annotations;
            }
            internal set => 
                this.annotations = value;
        }

        [DataMember(EmitDefaultValue=false, Name="annotations")]
        internal IDictionary<string, string> SerializedAnnotations
        {
            get => 
                this.annotations;
            set => 
                this.annotations = value;
        }

        [DataMember(Name="EventTime")]
        internal DateTime SerializedEventTime
        {
            get => 
                this.EventTime;
            set => 
                this.EventTime = value;
        }

        [DataMember(Name="Level")]
        internal TraceLevel SerializedLevel
        {
            get => 
                this.Level;
            set => 
                this.Level = value;
        }

        internal System.Runtime.Diagnostics.EventTraceActivity EventTraceActivity
        {
            get
            {
                if (this.eventTraceActivity == null)
                {
                    this.eventTraceActivity = new System.Runtime.Diagnostics.EventTraceActivity(this.InstanceId, false);
                }
                return this.eventTraceActivity;
            }
        }

        private static ReadOnlyDictionaryInternal<string, string> ReadOnlyEmptyAnnotations
        {
            get
            {
                if (readonlyEmptyAnnotations == null)
                {
                    readonlyEmptyAnnotations = new ReadOnlyDictionaryInternal<string, string>(new Dictionary<string, string>(0));
                }
                return readonlyEmptyAnnotations;
            }
        }

        internal bool HasAnnotations =>
            (this.annotations != null) && (this.annotations.Count > 0);
    }
}

