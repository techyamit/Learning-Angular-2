﻿namespace System.Activities
{
    using System;
    using System.Runtime;
    using System.Runtime.Serialization;

    [DataContract]
    public class Location<T> : System.Activities.Location
    {
        private T value;

        internal override object CreateDefaultValue() => 
            Activator.CreateInstance<T>();

        internal override System.Activities.Location CreateReference(bool bufferGets)
        {
            if (this.CanBeMapped | bufferGets)
            {
                return new ReferenceLocation<T>((Location<T>) this, bufferGets);
            }
            return this;
        }

        public override string ToString()
        {
            if (this.value == null)
            {
                return "<null>";
            }
            return this.value.ToString();
        }

        public override Type LocationType =>
            typeof(T);

        public virtual T Value
        {
            get => 
                this.value;
            set => 
                this.value = value;
        }

        internal T TypedValue
        {
            get => 
                this.Value;
            set => 
                this.Value = value;
        }

        protected sealed override object ValueCore
        {
            get => 
                this.Value;
            set => 
                this.Value = TypeHelper.Convert<T>(value);
        }

        [DataMember(EmitDefaultValue=false, Name="value")]
        internal T SerializedValue
        {
            get => 
                this.value;
            set => 
                this.value = value;
        }

        [DataContract]
        internal class ReferenceLocation : Location<T>
        {
            private Location<T> innerLocation;
            private bool bufferGets;

            public ReferenceLocation(Location<T> innerLocation, bool bufferGets)
            {
                this.innerLocation = innerLocation;
                this.bufferGets = bufferGets;
            }

            public override string ToString()
            {
                if (this.bufferGets)
                {
                    return base.ToString();
                }
                return this.innerLocation.ToString();
            }

            public override T Value
            {
                get
                {
                    if (this.bufferGets)
                    {
                        return base.value;
                    }
                    return this.innerLocation.Value;
                }
                set
                {
                    this.innerLocation.Value = value;
                    if (this.bufferGets)
                    {
                        base.value = value;
                    }
                }
            }

            [DataMember(Name="innerLocation")]
            internal Location<T> SerializedInnerLocation
            {
                get => 
                    this.innerLocation;
                set => 
                    this.innerLocation = value;
            }

            [DataMember(EmitDefaultValue=false, Name="bufferGets")]
            internal bool SerializedBufferGets
            {
                get => 
                    this.bufferGets;
                set => 
                    this.bufferGets = value;
            }
        }
    }
}

