﻿namespace System.Activities
{
    using System;
    using System.Activities.Validation;
    using System.Runtime.CompilerServices;
    using System.Threading;

    internal class ProcessActivityTreeOptions
    {
        private static ProcessActivityTreeOptions validationOptions;
        private static ProcessActivityTreeOptions validationAndPrepareForRuntimeOptions;
        private static ProcessActivityTreeOptions singleLevelValidationOptions;
        private static ProcessActivityTreeOptions fullCachingOptions;
        private static ProcessActivityTreeOptions dynamicUpdateOptions;
        private static ProcessActivityTreeOptions dynamicUpdateOptionsForImplementation;
        private static ProcessActivityTreeOptions finishCachingSubtreeOptionsWithCreateEmptyBindings;
        private static ProcessActivityTreeOptions finishCachingSubtreeOptionsWithoutCreateEmptyBindings;
        private static ProcessActivityTreeOptions skipRootFinishCachingSubtreeOptions;
        private static ProcessActivityTreeOptions skipRootConfigurationValidationOptions;
        private static ProcessActivityTreeOptions singleLevelSkipRootConfigurationValidationOptions;

        private ProcessActivityTreeOptions()
        {
        }

        private static ProcessActivityTreeOptions AttachCancellationToken(ProcessActivityTreeOptions result, System.Threading.CancellationToken cancellationToken)
        {
            ProcessActivityTreeOptions options = result.Clone();
            options.CancellationToken = cancellationToken;
            return options;
        }

        private ProcessActivityTreeOptions Clone() => 
            new ProcessActivityTreeOptions { 
                CancellationToken = this.CancellationToken,
                SkipIfCached = this.SkipIfCached,
                CreateEmptyBindings = this.CreateEmptyBindings,
                SkipPrivateChildren = this.SkipPrivateChildren,
                OnlyCallCallbackForDeclarations = this.OnlyCallCallbackForDeclarations,
                SkipConstraints = this.SkipConstraints,
                OnlyVisitSingleLevel = this.OnlyVisitSingleLevel,
                SkipRootConfigurationValidation = this.SkipRootConfigurationValidation,
                StoreTempViolations = this.StoreTempViolations
            };

        public static ProcessActivityTreeOptions GetFinishCachingSubtreeOptions(ProcessActivityTreeOptions originalOptions)
        {
            ProcessActivityTreeOptions finishCachingSubtreeOptionsWithCreateEmptyBindings;
            if (originalOptions.CreateEmptyBindings)
            {
                finishCachingSubtreeOptionsWithCreateEmptyBindings = FinishCachingSubtreeOptionsWithCreateEmptyBindings;
            }
            else if (originalOptions.SkipRootConfigurationValidation)
            {
                finishCachingSubtreeOptionsWithCreateEmptyBindings = SkipRootFinishCachingSubtreeOptions;
            }
            else
            {
                finishCachingSubtreeOptionsWithCreateEmptyBindings = FinishCachingSubtreeOptionsWithoutCreateEmptyBindings;
            }
            if (originalOptions.CancellationToken == System.Threading.CancellationToken.None)
            {
                return finishCachingSubtreeOptionsWithCreateEmptyBindings;
            }
            return AttachCancellationToken(finishCachingSubtreeOptionsWithCreateEmptyBindings, originalOptions.CancellationToken);
        }

        public static ProcessActivityTreeOptions GetValidationOptions(ValidationSettings settings)
        {
            ProcessActivityTreeOptions result = null;
            if (settings.SkipValidatingRootConfiguration && settings.SingleLevel)
            {
                result = SingleLevelSkipRootConfigurationValidationOptions;
            }
            else if (settings.SkipValidatingRootConfiguration)
            {
                result = SkipRootConfigurationValidationOptions;
            }
            else if (settings.SingleLevel)
            {
                result = SingleLevelValidationOptions;
            }
            else if (settings.PrepareForRuntime)
            {
                result = ValidationAndPrepareForRuntimeOptions;
            }
            else
            {
                result = ValidationOptions;
            }
            if (settings.CancellationToken == System.Threading.CancellationToken.None)
            {
                return result;
            }
            return AttachCancellationToken(result, settings.CancellationToken);
        }

        public System.Threading.CancellationToken CancellationToken { get; private set; }

        public bool SkipIfCached { get; private set; }

        public bool CreateEmptyBindings { get; private set; }

        public bool SkipPrivateChildren { get; private set; }

        public bool OnlyCallCallbackForDeclarations { get; private set; }

        public bool SkipConstraints { get; private set; }

        public bool OnlyVisitSingleLevel { get; private set; }

        public bool SkipRootConfigurationValidation { get; private set; }

        public bool StoreTempViolations { get; private set; }

        public bool IsRuntimeReadyOptions =>
            !this.SkipPrivateChildren && this.CreateEmptyBindings;

        public static ProcessActivityTreeOptions FullCachingOptions
        {
            get
            {
                if (fullCachingOptions == null)
                {
                    ProcessActivityTreeOptions options1 = new ProcessActivityTreeOptions {
                        SkipIfCached = true,
                        CreateEmptyBindings = true,
                        OnlyCallCallbackForDeclarations = true
                    };
                    fullCachingOptions = options1;
                }
                return fullCachingOptions;
            }
        }

        public static ProcessActivityTreeOptions ValidationOptions
        {
            get
            {
                if (validationOptions == null)
                {
                    ProcessActivityTreeOptions options1 = new ProcessActivityTreeOptions {
                        SkipPrivateChildren = false,
                        CreateEmptyBindings = false
                    };
                    validationOptions = options1;
                }
                return validationOptions;
            }
        }

        public static ProcessActivityTreeOptions ValidationAndPrepareForRuntimeOptions
        {
            get
            {
                if (validationAndPrepareForRuntimeOptions == null)
                {
                    ProcessActivityTreeOptions options1 = new ProcessActivityTreeOptions {
                        SkipIfCached = false,
                        SkipPrivateChildren = false,
                        CreateEmptyBindings = true
                    };
                    validationAndPrepareForRuntimeOptions = options1;
                }
                return validationAndPrepareForRuntimeOptions;
            }
        }

        private static ProcessActivityTreeOptions SkipRootConfigurationValidationOptions
        {
            get
            {
                if (skipRootConfigurationValidationOptions == null)
                {
                    ProcessActivityTreeOptions options1 = new ProcessActivityTreeOptions {
                        SkipPrivateChildren = false,
                        CreateEmptyBindings = false,
                        SkipRootConfigurationValidation = true
                    };
                    skipRootConfigurationValidationOptions = options1;
                }
                return skipRootConfigurationValidationOptions;
            }
        }

        private static ProcessActivityTreeOptions SingleLevelSkipRootConfigurationValidationOptions
        {
            get
            {
                if (singleLevelSkipRootConfigurationValidationOptions == null)
                {
                    ProcessActivityTreeOptions options1 = new ProcessActivityTreeOptions {
                        SkipPrivateChildren = false,
                        CreateEmptyBindings = false,
                        SkipRootConfigurationValidation = true,
                        OnlyVisitSingleLevel = true
                    };
                    singleLevelSkipRootConfigurationValidationOptions = options1;
                }
                return singleLevelSkipRootConfigurationValidationOptions;
            }
        }

        private static ProcessActivityTreeOptions SingleLevelValidationOptions
        {
            get
            {
                if (singleLevelValidationOptions == null)
                {
                    ProcessActivityTreeOptions options1 = new ProcessActivityTreeOptions {
                        SkipPrivateChildren = false,
                        CreateEmptyBindings = false,
                        OnlyVisitSingleLevel = true
                    };
                    singleLevelValidationOptions = options1;
                }
                return singleLevelValidationOptions;
            }
        }

        private static ProcessActivityTreeOptions FinishCachingSubtreeOptionsWithoutCreateEmptyBindings
        {
            get
            {
                if (finishCachingSubtreeOptionsWithoutCreateEmptyBindings == null)
                {
                    ProcessActivityTreeOptions options1 = new ProcessActivityTreeOptions {
                        SkipConstraints = true,
                        StoreTempViolations = true
                    };
                    finishCachingSubtreeOptionsWithoutCreateEmptyBindings = options1;
                }
                return finishCachingSubtreeOptionsWithoutCreateEmptyBindings;
            }
        }

        private static ProcessActivityTreeOptions SkipRootFinishCachingSubtreeOptions
        {
            get
            {
                if (skipRootFinishCachingSubtreeOptions == null)
                {
                    ProcessActivityTreeOptions options1 = new ProcessActivityTreeOptions {
                        SkipConstraints = true,
                        SkipRootConfigurationValidation = true,
                        StoreTempViolations = true
                    };
                    skipRootFinishCachingSubtreeOptions = options1;
                }
                return skipRootFinishCachingSubtreeOptions;
            }
        }

        private static ProcessActivityTreeOptions FinishCachingSubtreeOptionsWithCreateEmptyBindings
        {
            get
            {
                if (finishCachingSubtreeOptionsWithCreateEmptyBindings == null)
                {
                    ProcessActivityTreeOptions options1 = new ProcessActivityTreeOptions {
                        SkipConstraints = true,
                        CreateEmptyBindings = true,
                        StoreTempViolations = true
                    };
                    finishCachingSubtreeOptionsWithCreateEmptyBindings = options1;
                }
                return finishCachingSubtreeOptionsWithCreateEmptyBindings;
            }
        }

        public static ProcessActivityTreeOptions DynamicUpdateOptions
        {
            get
            {
                if (dynamicUpdateOptions == null)
                {
                    ProcessActivityTreeOptions options1 = new ProcessActivityTreeOptions {
                        OnlyCallCallbackForDeclarations = true,
                        SkipConstraints = true
                    };
                    dynamicUpdateOptions = options1;
                }
                return dynamicUpdateOptions;
            }
        }

        public static ProcessActivityTreeOptions DynamicUpdateOptionsForImplementation
        {
            get
            {
                if (dynamicUpdateOptionsForImplementation == null)
                {
                    ProcessActivityTreeOptions options1 = new ProcessActivityTreeOptions {
                        SkipRootConfigurationValidation = true,
                        OnlyCallCallbackForDeclarations = true,
                        SkipConstraints = true
                    };
                    dynamicUpdateOptionsForImplementation = options1;
                }
                return dynamicUpdateOptionsForImplementation;
            }
        }
    }
}

