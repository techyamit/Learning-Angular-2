﻿namespace System.Activities
{
    using System;
    using System.Activities.Runtime;

    public sealed class RegistrationContext
    {
        private ExecutionPropertyManager properties;
        private IdSpace currentIdSpace;

        internal RegistrationContext(ExecutionPropertyManager properties, IdSpace currentIdSpace)
        {
            this.properties = properties;
            this.currentIdSpace = currentIdSpace;
        }

        public object FindProperty(string name)
        {
            if (string.IsNullOrEmpty(name))
            {
                throw FxTrace.Exception.ArgumentNullOrEmpty("name");
            }
            return this.properties?.GetProperty(name, this.currentIdSpace);
        }
    }
}

