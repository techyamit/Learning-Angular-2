﻿namespace System.Activities
{
    using System;
    using System.Runtime.CompilerServices;

    internal static class ActivityInstanceStateExtension
    {
        internal static string GetStateName(this ActivityInstanceState state)
        {
            switch (state)
            {
                case ActivityInstanceState.Executing:
                    return "Executing";

                case ActivityInstanceState.Closed:
                    return "Closed";

                case ActivityInstanceState.Canceled:
                    return "Canceled";

                case ActivityInstanceState.Faulted:
                    return "Faulted";
            }
            return state.ToString();
        }
    }
}

