﻿namespace System.Activities
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Diagnostics;
    using System.Reflection;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;

    internal class HybridDictionary<TKey, TValue> : IDictionary<TKey, TValue>, ICollection<KeyValuePair<TKey, TValue>>, IEnumerable<KeyValuePair<TKey, TValue>>, IEnumerable where TKey: class where TValue: class
    {
        private TKey singleItemKey;
        private TValue singleItemValue;
        private IDictionary<TKey, TValue> dictionary;

        public void Add(KeyValuePair<TKey, TValue> item)
        {
            this.Add(item.Key, item.Value);
        }

        public void Add(TKey key, TValue value)
        {
            if (key == null)
            {
                throw FxTrace.Exception.ArgumentNull("key");
            }
            if (((this.singleItemKey == null) && (this.singleItemValue == null)) && (this.dictionary == null))
            {
                this.singleItemKey = key;
                this.singleItemValue = value;
            }
            else if (this.singleItemKey != null)
            {
                this.dictionary = new Dictionary<TKey, TValue>();
                this.dictionary.Add(this.singleItemKey, this.singleItemValue);
                this.singleItemKey = default(TKey);
                this.singleItemValue = default(TValue);
                this.dictionary.Add(key, value);
            }
            else
            {
                this.dictionary.Add(key, value);
            }
        }

        public void Clear()
        {
            this.singleItemKey = default(TKey);
            this.singleItemValue = default(TValue);
            this.dictionary = null;
        }

        public bool Contains(KeyValuePair<TKey, TValue> item)
        {
            if (this.singleItemKey != null)
            {
                return ((this.singleItemKey == item.Key) && (this.singleItemValue == item.Value));
            }
            return ((this.dictionary != null) && this.dictionary.Contains(item));
        }

        public bool ContainsKey(TKey key)
        {
            if (key == null)
            {
                throw FxTrace.Exception.ArgumentNull("key");
            }
            if (this.singleItemKey != null)
            {
                return (this.singleItemKey == key);
            }
            return ((this.dictionary != null) && this.dictionary.ContainsKey(key));
        }

        public void CopyTo(KeyValuePair<TKey, TValue>[] array, int arrayIndex)
        {
            if (this.singleItemKey != null)
            {
                array[arrayIndex] = new KeyValuePair<TKey, TValue>(this.singleItemKey, this.singleItemValue);
            }
            else if (this.dictionary != null)
            {
                this.dictionary.CopyTo(array, arrayIndex);
            }
        }

        [IteratorStateMachine(typeof(<GetEnumerator>d__23))]
        public IEnumerator<KeyValuePair<TKey, TValue>> GetEnumerator() => 
            new <GetEnumerator>d__23<TKey, TValue>(0) { <>4__this = (HybridDictionary<TKey, TValue>) this };

        public bool Remove(TKey key)
        {
            if (this.singleItemKey == key)
            {
                this.singleItemKey = default(TKey);
                this.singleItemValue = default(TValue);
                return true;
            }
            if (this.dictionary == null)
            {
                return false;
            }
            bool flag = this.dictionary.Remove(key);
            if (this.dictionary.Count == 0)
            {
                this.dictionary = null;
            }
            return flag;
        }

        public bool Remove(KeyValuePair<TKey, TValue> item) => 
            this.Remove(item.Key);

        IEnumerator IEnumerable.GetEnumerator() => 
            this.GetEnumerator();

        public bool TryGetValue(TKey key, out TValue value)
        {
            if (this.singleItemKey == key)
            {
                value = this.singleItemValue;
                return true;
            }
            if (this.dictionary != null)
            {
                return this.dictionary.TryGetValue(key, out value);
            }
            value = default(TValue);
            return false;
        }

        public int Count
        {
            get
            {
                if (this.singleItemKey != null)
                {
                    return 1;
                }
                if (this.dictionary != null)
                {
                    return this.dictionary.Count;
                }
                return 0;
            }
        }

        public bool IsReadOnly =>
            false;

        public ICollection<TValue> Values
        {
            get
            {
                if (this.singleItemKey != null)
                {
                    return new ReadOnlyCollection<TValue>(new List<TValue> { this.singleItemValue });
                }
                if (this.dictionary != null)
                {
                    return new ReadOnlyCollection<TValue>(new List<TValue>(this.dictionary.Values));
                }
                return null;
            }
        }

        public ICollection<TKey> Keys
        {
            get
            {
                if (this.singleItemKey != null)
                {
                    return new ReadOnlyCollection<TKey>(new List<TKey> { this.singleItemKey });
                }
                if (this.dictionary != null)
                {
                    return new ReadOnlyCollection<TKey>(new List<TKey>(this.dictionary.Keys));
                }
                return null;
            }
        }

        public TValue this[TKey key]
        {
            get
            {
                if (this.singleItemKey == key)
                {
                    return this.singleItemValue;
                }
                if (this.dictionary != null)
                {
                    return this.dictionary[key];
                }
                return default(TValue);
            }
            set => 
                this.Add(key, value);
        }

        [CompilerGenerated]
        private sealed class <GetEnumerator>d__23 : IEnumerator<KeyValuePair<TKey, TValue>>, IDisposable, IEnumerator
        {
            private int <>1__state;
            private KeyValuePair<TKey, TValue> <>2__current;
            public HybridDictionary<TKey, TValue> <>4__this;
            private IEnumerator<KeyValuePair<TKey, TValue>> <>7__wrap1;

            [DebuggerHidden]
            public <GetEnumerator>d__23(int <>1__state)
            {
                this.<>1__state = <>1__state;
            }

            private void <>m__Finally1()
            {
                this.<>1__state = -1;
                if (this.<>7__wrap1 != null)
                {
                    this.<>7__wrap1.Dispose();
                }
            }

            private bool MoveNext()
            {
                bool flag;
                try
                {
                    int num = this.<>1__state;
                    HybridDictionary<TKey, TValue> dictionary = this.<>4__this;
                    switch (num)
                    {
                        case 0:
                            this.<>1__state = -1;
                            if (dictionary.singleItemKey == null)
                            {
                                break;
                            }
                            this.<>2__current = new KeyValuePair<TKey, TValue>(dictionary.singleItemKey, dictionary.singleItemValue);
                            this.<>1__state = 1;
                            return true;

                        case 1:
                            this.<>1__state = -1;
                            goto Label_00C9;

                        case 2:
                            goto Label_00A7;

                        default:
                            return false;
                    }
                    if (dictionary.dictionary != null)
                    {
                        this.<>7__wrap1 = dictionary.dictionary.GetEnumerator();
                        this.<>1__state = -3;
                        while (this.<>7__wrap1.MoveNext())
                        {
                            KeyValuePair<TKey, TValue> current = this.<>7__wrap1.Current;
                            this.<>2__current = current;
                            this.<>1__state = 2;
                            return true;
                        Label_00A7:
                            this.<>1__state = -3;
                        }
                        this.<>m__Finally1();
                        this.<>7__wrap1 = null;
                    }
                Label_00C9:
                    flag = false;
                }
                fault
                {
                    this.System.IDisposable.Dispose();
                }
                return flag;
            }

            [DebuggerHidden]
            void IEnumerator.Reset()
            {
                throw new NotSupportedException();
            }

            [DebuggerHidden]
            void IDisposable.Dispose()
            {
                switch (this.<>1__state)
                {
                    case -3:
                    case 2:
                        try
                        {
                        }
                        finally
                        {
                            this.<>m__Finally1();
                        }
                        break;
                }
            }

            KeyValuePair<TKey, TValue> IEnumerator<KeyValuePair<TKey, TValue>>.Current =>
                this.<>2__current;

            object IEnumerator.Current =>
                this.<>2__current;
        }
    }
}

