﻿namespace System.Activities
{
    using System;
    using System.Runtime.CompilerServices;

    internal static class LocalAppContextSwitches
    {
        private static int useMD5ForWFDebugger;
        private static int useSHA1HashForDebuggerSymbols;
        private static int terminateOnUnhandledExceptionInCancel;

        public static bool UseMD5ForWFDebugger =>
            System.LocalAppContext.GetCachedSwitchValue("Switch.System.Activities.UseMD5ForWFDebugger", ref useMD5ForWFDebugger);

        public static bool UseSHA1HashForDebuggerSymbols =>
            System.LocalAppContext.GetCachedSwitchValue("Switch.System.Activities.UseSHA1HashForDebuggerSymbols", ref useSHA1HashForDebuggerSymbols);

        public static bool TerminateOnUnhandledExceptionDuringCancel =>
            System.LocalAppContext.GetCachedSwitchValue("Switch.System.Activities.TerminateOnUnhandledExceptionDuringCancel", ref terminateOnUnhandledExceptionInCancel);
    }
}

