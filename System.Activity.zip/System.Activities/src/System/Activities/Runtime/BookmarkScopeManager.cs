﻿namespace System.Activities.Runtime
{
    using System;
    using System.Activities;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Globalization;
    using System.Runtime.DurableInstancing;
    using System.Runtime.InteropServices;
    using System.Runtime.Serialization;

    [DataContract]
    internal class BookmarkScopeManager
    {
        private Dictionary<BookmarkScope, BookmarkManager> bookmarkManagers;
        private List<BookmarkScope> uninitializedScopes;
        private List<InstanceKey> keysToAssociate;
        private List<InstanceKey> keysToDisassociate;
        private BookmarkScope defaultScope;
        private long nextTemporaryId = 1L;

        public BookmarkScopeManager()
        {
            this.defaultScope = this.CreateAndRegisterScope(Guid.Empty);
        }

        public BookmarkScope CreateAndRegisterScope(Guid scopeId) => 
            this.CreateAndRegisterScope(scopeId, null);

        internal BookmarkScope CreateAndRegisterScope(Guid scopeId, BookmarkScopeHandle scopeHandle)
        {
            if (this.bookmarkManagers == null)
            {
                this.bookmarkManagers = new Dictionary<BookmarkScope, BookmarkManager>();
            }
            BookmarkScope key = null;
            if (scopeId == Guid.Empty)
            {
                key = new BookmarkScope(this.GetNextTemporaryId());
                this.bookmarkManagers.Add(key, new BookmarkManager(key, scopeHandle));
                if (TD.CreateBookmarkScopeIsEnabled())
                {
                    TD.CreateBookmarkScope(ActivityUtilities.GetTraceString(key));
                }
                if (this.uninitializedScopes == null)
                {
                    this.uninitializedScopes = new List<BookmarkScope>();
                }
                this.uninitializedScopes.Add(key);
                return key;
            }
            foreach (BookmarkScope scope2 in this.bookmarkManagers.Keys)
            {
                if (scope2.Id.Equals(scopeId))
                {
                    key = scope2;
                    break;
                }
            }
            if (key == null)
            {
                key = new BookmarkScope(scopeId);
                this.bookmarkManagers.Add(key, new BookmarkManager(key, scopeHandle));
                if (TD.CreateBookmarkScopeIsEnabled())
                {
                    object[] args = new object[] { ActivityUtilities.GetTraceString(key) };
                    TD.CreateBookmarkScope(string.Format(CultureInfo.InvariantCulture, "Id: {0}", args));
                }
            }
            this.CreateAssociatedKey(key);
            return key;
        }

        private void CreateAssociatedKey(BookmarkScope newScope)
        {
            if (this.keysToAssociate == null)
            {
                this.keysToAssociate = new List<InstanceKey>(2);
            }
            this.keysToAssociate.Add(new InstanceKey(newScope.Id));
        }

        public Bookmark CreateBookmark(string name, BookmarkScope scope, BookmarkCallback callback, System.Activities.ActivityInstance owningInstance, BookmarkOptions options)
        {
            BookmarkManager manager = null;
            BookmarkScope key = scope;
            if (scope.IsDefault)
            {
                key = this.defaultScope;
            }
            if (!this.bookmarkManagers.TryGetValue(key, out manager))
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.RegisteredBookmarkScopeRequired));
            }
            return manager.CreateBookmark(name, callback, owningInstance, options);
        }

        public ReadOnlyCollection<BookmarkInfo> GetBookmarks(BookmarkScope scope)
        {
            BookmarkManager manager = null;
            BookmarkScope key = scope;
            if (scope.IsDefault)
            {
                key = this.defaultScope;
            }
            if (this.bookmarkManagers.TryGetValue(key, out manager) && !manager.HasBookmarks)
            {
                manager = null;
            }
            if (manager != null)
            {
                List<BookmarkInfo> bookmarks = new List<BookmarkInfo>();
                manager.PopulateBookmarkInfo(bookmarks);
                return new ReadOnlyCollection<BookmarkInfo>(bookmarks);
            }
            return null;
        }

        public ICollection<InstanceKey> GetKeysToAssociate()
        {
            if ((this.keysToAssociate == null) || (this.keysToAssociate.Count == 0))
            {
                return null;
            }
            ICollection<InstanceKey> keysToAssociate = this.keysToAssociate;
            this.keysToAssociate = null;
            return keysToAssociate;
        }

        public ICollection<InstanceKey> GetKeysToDisassociate()
        {
            if ((this.keysToDisassociate == null) || (this.keysToDisassociate.Count == 0))
            {
                return null;
            }
            ICollection<InstanceKey> keysToDisassociate = this.keysToDisassociate;
            this.keysToDisassociate = null;
            return keysToDisassociate;
        }

        private long GetNextTemporaryId()
        {
            long nextTemporaryId = this.nextTemporaryId;
            this.nextTemporaryId += 1L;
            return nextTemporaryId;
        }

        public BookmarkScope InitializeBookmarkScopeWithoutKeyAssociation(BookmarkScope scope, Guid id)
        {
            BookmarkScope item = scope;
            if (scope.IsDefault)
            {
                item = this.defaultScope;
            }
            if ((this.uninitializedScopes == null) || !this.uninitializedScopes.Contains(item))
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.BookmarkScopeNotRegisteredForInitialize));
            }
            if (this.bookmarkManagers.ContainsKey(new BookmarkScope(id)))
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.BookmarkScopeWithIdAlreadyExists(id)));
            }
            BookmarkManager manager = this.bookmarkManagers[item];
            this.bookmarkManagers.Remove(item);
            this.uninitializedScopes.Remove(item);
            long temporaryId = item.TemporaryId;
            item.Id = id;
            this.bookmarkManagers.Add(item, manager);
            if (TD.BookmarkScopeInitializedIsEnabled())
            {
                TD.BookmarkScopeInitialized(temporaryId.ToString(CultureInfo.InvariantCulture), item.Id.ToString());
            }
            return item;
        }

        public void InitializeScope(BookmarkScope scope, Guid id)
        {
            BookmarkScope newScope = this.InitializeBookmarkScopeWithoutKeyAssociation(scope, id);
            this.CreateAssociatedKey(newScope);
        }

        public bool IsExclusiveScopeUnstable(Bookmark bookmark)
        {
            if (bookmark.ExclusiveHandles != null)
            {
                for (int i = 0; i < bookmark.ExclusiveHandles.Count; i++)
                {
                    ExclusiveHandle handle = bookmark.ExclusiveHandles[i];
                    if (((handle.ImportantBookmarks != null) && handle.ImportantBookmarks.Contains(bookmark)) && ((handle.UnimportantBookmarks != null) && (handle.UnimportantBookmarks.Count != 0)))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        private bool IsStable(BookmarkScope scope, bool nonScopedBookmarksExist)
        {
            if (nonScopedBookmarksExist)
            {
                return false;
            }
            if (this.bookmarkManagers != null)
            {
                foreach (KeyValuePair<BookmarkScope, BookmarkManager> pair in this.bookmarkManagers)
                {
                    if (!pair.Key.Equals(scope) && pair.Value.HasBookmarks)
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        public void PopulateBookmarkInfo(ref List<BookmarkInfo> bookmarks)
        {
            foreach (BookmarkManager manager in this.bookmarkManagers.Values)
            {
                if (manager.HasBookmarks)
                {
                    if (bookmarks == null)
                    {
                        bookmarks = new List<BookmarkInfo>();
                    }
                    manager.PopulateBookmarkInfo(bookmarks);
                }
            }
        }

        private void PurgeBookmark(Bookmark bookmark, BookmarkManager nonScopedBookmarkManager)
        {
            BookmarkManager manager = null;
            if (bookmark.Scope != null)
            {
                BookmarkScope defaultScope = bookmark.Scope;
                if (bookmark.Scope.IsDefault)
                {
                    defaultScope = this.defaultScope;
                }
                manager = this.bookmarkManagers[bookmark.Scope];
            }
            else
            {
                manager = nonScopedBookmarkManager;
            }
            manager.PurgeSingleBookmark(bookmark);
        }

        public void PurgeBookmarks(BookmarkManager nonScopedBookmarkManager, Bookmark singleBookmark, IList<Bookmark> multipleBookmarks)
        {
            if (singleBookmark != null)
            {
                this.PurgeBookmark(singleBookmark, nonScopedBookmarkManager);
            }
            else
            {
                for (int i = 0; i < multipleBookmarks.Count; i++)
                {
                    Bookmark bookmark = multipleBookmarks[i];
                    this.PurgeBookmark(bookmark, nonScopedBookmarkManager);
                }
            }
        }

        public bool RemoveBookmark(Bookmark bookmark, BookmarkScope scope, System.Activities.ActivityInstance instanceAttemptingRemove)
        {
            BookmarkScope key = scope;
            if (scope.IsDefault)
            {
                key = this.defaultScope;
            }
            return (this.bookmarkManagers.TryGetValue(key, out BookmarkManager manager) && manager.Remove(bookmark, instanceAttemptingRemove));
        }

        public BookmarkResumptionResult TryGenerateWorkItem(ActivityExecutor executor, ref Bookmark bookmark, BookmarkScope scope, object value, System.Activities.ActivityInstance isolationInstance, bool nonScopedBookmarksExist, out ActivityExecutionWorkItem workItem)
        {
            BookmarkManager manager = null;
            BookmarkResumptionResult notFound;
            workItem = null;
            BookmarkScope key = scope;
            if (scope.IsDefault)
            {
                key = this.defaultScope;
            }
            this.bookmarkManagers.TryGetValue(key, out manager);
            if (manager == null)
            {
                BookmarkResumptionResult notFound = BookmarkResumptionResult.NotFound;
                if (this.uninitializedScopes != null)
                {
                    for (int i = 0; i < this.uninitializedScopes.Count; i++)
                    {
                        BookmarkResumptionResult notReady;
                        BookmarkScope scope3 = this.uninitializedScopes[i];
                        if (!this.bookmarkManagers[scope3].TryGetBookmarkFromInternalList(bookmark, out Bookmark bookmark2, out _))
                        {
                            notReady = BookmarkResumptionResult.NotFound;
                        }
                        else if (this.IsExclusiveScopeUnstable(bookmark2))
                        {
                            notReady = BookmarkResumptionResult.NotReady;
                        }
                        else
                        {
                            notReady = this.bookmarkManagers[scope3].TryGenerateWorkItem(executor, true, ref bookmark, value, isolationInstance, out workItem);
                        }
                        switch (notReady)
                        {
                            case BookmarkResumptionResult.Success:
                                this.InitializeBookmarkScopeWithoutKeyAssociation(scope3, scope.Id);
                                return BookmarkResumptionResult.Success;

                            case BookmarkResumptionResult.NotReady:
                                notFound = BookmarkResumptionResult.NotReady;
                                break;

                            default:
                                if ((notFound == BookmarkResumptionResult.NotFound) && !this.IsStable(scope3, nonScopedBookmarksExist))
                                {
                                    notFound = BookmarkResumptionResult.NotReady;
                                }
                                break;
                        }
                    }
                }
                return notFound;
            }
            if (!manager.TryGetBookmarkFromInternalList(bookmark, out Bookmark bookmark3, out _))
            {
                notFound = BookmarkResumptionResult.NotFound;
            }
            else if (this.IsExclusiveScopeUnstable(bookmark3))
            {
                notFound = BookmarkResumptionResult.NotReady;
            }
            else
            {
                notFound = manager.TryGenerateWorkItem(executor, true, ref bookmark, value, isolationInstance, out workItem);
            }
            if ((notFound == BookmarkResumptionResult.NotFound) && !this.IsStable(key, nonScopedBookmarksExist))
            {
                notFound = BookmarkResumptionResult.NotReady;
            }
            return notFound;
        }

        public void UnregisterScope(BookmarkScope scope)
        {
            if ((this.bookmarkManagers == null) || !this.bookmarkManagers.ContainsKey(scope))
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.BookmarkScopeNotRegisteredForUnregister));
            }
            if (this.bookmarkManagers[scope].HasBookmarks)
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.BookmarkScopeHasBookmarks));
            }
            this.bookmarkManagers.Remove(scope);
            if (!scope.IsInitialized)
            {
                this.uninitializedScopes.Remove(scope);
            }
            else
            {
                if (this.keysToDisassociate == null)
                {
                    this.keysToDisassociate = new List<InstanceKey>(2);
                }
                this.keysToDisassociate.Add(new InstanceKey(scope.Id));
            }
        }

        public BookmarkScope Default =>
            this.defaultScope;

        public bool HasKeysToUpdate =>
            ((this.keysToAssociate != null) && (this.keysToAssociate.Count > 0)) || ((this.keysToDisassociate != null) && (this.keysToDisassociate.Count > 0));

        [DataMember(Name="defaultScope")]
        internal BookmarkScope SerializedDefaultScope
        {
            get => 
                this.defaultScope;
            set => 
                this.defaultScope = value;
        }

        [DataMember(Name="nextTemporaryId")]
        internal long SerializedNextTemporaryId
        {
            get => 
                this.nextTemporaryId;
            set => 
                this.nextTemporaryId = value;
        }

        [DataMember(EmitDefaultValue=false)]
        internal Dictionary<BookmarkScope, BookmarkManager> SerializedBookmarkManagers
        {
            get => 
                this.bookmarkManagers;
            set => 
                this.bookmarkManagers = value;
        }

        [DataMember(EmitDefaultValue=false)]
        internal List<BookmarkScope> SerializedUninitializedScopes
        {
            get
            {
                if ((this.uninitializedScopes != null) && (this.uninitializedScopes.Count != 0))
                {
                    return this.uninitializedScopes;
                }
                return null;
            }
            set => 
                this.uninitializedScopes = value;
        }
    }
}

