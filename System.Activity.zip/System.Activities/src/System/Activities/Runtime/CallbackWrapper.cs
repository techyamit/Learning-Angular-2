﻿namespace System.Activities.Runtime
{
    using System;
    using System.Activities;
    using System.Reflection;
    using System.Runtime.InteropServices;
    using System.Runtime.Serialization;
    using System.Security;
    using System.Security.Permissions;
    using System.Threading;

    [DataContract]
    internal class CallbackWrapper
    {
        private static BindingFlags bindingFlags = (BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Static | BindingFlags.Instance | BindingFlags.DeclaredOnly);
        private static PermissionSet ReflectionMemberAccessPermissionSet = null;
        private string callbackName;
        private string declaringAssemblyName;
        private string declaringTypeName;
        private Delegate callback;
        private System.Activities.ActivityInstance activityInstance;

        public CallbackWrapper(Delegate callback, System.Activities.ActivityInstance owningInstance)
        {
            this.ActivityInstance = owningInstance;
            this.callback = callback;
        }

        [SecurityCritical]
        protected void EnsureCallback(Type delegateType, Type[] parameters)
        {
            if (this.callback == null)
            {
                MethodInfo matchingMethod = this.GetMatchingMethod(parameters, out _);
                this.callback = this.RecreateCallback(delegateType, matchingMethod);
            }
        }

        [SecurityCritical]
        protected void EnsureCallback(Type delegateType, Type[] parameterTypes, Type genericParameter)
        {
            if (this.callback == null)
            {
                this.callback = this.GenerateCallback(delegateType, parameterTypes, genericParameter);
            }
        }

        private MethodInfo FindMatchingGenericMethod(Type declaringType, Type[] parameterTypes, Type genericParameter)
        {
            foreach (MethodInfo info in declaringType.GetMethods(bindingFlags))
            {
                if ((!info.IsGenericMethod || (info.Name != this.callbackName)) || (info.GetGenericArguments().Length != 1))
                {
                    continue;
                }
                Type[] typeArguments = new Type[] { genericParameter };
                info = info.MakeGenericMethod(typeArguments);
                ParameterInfo[] parameters = info.GetParameters();
                bool flag = true;
                for (int i = 0; i < parameters.Length; i++)
                {
                    ParameterInfo info2 = parameters[i];
                    if ((info2.IsOut || info2.IsOptional) || (info2.ParameterType != parameterTypes[i]))
                    {
                        flag = false;
                        break;
                    }
                }
                if (flag)
                {
                    return info;
                }
            }
            return null;
        }

        [SecurityCritical]
        private Delegate GenerateCallback(Type delegateType, Type[] parameterTypes, Type genericParameter)
        {
            MethodInfo matchingMethod = this.GetMatchingMethod(parameterTypes, out Type type);
            if (matchingMethod == null)
            {
                matchingMethod = this.FindMatchingGenericMethod(type, parameterTypes, genericParameter);
            }
            if (matchingMethod == null)
            {
                return null;
            }
            return this.RecreateCallback(delegateType, matchingMethod);
        }

        private MethodInfo GetMatchingMethod(Type[] parameters, out Type declaringType)
        {
            object activity = this.ActivityInstance.Activity;
            if (this.declaringTypeName == null)
            {
                declaringType = activity.GetType();
            }
            else
            {
                Assembly assembly;
                if (this.declaringAssemblyName != null)
                {
                    assembly = Assembly.Load(this.declaringAssemblyName);
                }
                else
                {
                    assembly = activity.GetType().Assembly;
                }
                declaringType = assembly.GetType(this.declaringTypeName);
            }
            return declaringType.GetMethod(this.callbackName, bindingFlags, null, parameters, null);
        }

        public static bool IsValidCallback(Delegate callback, System.Activities.ActivityInstance owningInstance)
        {
            object target = callback.Target;
            return ((target == null) || (target == owningInstance.Activity));
        }

        [OnSerializing]
        internal void OnSerializing(StreamingContext context)
        {
            if ((this.callbackName == null) && !this.IsCallbackNull)
            {
                MethodInfo method = this.callback.Method;
                this.callbackName = method.Name;
                Type declaringType = method.DeclaringType;
                Type type = this.ActivityInstance.Activity.GetType();
                if (declaringType != type)
                {
                    this.declaringTypeName = declaringType.FullName;
                    if (declaringType.Assembly != type.Assembly)
                    {
                        this.declaringAssemblyName = declaringType.Assembly.FullName;
                    }
                }
                if (method.IsGenericMethod)
                {
                    this.OnSerializingGenericCallback();
                }
            }
        }

        protected virtual void OnSerializingGenericCallback()
        {
            throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.InvalidExecutionCallback(this.callback.Method, null)));
        }

        [SecurityCritical]
        private Delegate RecreateCallback(Type delegateType, MethodInfo callbackMethod)
        {
            object firstArgument = null;
            Delegate delegate2;
            if (!typeof(Activity).IsAssignableFrom(callbackMethod.DeclaringType))
            {
                return null;
            }
            if (!callbackMethod.IsStatic)
            {
                firstArgument = this.ActivityInstance.Activity;
            }
            if (ReflectionMemberAccessPermissionSet == null)
            {
                PermissionSet set = new PermissionSet(PermissionState.None);
                set.AddPermission(new ReflectionPermission(ReflectionPermissionFlag.MemberAccess));
                Interlocked.CompareExchange<PermissionSet>(ref ReflectionMemberAccessPermissionSet, set, null);
            }
            ReflectionMemberAccessPermissionSet.Assert();
            try
            {
                delegate2 = Delegate.CreateDelegate(delegateType, firstArgument, callbackMethod);
            }
            finally
            {
                CodeAccessPermission.RevertAssert();
            }
            return delegate2;
        }

        [SecuritySafeCritical]
        protected void ValidateCallbackResolution(Type delegateType, Type[] parameterTypes, Type genericParameter)
        {
            if (!this.callback.Equals(this.GenerateCallback(delegateType, parameterTypes, genericParameter)))
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.InvalidExecutionCallback(this.callback.Method, null)));
            }
        }

        public System.Activities.ActivityInstance ActivityInstance
        {
            get => 
                this.activityInstance;
            private set => 
                this.activityInstance = value;
        }

        protected bool IsCallbackNull =>
            (this.callback == null) && (this.callbackName == null);

        protected Delegate Callback =>
            this.callback;

        [DataMember(Name="callbackName")]
        internal string SerializedCallbackName
        {
            get => 
                this.callbackName;
            set => 
                this.callbackName = value;
        }

        [DataMember(EmitDefaultValue=false, Name="declaringAssemblyName")]
        internal string SerializedDeclaringAssemblyName
        {
            get => 
                this.declaringAssemblyName;
            set => 
                this.declaringAssemblyName = value;
        }

        [DataMember(EmitDefaultValue=false, Name="declaringTypeName")]
        internal string SerializedDeclaringTypeName
        {
            get => 
                this.declaringTypeName;
            set => 
                this.declaringTypeName = value;
        }

        [DataMember(Name="ActivityInstance")]
        internal System.Activities.ActivityInstance SerializedActivityInstance
        {
            get => 
                this.ActivityInstance;
            set => 
                this.ActivityInstance = value;
        }
    }
}

