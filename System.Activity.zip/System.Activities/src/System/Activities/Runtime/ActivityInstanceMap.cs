﻿namespace System.Activities.Runtime
{
    using System;
    using System.Activities;
    using System.Activities.DynamicUpdate;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Runtime;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Runtime.Serialization;

    [DataContract(Name="InstanceMap", Namespace="http://schemas.datacontract.org/2010/02/System.Activities")]
    internal class ActivityInstanceMap
    {
        private IDictionary<Activity, InstanceList> instanceMapping;
        private InstanceList[] rawDeserializedLists;
        private IList<InstanceListNeedingUpdate> updateList;

        internal ActivityInstanceMap()
        {
        }

        private static void AddBlockingActivity(ref Collection<ActivityBlockingUpdate> updateErrors, DynamicUpdateMap.UpdatedActivity updatedActivity, QualifiedId originalId, string reason, string activityInstanceId)
        {
            if (updatedActivity.NewActivity != null)
            {
                ActivityBlockingUpdate.AddBlockingActivity(ref updateErrors, updatedActivity.NewActivity, originalId.ToString(), reason, activityInstanceId);
            }
            else
            {
                string updatedActivityId = updatedActivity.MapEntry.IsRemoval ? null : updatedActivity.NewId.ToString();
                ActivityBlockingUpdate.AddBlockingActivity(ref updateErrors, updatedActivityId, originalId.ToString(), reason, activityInstanceId);
            }
        }

        public void AddEntry(IActivityReference reference)
        {
            this.AddEntry(reference, false);
        }

        public void AddEntry(IActivityReference reference, bool skipIfDuplicate)
        {
            Activity key = reference.Activity;
            if (this.InstanceMapping.TryGetValue(key, out InstanceList list))
            {
                list.Add(reference, skipIfDuplicate);
            }
            else
            {
                this.InstanceMapping.Add(key, new InstanceList(reference));
            }
        }

        private static bool CanCompensationOrConfirmationHandlerReferenceAddedSymbols(InstanceList instanceList, DynamicUpdateMap rootUpdateMap, IdSpace rootIdSpace, List<System.Activities.ActivityInstance> secondaryRootInstances, ref Collection<ActivityBlockingUpdate> updateErrors)
        {
            for (int i = 0; i < instanceList.Count; i++)
            {
                System.Activities.ActivityInstance instance = instanceList[i] as System.Activities.ActivityInstance;
                if ((instance != null) && IsNonDefaultSecondaryRoot(instance, secondaryRootInstances))
                {
                    int[] sourceArray = new QualifiedId(instanceList.ActivityId).AsIDArray();
                    int[] destinationArray = new int[sourceArray.Length - 1];
                    Array.Copy(sourceArray, destinationArray, (int) (sourceArray.Length - 1));
                    List<int> list = new List<int>();
                    for (int j = 0; j < destinationArray.Length; j++)
                    {
                        list.Add(destinationArray[j]);
                        DynamicUpdateMap.UpdatedActivity updatedActivity = rootUpdateMap.GetUpdatedActivity(new QualifiedId(list.ToArray()), rootIdSpace);
                        if (updatedActivity.MapEntry != null)
                        {
                            DynamicUpdateMapEntry mapEntry = updatedActivity.MapEntry;
                            do
                            {
                                if ((!mapEntry.IsRemoval && mapEntry.HasEnvironmentUpdates) && mapEntry.EnvironmentUpdateMap.IsAdditionToNoSymbols)
                                {
                                    int[] idArray = list.ToArray();
                                    idArray[idArray.Length - 1] = mapEntry.OldActivityId;
                                    QualifiedId oldQualifiedId = new QualifiedId(idArray);
                                    DynamicUpdateMap.UpdatedActivity activity2 = rootUpdateMap.GetUpdatedActivity(oldQualifiedId, rootIdSpace);
                                    AddBlockingActivity(ref updateErrors, activity2, oldQualifiedId, System.Activities.SR.VariableOrArgumentAdditionToReferencedEnvironmentNoDUSupported, null);
                                    return true;
                                }
                                mapEntry = mapEntry.Parent;
                            }
                            while (mapEntry != null);
                        }
                    }
                }
            }
            return false;
        }

        public void GetActivitiesBlockingUpdate(DynamicUpdateMap updateMap, List<System.Activities.ActivityInstance> secondaryRootInstances, ref Collection<ActivityBlockingUpdate> updateErrors)
        {
            this.GetInstanceListsNeedingUpdate(updateMap, null, secondaryRootInstances, ref updateErrors);
        }

        private IList<InstanceListNeedingUpdate> GetInstanceListsNeedingUpdate(DynamicUpdateMap updateMap, Activity targetDefinition, List<System.Activities.ActivityInstance> secondaryRootInstances, ref Collection<ActivityBlockingUpdate> updateErrors)
        {
            IList<InstanceListNeedingUpdate> list = new List<InstanceListNeedingUpdate>();
            if (this.rawDeserializedLists != null)
            {
                IdSpace rootIdSpace = null;
                if (targetDefinition != null)
                {
                    rootIdSpace = targetDefinition.MemberOf;
                }
                for (int i = 0; i < this.rawDeserializedLists.Length; i++)
                {
                    InstanceListNeedingUpdate update;
                    InstanceList instanceList = this.rawDeserializedLists[i];
                    QualifiedId oldQualifiedId = new QualifiedId(instanceList.ActivityId);
                    if (updateMap.IsImplementationAsRoot)
                    {
                        int[] numArray = oldQualifiedId.AsIDArray();
                        if ((numArray.Length == 1) && (numArray[0] != 1))
                        {
                            throw System.Activities.FxTrace.Exception.AsError(new InstanceUpdateException(System.Activities.SR.InvalidImplementationAsWorkflowRootForRuntimeState));
                        }
                    }
                    DynamicUpdateMap.UpdatedActivity updatedActivity = updateMap.GetUpdatedActivity(oldQualifiedId, rootIdSpace);
                    if (CanCompensationOrConfirmationHandlerReferenceAddedSymbols(instanceList, updateMap, rootIdSpace, secondaryRootInstances, ref updateErrors))
                    {
                        update = null;
                    }
                    else if (updatedActivity.MapEntry == null)
                    {
                        if (updatedActivity.IdChanged)
                        {
                            update = new InstanceListNeedingUpdate {
                                InstanceList = instanceList,
                                NewId = updatedActivity.NewId
                            };
                        }
                        else
                        {
                            update = new InstanceListNeedingUpdate {
                                InstanceList = instanceList,
                                NewId = null
                            };
                        }
                    }
                    else if (updatedActivity.MapEntry.IsParentRemovedOrBlocked)
                    {
                        update = null;
                    }
                    else if (IsRemovalOrRTUpdateBlockedOrBlockedByUser(updatedActivity, oldQualifiedId, out string str))
                    {
                        string activityInstanceId = null;
                        for (int j = 0; j < instanceList.Count; j++)
                        {
                            System.Activities.ActivityInstance instance = instanceList[j] as System.Activities.ActivityInstance;
                            if (instance != null)
                            {
                                activityInstanceId = instance.Id;
                                break;
                            }
                        }
                        AddBlockingActivity(ref updateErrors, updatedActivity, oldQualifiedId, str, activityInstanceId);
                        update = null;
                    }
                    else if (IsInvalidEnvironmentUpdate(instanceList, updatedActivity, ref updateErrors))
                    {
                        update = null;
                    }
                    else
                    {
                        update = new InstanceListNeedingUpdate {
                            InstanceList = instanceList,
                            NewId = updatedActivity.NewId,
                            UpdateMap = updatedActivity.Map,
                            MapEntry = updatedActivity.MapEntry,
                            NewActivity = updatedActivity.NewActivity
                        };
                    }
                    if (update != null)
                    {
                        update.OriginalId = instanceList.ActivityId;
                        list.Add(update);
                    }
                }
            }
            return list;
        }

        private static bool IsInvalidEnvironmentUpdate(InstanceList instanceList, DynamicUpdateMap.UpdatedActivity updatedActivity, ref Collection<ActivityBlockingUpdate> updateErrors)
        {
            if ((updatedActivity.MapEntry != null) && updatedActivity.MapEntry.HasEnvironmentUpdates)
            {
                for (int i = 0; i < instanceList.Count; i++)
                {
                    System.Activities.ActivityInstance instance = instanceList[i] as System.Activities.ActivityInstance;
                    if (instance != null)
                    {
                        string reason = null;
                        if (instance.SubState == System.Activities.ActivityInstance.Substate.ResolvingVariables)
                        {
                            reason = System.Activities.SR.CannotUpdateEnvironmentInTheMiddleOfResolvingVariables;
                        }
                        else if (instance.SubState == System.Activities.ActivityInstance.Substate.ResolvingArguments)
                        {
                            reason = System.Activities.SR.CannotUpdateEnvironmentInTheMiddleOfResolvingArguments;
                        }
                        if (reason != null)
                        {
                            AddBlockingActivity(ref updateErrors, updatedActivity, new QualifiedId(instanceList.ActivityId), reason, instance.Id);
                            return true;
                        }
                    }
                    else if (instanceList[i] is LocationEnvironment)
                    {
                        EnvironmentUpdateMap environmentUpdateMap = updatedActivity.MapEntry.EnvironmentUpdateMap;
                        if (((environmentUpdateMap.HasVariableEntries && TryGatherSchedulableExpressions(environmentUpdateMap.VariableEntries, out List<int> list)) || (environmentUpdateMap.HasPrivateVariableEntries && TryGatherSchedulableExpressions(environmentUpdateMap.PrivateVariableEntries, out list))) || (environmentUpdateMap.HasArgumentEntries && TryGatherSchedulableExpressions(environmentUpdateMap.ArgumentEntries, out list)))
                        {
                            AddBlockingActivity(ref updateErrors, updatedActivity, new QualifiedId(instanceList.ActivityId), System.Activities.SR.VariableOrArgumentAdditionToReferencedEnvironmentNoDUSupported, null);
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        private static bool IsNonDefaultSecondaryRoot(System.Activities.ActivityInstance instance, List<System.Activities.ActivityInstance> secondaryRootInstances) => 
            ((secondaryRootInstances != null) && secondaryRootInstances.Contains(instance)) && (instance.IsEnvironmentOwner && (instance.Environment.Parent != null));

        private static bool IsRemovalOrRTUpdateBlockedOrBlockedByUser(DynamicUpdateMap.UpdatedActivity updatedActivity, QualifiedId oldQualifiedId, out string error)
        {
            error = null;
            if (updatedActivity.MapEntry.IsRemoval)
            {
                error = System.Activities.SR.CannotRemoveExecutingActivityUpdateError(oldQualifiedId, updatedActivity.MapEntry.DisplayName);
            }
            else if (updatedActivity.MapEntry.IsRuntimeUpdateBlocked)
            {
                error = updatedActivity.MapEntry.BlockReasonMessage ?? UpdateBlockedReasonMessages.Get(updatedActivity.MapEntry.BlockReason);
            }
            else if (updatedActivity.MapEntry.IsUpdateBlockedByUpdateAuthor)
            {
                error = System.Activities.SR.BlockedUpdateInsideActivityUpdateByUserError;
            }
            return (error > null);
        }

        public void LoadActivityTree(Activity rootActivity, System.Activities.ActivityInstance rootInstance, List<System.Activities.ActivityInstance> secondaryRootInstances, ActivityExecutor executor)
        {
            this.instanceMapping = new Dictionary<Activity, InstanceList>(this.rawDeserializedLists.Length);
            for (int i = 0; i < this.rawDeserializedLists.Length; i++)
            {
                InstanceList list = this.rawDeserializedLists[i];
                if (!QualifiedId.TryGetElementFromRoot(rootActivity, list.ActivityId, out Activity activity))
                {
                    throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.ActivityInstanceFixupFailed));
                }
                this.instanceMapping.Add(activity, list);
                list.Load(activity, this);
            }
            this.rawDeserializedLists = null;
            Func<System.Activities.ActivityInstance, ActivityExecutor, bool> callback = new Func<System.Activities.ActivityInstance, ActivityExecutor, bool>(this.OnActivityInstanceLoaded);
            rootInstance.FixupInstance(null, this, executor);
            ActivityUtilities.ProcessActivityInstanceTree(rootInstance, executor, callback);
            if (secondaryRootInstances != null)
            {
                foreach (System.Activities.ActivityInstance instance in secondaryRootInstances)
                {
                    instance.FixupInstance(null, this, executor);
                    ActivityUtilities.ProcessActivityInstanceTree(instance, executor, callback);
                }
            }
        }

        private bool OnActivityInstanceLoaded(System.Activities.ActivityInstance activityInstance, ActivityExecutor executor) => 
            activityInstance.TryFixupChildren(this, executor);

        public bool RemoveEntry(IActivityReference reference)
        {
            if (this.instanceMapping == null)
            {
                return false;
            }
            Activity key = reference.Activity;
            if (!this.InstanceMapping.TryGetValue(key, out InstanceList list))
            {
                return false;
            }
            if (list.Count == 1)
            {
                this.InstanceMapping.Remove(key);
            }
            else
            {
                list.Remove(reference);
            }
            return true;
        }

        private static bool TryGatherSchedulableExpressions(IList<EnvironmentUpdateMapEntry> entries, out List<int> addedLocationReferenceIndexes)
        {
            addedLocationReferenceIndexes = null;
            for (int i = 0; i < entries.Count; i++)
            {
                EnvironmentUpdateMapEntry entry = entries[i];
                if (entry.IsAddition)
                {
                    if (addedLocationReferenceIndexes == null)
                    {
                        addedLocationReferenceIndexes = new List<int>();
                    }
                    addedLocationReferenceIndexes.Add(entry.NewOffset);
                }
            }
            return (addedLocationReferenceIndexes > null);
        }

        public void UpdateInstanceByActivityParticipation(ActivityExecutor activityExecutor, DynamicUpdateMap rootMap, ref Collection<ActivityBlockingUpdate> updateErrors)
        {
            foreach (InstanceListNeedingUpdate update in this.updateList)
            {
                if (update.NothingChanged || update.ParentIdShiftOnly)
                {
                    update.UpdateMap = DynamicUpdateMap.DummyMap;
                    update.MapEntry = DynamicUpdateMapEntry.DummyMapEntry;
                }
                for (int j = 0; j < update.InstanceList.Count; j++)
                {
                    System.Activities.ActivityInstance currentInstance = update.InstanceList[j] as System.Activities.ActivityInstance;
                    if (currentInstance != null)
                    {
                        IInstanceUpdatable activity = currentInstance.Activity as IInstanceUpdatable;
                        if ((activity != null) && (currentInstance.SubState == System.Activities.ActivityInstance.Substate.Executing))
                        {
                            NativeActivityUpdateContext updateContext = new NativeActivityUpdateContext(this, activityExecutor, currentInstance, update.UpdateMap, update.MapEntry, rootMap);
                            try
                            {
                                activity.InternalUpdateInstance(updateContext);
                                if (updateContext.IsUpdateDisallowed)
                                {
                                    ActivityBlockingUpdate.AddBlockingActivity(ref updateErrors, currentInstance.Activity, new QualifiedId(update.OriginalId).ToString(), updateContext.DisallowedReason, currentInstance.Id);
                                }
                            }
                            catch (Exception exception)
                            {
                                if (Fx.IsFatal(exception))
                                {
                                    throw;
                                }
                                throw System.Activities.FxTrace.Exception.AsError(new InstanceUpdateException(System.Activities.SR.NativeActivityUpdateInstanceThrewException(exception.Message), exception));
                            }
                            finally
                            {
                                updateContext.Dispose();
                            }
                        }
                    }
                }
            }
            for (int i = this.updateList.Count - 1; i >= 0; i--)
            {
                InstanceListNeedingUpdate update2 = this.updateList[i];
                if (update2.MapEntryExists && update2.MapEntry.HasEnvironmentUpdates)
                {
                    for (int j = 0; j < update2.InstanceList.Count; j++)
                    {
                        System.Activities.ActivityInstance instance2 = update2.InstanceList[j] as System.Activities.ActivityInstance;
                        if ((instance2 != null) && (instance2.SubState == System.Activities.ActivityInstance.Substate.Executing))
                        {
                            EnvironmentUpdateMap environmentUpdateMap = update2.MapEntry.EnvironmentUpdateMap;
                            if (environmentUpdateMap.HasVariableEntries && TryGatherSchedulableExpressions(environmentUpdateMap.VariableEntries, out List<int> list2))
                            {
                                instance2.ResolveNewVariableDefaultsDuringDynamicUpdate(activityExecutor, list2, false);
                            }
                            if (environmentUpdateMap.HasPrivateVariableEntries && TryGatherSchedulableExpressions(environmentUpdateMap.PrivateVariableEntries, out List<int> list3))
                            {
                                instance2.ResolveNewVariableDefaultsDuringDynamicUpdate(activityExecutor, list3, true);
                            }
                            if (environmentUpdateMap.HasArgumentEntries && TryGatherSchedulableExpressions(environmentUpdateMap.ArgumentEntries, out List<int> list))
                            {
                                instance2.ResolveNewArgumentsDuringDynamicUpdate(activityExecutor, list);
                            }
                        }
                    }
                }
            }
        }

        public void UpdateRawInstance(DynamicUpdateMap updateMap, Activity targetDefinition, List<System.Activities.ActivityInstance> secondaryRootInstances, ref Collection<ActivityBlockingUpdate> updateErrors)
        {
            this.updateList = this.GetInstanceListsNeedingUpdate(updateMap, targetDefinition, secondaryRootInstances, ref updateErrors);
            if ((updateErrors == null) || (updateErrors.Count <= 0))
            {
                foreach (InstanceListNeedingUpdate update in this.updateList)
                {
                    if (!update.NothingChanged)
                    {
                        InstanceList instanceList = update.InstanceList;
                        instanceList.ActivityId = update.NewId.AsByteArray();
                        if (!update.ParentIdShiftOnly)
                        {
                            bool flag = false;
                            if (update.MapEntry.ImplementationUpdateMap != null)
                            {
                                flag = true;
                            }
                            if (update.MapEntry.HasEnvironmentUpdates)
                            {
                                instanceList.UpdateEnvironments(update.MapEntry.EnvironmentUpdateMap, update.NewActivity);
                            }
                            for (int i = 0; i < instanceList.Count; i++)
                            {
                                System.Activities.ActivityInstance instance = instanceList[i] as System.Activities.ActivityInstance;
                                if (flag)
                                {
                                    instance.ImplementationVersion = update.NewActivity.ImplementationVersion;
                                }
                            }
                        }
                    }
                }
            }
        }

        [DataMember(EmitDefaultValue=false)]
        internal InstanceList[] SerializedInstanceLists
        {
            get
            {
                if ((this.instanceMapping == null) || (this.instanceMapping.Count == 0))
                {
                    return this.rawDeserializedLists;
                }
                InstanceList[] listArray = new InstanceList[this.instanceMapping.Count];
                int index = 0;
                foreach (KeyValuePair<Activity, InstanceList> pair in this.instanceMapping)
                {
                    pair.Value.ActivityId = pair.Key.QualifiedId.AsByteArray();
                    listArray[index] = pair.Value;
                    index++;
                }
                return listArray;
            }
            set => 
                this.rawDeserializedLists = value;
        }

        private IDictionary<Activity, InstanceList> InstanceMapping
        {
            get
            {
                if (this.instanceMapping == null)
                {
                    this.instanceMapping = new Dictionary<Activity, InstanceList>();
                }
                return this.instanceMapping;
            }
        }

        public interface IActivityReference
        {
            void Load(System.Activities.Activity activity, ActivityInstanceMap instanceMap);

            System.Activities.Activity Activity { get; }
        }

        public interface IActivityReferenceWithEnvironment : ActivityInstanceMap.IActivityReference
        {
            void UpdateEnvironment(EnvironmentUpdateMap map, Activity activity);
        }

        [DataContract]
        internal class InstanceList : HybridCollection<ActivityInstanceMap.IActivityReference>
        {
            public InstanceList(ActivityInstanceMap.IActivityReference reference) : base(reference)
            {
            }

            public void Add(ActivityInstanceMap.IActivityReference reference, bool skipIfDuplicate)
            {
                if (skipIfDuplicate)
                {
                    if (base.SingleItem != null)
                    {
                        if (base.SingleItem == reference)
                        {
                            return;
                        }
                    }
                    else if (base.MultipleItems.Contains(reference))
                    {
                        return;
                    }
                }
                base.Add(reference);
            }

            public void Load(Activity activity, ActivityInstanceMap instanceMap)
            {
                if (base.SingleItem != null)
                {
                    base.SingleItem.Load(activity, instanceMap);
                }
                else
                {
                    for (int i = 0; i < base.MultipleItems.Count; i++)
                    {
                        base.MultipleItems[i].Load(activity, instanceMap);
                    }
                }
            }

            [OnSerializing]
            internal void OnSerializing(StreamingContext context)
            {
                base.Compress();
            }

            public void UpdateEnvironments(EnvironmentUpdateMap map, Activity activity)
            {
                if (base.SingleItem != null)
                {
                    ActivityInstanceMap.IActivityReferenceWithEnvironment singleItem = base.SingleItem as ActivityInstanceMap.IActivityReferenceWithEnvironment;
                    if (singleItem != null)
                    {
                        singleItem.UpdateEnvironment(map, activity);
                    }
                }
                else
                {
                    for (int i = 0; i < base.MultipleItems.Count; i++)
                    {
                        ActivityInstanceMap.IActivityReferenceWithEnvironment environment2 = base.MultipleItems[i] as ActivityInstanceMap.IActivityReferenceWithEnvironment;
                        if (environment2 != null)
                        {
                            environment2.UpdateEnvironment(map, activity);
                        }
                    }
                }
            }

            [DataMember]
            public byte[] ActivityId { get; set; }
        }

        private class InstanceListNeedingUpdate
        {
            public System.Activities.Runtime.ActivityInstanceMap.InstanceList InstanceList { get; set; }

            public byte[] OriginalId { get; set; }

            public QualifiedId NewId { get; set; }

            public DynamicUpdateMap UpdateMap { get; set; }

            public DynamicUpdateMapEntry MapEntry { get; set; }

            public Activity NewActivity { get; set; }

            public bool NothingChanged =>
                (this.MapEntry == null) && (this.NewId == null);

            public bool MapEntryExists =>
                this.MapEntry > null;

            public bool ParentIdShiftOnly =>
                (this.MapEntry == null) && (this.NewId > null);
        }
    }
}

