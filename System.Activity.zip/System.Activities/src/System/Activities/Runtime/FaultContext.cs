﻿namespace System.Activities.Runtime
{
    using System;
    using System.Runtime.Serialization;

    [DataContract]
    internal class FaultContext
    {
        private System.Exception exception;
        private ActivityInstanceReference source;

        internal FaultContext(System.Exception exception, ActivityInstanceReference sourceReference)
        {
            this.Exception = exception;
            this.Source = sourceReference;
        }

        public System.Exception Exception
        {
            get => 
                this.exception;
            private set => 
                this.exception = value;
        }

        public ActivityInstanceReference Source
        {
            get => 
                this.source;
            private set => 
                this.source = value;
        }

        [DataMember(Name="Exception")]
        internal System.Exception SerializedException
        {
            get => 
                this.Exception;
            set => 
                this.Exception = value;
        }

        [DataMember(Name="Source")]
        internal ActivityInstanceReference SerializedSource
        {
            get => 
                this.Source;
            set => 
                this.Source = value;
        }
    }
}

