﻿namespace System.Activities.Runtime
{
    using System;
    using System.Activities;
    using System.Runtime.Serialization;

    [DataContract]
    internal class FaultBookmark
    {
        private FaultCallbackWrapper callbackWrapper;

        public FaultBookmark(FaultCallbackWrapper callbackWrapper)
        {
            this.callbackWrapper = callbackWrapper;
        }

        public System.Activities.Runtime.WorkItem GenerateWorkItem(Exception propagatedException, System.Activities.ActivityInstance propagatedFrom, ActivityInstanceReference originalExceptionSource) => 
            this.callbackWrapper.CreateWorkItem(propagatedException, propagatedFrom, originalExceptionSource);

        [DataMember(Name="callbackWrapper")]
        internal FaultCallbackWrapper SerializedCallbackWrapper
        {
            get => 
                this.callbackWrapper;
            set => 
                this.callbackWrapper = value;
        }
    }
}

