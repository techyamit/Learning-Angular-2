﻿namespace System.Activities.Runtime
{
    using System;
    using System.Activities;
    using System.Runtime.Serialization;

    [DataContract]
    internal class ActivityInstanceReference : ActivityInstanceMap.IActivityReference
    {
        private System.Activities.ActivityInstance activityInstance;

        internal ActivityInstanceReference(System.Activities.ActivityInstance activity)
        {
            this.activityInstance = activity;
        }

        void ActivityInstanceMap.IActivityReference.Load(Activity activity, ActivityInstanceMap instanceMap)
        {
            if (this.activityInstance.Activity == null)
            {
                ((ActivityInstanceMap.IActivityReference) this.activityInstance).Load(activity, instanceMap);
            }
        }

        [DataMember(Name="activityInstance")]
        internal System.Activities.ActivityInstance SerializedActivityInstance
        {
            get => 
                this.activityInstance;
            set => 
                this.activityInstance = value;
        }

        Activity ActivityInstanceMap.IActivityReference.Activity =>
            this.activityInstance.Activity;

        public System.Activities.ActivityInstance ActivityInstance =>
            this.activityInstance;
    }
}

