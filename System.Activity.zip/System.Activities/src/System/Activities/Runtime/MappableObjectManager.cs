﻿namespace System.Activities.Runtime
{
    using System;
    using System.Activities;
    using System.Activities.Hosting;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Runtime.Serialization;

    [DataContract]
    internal class MappableObjectManager
    {
        private List<MappableLocation> mappableLocations;

        public IDictionary<string, LocationInfo> GatherMappableVariables()
        {
            Dictionary<string, LocationInfo> dictionary = null;
            if ((this.mappableLocations != null) && (this.mappableLocations.Count > 0))
            {
                dictionary = new Dictionary<string, LocationInfo>(this.mappableLocations.Count);
                for (int i = 0; i < this.mappableLocations.Count; i++)
                {
                    MappableLocation location = this.mappableLocations[i];
                    dictionary.Add(location.MappingKeyName, new LocationInfo(location.Name, location.OwnerDisplayName, location.Location.Value));
                }
            }
            return dictionary;
        }

        public void Register(Location location, Activity activity, LocationReference locationOwner, System.Activities.ActivityInstance activityInstance)
        {
            if (this.mappableLocations == null)
            {
                this.mappableLocations = new List<MappableLocation>();
            }
            this.mappableLocations.Add(new MappableLocation(locationOwner, activity, activityInstance, location));
        }

        public void Unregister(Location location)
        {
            int count = this.mappableLocations.Count;
            for (int i = 0; i < count; i++)
            {
                if (this.mappableLocations[i].Location == location)
                {
                    this.mappableLocations.RemoveAt(i);
                    return;
                }
            }
        }

        public int Count
        {
            get
            {
                int num = 0;
                if (this.mappableLocations != null)
                {
                    num += this.mappableLocations.Count;
                }
                return num;
            }
        }

        [DataMember(EmitDefaultValue=false, Name="mappableLocations")]
        internal List<MappableLocation> SerializedMappableLocations
        {
            get => 
                this.mappableLocations;
            set => 
                this.mappableLocations = value;
        }

        [DataContract]
        internal class MappableLocation
        {
            private string mappingKeyName;
            private string name;
            private string ownerDisplayName;
            private System.Activities.Location location;

            public MappableLocation(LocationReference locationOwner, Activity activity, System.Activities.ActivityInstance activityInstance, System.Activities.Location location)
            {
                this.Name = locationOwner.Name;
                this.OwnerDisplayName = activity.DisplayName;
                this.Location = location;
                object[] args = new object[] { activity.Id, locationOwner.Id, activityInstance.Id };
                this.MappingKeyName = string.Format(CultureInfo.InvariantCulture, "activity.{0}-{1}_{2}", args);
            }

            internal string MappingKeyName
            {
                get => 
                    this.mappingKeyName;
                private set => 
                    this.mappingKeyName = value;
            }

            public string Name
            {
                get => 
                    this.name;
                private set => 
                    this.name = value;
            }

            public string OwnerDisplayName
            {
                get => 
                    this.ownerDisplayName;
                private set => 
                    this.ownerDisplayName = value;
            }

            internal System.Activities.Location Location
            {
                get => 
                    this.location;
                private set => 
                    this.location = value;
            }

            [DataMember(Name="MappingKeyName")]
            internal string SerializedMappingKeyName
            {
                get => 
                    this.MappingKeyName;
                set => 
                    this.MappingKeyName = value;
            }

            [DataMember(Name="Name")]
            internal string SerializedName
            {
                get => 
                    this.Name;
                set => 
                    this.Name = value;
            }

            [DataMember(EmitDefaultValue=false, Name="OwnerDisplayName")]
            internal string SerializedOwnerDisplayName
            {
                get => 
                    this.OwnerDisplayName;
                set => 
                    this.OwnerDisplayName = value;
            }

            [DataMember(Name="Location")]
            internal System.Activities.Location SerializedLocation
            {
                get => 
                    this.Location;
                set => 
                    this.Location = value;
            }
        }
    }
}

