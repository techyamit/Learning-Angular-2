﻿namespace System.Activities.Runtime
{
    using System;
    using System.Activities;
    using System.Runtime.CompilerServices;
    using System.Runtime.Serialization;
    using System.Security;

    [DataContract]
    internal class BookmarkCallbackWrapper : CallbackWrapper
    {
        private static readonly Type bookmarkCallbackType = typeof(BookmarkCallback);
        private static readonly Type[] bookmarkCallbackParameters = new Type[] { typeof(NativeActivityContext), typeof(System.Activities.Bookmark), typeof(object) };
        private BookmarkOptions options;

        public BookmarkCallbackWrapper(BookmarkCallback callback, System.Activities.ActivityInstance owningInstance) : this(callback, owningInstance, BookmarkOptions.None)
        {
        }

        public BookmarkCallbackWrapper(BookmarkCallback callback, System.Activities.ActivityInstance owningInstance, BookmarkOptions bookmarkOptions) : base(callback, owningInstance)
        {
            this.Options = bookmarkOptions;
        }

        public ActivityExecutionWorkItem CreateWorkItem(ActivityExecutor executor, bool isExternal, System.Activities.Bookmark bookmark, object value)
        {
            if (base.IsCallbackNull)
            {
                return executor.CreateEmptyWorkItem(base.ActivityInstance);
            }
            return new BookmarkWorkItem(executor, isExternal, this, bookmark, value);
        }

        [SecuritySafeCritical]
        public void Invoke(NativeActivityContext context, System.Activities.Bookmark bookmark, object value)
        {
            base.EnsureCallback(bookmarkCallbackType, bookmarkCallbackParameters);
            BookmarkCallback callback = (BookmarkCallback) base.Callback;
            callback(context, bookmark, value);
        }

        public BookmarkOptions Options
        {
            get => 
                this.options;
            private set => 
                this.options = value;
        }

        [DataMember(EmitDefaultValue=false)]
        public System.Activities.Bookmark Bookmark { get; set; }

        [DataMember(EmitDefaultValue=false, Name="Options")]
        internal BookmarkOptions SerializedOptions
        {
            get => 
                this.Options;
            set => 
                this.Options = value;
        }
    }
}

