﻿namespace System.Activities.Runtime
{
    using System;
    using System.Activities;
    using System.Activities.Debugger;
    using System.Activities.DynamicUpdate;
    using System.Activities.Hosting;
    using System.Activities.Tracking;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Diagnostics;
    using System.Globalization;
    using System.Runtime;
    using System.Runtime.CompilerServices;
    using System.Runtime.Diagnostics;
    using System.Runtime.InteropServices;
    using System.Runtime.Serialization;
    using System.Security;
    using System.Threading;
    using System.Transactions;

    [DataContract(Name="Executor", Namespace="http://schemas.datacontract.org/2010/02/System.Activities")]
    internal class ActivityExecutor : IEnlistmentNotification
    {
        private static ReadOnlyCollection<BookmarkInfo> emptyBookmarkInfoCollection;
        private BookmarkManager bookmarkManager;
        private System.Activities.Runtime.BookmarkScopeManager bookmarkScopeManager;
        private DebugController debugController;
        private bool hasRaisedWorkflowStarted;
        private Guid instanceId;
        private bool instanceIdSet;
        private Activity rootElement;
        private Dictionary<System.Activities.ActivityInstance, AsyncOperationContext> activeOperations;
        private WorkflowInstance host;
        private ActivityInstanceMap instanceMap;
        private System.Activities.Runtime.MappableObjectManager mappableObjectManager;
        private bool hasTrackedStarted;
        private long nextTrackingRecordNumber;
        private System.Activities.ActivityInstance rootInstance;
        private List<System.Activities.ActivityInstance> executingSecondaryRootInstances;
        private Scheduler scheduler;
        private Exception completionException;
        private bool shouldRaiseMainBodyComplete;
        private long lastInstanceId;
        private LocationEnvironment rootEnvironment;
        private IDictionary<string, object> workflowOutputs;
        private Bookmark mainRootCompleteBookmark;
        private ActivityInstanceState executionState;
        private Queue<PersistenceWaiter> persistenceWaiters;
        private Quack<TransactionContextWaiter> transactionContextWaiters;
        private RuntimeTransactionData runtimeTransaction;
        private bool isAbortPending;
        private bool isDisposed;
        private bool shouldPauseOnCanPersist;
        private bool isTerminatePending;
        private Exception terminationPendingException;
        private int noPersistCount;
        private System.Activities.Hosting.SymbolResolver symbolResolver;
        private bool throwDuringSerialization;
        private CodeActivityContext cachedResolutionContext;
        private System.Activities.Location ignorableResultLocation;
        private Pool<EmptyWorkItem> emptyWorkItemPool;
        private Pool<ExecuteActivityWorkItem> executeActivityWorkItemPool;
        private Pool<ExecuteSynchronousExpressionWorkItem> executeSynchronousExpressionWorkItemPool;
        private Pool<CompletionCallbackWrapper.CompletionWorkItem> completionWorkItemPool;
        private Pool<ResolveNextArgumentWorkItem> resolveNextArgumentWorkItemPool;
        private Pool<CodeActivityContext> codeActivityContextPool;
        private Pool<NativeActivityContext> nativeActivityContextPool;
        private ExecutionPropertyManager rootPropertyManager;
        private List<Handle> handles;
        private bool persistExceptions;
        private bool havePersistExceptionsValue;

        public ActivityExecutor(WorkflowInstance host)
        {
            this.host = host;
            this.WorkflowIdentity = host.DefinitionIdentity;
            this.bookmarkManager = new BookmarkManager();
            this.scheduler = new Scheduler(new Scheduler.Callbacks(this));
        }

        public bool Abort(Exception reason)
        {
            bool hasBeenResumed = this.TryTraceResume(out Guid guid);
            bool flag2 = this.Abort(reason, false);
            this.TraceSuspend(hasBeenResumed, guid);
            return flag2;
        }

        private bool Abort(Exception terminationException, bool isTerminate)
        {
            if (this.isDisposed)
            {
                return false;
            }
            if (!this.rootInstance.IsCompleted)
            {
                this.rootInstance.Abort(this, this.bookmarkManager, terminationException, isTerminate);
                if (this.rootPropertyManager != null)
                {
                    if (isTerminate)
                    {
                        HandleInitializationContext context = new HandleInitializationContext(this, null);
                        foreach (ExecutionPropertyManager.ExecutionProperty property in this.rootPropertyManager.Properties.Values)
                        {
                            Handle handle = property.Property as Handle;
                            if (handle != null)
                            {
                                handle.Uninitialize(context);
                            }
                        }
                        context.Dispose();
                    }
                    this.rootPropertyManager.UnregisterProperties(null, null, true);
                }
            }
            if (this.executingSecondaryRootInstances != null)
            {
                for (int i = this.executingSecondaryRootInstances.Count - 1; i >= 0; i--)
                {
                    this.executingSecondaryRootInstances[i].Abort(this, this.bookmarkManager, terminationException, isTerminate);
                }
            }
            this.scheduler.ClearAllWorkItems(this);
            if (isTerminate)
            {
                this.completionException = terminationException;
                this.executionState = ActivityInstanceState.Faulted;
            }
            this.Dispose();
            return true;
        }

        internal void AbortActivityInstance(System.Activities.ActivityInstance instance, Exception reason)
        {
            instance.Abort(this, this.bookmarkManager, reason, true);
            if (instance.CompletionBookmark != null)
            {
                instance.CompletionBookmark.CheckForCancelation();
            }
            else if (instance.Parent != null)
            {
                instance.CompletionBookmark = new CompletionBookmark();
            }
            this.ScheduleCompletionBookmark(instance);
        }

        public void AbortWorkflowInstance(Exception reason)
        {
            this.isAbortPending = true;
            this.host.Abort(reason);
            try
            {
                this.host.OnRequestAbort(reason);
            }
            catch (Exception exception)
            {
                if (Fx.IsFatal(exception))
                {
                    throw;
                }
                throw System.Activities.FxTrace.Exception.AsError(new CallbackException(System.Activities.SR.CallbackExceptionFromHostAbort(this.WorkflowInstanceId), exception));
            }
        }

        internal void AddHandle(Handle handleToAdd)
        {
            if (this.handles == null)
            {
                this.handles = new List<Handle>();
            }
            this.handles.Add(handleToAdd);
        }

        public void AddTrackingRecord(TrackingRecord record)
        {
            this.host.TrackingProvider.AddRecord(record);
        }

        internal IAsyncResult BeginAssociateKeys(ICollection<InstanceKey> keysToAssociate, AsyncCallback callback, object state) => 
            new AssociateKeysAsyncResult(this, keysToAssociate, callback, state);

        internal IAsyncResult BeginResumeBookmark(Bookmark bookmark, object value, TimeSpan timeout, AsyncCallback callback, object state) => 
            this.host.OnBeginResumeBookmark(bookmark, value, timeout, callback, state);

        public IAsyncResult BeginTrackPendingRecords(AsyncCallback callback, object state) => 
            this.host.BeginFlushTrackingRecordsInternal(callback, state);

        public void CancelActivity(System.Activities.ActivityInstance activityInstance)
        {
            if ((activityInstance.State == ActivityInstanceState.Executing) && !activityInstance.IsCancellationRequested)
            {
                activityInstance.IsCancellationRequested = true;
                if (activityInstance.HasNotExecuted)
                {
                    this.scheduler.PushWork(this.CreateEmptyWorkItem(activityInstance));
                }
                else
                {
                    this.scheduler.PushWork(new CancelActivityWorkItem(activityInstance));
                }
                if (this.ShouldTrackCancelRequestedRecords)
                {
                    this.AddTrackingRecord(new CancelRequestedRecord(this.WorkflowInstanceId, activityInstance.Parent, activityInstance));
                }
            }
        }

        internal void CancelPendingOperation(System.Activities.ActivityInstance instance)
        {
            if (this.TryGetPendingOperation(instance, out AsyncOperationContext context) && context.IsStillActive)
            {
                context.CancelOperation();
            }
        }

        public void CancelRootActivity()
        {
            if (this.rootInstance.State == ActivityInstanceState.Executing)
            {
                if (!this.rootInstance.IsCancellationRequested)
                {
                    bool hasBeenResumed = this.TryTraceResume(out Guid guid);
                    bool flag2 = true;
                    if ((this.runtimeTransaction != null) && (this.runtimeTransaction.IsolationScope != null))
                    {
                        if (this.runtimeTransaction.IsRootCancelPending)
                        {
                            flag2 = false;
                        }
                        this.runtimeTransaction.IsRootCancelPending = true;
                    }
                    else
                    {
                        this.rootInstance.IsCancellationRequested = true;
                        if (this.rootInstance.HasNotExecuted)
                        {
                            this.scheduler.PushWork(this.CreateEmptyWorkItem(this.rootInstance));
                        }
                        else
                        {
                            this.scheduler.PushWork(new CancelActivityWorkItem(this.rootInstance));
                        }
                    }
                    if (this.ShouldTrackCancelRequestedRecords & flag2)
                    {
                        this.AddTrackingRecord(new CancelRequestedRecord(this.WorkflowInstanceId, null, this.rootInstance));
                    }
                    this.TraceSuspend(hasBeenResumed, guid);
                }
            }
            else if (this.rootInstance.State != ActivityInstanceState.Closed)
            {
                this.executionState = ActivityInstanceState.Canceled;
                this.completionException = null;
            }
        }

        private List<BookmarkInfo> CollectExternalBookmarks()
        {
            List<BookmarkInfo> bookmarks = null;
            if ((this.bookmarkManager != null) && this.bookmarkManager.HasBookmarks)
            {
                bookmarks = new List<BookmarkInfo>();
                this.bookmarkManager.PopulateBookmarkInfo(bookmarks);
            }
            if (this.bookmarkScopeManager != null)
            {
                this.bookmarkScopeManager.PopulateBookmarkInfo(ref bookmarks);
            }
            if ((bookmarks != null) && (bookmarks.Count != 0))
            {
                return bookmarks;
            }
            return null;
        }

        internal Exception CompleteActivityInstance(System.Activities.ActivityInstance targetInstance)
        {
            Exception exception = null;
            this.HandleRootCompletion(targetInstance);
            this.ScheduleCompletionBookmark(targetInstance);
            if (!targetInstance.HasNotExecuted)
            {
                this.DebugActivityCompleted(targetInstance);
            }
            try
            {
                if (targetInstance.PropertyManager != null)
                {
                    targetInstance.PropertyManager.UnregisterProperties(targetInstance, targetInstance.Activity.MemberOf);
                }
                if (this.IsSecondaryRoot(targetInstance))
                {
                    LocationEnvironment reference = targetInstance.Environment;
                    if (targetInstance.IsEnvironmentOwner)
                    {
                        reference.RemoveReference(true);
                        if (reference.ShouldDispose)
                        {
                            reference.UninitializeHandles(targetInstance);
                            reference.Dispose();
                        }
                        reference = reference.Parent;
                    }
                    while (reference != null)
                    {
                        reference.RemoveReference(false);
                        if (reference.ShouldDispose)
                        {
                            reference.UninitializeHandles(targetInstance);
                            reference.Dispose();
                            if (this.instanceMap != null)
                            {
                                this.instanceMap.RemoveEntry(reference);
                            }
                        }
                        reference = reference.Parent;
                    }
                }
                else if (targetInstance.IsEnvironmentOwner)
                {
                    targetInstance.Environment.RemoveReference(true);
                    if (targetInstance.Environment.ShouldDispose)
                    {
                        targetInstance.Environment.UninitializeHandles(targetInstance);
                        targetInstance.Environment.Dispose();
                    }
                    else if (this.instanceMap != null)
                    {
                        this.instanceMap.AddEntry(targetInstance.Environment);
                    }
                }
            }
            catch (Exception exception2)
            {
                if (Fx.IsFatal(exception2))
                {
                    throw;
                }
                exception = exception2;
            }
            targetInstance.MarkAsComplete(this.bookmarkScopeManager, this.bookmarkManager);
            targetInstance.FinalizeState(this, exception > null);
            return exception;
        }

        public void CompleteOperation(System.Activities.ActivityInstance owningInstance)
        {
            this.CompleteOperation(owningInstance, true);
        }

        public void CompleteOperation(System.Activities.Runtime.WorkItem asyncCompletionWorkItem)
        {
            this.scheduler.EnqueueWork(asyncCompletionWorkItem);
            this.CompleteOperation(asyncCompletionWorkItem.ActivityInstance, false);
        }

        private void CompleteOperation(System.Activities.ActivityInstance owningInstance, bool exitNoPersist)
        {
            this.activeOperations.Remove(owningInstance);
            owningInstance.DecrementBusyCount();
            if (exitNoPersist)
            {
                this.ExitNoPersist();
            }
        }

        public void CompleteOperation(System.Activities.ActivityInstance owningInstance, BookmarkCallback callback, object state)
        {
            CompleteAsyncOperationWorkItem asyncCompletionWorkItem = new CompleteAsyncOperationWorkItem(new BookmarkCallbackWrapper(callback, owningInstance), this.bookmarkManager.GenerateTempBookmark(), state);
            this.CompleteOperation(asyncCompletionWorkItem);
        }

        public void CompleteTransaction(RuntimeTransactionHandle handle, BookmarkCallback callback, System.Activities.ActivityInstance callbackOwner)
        {
            if (callback != null)
            {
                Bookmark bookmark = this.bookmarkManager.CreateBookmark(callback, callbackOwner, BookmarkOptions.None);
                System.Activities.ActivityInstance isolationInstance = null;
                if (this.runtimeTransaction != null)
                {
                    isolationInstance = this.runtimeTransaction.IsolationScope;
                }
                this.bookmarkManager.TryGenerateWorkItem(this, false, ref bookmark, null, isolationInstance, out ActivityExecutionWorkItem item);
                this.scheduler.EnqueueWork(item);
            }
            if ((this.runtimeTransaction != null) && (this.runtimeTransaction.TransactionHandle == handle))
            {
                this.runtimeTransaction.ShouldScheduleCompletion = true;
                if (TD.RuntimeTransactionCompletionRequestedIsEnabled())
                {
                    TD.RuntimeTransactionCompletionRequested(callbackOwner.Activity.GetType().ToString(), callbackOwner.Activity.DisplayName, callbackOwner.Id);
                }
            }
        }

        internal ActivityInstanceReference CreateActivityInstanceReference(System.Activities.ActivityInstance toReference, System.Activities.ActivityInstance referenceOwner)
        {
            ActivityInstanceReference reference = new ActivityInstanceReference(toReference);
            if (this.instanceMap != null)
            {
                this.instanceMap.AddEntry(reference);
            }
            referenceOwner.AddActivityReference(reference);
            return reference;
        }

        public EmptyWorkItem CreateEmptyWorkItem(System.Activities.ActivityInstance instance)
        {
            EmptyWorkItem item = this.EmptyWorkItemPool.Acquire();
            item.Initialize(instance);
            return item;
        }

        public NoPersistProperty CreateNoPersistProperty() => 
            new NoPersistProperty(this);

        private System.Activities.ActivityInstance CreateUninitalizedActivityInstance(Activity activity, System.Activities.ActivityInstance parent, CompletionBookmark completionBookmark, FaultBookmark faultBookmark)
        {
            System.Activities.ActivityInstance item = new System.Activities.ActivityInstance(activity);
            if (parent != null)
            {
                item.CompletionBookmark = completionBookmark;
                item.FaultBookmark = faultBookmark;
                parent.AddChild(item);
            }
            this.IncrementLastInstanceId();
            return item;
        }

        public void DebugActivityCompleted(System.Activities.ActivityInstance instance)
        {
            if (this.debugController != null)
            {
                this.debugController.ActivityCompleted(instance);
            }
        }

        internal void DisassociateKeys(ICollection<InstanceKey> keysToDisassociate)
        {
            this.host.OnDisassociateKeys(keysToDisassociate);
        }

        public void Dispose()
        {
            this.Dispose(true);
        }

        private void Dispose(bool aborting)
        {
            if (!this.isDisposed)
            {
                if (this.debugController != null)
                {
                    this.debugController.WorkflowCompleted();
                    this.debugController = null;
                }
                if ((this.activeOperations != null) && (this.activeOperations.Count > 0))
                {
                    this.Abort(new OperationCanceledException());
                }
                else
                {
                    this.scheduler.ClearAllWorkItems(this);
                    if (!aborting)
                    {
                        this.scheduler = null;
                        this.bookmarkManager = null;
                        this.lastInstanceId = 0L;
                        this.rootInstance = null;
                    }
                    this.isDisposed = true;
                }
            }
        }

        internal void EndAssociateKeys(IAsyncResult result)
        {
            AssociateKeysAsyncResult.End(result);
        }

        internal BookmarkResumptionResult EndResumeBookmark(IAsyncResult result) => 
            this.host.OnEndResumeBookmark(result);

        public void EndTrackPendingRecords(IAsyncResult result)
        {
            this.host.EndFlushTrackingRecordsInternal(result);
        }

        public void EnterNoPersist()
        {
            this.noPersistCount++;
            if (TD.EnterNoPersistBlockIsEnabled())
            {
                TD.EnterNoPersistBlock();
            }
        }

        public T ExecuteInResolutionContext<T>(System.Activities.ActivityInstance parentInstance, Activity<T> expressionActivity)
        {
            T local;
            if (this.cachedResolutionContext == null)
            {
                this.cachedResolutionContext = new CodeActivityContext(parentInstance, this);
            }
            this.cachedResolutionContext.Reinitialize(parentInstance, this, expressionActivity, parentInstance.InternalId);
            try
            {
                local = expressionActivity.InternalExecuteInResolutionContext(this.cachedResolutionContext);
            }
            finally
            {
                this.cachedResolutionContext.Dispose();
            }
            return local;
        }

        public void ExecuteInResolutionContextUntyped(System.Activities.ActivityInstance parentInstance, ActivityWithResult expressionActivity, long instanceId, System.Activities.Location resultLocation)
        {
            if (this.cachedResolutionContext == null)
            {
                this.cachedResolutionContext = new CodeActivityContext(parentInstance, this);
            }
            this.cachedResolutionContext.Reinitialize(parentInstance, this, expressionActivity, instanceId);
            try
            {
                this.ignorableResultLocation = resultLocation;
                resultLocation.Value = expressionActivity.InternalExecuteInResolutionContextUntyped(this.cachedResolutionContext);
            }
            finally
            {
                if (!expressionActivity.UseOldFastPath)
                {
                    this.cachedResolutionContext.DisposeDataContext();
                }
                this.cachedResolutionContext.Dispose();
                this.ignorableResultLocation = null;
            }
        }

        internal void ExecuteSynchronousWorkItem(System.Activities.Runtime.WorkItem workItem)
        {
            workItem.Release(this);
            try
            {
                Fx.AssertAndThrow(workItem.Execute(this, this.bookmarkManager), "Synchronous work item should not yield the scheduler");
            }
            finally
            {
                workItem.Dispose(this);
            }
        }

        public void ExitNoPersist()
        {
            this.noPersistCount--;
            if (TD.ExitNoPersistBlockIsEnabled())
            {
                TD.ExitNoPersistBlock();
            }
            if (this.shouldPauseOnCanPersist && this.IsPersistable)
            {
                this.scheduler.Pause();
            }
        }

        internal void ExitNoPersistForExceptionPropagation()
        {
            if (!this.PersistExceptions)
            {
                this.ExitNoPersist();
            }
        }

        internal void FinishWorkItem(System.Activities.Runtime.WorkItem workItem)
        {
            Scheduler.RequestedAction yieldSilently = Scheduler.Continue;
            try
            {
                if (workItem.WorkflowAbortException != null)
                {
                    this.AbortWorkflowInstance(new OperationCanceledException(System.Activities.SR.WorkItemAbortedInstance, workItem.WorkflowAbortException));
                }
                else
                {
                    workItem.PostProcess(this);
                    if (workItem.ExceptionToPropagate != null)
                    {
                        this.PropagateException(workItem);
                    }
                    if (this.HasPendingTrackingRecords && !workItem.FlushTracking(this))
                    {
                        yieldSilently = Scheduler.YieldSilently;
                        return;
                    }
                    if (workItem.WorkflowAbortException != null)
                    {
                        this.AbortWorkflowInstance(new OperationCanceledException(System.Activities.SR.TrackingRelatedWorkflowAbort, workItem.WorkflowAbortException));
                    }
                    else
                    {
                        this.ScheduleRuntimeWorkItems();
                        if (workItem.ExceptionToPropagate != null)
                        {
                            this.ExitNoPersistForExceptionPropagation();
                            yieldSilently = Scheduler.CreateNotifyUnhandledExceptionAction(workItem.ExceptionToPropagate, workItem.OriginalExceptionSource);
                        }
                    }
                }
            }
            finally
            {
                if (yieldSilently != Scheduler.YieldSilently)
                {
                    workItem.Dispose(this);
                }
            }
            this.scheduler.InternalResume(yieldSilently);
        }

        internal void FinishWorkItemAfterTracking(System.Activities.Runtime.WorkItem workItem)
        {
            Scheduler.RequestedAction action = Scheduler.Continue;
            try
            {
                if (workItem.WorkflowAbortException != null)
                {
                    this.AbortWorkflowInstance(new OperationCanceledException(System.Activities.SR.TrackingRelatedWorkflowAbort, workItem.WorkflowAbortException));
                }
                else
                {
                    this.ScheduleRuntimeWorkItems();
                    if (workItem.ExceptionToPropagate != null)
                    {
                        this.ExitNoPersistForExceptionPropagation();
                        action = Scheduler.CreateNotifyUnhandledExceptionAction(workItem.ExceptionToPropagate, workItem.OriginalExceptionSource);
                    }
                }
            }
            finally
            {
                workItem.Dispose(this);
            }
            this.scheduler.InternalResume(action);
        }

        internal IDictionary<string, LocationInfo> GatherMappableVariables()
        {
            if (this.mappableObjectManager != null)
            {
                return this.MappableObjectManager.GatherMappableVariables();
            }
            return null;
        }

        private void GatherRootOutputs()
        {
            if (this.rootInstance.State == ActivityInstanceState.Closed)
            {
                IList<RuntimeArgument> runtimeArguments = this.rootElement.RuntimeArguments;
                for (int i = 0; i < runtimeArguments.Count; i++)
                {
                    RuntimeArgument argument = runtimeArguments[i];
                    if (ArgumentDirectionHelper.IsOut(argument.Direction))
                    {
                        if (this.workflowOutputs == null)
                        {
                            this.workflowOutputs = new Dictionary<string, object>();
                        }
                        System.Activities.Location specificLocation = this.rootEnvironment.GetSpecificLocation(argument.BoundArgument.Id);
                        if (specificLocation == null)
                        {
                            throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.NoOutputLocationWasFound(argument.Name)));
                        }
                        this.workflowOutputs.Add(argument.Name, specificLocation.Value);
                    }
                }
            }
            this.rootEnvironment = null;
        }

        public IList<ActivityBlockingUpdate> GetActivitiesBlockingUpdate(DynamicUpdateMap updateMap)
        {
            Collection<ActivityBlockingUpdate> updateErrors = null;
            this.instanceMap.GetActivitiesBlockingUpdate(updateMap, this.executingSecondaryRootInstances, ref updateErrors);
            return updateErrors;
        }

        internal ReadOnlyCollection<BookmarkInfo> GetAllBookmarks()
        {
            List<BookmarkInfo> list = this.CollectExternalBookmarks();
            if (list != null)
            {
                return new ReadOnlyCollection<BookmarkInfo>(list);
            }
            return EmptyBookmarkInfoCollection;
        }

        internal ReadOnlyCollection<BookmarkInfo> GetBookmarks(BookmarkScope scope)
        {
            if (this.bookmarkScopeManager == null)
            {
                return EmptyBookmarkInfoCollection;
            }
            ReadOnlyCollection<BookmarkInfo> bookmarks = this.bookmarkScopeManager.GetBookmarks(scope);
            if (bookmarks == null)
            {
                return EmptyBookmarkInfoCollection;
            }
            return bookmarks;
        }

        public T GetExtension<T>() where T: class
        {
            T extension = default(T);
            try
            {
                extension = this.host.GetExtension<T>();
            }
            catch (Exception exception)
            {
                if (Fx.IsFatal(exception))
                {
                    throw;
                }
                throw System.Activities.FxTrace.Exception.AsError(new CallbackException(System.Activities.SR.CallbackExceptionFromHostGetExtension(this.WorkflowInstanceId), exception));
            }
            return extension;
        }

        internal System.Activities.Location GetIgnorableResultLocation(RuntimeArgument resultArgument) => 
            this.ignorableResultLocation;

        internal void HandleRootCompletion(System.Activities.ActivityInstance completedInstance)
        {
            if (completedInstance.Parent == null)
            {
                if (completedInstance == this.rootInstance)
                {
                    this.shouldRaiseMainBodyComplete = true;
                    this.executionState = this.rootInstance.State;
                    this.rootEnvironment = this.rootInstance.Environment;
                }
                else
                {
                    this.executingSecondaryRootInstances.Remove(completedInstance);
                }
                if (this.rootInstance.IsCompleted && ((this.executingSecondaryRootInstances == null) || (this.executingSecondaryRootInstances.Count == 0)))
                {
                    this.GatherRootOutputs();
                    if (this.rootPropertyManager != null)
                    {
                        HandleInitializationContext context = new HandleInitializationContext(this, null);
                        foreach (ExecutionPropertyManager.ExecutionProperty property in this.rootPropertyManager.Properties.Values)
                        {
                            Handle handle = property.Property as Handle;
                            if (handle != null)
                            {
                                handle.Uninitialize(context);
                            }
                        }
                        context.Dispose();
                        this.rootPropertyManager.UnregisterProperties(null, null);
                    }
                }
            }
        }

        private void IncrementLastInstanceId()
        {
            if (this.lastInstanceId == 0x7fffffffffffffffL)
            {
                throw System.Activities.FxTrace.Exception.AsError(new NotSupportedException(System.Activities.SR.OutOfInstanceIds));
            }
            this.lastInstanceId += 1L;
        }

        public bool IsCompletingTransaction(System.Activities.ActivityInstance instance)
        {
            if ((this.runtimeTransaction == null) || (this.runtimeTransaction.IsolationScope != instance))
            {
                return false;
            }
            this.scheduler.PushWork(this.CreateEmptyWorkItem(instance));
            this.runtimeTransaction.ShouldScheduleCompletion = true;
            if (TD.RuntimeTransactionCompletionRequestedIsEnabled())
            {
                TD.RuntimeTransactionCompletionRequested(instance.Activity.GetType().ToString(), instance.Activity.DisplayName, instance.Id);
            }
            return true;
        }

        private bool IsDebugged()
        {
            if ((this.debugController == null) && Debugger.IsAttached)
            {
                this.debugController = new DebugController(this.host);
            }
            return (this.debugController > null);
        }

        private bool IsSecondaryRoot(System.Activities.ActivityInstance instance) => 
            (instance.Parent == null) && (instance != this.rootInstance);

        public void MakeNonSerializable()
        {
            this.throwDuringSerialization = true;
        }

        public void MarkSchedulerRunning()
        {
            this.scheduler.MarkRunning();
        }

        internal void NotifyUnhandledException(Exception exception, System.Activities.ActivityInstance source)
        {
            try
            {
                this.host.NotifyUnhandledException(exception, source.Activity, source.Id);
            }
            catch (Exception exception2)
            {
                if (Fx.IsFatal(exception2))
                {
                    throw;
                }
                this.AbortWorkflowInstance(exception2);
            }
        }

        internal void OnDeserialized(Activity workflow, WorkflowInstance workflowInstance)
        {
            if (!Equals(workflowInstance.DefinitionIdentity, this.WorkflowIdentity))
            {
                throw System.Activities.FxTrace.Exception.AsError(new VersionMismatchException(workflowInstance.DefinitionIdentity, this.WorkflowIdentity));
            }
            this.rootElement = workflow;
            this.host = workflowInstance;
            if (!this.instanceIdSet)
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.EmptyGuidOnDeserializedInstance));
            }
            if (this.host.Id != this.instanceId)
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.HostIdDoesNotMatchInstance(this.host.Id, this.instanceId)));
            }
            if (this.host.HasTrackingParticipant)
            {
                this.host.TrackingProvider.OnDeserialized(this.nextTrackingRecordNumber);
                this.host.OnDeserialized(this.hasTrackedStarted);
            }
            if (this.scheduler != null)
            {
                this.scheduler.OnDeserialized(new Scheduler.Callbacks(this));
            }
            if (this.rootInstance != null)
            {
                this.instanceMap.LoadActivityTree(workflow, this.rootInstance, this.executingSecondaryRootInstances, this);
                if (this.executingSecondaryRootInstances != null)
                {
                    for (int i = 0; i < this.executingSecondaryRootInstances.Count; i++)
                    {
                        System.Activities.ActivityInstance handleScope = this.executingSecondaryRootInstances[i];
                        LocationEnvironment parent = handleScope.Environment.Parent;
                        if (parent != null)
                        {
                            parent.OnDeserialized(this, handleScope);
                        }
                    }
                }
            }
            else
            {
                this.isDisposed = true;
            }
        }

        internal Scheduler.RequestedAction OnExecuteWorkItem(System.Activities.Runtime.WorkItem workItem)
        {
            workItem.Release(this);
            if (workItem.IsValid)
            {
                if (!workItem.IsEmpty)
                {
                    Scheduler.RequestedAction action = this.TryExecuteNonEmptyWorkItem(workItem);
                    if (action != null)
                    {
                        return action;
                    }
                }
                if (workItem.WorkflowAbortException != null)
                {
                    this.AbortWorkflowInstance(new OperationCanceledException(System.Activities.SR.WorkItemAbortedInstance, workItem.WorkflowAbortException));
                    return Scheduler.Continue;
                }
                if ((this.bookmarkScopeManager != null) && this.bookmarkScopeManager.HasKeysToUpdate)
                {
                    if (!workItem.FlushBookmarkScopeKeys(this))
                    {
                        return Scheduler.YieldSilently;
                    }
                    if (workItem.WorkflowAbortException != null)
                    {
                        this.AbortWorkflowInstance(new OperationCanceledException(System.Activities.SR.WorkItemAbortedInstance, workItem.WorkflowAbortException));
                        return Scheduler.Continue;
                    }
                }
                workItem.PostProcess(this);
                if (workItem.ExceptionToPropagate != null)
                {
                    this.PropagateException(workItem);
                }
                if (this.HasPendingTrackingRecords)
                {
                    if (!workItem.FlushTracking(this))
                    {
                        return Scheduler.YieldSilently;
                    }
                    if (workItem.WorkflowAbortException != null)
                    {
                        this.AbortWorkflowInstance(new OperationCanceledException(System.Activities.SR.TrackingRelatedWorkflowAbort, workItem.WorkflowAbortException));
                        return Scheduler.Continue;
                    }
                }
                this.ScheduleRuntimeWorkItems();
                if (workItem.ExceptionToPropagate != null)
                {
                    this.ExitNoPersistForExceptionPropagation();
                    return Scheduler.CreateNotifyUnhandledExceptionAction(workItem.ExceptionToPropagate, workItem.OriginalExceptionSource);
                }
            }
            return Scheduler.Continue;
        }

        internal void OnSchedulerIdle()
        {
            if (this.isTerminatePending)
            {
                this.Terminate(this.terminationPendingException);
                this.isTerminatePending = false;
            }
            if (this.IsIdle)
            {
                if (((this.transactionContextWaiters != null) && (this.transactionContextWaiters.Count > 0)) && (this.IsPersistable || (this.transactionContextWaiters[0].IsRequires && (this.noPersistCount == 1))))
                {
                    TransactionContextWaiter waiter = this.transactionContextWaiters.Dequeue();
                    waiter.WaitingInstance.DecrementBusyCount();
                    waiter.WaitingInstance.WaitingForTransactionContext = false;
                    this.ScheduleItem(new TransactionContextWorkItem(waiter));
                    this.MarkSchedulerRunning();
                    this.ResumeScheduler();
                    return;
                }
                if (this.shouldRaiseMainBodyComplete)
                {
                    this.shouldRaiseMainBodyComplete = false;
                    if (this.mainRootCompleteBookmark != null)
                    {
                        BookmarkResumptionResult result = this.TryResumeUserBookmark(this.mainRootCompleteBookmark, this.rootInstance.State, false);
                        this.mainRootCompleteBookmark = null;
                        if (result == BookmarkResumptionResult.Success)
                        {
                            this.MarkSchedulerRunning();
                            this.ResumeScheduler();
                            return;
                        }
                    }
                    if ((this.executingSecondaryRootInstances == null) || (this.executingSecondaryRootInstances.Count == 0))
                    {
                        this.Dispose(false);
                    }
                }
            }
            if (this.shouldPauseOnCanPersist && this.IsPersistable)
            {
                this.shouldPauseOnCanPersist = false;
            }
            try
            {
                this.host.NotifyPaused();
            }
            catch (Exception exception)
            {
                if (Fx.IsFatal(exception))
                {
                    throw;
                }
                this.AbortWorkflowInstance(exception);
            }
        }

        internal void OnSchedulerThreadAcquired()
        {
            if (this.IsDebugged() && !this.hasRaisedWorkflowStarted)
            {
                this.hasRaisedWorkflowStarted = true;
                this.debugController.WorkflowStarted();
            }
        }

        public void Open(SynchronizationContext synchronizationContext)
        {
            this.scheduler.Open(synchronizationContext);
        }

        public void PauseScheduler()
        {
            Scheduler scheduler = this.scheduler;
            if (scheduler != null)
            {
                scheduler.Pause();
            }
        }

        public void PauseWhenPersistable()
        {
            this.shouldPauseOnCanPersist = true;
        }

        public object PrepareForSerialization()
        {
            if (this.host.HasTrackingParticipant)
            {
                this.nextTrackingRecordNumber = this.host.TrackingProvider.NextTrackingRecordNumber;
                this.hasTrackedStarted = this.host.HasTrackedStarted;
            }
            return this;
        }

        private void PropagateException(System.Activities.Runtime.WorkItem workItem)
        {
            System.Activities.ActivityInstance activityInstance = workItem.ActivityInstance;
            Exception exceptionToPropagate = workItem.ExceptionToPropagate;
            System.Activities.ActivityInstance parent = activityInstance;
            FaultBookmark faultBookmark = null;
            if (!this.PersistExceptions)
            {
                this.EnterNoPersist();
            }
            while ((parent != null) && (faultBookmark == null))
            {
                if ((!parent.IsCompleted && (this.runtimeTransaction != null)) && (this.runtimeTransaction.IsolationScope == parent))
                {
                    this.scheduler.PushWork(new AbortActivityWorkItem(this, parent, exceptionToPropagate, this.CreateActivityInstanceReference(workItem.OriginalExceptionSource, parent)));
                    this.runtimeTransaction.ShouldScheduleCompletion = false;
                    workItem.ExceptionPropagated();
                    return;
                }
                if (parent.IsCancellationRequested)
                {
                    if (System.Activities.LocalAppContextSwitches.TerminateOnUnhandledExceptionDuringCancel)
                    {
                        this.Terminate(new InvalidOperationException(System.Activities.SR.CannotPropagateExceptionWhileCanceling(activityInstance.Activity.DisplayName, activityInstance.Id), exceptionToPropagate));
                    }
                    else
                    {
                        this.AbortWorkflowInstance(new InvalidOperationException(System.Activities.SR.CannotPropagateExceptionWhileCanceling(activityInstance.Activity.DisplayName, activityInstance.Id), exceptionToPropagate));
                    }
                    workItem.ExceptionPropagated();
                    this.ExitNoPersistForExceptionPropagation();
                    return;
                }
                if (parent.FaultBookmark != null)
                {
                    faultBookmark = parent.FaultBookmark;
                }
                else
                {
                    parent = parent.Parent;
                }
            }
            if (faultBookmark != null)
            {
                if (this.ShouldTrackFaultPropagationRecords)
                {
                    this.AddTrackingRecord(new FaultPropagationRecord(this.WorkflowInstanceId, workItem.OriginalExceptionSource, parent.Parent, activityInstance == workItem.OriginalExceptionSource, exceptionToPropagate));
                }
                this.scheduler.PushWork(faultBookmark.GenerateWorkItem(exceptionToPropagate, parent, this.CreateActivityInstanceReference(workItem.OriginalExceptionSource, parent.Parent)));
                workItem.ExceptionPropagated();
            }
            else if (this.ShouldTrackFaultPropagationRecords)
            {
                this.AddTrackingRecord(new FaultPropagationRecord(this.WorkflowInstanceId, workItem.OriginalExceptionSource, null, activityInstance == workItem.OriginalExceptionSource, exceptionToPropagate));
            }
        }

        public void RegisterMainRootCompleteCallback(Bookmark bookmark)
        {
            this.mainRootCompleteBookmark = bookmark;
        }

        public void RequestPersist(Bookmark onPersistBookmark, System.Activities.ActivityInstance requestingInstance)
        {
            if (this.persistenceWaiters == null)
            {
                this.persistenceWaiters = new Queue<PersistenceWaiter>();
            }
            this.persistenceWaiters.Enqueue(new PersistenceWaiter(onPersistBookmark, requestingInstance));
        }

        public void RequestTransactionContext(System.Activities.ActivityInstance instance, bool isRequires, RuntimeTransactionHandle handle, Action<NativeActivityTransactionContext, object> callback, object state)
        {
            if (isRequires)
            {
                this.EnterNoPersist();
            }
            if (this.transactionContextWaiters == null)
            {
                this.transactionContextWaiters = new Quack<TransactionContextWaiter>();
            }
            TransactionContextWaiter item = new TransactionContextWaiter(instance, isRequires, handle, new TransactionContextWaiterCallbackWrapper(callback, instance), state);
            if (isRequires)
            {
                this.transactionContextWaiters.PushFront(item);
            }
            else
            {
                this.transactionContextWaiters.Enqueue(item);
            }
            instance.IncrementBusyCount();
            instance.WaitingForTransactionContext = true;
        }

        private void ResumeScheduler()
        {
            this.scheduler.Resume();
        }

        internal void RethrowException(System.Activities.ActivityInstance fromInstance, FaultContext context)
        {
            this.scheduler.PushWork(new RethrowExceptionWorkItem(fromInstance, context.Exception, context.Source));
        }

        public void Run()
        {
            this.ResumeScheduler();
        }

        public System.Activities.ActivityInstance ScheduleActivity(Activity activity, System.Activities.ActivityInstance parent, CompletionBookmark completionBookmark, FaultBookmark faultBookmark, LocationEnvironment parentEnvironment) => 
            this.ScheduleActivity(activity, parent, completionBookmark, faultBookmark, parentEnvironment, null, null);

        private System.Activities.ActivityInstance ScheduleActivity(Activity activity, System.Activities.ActivityInstance parent, CompletionBookmark completionBookmark, FaultBookmark faultBookmark, LocationEnvironment parentEnvironment, IDictionary<string, object> argumentValueOverrides, System.Activities.Location resultLocation)
        {
            System.Activities.ActivityInstance child = this.CreateUninitalizedActivityInstance(activity, parent, completionBookmark, faultBookmark);
            bool requiresSymbolResolution = child.Initialize(parent, this.instanceMap, parentEnvironment, this.lastInstanceId, this);
            if (TD.ActivityScheduledIsEnabled())
            {
                this.TraceActivityScheduled(parent, activity, child.Id);
            }
            if (this.ShouldTrackActivityScheduledRecords)
            {
                this.AddTrackingRecord(new ActivityScheduledRecord(this.WorkflowInstanceId, parent, child));
            }
            this.ScheduleBody(child, requiresSymbolResolution, argumentValueOverrides, resultLocation);
            return child;
        }

        internal void ScheduleBody(System.Activities.ActivityInstance activityInstance, bool requiresSymbolResolution, IDictionary<string, object> argumentValueOverrides, System.Activities.Location resultLocation)
        {
            if (resultLocation == null)
            {
                ExecuteActivityWorkItem workItem = this.ExecuteActivityWorkItemPool.Acquire();
                workItem.Initialize(activityInstance, requiresSymbolResolution, argumentValueOverrides);
                this.scheduler.PushWork(workItem);
            }
            else
            {
                this.scheduler.PushWork(new ExecuteExpressionWorkItem(activityInstance, requiresSymbolResolution, argumentValueOverrides, resultLocation));
            }
        }

        private void ScheduleCompletionBookmark(System.Activities.ActivityInstance completedInstance)
        {
            if (completedInstance.CompletionBookmark != null)
            {
                this.scheduler.PushWork(completedInstance.CompletionBookmark.GenerateWorkItem(completedInstance, this));
            }
            else if (completedInstance.Parent != null)
            {
                if ((completedInstance.State != ActivityInstanceState.Closed) && completedInstance.Parent.HasNotExecuted)
                {
                    completedInstance.Parent.SetInitializationIncomplete();
                }
                this.scheduler.PushWork(this.CreateEmptyWorkItem(completedInstance.Parent));
            }
        }

        public System.Activities.ActivityInstance ScheduleDelegate(ActivityDelegate activityDelegate, IDictionary<string, object> inputParameters, System.Activities.ActivityInstance parent, LocationEnvironment executionEnvironment, CompletionBookmark completionBookmark, FaultBookmark faultBookmark)
        {
            System.Activities.ActivityInstance instance;
            if (activityDelegate.Handler == null)
            {
                instance = System.Activities.ActivityInstance.CreateCompletedInstance(new EmptyDelegateActivity());
                instance.CompletionBookmark = completionBookmark;
                this.ScheduleCompletionBookmark(instance);
                return instance;
            }
            instance = this.CreateUninitalizedActivityInstance(activityDelegate.Handler, parent, completionBookmark, faultBookmark);
            bool requiresSymbolResolution = instance.Initialize(parent, this.instanceMap, executionEnvironment, this.lastInstanceId, this, activityDelegate.RuntimeDelegateArguments.Count);
            IList<RuntimeDelegateArgument> runtimeDelegateArguments = activityDelegate.RuntimeDelegateArguments;
            for (int i = 0; i < runtimeDelegateArguments.Count; i++)
            {
                RuntimeDelegateArgument argument = runtimeDelegateArguments[i];
                if (argument.BoundArgument != null)
                {
                    string name = argument.Name;
                    System.Activities.Location location = argument.BoundArgument.CreateLocation();
                    instance.Environment.Declare(argument.BoundArgument, location, instance);
                    if ((ArgumentDirectionHelper.IsIn(argument.Direction) && (inputParameters != null)) && (inputParameters.Count > 0))
                    {
                        location.Value = inputParameters[name];
                    }
                }
            }
            if (TD.ActivityScheduledIsEnabled())
            {
                this.TraceActivityScheduled(parent, activityDelegate.Handler, instance.Id);
            }
            if (this.ShouldTrackActivityScheduledRecords)
            {
                this.AddTrackingRecord(new ActivityScheduledRecord(this.WorkflowInstanceId, parent, instance));
            }
            this.ScheduleBody(instance, requiresSymbolResolution, null, null);
            return instance;
        }

        private void ScheduleExpression(ActivityWithResult activity, System.Activities.ActivityInstance parent, System.Activities.Location resultLocation, ResolveNextArgumentWorkItem nextArgumentWorkItem, long instanceId)
        {
            if (TD.ActivityScheduledIsEnabled())
            {
                this.TraceActivityScheduled(parent, activity, instanceId.ToString(CultureInfo.InvariantCulture));
            }
            if (this.ShouldTrackActivityScheduledRecords)
            {
                this.AddTrackingRecord(new ActivityScheduledRecord(this.WorkflowInstanceId, parent, new ActivityInfo(activity, instanceId)));
            }
            ExecuteSynchronousExpressionWorkItem reference = this.ExecuteSynchronousExpressionWorkItemPool.Acquire();
            reference.Initialize(parent, activity, this.lastInstanceId, resultLocation, nextArgumentWorkItem);
            if (this.instanceMap != null)
            {
                this.instanceMap.AddEntry(reference);
            }
            this.ScheduleItem(reference);
        }

        internal void ScheduleExpression(ActivityWithResult activity, System.Activities.ActivityInstance parent, LocationEnvironment parentEnvironment, System.Activities.Location resultLocation, ResolveNextArgumentWorkItem nextArgumentWorkItem)
        {
            if (!activity.IsMetadataCached || (activity.CacheId != parent.Activity.CacheId))
            {
                throw System.Activities.FxTrace.Exception.Argument("activity", System.Activities.SR.ActivityNotPartOfThisTree(activity.DisplayName, parent.Activity.DisplayName));
            }
            if (activity.SkipArgumentResolution)
            {
                this.IncrementLastInstanceId();
                this.ScheduleExpression(activity, parent, resultLocation, nextArgumentWorkItem, this.lastInstanceId);
            }
            else
            {
                if (nextArgumentWorkItem != null)
                {
                    this.ScheduleItem(nextArgumentWorkItem);
                }
                this.ScheduleActivity(activity, parent, null, null, parentEnvironment, null, resultLocation.CreateReference(true));
            }
        }

        internal void ScheduleExpressionFaultPropagation(Activity activity, long instanceId, System.Activities.ActivityInstance parent, Exception exception)
        {
            System.Activities.ActivityInstance activityInstance = new System.Activities.ActivityInstance(activity);
            activityInstance.Initialize(parent, this.instanceMap, parent.Environment, instanceId, this);
            if (!parent.HasPendingWork)
            {
                this.ScheduleItem(this.CreateEmptyWorkItem(parent));
            }
            PropagateExceptionWorkItem workItem = new PropagateExceptionWorkItem(exception, activityInstance);
            this.ScheduleItem(workItem);
            parent.SetInitializationIncomplete();
        }

        internal void ScheduleItem(System.Activities.Runtime.WorkItem workItem)
        {
            this.scheduler.PushWork(workItem);
        }

        private void SchedulePendingCancelation()
        {
            if (this.runtimeTransaction.IsRootCancelPending)
            {
                if (!this.rootInstance.IsCancellationRequested && !this.rootInstance.IsCompleted)
                {
                    this.rootInstance.IsCancellationRequested = true;
                    this.scheduler.PushWork(new CancelActivityWorkItem(this.rootInstance));
                }
                this.runtimeTransaction.IsRootCancelPending = false;
            }
        }

        public void ScheduleRootActivity(Activity activity, IDictionary<string, object> argumentValueOverrides, IList<Handle> hostProperties)
        {
            if ((hostProperties != null) && (hostProperties.Count > 0))
            {
                Dictionary<string, ExecutionPropertyManager.ExecutionProperty> properties = new Dictionary<string, ExecutionPropertyManager.ExecutionProperty>(hostProperties.Count);
                HandleInitializationContext context = new HandleInitializationContext(this, null);
                for (int i = 0; i < hostProperties.Count; i++)
                {
                    Handle property = hostProperties[i];
                    property.Initialize(context);
                    properties.Add(property.ExecutionPropertyName, new ExecutionPropertyManager.ExecutionProperty(property.ExecutionPropertyName, property, null));
                }
                context.Dispose();
                this.rootPropertyManager = new ExecutionPropertyManager(null, properties);
            }
            bool hasBeenResumed = this.TryTraceStart(out Guid guid);
            System.Activities.ActivityInstance instance1 = new System.Activities.ActivityInstance(activity) {
                PropertyManager = this.rootPropertyManager
            };
            this.rootInstance = instance1;
            this.rootElement = activity;
            this.lastInstanceId += 1L;
            bool requiresSymbolResolution = this.rootInstance.Initialize(null, this.instanceMap, null, this.lastInstanceId, this);
            if (TD.ActivityScheduledIsEnabled())
            {
                this.TraceActivityScheduled(null, activity, this.rootInstance.Id);
            }
            this.scheduler.PushWork(new ExecuteRootWorkItem(this.rootInstance, requiresSymbolResolution, argumentValueOverrides));
            this.TraceSuspend(hasBeenResumed, guid);
        }

        private void ScheduleRuntimeWorkItems()
        {
            if ((this.runtimeTransaction != null) && this.runtimeTransaction.ShouldScheduleCompletion)
            {
                this.scheduler.PushWork(new CompleteTransactionWorkItem(this.runtimeTransaction.IsolationScope));
            }
            else if (((this.persistenceWaiters != null) && (this.persistenceWaiters.Count > 0)) && this.IsPersistable)
            {
                PersistenceWaiter waiter = this.persistenceWaiters.Dequeue();
                while ((waiter != null) && waiter.WaitingInstance.IsCompleted)
                {
                    if (this.persistenceWaiters.Count == 0)
                    {
                        waiter = null;
                    }
                    else
                    {
                        waiter = this.persistenceWaiters.Dequeue();
                    }
                }
                if (waiter != null)
                {
                    this.scheduler.PushWork(waiter.CreateWorkItem());
                }
            }
        }

        public System.Activities.ActivityInstance ScheduleSecondaryRootActivity(Activity activity, LocationEnvironment environment)
        {
            System.Activities.ActivityInstance item = this.ScheduleActivity(activity, null, null, null, environment);
            while (environment != null)
            {
                environment.AddReference();
                environment = environment.Parent;
            }
            if (this.executingSecondaryRootInstances == null)
            {
                this.executingSecondaryRootInstances = new List<System.Activities.ActivityInstance>();
            }
            this.executingSecondaryRootInstances.Add(item);
            return item;
        }

        public void ScheduleTerminate(Exception reason)
        {
            this.isTerminatePending = true;
            this.terminationPendingException = reason;
        }

        public void SetTransaction(RuntimeTransactionHandle handle, Transaction transaction, System.Activities.ActivityInstance isolationScope, System.Activities.ActivityInstance transactionOwner)
        {
            this.runtimeTransaction = new RuntimeTransactionData(handle, transaction, isolationScope);
            this.EnterNoPersist();
            if (transactionOwner != null)
            {
                Exception reason = null;
                try
                {
                    transaction.EnlistVolatile(this, EnlistmentOptions.EnlistDuringPrepareRequired);
                }
                catch (Exception exception2)
                {
                    if (Fx.IsFatal(exception2))
                    {
                        throw;
                    }
                    reason = exception2;
                }
                if (reason != null)
                {
                    this.AbortWorkflowInstance(reason);
                }
                else if (TD.RuntimeTransactionSetIsEnabled())
                {
                    TD.RuntimeTransactionSet(transactionOwner.Activity.GetType().ToString(), transactionOwner.Activity.DisplayName, transactionOwner.Id, isolationScope.Activity.GetType().ToString(), isolationScope.Activity.DisplayName, isolationScope.Id);
                }
            }
        }

        public AsyncOperationContext SetupAsyncOperationBlock(System.Activities.ActivityInstance owningActivity)
        {
            if ((this.activeOperations != null) && this.activeOperations.ContainsKey(owningActivity))
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.OnlyOneOperationPerActivity));
            }
            this.EnterNoPersist();
            AsyncOperationContext context = new AsyncOperationContext(this, owningActivity);
            if (this.activeOperations == null)
            {
                this.activeOperations = new Dictionary<System.Activities.ActivityInstance, AsyncOperationContext>();
            }
            this.activeOperations.Add(owningActivity, context);
            return context;
        }

        public bool ShouldTrackActivity(string name) => 
            this.host.TrackingProvider.ShouldTrackActivity(name);

        void IEnlistmentNotification.Commit(Enlistment enlistment)
        {
            RuntimeTransactionData runtimeTransaction = this.runtimeTransaction;
            if (runtimeTransaction != null)
            {
                AsyncWaitHandle completionEvent = null;
                RuntimeTransactionData data2 = runtimeTransaction;
                lock (data2)
                {
                    completionEvent = runtimeTransaction.CompletionEvent;
                    runtimeTransaction.TransactionStatus = TransactionStatus.Committed;
                }
                enlistment.Done();
                if (completionEvent != null)
                {
                    completionEvent.Set();
                }
            }
            else
            {
                enlistment.Done();
            }
        }

        void IEnlistmentNotification.InDoubt(Enlistment enlistment)
        {
            ((IEnlistmentNotification) this).Rollback(enlistment);
        }

        void IEnlistmentNotification.Prepare(PreparingEnlistment preparingEnlistment)
        {
            RuntimeTransactionData runtimeTransaction = this.runtimeTransaction;
            if (runtimeTransaction != null)
            {
                bool flag = false;
                RuntimeTransactionData data2 = runtimeTransaction;
                lock (data2)
                {
                    if (runtimeTransaction.HasPrepared)
                    {
                        flag = true;
                    }
                    else
                    {
                        runtimeTransaction.PendingPreparingEnlistment = preparingEnlistment;
                    }
                }
                if (flag)
                {
                    preparingEnlistment.Prepared();
                }
            }
            else
            {
                preparingEnlistment.Prepared();
            }
        }

        void IEnlistmentNotification.Rollback(Enlistment enlistment)
        {
            RuntimeTransactionData runtimeTransaction = this.runtimeTransaction;
            if (runtimeTransaction != null)
            {
                AsyncWaitHandle completionEvent = null;
                RuntimeTransactionData data2 = runtimeTransaction;
                lock (data2)
                {
                    completionEvent = runtimeTransaction.CompletionEvent;
                    runtimeTransaction.TransactionStatus = TransactionStatus.Aborted;
                }
                enlistment.Done();
                if (completionEvent != null)
                {
                    completionEvent.Set();
                }
            }
            else
            {
                enlistment.Done();
            }
        }

        public void Terminate(Exception reason)
        {
            bool hasBeenResumed = this.TryTraceResume(out Guid guid);
            this.Abort(reason, true);
            this.TraceSuspend(hasBeenResumed, guid);
        }

        public void TerminateSpecialExecutionBlocks(System.Activities.ActivityInstance terminatedInstance, Exception terminationReason)
        {
            if ((this.runtimeTransaction != null) && (this.runtimeTransaction.IsolationScope == terminatedInstance))
            {
                Exception reason = null;
                try
                {
                    this.runtimeTransaction.Rollback(terminationReason);
                }
                catch (Exception exception2)
                {
                    if (Fx.IsFatal(exception2))
                    {
                        throw;
                    }
                    reason = exception2;
                }
                if (reason != null)
                {
                    this.AbortWorkflowInstance(reason);
                }
                this.SchedulePendingCancelation();
                this.ExitNoPersist();
                if (this.runtimeTransaction.TransactionHandle.AbortInstanceOnTransactionFailure)
                {
                    this.AbortWorkflowInstance(terminationReason);
                }
                this.runtimeTransaction = null;
            }
        }

        public void ThrowIfNonSerializable()
        {
            if (this.throwDuringSerialization)
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.StateCannotBeSerialized(this.WorkflowInstanceId)));
            }
        }

        private void TraceActivityScheduled(System.Activities.ActivityInstance parent, Activity activity, string scheduledInstanceId)
        {
            if (parent != null)
            {
                TD.ActivityScheduled(parent.Activity.GetType().ToString(), parent.Activity.DisplayName, parent.Id, activity.GetType().ToString(), activity.DisplayName, scheduledInstanceId);
            }
            else
            {
                TD.ActivityScheduled(string.Empty, string.Empty, string.Empty, activity.GetType().ToString(), activity.DisplayName, scheduledInstanceId);
            }
        }

        private void TraceSuspend(bool hasBeenResumed, Guid oldActivityId)
        {
            if (hasBeenResumed)
            {
                if (TD.WorkflowActivitySuspendIsEnabled())
                {
                    TD.WorkflowActivitySuspend(this.WorkflowInstanceId);
                }
                DiagnosticTraceBase.ActivityId = oldActivityId;
            }
        }

        internal Scheduler.RequestedAction TryExecuteNonEmptyWorkItem(System.Activities.Runtime.WorkItem workItem)
        {
            Exception abortException = null;
            System.Activities.ActivityInstance propertyManagerOwner = workItem.PropertyManagerOwner;
            try
            {
                if ((propertyManagerOwner != null) && (propertyManagerOwner.PropertyManager != null))
                {
                    try
                    {
                        propertyManagerOwner.PropertyManager.SetupWorkflowThread();
                    }
                    catch (Exception exception2)
                    {
                        if (Fx.IsFatal(exception2))
                        {
                            throw;
                        }
                        abortException = exception2;
                    }
                }
                if ((abortException == null) && !workItem.Execute(this, this.bookmarkManager))
                {
                    return Scheduler.YieldSilently;
                }
            }
            finally
            {
                if ((propertyManagerOwner != null) && (propertyManagerOwner.PropertyManager != null))
                {
                    propertyManagerOwner.PropertyManager.CleanupWorkflowThread(ref abortException);
                }
                if (abortException != null)
                {
                    this.AbortWorkflowInstance(new OperationCanceledException(System.Activities.SR.SetupOrCleanupWorkflowThreadThrew, abortException));
                }
            }
            if (abortException != null)
            {
                return Scheduler.Continue;
            }
            return null;
        }

        internal bool TryGetPendingOperation(System.Activities.ActivityInstance instance, out AsyncOperationContext asyncContext)
        {
            if (this.activeOperations != null)
            {
                return this.activeOperations.TryGetValue(instance, out asyncContext);
            }
            asyncContext = null;
            return false;
        }

        internal BookmarkResumptionResult TryResumeBookmark(Bookmark bookmark, object value, BookmarkScope scope)
        {
            bool hasBeenResumed = this.TryTraceResume(out Guid guid);
            System.Activities.ActivityInstance isolationInstance = null;
            if (this.runtimeTransaction != null)
            {
                isolationInstance = this.runtimeTransaction.IsolationScope;
            }
            bool flag2 = (this.activeOperations != null) && (this.activeOperations.Count > 0);
            BookmarkResumptionResult result = this.BookmarkScopeManager.TryGenerateWorkItem(this, ref bookmark, scope, value, isolationInstance, flag2 || this.bookmarkManager.HasBookmarks, out ActivityExecutionWorkItem item);
            if (result == BookmarkResumptionResult.Success)
            {
                this.scheduler.EnqueueWork(item);
                if (this.ShouldTrackBookmarkResumptionRecords)
                {
                    this.AddTrackingRecord(new BookmarkResumptionRecord(this.WorkflowInstanceId, bookmark, item.ActivityInstance, value));
                }
            }
            this.TraceSuspend(hasBeenResumed, guid);
            return result;
        }

        internal BookmarkResumptionResult TryResumeHostBookmark(Bookmark bookmark, object value)
        {
            bool hasBeenResumed = this.TryTraceResume(out Guid guid);
            BookmarkResumptionResult result = this.TryResumeUserBookmark(bookmark, value, true);
            this.TraceSuspend(hasBeenResumed, guid);
            return result;
        }

        internal BookmarkResumptionResult TryResumeUserBookmark(Bookmark bookmark, object value, bool isExternal)
        {
            if (this.isDisposed)
            {
                return BookmarkResumptionResult.NotFound;
            }
            System.Activities.ActivityInstance isolationInstance = null;
            if (this.runtimeTransaction != null)
            {
                isolationInstance = this.runtimeTransaction.IsolationScope;
            }
            BookmarkResumptionResult success = this.bookmarkManager.TryGenerateWorkItem(this, isExternal, ref bookmark, value, isolationInstance, out ActivityExecutionWorkItem item);
            if (success == BookmarkResumptionResult.Success)
            {
                this.scheduler.EnqueueWork(item);
                if (this.ShouldTrackBookmarkResumptionRecords)
                {
                    this.AddTrackingRecord(new BookmarkResumptionRecord(this.WorkflowInstanceId, bookmark, item.ActivityInstance, value));
                }
                return success;
            }
            if ((success != BookmarkResumptionResult.NotReady) && (bookmark == Bookmark.AsyncOperationCompletionBookmark))
            {
                ((AsyncOperationContext.CompleteData) value).CompleteOperation();
                success = BookmarkResumptionResult.Success;
            }
            return success;
        }

        private bool TryTraceResume(out Guid oldActivityId)
        {
            if (System.Activities.FxTrace.Trace.ShouldTraceToTraceSource(TraceEventLevel.Informational))
            {
                oldActivityId = DiagnosticTraceBase.ActivityId;
                System.Activities.FxTrace.Trace.SetAndTraceTransfer(this.WorkflowInstanceId, true);
                if (TD.WorkflowActivityResumeIsEnabled())
                {
                    TD.WorkflowActivityResume(this.WorkflowInstanceId);
                }
                return true;
            }
            oldActivityId = Guid.Empty;
            return false;
        }

        private bool TryTraceStart(out Guid oldActivityId)
        {
            if (System.Activities.FxTrace.Trace.ShouldTraceToTraceSource(TraceEventLevel.Informational))
            {
                oldActivityId = DiagnosticTraceBase.ActivityId;
                System.Activities.FxTrace.Trace.SetAndTraceTransfer(this.WorkflowInstanceId, true);
                if (TD.WorkflowActivityStartIsEnabled())
                {
                    TD.WorkflowActivityStart(this.WorkflowInstanceId);
                }
                return true;
            }
            oldActivityId = Guid.Empty;
            return false;
        }

        public void UpdateInstancePhase1(DynamicUpdateMap updateMap, Activity targetDefinition, ref Collection<ActivityBlockingUpdate> updateErrors)
        {
            this.instanceMap.UpdateRawInstance(updateMap, targetDefinition, this.executingSecondaryRootInstances, ref updateErrors);
        }

        public void UpdateInstancePhase2(DynamicUpdateMap updateMap, ref Collection<ActivityBlockingUpdate> updateErrors)
        {
            this.instanceMap.UpdateInstanceByActivityParticipation(this, updateMap, ref updateErrors);
        }

        public Pool<EmptyWorkItem> EmptyWorkItemPool
        {
            get
            {
                if (this.emptyWorkItemPool == null)
                {
                    this.emptyWorkItemPool = new PoolOfEmptyWorkItems();
                }
                return this.emptyWorkItemPool;
            }
        }

        private Pool<ExecuteActivityWorkItem> ExecuteActivityWorkItemPool
        {
            get
            {
                if (this.executeActivityWorkItemPool == null)
                {
                    this.executeActivityWorkItemPool = new PoolOfExecuteActivityWorkItems();
                }
                return this.executeActivityWorkItemPool;
            }
        }

        public Pool<ExecuteSynchronousExpressionWorkItem> ExecuteSynchronousExpressionWorkItemPool
        {
            get
            {
                if (this.executeSynchronousExpressionWorkItemPool == null)
                {
                    this.executeSynchronousExpressionWorkItemPool = new PoolOfExecuteSynchronousExpressionWorkItems();
                }
                return this.executeSynchronousExpressionWorkItemPool;
            }
        }

        public Pool<CompletionCallbackWrapper.CompletionWorkItem> CompletionWorkItemPool
        {
            get
            {
                if (this.completionWorkItemPool == null)
                {
                    this.completionWorkItemPool = new PoolOfCompletionWorkItems();
                }
                return this.completionWorkItemPool;
            }
        }

        public Pool<CodeActivityContext> CodeActivityContextPool
        {
            get
            {
                if (this.codeActivityContextPool == null)
                {
                    this.codeActivityContextPool = new PoolOfCodeActivityContexts();
                }
                return this.codeActivityContextPool;
            }
        }

        public Pool<NativeActivityContext> NativeActivityContextPool
        {
            get
            {
                if (this.nativeActivityContextPool == null)
                {
                    this.nativeActivityContextPool = new PoolOfNativeActivityContexts();
                }
                return this.nativeActivityContextPool;
            }
        }

        public Pool<ResolveNextArgumentWorkItem> ResolveNextArgumentWorkItemPool
        {
            get
            {
                if (this.resolveNextArgumentWorkItemPool == null)
                {
                    this.resolveNextArgumentWorkItemPool = new PoolOfResolveNextArgumentWorkItems();
                }
                return this.resolveNextArgumentWorkItemPool;
            }
        }

        public Activity RootActivity =>
            this.rootElement;

        public bool IsInitialized =>
            this.host > null;

        public bool HasPendingTrackingRecords =>
            this.host.HasTrackingParticipant && this.host.TrackingProvider.HasPendingRecords;

        public bool ShouldTrack =>
            this.host.HasTrackingParticipant && this.host.TrackingProvider.ShouldTrack;

        public bool ShouldTrackBookmarkResumptionRecords =>
            this.host.HasTrackingParticipant && this.host.TrackingProvider.ShouldTrackBookmarkResumptionRecords;

        public bool ShouldTrackActivityScheduledRecords =>
            this.host.HasTrackingParticipant && this.host.TrackingProvider.ShouldTrackActivityScheduledRecords;

        public bool ShouldTrackActivityStateRecords =>
            this.host.HasTrackingParticipant && this.host.TrackingProvider.ShouldTrackActivityStateRecords;

        public bool ShouldTrackActivityStateRecordsExecutingState =>
            this.host.HasTrackingParticipant && this.host.TrackingProvider.ShouldTrackActivityStateRecordsExecutingState;

        public bool ShouldTrackActivityStateRecordsClosedState =>
            this.host.HasTrackingParticipant && this.host.TrackingProvider.ShouldTrackActivityStateRecordsClosedState;

        public bool ShouldTrackCancelRequestedRecords =>
            this.host.HasTrackingParticipant && this.host.TrackingProvider.ShouldTrackCancelRequestedRecords;

        public bool ShouldTrackFaultPropagationRecords =>
            this.host.HasTrackingParticipant && this.host.TrackingProvider.ShouldTrackFaultPropagationRecords;

        public System.Activities.Hosting.SymbolResolver SymbolResolver
        {
            get
            {
                if (this.symbolResolver == null)
                {
                    try
                    {
                        this.symbolResolver = this.host.GetExtension<System.Activities.Hosting.SymbolResolver>();
                    }
                    catch (Exception exception)
                    {
                        if (Fx.IsFatal(exception))
                        {
                            throw;
                        }
                        throw System.Activities.FxTrace.Exception.AsError(new CallbackException(System.Activities.SR.CallbackExceptionFromHostGetExtension(this.WorkflowInstanceId), exception));
                    }
                }
                return this.symbolResolver;
            }
        }

        public LocationEnvironment EmptyEnvironment =>
            new LocationEnvironment(this, null);

        public ActivityInstanceState State
        {
            get
            {
                if (((this.executingSecondaryRootInstances == null) || (this.executingSecondaryRootInstances.Count <= 0)) && ((this.rootInstance == null) || this.rootInstance.IsCompleted))
                {
                    return this.executionState;
                }
                return ActivityInstanceState.Executing;
            }
        }

        [DataMember(EmitDefaultValue=false)]
        public System.Activities.WorkflowIdentity WorkflowIdentity { get; internal set; }

        [DataMember]
        public Guid WorkflowInstanceId
        {
            get
            {
                if (!this.instanceIdSet)
                {
                    this.WorkflowInstanceId = this.host.Id;
                    if (!this.instanceIdSet)
                    {
                        throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.EmptyIdReturnedFromHost(this.host.GetType())));
                    }
                }
                return this.instanceId;
            }
            internal set
            {
                this.instanceId = value;
                this.instanceIdSet = value != Guid.Empty;
            }
        }

        public Exception TerminationException =>
            this.completionException;

        public bool IsRunning =>
            !this.isDisposed && this.scheduler.IsRunning;

        public bool IsPersistable =>
            this.noPersistCount == 0;

        public bool IsAbortPending =>
            this.isAbortPending;

        public bool IsIdle
        {
            get
            {
                if (!this.isDisposed)
                {
                    return this.scheduler.IsIdle;
                }
                return true;
            }
        }

        public bool IsTerminatePending =>
            this.isTerminatePending;

        public bool KeysAllowed =>
            this.host.SupportsInstanceKeys;

        public IDictionary<string, object> WorkflowOutputs =>
            this.workflowOutputs;

        internal System.Activities.Runtime.BookmarkScopeManager BookmarkScopeManager
        {
            get
            {
                if (this.bookmarkScopeManager == null)
                {
                    this.bookmarkScopeManager = new System.Activities.Runtime.BookmarkScopeManager();
                }
                return this.bookmarkScopeManager;
            }
        }

        internal System.Activities.Runtime.BookmarkScopeManager RawBookmarkScopeManager =>
            this.bookmarkScopeManager;

        internal BookmarkManager RawBookmarkManager =>
            this.bookmarkManager;

        internal System.Activities.Runtime.MappableObjectManager MappableObjectManager
        {
            get
            {
                if (this.mappableObjectManager == null)
                {
                    this.mappableObjectManager = new System.Activities.Runtime.MappableObjectManager();
                }
                return this.mappableObjectManager;
            }
        }

        public bool RequiresTransactionContextWaiterExists =>
            ((this.transactionContextWaiters != null) && (this.transactionContextWaiters.Count > 0)) && this.transactionContextWaiters[0].IsRequires;

        public bool HasRuntimeTransaction =>
            this.runtimeTransaction > null;

        public Transaction CurrentTransaction
        {
            get
            {
                if (this.runtimeTransaction != null)
                {
                    return this.runtimeTransaction.ClonedTransaction;
                }
                return null;
            }
        }

        private static ReadOnlyCollection<BookmarkInfo> EmptyBookmarkInfoCollection
        {
            get
            {
                if (emptyBookmarkInfoCollection == null)
                {
                    emptyBookmarkInfoCollection = new ReadOnlyCollection<BookmarkInfo>(new List<BookmarkInfo>(0));
                }
                return emptyBookmarkInfoCollection;
            }
        }

        [DataMember(Name="bookmarkMgr", EmitDefaultValue=false)]
        internal BookmarkManager SerializedBookmarkManager
        {
            get => 
                this.bookmarkManager;
            set => 
                this.bookmarkManager = value;
        }

        [DataMember(Name="bookmarkScopeManager", EmitDefaultValue=false)]
        internal System.Activities.Runtime.BookmarkScopeManager SerializedBookmarkScopeManager
        {
            get => 
                this.bookmarkScopeManager;
            set => 
                this.bookmarkScopeManager = value;
        }

        [DataMember(EmitDefaultValue=false, Name="hasTrackedStarted")]
        internal bool SerializedHasTrackedStarted
        {
            get => 
                this.hasTrackedStarted;
            set => 
                this.hasTrackedStarted = value;
        }

        [DataMember(EmitDefaultValue=false, Name="nextTrackingRecordNumber")]
        internal long SerializedNextTrackingRecordNumber
        {
            get => 
                this.nextTrackingRecordNumber;
            set => 
                this.nextTrackingRecordNumber = value;
        }

        [DataMember(Name="rootInstance", EmitDefaultValue=false)]
        internal System.Activities.ActivityInstance SerializedRootInstance
        {
            get => 
                this.rootInstance;
            set => 
                this.rootInstance = value;
        }

        [DataMember(Name="scheduler", EmitDefaultValue=false)]
        internal Scheduler SerializedScheduler
        {
            get => 
                this.scheduler;
            set => 
                this.scheduler = value;
        }

        [DataMember(Name="shouldRaiseMainBodyComplete", EmitDefaultValue=false)]
        internal bool SerializedShouldRaiseMainBodyComplete
        {
            get => 
                this.shouldRaiseMainBodyComplete;
            set => 
                this.shouldRaiseMainBodyComplete = value;
        }

        [DataMember(Name="lastInstanceId", EmitDefaultValue=false)]
        internal long SerializedLastInstanceId
        {
            get => 
                this.lastInstanceId;
            set => 
                this.lastInstanceId = value;
        }

        [DataMember(Name="rootEnvironment", EmitDefaultValue=false)]
        internal LocationEnvironment SerializedRootEnvironment
        {
            get => 
                this.rootEnvironment;
            set => 
                this.rootEnvironment = value;
        }

        [DataMember(Name="workflowOutputs", EmitDefaultValue=false)]
        internal IDictionary<string, object> SerializedWorkflowOutputs
        {
            get => 
                this.workflowOutputs;
            set => 
                this.workflowOutputs = value;
        }

        [DataMember(Name="mainRootCompleteBookmark", EmitDefaultValue=false)]
        internal Bookmark SerializedMainRootCompleteBookmark
        {
            get => 
                this.mainRootCompleteBookmark;
            set => 
                this.mainRootCompleteBookmark = value;
        }

        [DataMember(Name="state", EmitDefaultValue=false)]
        internal ActivityInstanceState SerializedExecutionState
        {
            get => 
                this.executionState;
            set => 
                this.executionState = value;
        }

        [DataMember(EmitDefaultValue=false, Name="handles")]
        internal List<Handle> SerializedHandles
        {
            get => 
                this.handles;
            set => 
                this.handles = value;
        }

        internal bool PersistExceptions
        {
            get
            {
                if (!this.havePersistExceptionsValue)
                {
                    ExceptionPersistenceExtension extension = this.host.GetExtension<ExceptionPersistenceExtension>();
                    if (extension != null)
                    {
                        this.persistExceptions = extension.PersistExceptions;
                    }
                    else
                    {
                        this.persistExceptions = true;
                    }
                    this.havePersistExceptionsValue = true;
                }
                return this.persistExceptions;
            }
        }

        [DataMember(Name="completionException", EmitDefaultValue=false)]
        internal Exception SerializedCompletionException
        {
            get
            {
                if (this.PersistExceptions)
                {
                    return this.completionException;
                }
                return null;
            }
            set => 
                this.completionException = value;
        }

        [DataMember(Name="transactionContextWaiters", EmitDefaultValue=false)]
        internal TransactionContextWaiter[] SerializedTransactionContextWaiters
        {
            get
            {
                if ((this.transactionContextWaiters != null) && (this.transactionContextWaiters.Count > 0))
                {
                    return this.transactionContextWaiters.ToArray();
                }
                return null;
            }
            set => 
                this.transactionContextWaiters = new Quack<TransactionContextWaiter>(value);
        }

        [DataMember(Name="persistenceWaiters", EmitDefaultValue=false)]
        internal Queue<PersistenceWaiter> SerializedPersistenceWaiters
        {
            get
            {
                if ((this.persistenceWaiters != null) && (this.persistenceWaiters.Count != 0))
                {
                    return this.persistenceWaiters;
                }
                return null;
            }
            set => 
                this.persistenceWaiters = value;
        }

        [DataMember(Name="secondaryRootInstances", EmitDefaultValue=false)]
        internal List<System.Activities.ActivityInstance> SerializedExecutingSecondaryRootInstances
        {
            get
            {
                if ((this.executingSecondaryRootInstances != null) && (this.executingSecondaryRootInstances.Count > 0))
                {
                    return this.executingSecondaryRootInstances;
                }
                return null;
            }
            set => 
                this.executingSecondaryRootInstances = value;
        }

        [DataMember(Name="mappableObjectManager", EmitDefaultValue=false)]
        internal System.Activities.Runtime.MappableObjectManager SerializedMappableObjectManager
        {
            get
            {
                if ((this.mappableObjectManager != null) && (this.mappableObjectManager.Count != 0))
                {
                    return this.mappableObjectManager;
                }
                return null;
            }
            set => 
                this.mappableObjectManager = value;
        }

        [DataMember(Name="activities", EmitDefaultValue=false)]
        internal ActivityInstanceMap SerializedProgramMapping
        {
            get
            {
                this.ThrowIfNonSerializable();
                if ((this.instanceMap == null) && !this.isDisposed)
                {
                    this.instanceMap = new ActivityInstanceMap();
                    this.rootInstance.FillInstanceMap(this.instanceMap);
                    this.scheduler.FillInstanceMap(this.instanceMap);
                    if ((this.executingSecondaryRootInstances != null) && (this.executingSecondaryRootInstances.Count > 0))
                    {
                        foreach (System.Activities.ActivityInstance instance in this.executingSecondaryRootInstances)
                        {
                            instance.FillInstanceMap(this.instanceMap);
                            LocationEnvironment reference = instance.Environment;
                            if (instance.IsEnvironmentOwner)
                            {
                                reference = reference.Parent;
                            }
                            while (reference != null)
                            {
                                if (reference.HasOwnerCompleted)
                                {
                                    this.instanceMap.AddEntry(reference, true);
                                }
                                reference = reference.Parent;
                            }
                        }
                    }
                }
                return this.instanceMap;
            }
            set => 
                this.instanceMap = value;
        }

        internal ExecutionPropertyManager RootPropertyManager =>
            this.rootPropertyManager;

        [DataMember(Name="propertyManager", EmitDefaultValue=false)]
        internal ExecutionPropertyManager SerializedPropertyManager
        {
            get => 
                this.rootPropertyManager;
            set
            {
                this.rootPropertyManager = value;
                this.rootPropertyManager.OnDeserialized(null, null, null, this);
            }
        }

        internal List<Handle> Handles =>
            this.handles;

        [DataContract]
        internal class AbortActivityWorkItem : System.Activities.Runtime.WorkItem
        {
            private Exception reason;
            private ActivityInstanceReference originalSource;
            private ActivityExecutor executor;

            public AbortActivityWorkItem(ActivityExecutor executor, System.Activities.ActivityInstance activityInstance, Exception reason, ActivityInstanceReference originalSource) : base(activityInstance)
            {
                this.reason = reason;
                this.originalSource = originalSource;
                base.IsEmpty = true;
                this.executor = executor;
            }

            public override bool Execute(ActivityExecutor executor, BookmarkManager bookmarkManager) => 
                true;

            public override void PostProcess(ActivityExecutor executor)
            {
                executor.AbortActivityInstance(base.ActivityInstance, this.reason);
                base.ExceptionToPropagate = this.reason;
                executor.ExitNoPersistForExceptionPropagation();
            }

            public override void TraceCompleted()
            {
                base.TraceRuntimeWorkItemCompleted();
            }

            public override void TraceScheduled()
            {
                base.TraceRuntimeWorkItemScheduled();
            }

            public override void TraceStarting()
            {
                base.TraceRuntimeWorkItemStarting();
            }

            public override System.Activities.ActivityInstance OriginalExceptionSource =>
                this.originalSource.ActivityInstance;

            public override bool IsValid =>
                base.ActivityInstance.State == ActivityInstanceState.Executing;

            public override System.Activities.ActivityInstance PropertyManagerOwner =>
                null;

            [DataMember(Name="reason")]
            internal Exception SerializedReason
            {
                get => 
                    this.reason;
                set => 
                    this.reason = value;
            }

            [DataMember(Name="originalSource")]
            internal ActivityInstanceReference SerializedOriginalSource
            {
                get => 
                    this.originalSource;
                set => 
                    this.originalSource = value;
            }
        }

        private class AssociateKeysAsyncResult : TransactedAsyncResult
        {
            private static readonly AsyncResult.AsyncCompletion associatedCallback = new AsyncResult.AsyncCompletion(ActivityExecutor.AssociateKeysAsyncResult.OnAssociated);
            private readonly ActivityExecutor executor;

            public AssociateKeysAsyncResult(ActivityExecutor executor, ICollection<InstanceKey> keysToAssociate, AsyncCallback callback, object state) : base(callback, state)
            {
                IAsyncResult result;
                this.executor = executor;
                using (base.PrepareTransactionalCall(this.executor.CurrentTransaction))
                {
                    result = this.executor.host.OnBeginAssociateKeys(keysToAssociate, base.PrepareAsyncCompletion(associatedCallback), this);
                }
                if (base.SyncContinue(result))
                {
                    base.Complete(true);
                }
            }

            public static void End(IAsyncResult result)
            {
                AsyncResult.End<ActivityExecutor.AssociateKeysAsyncResult>(result);
            }

            private static bool OnAssociated(IAsyncResult result)
            {
                ActivityExecutor.AssociateKeysAsyncResult asyncState = (ActivityExecutor.AssociateKeysAsyncResult) result.AsyncState;
                asyncState.executor.host.OnEndAssociateKeys(result);
                return true;
            }
        }

        [DataContract]
        internal class CancelActivityWorkItem : ActivityExecutionWorkItem
        {
            public CancelActivityWorkItem(System.Activities.ActivityInstance activityInstance) : base(activityInstance)
            {
            }

            public override bool Execute(ActivityExecutor executor, BookmarkManager bookmarkManager)
            {
                try
                {
                    base.ActivityInstance.Cancel(executor, bookmarkManager);
                }
                catch (Exception exception)
                {
                    if (Fx.IsFatal(exception))
                    {
                        throw;
                    }
                    base.ExceptionToPropagate = exception;
                }
                return true;
            }

            public override void TraceCompleted()
            {
                if (TD.CompleteCancelActivityWorkItemIsEnabled())
                {
                    TD.CompleteCancelActivityWorkItem(base.ActivityInstance.Activity.GetType().ToString(), base.ActivityInstance.Activity.DisplayName, base.ActivityInstance.Id);
                }
            }

            public override void TraceScheduled()
            {
                if (TD.ScheduleCancelActivityWorkItemIsEnabled())
                {
                    TD.ScheduleCancelActivityWorkItem(base.ActivityInstance.Activity.GetType().ToString(), base.ActivityInstance.Activity.DisplayName, base.ActivityInstance.Id);
                }
            }

            public override void TraceStarting()
            {
                if (TD.StartCancelActivityWorkItemIsEnabled())
                {
                    TD.StartCancelActivityWorkItem(base.ActivityInstance.Activity.GetType().ToString(), base.ActivityInstance.Activity.DisplayName, base.ActivityInstance.Id);
                }
            }
        }

        [DataContract]
        internal class CompleteAsyncOperationWorkItem : BookmarkWorkItem
        {
            public CompleteAsyncOperationWorkItem(BookmarkCallbackWrapper wrapper, Bookmark bookmark, object value) : base(wrapper, bookmark, value)
            {
                base.ExitNoPersistRequired = true;
            }
        }

        private class CompleteTransactionWorkItem : System.Activities.Runtime.WorkItem
        {
            private static AsyncCallback persistCompleteCallback;
            private static AsyncCallback commitCompleteCallback;
            private static Action<object, TimeoutException> outcomeDeterminedCallback;
            private ActivityExecutor.RuntimeTransactionData runtimeTransaction;
            private ActivityExecutor executor;

            public CompleteTransactionWorkItem(System.Activities.ActivityInstance instance) : base(instance)
            {
                base.ExitNoPersistRequired = true;
            }

            private bool CheckOutcome()
            {
                AsyncWaitHandle handle = null;
                ActivityExecutor.RuntimeTransactionData runtimeTransaction = this.runtimeTransaction;
                lock (runtimeTransaction)
                {
                    if (this.runtimeTransaction.TransactionStatus == TransactionStatus.Active)
                    {
                        handle = new AsyncWaitHandle();
                        this.runtimeTransaction.CompletionEvent = handle;
                    }
                }
                if ((handle != null) && !handle.WaitAsync(OutcomeDeterminedCallback, this, ActivityDefaults.TransactionCompletionTimeout))
                {
                    return false;
                }
                return this.FinishCheckOutcome();
            }

            private bool CheckTransactionAborted()
            {
                try
                {
                    TransactionHelper.ThrowIfTransactionAbortedOrInDoubt(this.runtimeTransaction.OriginalTransaction);
                    return false;
                }
                catch (TransactionException exception)
                {
                    if (this.runtimeTransaction.TransactionHandle.AbortInstanceOnTransactionFailure)
                    {
                        base.workflowAbortException = exception;
                    }
                    else
                    {
                        base.ExceptionToPropagate = exception;
                    }
                    return true;
                }
            }

            private bool CompleteTransaction()
            {
                PreparingEnlistment pendingPreparingEnlistment = null;
                ActivityExecutor.RuntimeTransactionData runtimeTransaction = this.runtimeTransaction;
                lock (runtimeTransaction)
                {
                    if (this.runtimeTransaction.PendingPreparingEnlistment != null)
                    {
                        pendingPreparingEnlistment = this.runtimeTransaction.PendingPreparingEnlistment;
                    }
                    this.runtimeTransaction.HasPrepared = true;
                }
                if (pendingPreparingEnlistment != null)
                {
                    pendingPreparingEnlistment.Prepared();
                }
                Transaction originalTransaction = this.runtimeTransaction.OriginalTransaction;
                DependentTransaction transaction2 = originalTransaction as DependentTransaction;
                if (transaction2 != null)
                {
                    transaction2.Complete();
                    return this.CheckOutcome();
                }
                CommittableTransaction transaction3 = originalTransaction as CommittableTransaction;
                if (transaction3 == null)
                {
                    return this.CheckOutcome();
                }
                IAsyncResult result = transaction3.BeginCommit(CommitCompleteCallback, this);
                return (result.CompletedSynchronously && this.FinishCommit(result));
            }

            public override bool Execute(ActivityExecutor executor, BookmarkManager bookmarkManager)
            {
                bool flag;
                this.runtimeTransaction = executor.runtimeTransaction;
                this.executor = executor;
                this.executor.SchedulePendingCancelation();
                try
                {
                    flag = this.CheckTransactionAborted();
                    if (!flag)
                    {
                        IAsyncResult result = new TransactionalPersistAsyncResult(this.executor, PersistCompleteCallback, this);
                        if (result.CompletedSynchronously)
                        {
                            flag = this.FinishPersist(result);
                        }
                    }
                }
                catch (Exception exception)
                {
                    if (Fx.IsFatal(exception))
                    {
                        throw;
                    }
                    this.HandleException(exception);
                    flag = true;
                }
                if (flag)
                {
                    this.executor.runtimeTransaction = null;
                    this.TraceTransactionOutcome();
                    return true;
                }
                return false;
            }

            private bool FinishCheckOutcome()
            {
                this.CheckTransactionAborted();
                return true;
            }

            private bool FinishCommit(IAsyncResult result)
            {
                ((CommittableTransaction) this.runtimeTransaction.OriginalTransaction).EndCommit(result);
                return this.CheckOutcome();
            }

            private bool FinishPersist(IAsyncResult result)
            {
                TransactionalPersistAsyncResult.End(result);
                return this.CompleteTransaction();
            }

            private void HandleException(Exception exception)
            {
                try
                {
                    this.runtimeTransaction.OriginalTransaction.Rollback(exception);
                }
                catch (Exception exception2)
                {
                    if (Fx.IsFatal(exception2))
                    {
                        throw;
                    }
                    base.workflowAbortException = exception2;
                }
                if (this.runtimeTransaction.TransactionHandle.AbortInstanceOnTransactionFailure)
                {
                    base.workflowAbortException = exception;
                }
                else
                {
                    base.ExceptionToPropagate = exception;
                }
            }

            private static void OnCommitComplete(IAsyncResult result)
            {
                if (!result.CompletedSynchronously)
                {
                    ActivityExecutor.CompleteTransactionWorkItem asyncState = (ActivityExecutor.CompleteTransactionWorkItem) result.AsyncState;
                    bool flag = true;
                    try
                    {
                        flag = asyncState.FinishCommit(result);
                    }
                    catch (Exception exception)
                    {
                        if (Fx.IsFatal(exception))
                        {
                            throw;
                        }
                        asyncState.HandleException(exception);
                        flag = true;
                    }
                    if (flag)
                    {
                        asyncState.executor.runtimeTransaction = null;
                        asyncState.TraceTransactionOutcome();
                        asyncState.executor.FinishWorkItem(asyncState);
                    }
                }
            }

            private static void OnOutcomeDetermined(object state, TimeoutException asyncException)
            {
                ActivityExecutor.CompleteTransactionWorkItem workItem = (ActivityExecutor.CompleteTransactionWorkItem) state;
                bool flag = true;
                if (asyncException != null)
                {
                    workItem.HandleException(asyncException);
                }
                else
                {
                    try
                    {
                        flag = workItem.FinishCheckOutcome();
                    }
                    catch (Exception exception)
                    {
                        if (Fx.IsFatal(exception))
                        {
                            throw;
                        }
                        workItem.HandleException(exception);
                        flag = true;
                    }
                }
                if (flag)
                {
                    workItem.executor.runtimeTransaction = null;
                    workItem.TraceTransactionOutcome();
                    workItem.executor.FinishWorkItem(workItem);
                }
            }

            private static void OnPersistComplete(IAsyncResult result)
            {
                if (!result.CompletedSynchronously)
                {
                    ActivityExecutor.CompleteTransactionWorkItem asyncState = (ActivityExecutor.CompleteTransactionWorkItem) result.AsyncState;
                    bool flag = true;
                    try
                    {
                        flag = asyncState.FinishPersist(result);
                    }
                    catch (Exception exception)
                    {
                        if (Fx.IsFatal(exception))
                        {
                            throw;
                        }
                        asyncState.HandleException(exception);
                        flag = true;
                    }
                    if (flag)
                    {
                        asyncState.executor.runtimeTransaction = null;
                        asyncState.TraceTransactionOutcome();
                        asyncState.executor.FinishWorkItem(asyncState);
                    }
                }
            }

            public override void PostProcess(ActivityExecutor executor)
            {
            }

            public override void TraceCompleted()
            {
                base.TraceRuntimeWorkItemCompleted();
            }

            public override void TraceScheduled()
            {
                base.TraceRuntimeWorkItemScheduled();
            }

            public override void TraceStarting()
            {
                base.TraceRuntimeWorkItemStarting();
            }

            private void TraceTransactionOutcome()
            {
                if (TD.RuntimeTransactionCompleteIsEnabled())
                {
                    TD.RuntimeTransactionComplete(this.runtimeTransaction.TransactionStatus.ToString());
                }
            }

            private static AsyncCallback PersistCompleteCallback
            {
                get
                {
                    if (persistCompleteCallback == null)
                    {
                        persistCompleteCallback = Fx.ThunkCallback(new AsyncCallback(ActivityExecutor.CompleteTransactionWorkItem.OnPersistComplete));
                    }
                    return persistCompleteCallback;
                }
            }

            private static AsyncCallback CommitCompleteCallback
            {
                get
                {
                    if (commitCompleteCallback == null)
                    {
                        commitCompleteCallback = Fx.ThunkCallback(new AsyncCallback(ActivityExecutor.CompleteTransactionWorkItem.OnCommitComplete));
                    }
                    return commitCompleteCallback;
                }
            }

            private static Action<object, TimeoutException> OutcomeDeterminedCallback
            {
                get
                {
                    if (outcomeDeterminedCallback == null)
                    {
                        outcomeDeterminedCallback = new Action<object, TimeoutException>(ActivityExecutor.CompleteTransactionWorkItem.OnOutcomeDetermined);
                    }
                    return outcomeDeterminedCallback;
                }
            }

            public override bool IsValid =>
                true;

            public override System.Activities.ActivityInstance PropertyManagerOwner =>
                null;

            private class TransactionalPersistAsyncResult : TransactedAsyncResult
            {
                private ActivityExecutor.CompleteTransactionWorkItem workItem;
                private static readonly AsyncResult.AsyncCompletion onPersistComplete = new AsyncResult.AsyncCompletion(ActivityExecutor.CompleteTransactionWorkItem.TransactionalPersistAsyncResult.OnPersistComplete);
                private readonly ActivityExecutor executor;

                public TransactionalPersistAsyncResult(ActivityExecutor executor, AsyncCallback callback, object state) : base(callback, state)
                {
                    this.executor = executor;
                    this.workItem = (ActivityExecutor.CompleteTransactionWorkItem) state;
                    IAsyncResult result = null;
                    IDisposable disposable = base.PrepareTransactionalCall(this.executor.CurrentTransaction);
                    try
                    {
                        result = this.executor.host.OnBeginPersist(base.PrepareAsyncCompletion(onPersistComplete), this);
                    }
                    catch (Exception exception)
                    {
                        if (Fx.IsFatal(exception))
                        {
                            throw;
                        }
                        this.workItem.workflowAbortException = exception;
                        throw;
                    }
                    finally
                    {
                        if (disposable != null)
                        {
                            disposable.Dispose();
                        }
                    }
                    if (base.SyncContinue(result))
                    {
                        base.Complete(true);
                    }
                }

                public static void End(IAsyncResult result)
                {
                    AsyncResult.End<ActivityExecutor.CompleteTransactionWorkItem.TransactionalPersistAsyncResult>(result);
                }

                private static bool OnPersistComplete(IAsyncResult result)
                {
                    ActivityExecutor.CompleteTransactionWorkItem.TransactionalPersistAsyncResult asyncState = (ActivityExecutor.CompleteTransactionWorkItem.TransactionalPersistAsyncResult) result.AsyncState;
                    try
                    {
                        asyncState.executor.host.OnEndPersist(result);
                    }
                    catch (Exception exception)
                    {
                        if (Fx.IsFatal(exception))
                        {
                            throw;
                        }
                        asyncState.workItem.workflowAbortException = exception;
                        throw;
                    }
                    return true;
                }
            }
        }

        private class EmptyDelegateActivity : NativeActivity
        {
            internal EmptyDelegateActivity()
            {
            }

            protected override void Execute(NativeActivityContext context)
            {
            }
        }

        [DataContract]
        internal class ExecuteActivityWorkItem : ActivityExecutionWorkItem
        {
            private bool requiresSymbolResolution;
            private IDictionary<string, object> argumentValueOverrides;

            public ExecuteActivityWorkItem()
            {
                base.IsPooled = true;
            }

            protected ExecuteActivityWorkItem(System.Activities.ActivityInstance activityInstance, bool requiresSymbolResolution, IDictionary<string, object> argumentValueOverrides) : base(activityInstance)
            {
                this.requiresSymbolResolution = requiresSymbolResolution;
                this.argumentValueOverrides = argumentValueOverrides;
            }

            public override bool Execute(ActivityExecutor executor, BookmarkManager bookmarkManager) => 
                this.ExecuteBody(executor, bookmarkManager, null);

            protected bool ExecuteBody(ActivityExecutor executor, BookmarkManager bookmarkManager, System.Activities.Location resultLocation)
            {
                try
                {
                    if (this.requiresSymbolResolution)
                    {
                        if (!base.ActivityInstance.ResolveArguments(executor, this.argumentValueOverrides, resultLocation, 0))
                        {
                            return true;
                        }
                        if (!base.ActivityInstance.ResolveVariables(executor))
                        {
                            return true;
                        }
                    }
                    base.ActivityInstance.SetInitializedSubstate(executor);
                    if (executor.IsDebugged())
                    {
                        executor.debugController.ActivityStarted(base.ActivityInstance);
                    }
                    base.ActivityInstance.Execute(executor, bookmarkManager);
                }
                catch (Exception exception)
                {
                    if (Fx.IsFatal(exception))
                    {
                        throw;
                    }
                    base.ExceptionToPropagate = exception;
                }
                return true;
            }

            public void Initialize(System.Activities.ActivityInstance activityInstance, bool requiresSymbolResolution, IDictionary<string, object> argumentValueOverrides)
            {
                base.Reinitialize(activityInstance);
                this.requiresSymbolResolution = requiresSymbolResolution;
                this.argumentValueOverrides = argumentValueOverrides;
            }

            protected override void ReleaseToPool(ActivityExecutor executor)
            {
                base.ClearForReuse();
                this.requiresSymbolResolution = false;
                this.argumentValueOverrides = null;
                executor.ExecuteActivityWorkItemPool.Release(this);
            }

            public override void TraceCompleted()
            {
                if (TD.CompleteExecuteActivityWorkItemIsEnabled())
                {
                    TD.CompleteExecuteActivityWorkItem(base.ActivityInstance.Activity.GetType().ToString(), base.ActivityInstance.Activity.DisplayName, base.ActivityInstance.Id);
                }
            }

            public override void TraceScheduled()
            {
                if (TD.ScheduleExecuteActivityWorkItemIsEnabled())
                {
                    TD.ScheduleExecuteActivityWorkItem(base.ActivityInstance.Activity.GetType().ToString(), base.ActivityInstance.Activity.DisplayName, base.ActivityInstance.Id);
                }
            }

            public override void TraceStarting()
            {
                if (TD.StartExecuteActivityWorkItemIsEnabled())
                {
                    TD.StartExecuteActivityWorkItem(base.ActivityInstance.Activity.GetType().ToString(), base.ActivityInstance.Activity.DisplayName, base.ActivityInstance.Id);
                }
            }

            [DataMember(EmitDefaultValue=false, Name="requiresSymbolResolution")]
            internal bool SerializedRequiresSymbolResolution
            {
                get => 
                    this.requiresSymbolResolution;
                set => 
                    this.requiresSymbolResolution = value;
            }

            [DataMember(EmitDefaultValue=false, Name="argumentValueOverrides")]
            internal IDictionary<string, object> SerializedArgumentValueOverrides
            {
                get => 
                    this.argumentValueOverrides;
                set => 
                    this.argumentValueOverrides = value;
            }
        }

        [DataContract]
        internal class ExecuteExpressionWorkItem : ActivityExecutor.ExecuteActivityWorkItem
        {
            private System.Activities.Location resultLocation;

            public ExecuteExpressionWorkItem(System.Activities.ActivityInstance activityInstance, bool requiresSymbolResolution, IDictionary<string, object> argumentValueOverrides, System.Activities.Location resultLocation) : base(activityInstance, requiresSymbolResolution, argumentValueOverrides)
            {
                this.resultLocation = resultLocation;
            }

            public override bool Execute(ActivityExecutor executor, BookmarkManager bookmarkManager) => 
                base.ExecuteBody(executor, bookmarkManager, this.resultLocation);

            [DataMember(Name="resultLocation")]
            internal System.Activities.Location SerializedResultLocation
            {
                get => 
                    this.resultLocation;
                set => 
                    this.resultLocation = value;
            }
        }

        [DataContract]
        internal class ExecuteRootWorkItem : ActivityExecutor.ExecuteActivityWorkItem
        {
            public ExecuteRootWorkItem(System.Activities.ActivityInstance activityInstance, bool requiresSymbolResolution, IDictionary<string, object> argumentValueOverrides) : base(activityInstance, requiresSymbolResolution, argumentValueOverrides)
            {
            }

            public override bool Execute(ActivityExecutor executor, BookmarkManager bookmarkManager)
            {
                if (executor.ShouldTrackActivityScheduledRecords)
                {
                    executor.AddTrackingRecord(new ActivityScheduledRecord(executor.WorkflowInstanceId, null, base.ActivityInstance));
                }
                return base.ExecuteBody(executor, bookmarkManager, null);
            }
        }

        [DataContract]
        internal class PersistenceWaiter
        {
            private Bookmark onPersistBookmark;
            private System.Activities.ActivityInstance waitingInstance;

            public PersistenceWaiter(Bookmark onPersist, System.Activities.ActivityInstance waitingInstance)
            {
                this.OnPersistBookmark = onPersist;
                this.WaitingInstance = waitingInstance;
            }

            public System.Activities.Runtime.WorkItem CreateWorkItem() => 
                new PersistWorkItem(this);

            public Bookmark OnPersistBookmark
            {
                get => 
                    this.onPersistBookmark;
                private set => 
                    this.onPersistBookmark = value;
            }

            public System.Activities.ActivityInstance WaitingInstance
            {
                get => 
                    this.waitingInstance;
                private set => 
                    this.waitingInstance = value;
            }

            [DataMember(Name="OnPersistBookmark")]
            internal Bookmark SerializedOnPersistBookmark
            {
                get => 
                    this.OnPersistBookmark;
                set => 
                    this.OnPersistBookmark = value;
            }

            [DataMember(Name="WaitingInstance")]
            internal System.Activities.ActivityInstance SerializedWaitingInstance
            {
                get => 
                    this.WaitingInstance;
                set => 
                    this.WaitingInstance = value;
            }

            [DataContract]
            internal class PersistWorkItem : System.Activities.Runtime.WorkItem
            {
                private ActivityExecutor.PersistenceWaiter waiter;

                public PersistWorkItem(ActivityExecutor.PersistenceWaiter waiter) : base(waiter.WaitingInstance)
                {
                    this.waiter = waiter;
                }

                public override bool Execute(ActivityExecutor executor, BookmarkManager bookmarkManager)
                {
                    executor.TryResumeUserBookmark(this.waiter.OnPersistBookmark, null, false);
                    IAsyncResult result = null;
                    try
                    {
                        result = executor.host.OnBeginPersist(Fx.ThunkCallback(new AsyncCallback(this.OnPersistComplete)), executor);
                        if (result.CompletedSynchronously)
                        {
                            executor.host.OnEndPersist(result);
                        }
                    }
                    catch (Exception exception)
                    {
                        if (Fx.IsFatal(exception))
                        {
                            throw;
                        }
                        base.workflowAbortException = exception;
                    }
                    if (result != null)
                    {
                        return result.CompletedSynchronously;
                    }
                    return true;
                }

                private void OnPersistComplete(IAsyncResult result)
                {
                    if (!result.CompletedSynchronously)
                    {
                        ActivityExecutor asyncState = (ActivityExecutor) result.AsyncState;
                        try
                        {
                            asyncState.host.OnEndPersist(result);
                        }
                        catch (Exception exception)
                        {
                            if (Fx.IsFatal(exception))
                            {
                                throw;
                            }
                            base.workflowAbortException = exception;
                        }
                        asyncState.FinishWorkItem(this);
                    }
                }

                public override void PostProcess(ActivityExecutor executor)
                {
                    if (base.ExceptionToPropagate != null)
                    {
                        executor.AbortActivityInstance(this.waiter.WaitingInstance, base.ExceptionToPropagate);
                    }
                }

                public override void TraceCompleted()
                {
                    base.TraceRuntimeWorkItemCompleted();
                }

                public override void TraceScheduled()
                {
                    base.TraceRuntimeWorkItemScheduled();
                }

                public override void TraceStarting()
                {
                    base.TraceRuntimeWorkItemStarting();
                }

                public override bool IsValid =>
                    true;

                public override System.Activities.ActivityInstance PropertyManagerOwner =>
                    null;

                [DataMember(Name="waiter")]
                internal ActivityExecutor.PersistenceWaiter SerializedWaiter
                {
                    get => 
                        this.waiter;
                    set => 
                        this.waiter = value;
                }
            }
        }

        private class PoolOfCodeActivityContexts : Pool<CodeActivityContext>
        {
            protected override CodeActivityContext CreateNew() => 
                new CodeActivityContext();
        }

        private class PoolOfCompletionWorkItems : Pool<CompletionCallbackWrapper.CompletionWorkItem>
        {
            protected override CompletionCallbackWrapper.CompletionWorkItem CreateNew() => 
                new CompletionCallbackWrapper.CompletionWorkItem();
        }

        private class PoolOfEmptyWorkItems : Pool<EmptyWorkItem>
        {
            protected override EmptyWorkItem CreateNew() => 
                new EmptyWorkItem();
        }

        private class PoolOfExecuteActivityWorkItems : Pool<ActivityExecutor.ExecuteActivityWorkItem>
        {
            protected override ActivityExecutor.ExecuteActivityWorkItem CreateNew() => 
                new ActivityExecutor.ExecuteActivityWorkItem();
        }

        private class PoolOfExecuteSynchronousExpressionWorkItems : Pool<ExecuteSynchronousExpressionWorkItem>
        {
            protected override ExecuteSynchronousExpressionWorkItem CreateNew() => 
                new ExecuteSynchronousExpressionWorkItem();
        }

        private class PoolOfNativeActivityContexts : Pool<NativeActivityContext>
        {
            protected override NativeActivityContext CreateNew() => 
                new NativeActivityContext();
        }

        private class PoolOfResolveNextArgumentWorkItems : Pool<ResolveNextArgumentWorkItem>
        {
            protected override ResolveNextArgumentWorkItem CreateNew() => 
                new ResolveNextArgumentWorkItem();
        }

        [DataContract]
        internal class PropagateExceptionWorkItem : ActivityExecutionWorkItem
        {
            private Exception exception;

            public PropagateExceptionWorkItem(Exception exception, System.Activities.ActivityInstance activityInstance) : base(activityInstance)
            {
                this.exception = exception;
                base.IsEmpty = true;
            }

            public override bool Execute(ActivityExecutor executor, BookmarkManager bookmarkManager) => 
                false;

            public override void PostProcess(ActivityExecutor executor)
            {
                base.ExceptionToPropagate = this.exception;
            }

            public override void TraceCompleted()
            {
                base.TraceRuntimeWorkItemCompleted();
            }

            public override void TraceScheduled()
            {
                base.TraceRuntimeWorkItemScheduled();
            }

            public override void TraceStarting()
            {
                base.TraceRuntimeWorkItemStarting();
            }

            [DataMember(EmitDefaultValue=false, Name="exception")]
            internal Exception SerializedException
            {
                get => 
                    this.exception;
                set => 
                    this.exception = value;
            }
        }

        [DataContract]
        internal class RethrowExceptionWorkItem : System.Activities.Runtime.WorkItem
        {
            private Exception exception;
            private ActivityInstanceReference source;

            public RethrowExceptionWorkItem(System.Activities.ActivityInstance activityInstance, Exception exception, ActivityInstanceReference source) : base(activityInstance)
            {
                this.exception = exception;
                this.source = source;
                base.IsEmpty = true;
            }

            public override bool Execute(ActivityExecutor executor, BookmarkManager bookmarkManager) => 
                true;

            public override void PostProcess(ActivityExecutor executor)
            {
                executor.AbortActivityInstance(base.ActivityInstance, base.ExceptionToPropagate);
                base.ExceptionToPropagate = this.exception;
            }

            public override void TraceCompleted()
            {
                base.TraceRuntimeWorkItemCompleted();
            }

            public override void TraceScheduled()
            {
                base.TraceRuntimeWorkItemScheduled();
            }

            public override void TraceStarting()
            {
                base.TraceRuntimeWorkItemStarting();
            }

            public override bool IsValid =>
                base.ActivityInstance.State == ActivityInstanceState.Executing;

            public override System.Activities.ActivityInstance PropertyManagerOwner =>
                null;

            public override System.Activities.ActivityInstance OriginalExceptionSource =>
                this.source.ActivityInstance;

            [DataMember(Name="exception")]
            internal Exception SerializedException
            {
                get => 
                    this.exception;
                set => 
                    this.exception = value;
            }

            [DataMember(Name="source")]
            internal ActivityInstanceReference SerializedSource
            {
                get => 
                    this.source;
                set => 
                    this.source = value;
            }
        }

        private class RuntimeTransactionData
        {
            public RuntimeTransactionData(RuntimeTransactionHandle handle, Transaction transaction, System.Activities.ActivityInstance isolationScope)
            {
                this.TransactionHandle = handle;
                this.OriginalTransaction = transaction;
                this.ClonedTransaction = transaction.Clone();
                this.IsolationScope = isolationScope;
                this.TransactionStatus = System.Transactions.TransactionStatus.Active;
            }

            public void Rollback(Exception reason)
            {
                this.OriginalTransaction.Rollback(reason);
            }

            public AsyncWaitHandle CompletionEvent { get; set; }

            public PreparingEnlistment PendingPreparingEnlistment { get; set; }

            public bool HasPrepared { get; set; }

            public bool ShouldScheduleCompletion { get; set; }

            public System.Transactions.TransactionStatus TransactionStatus { get; set; }

            public bool IsRootCancelPending { get; set; }

            public RuntimeTransactionHandle TransactionHandle { get; private set; }

            public Transaction ClonedTransaction { get; private set; }

            public Transaction OriginalTransaction { get; private set; }

            public System.Activities.ActivityInstance IsolationScope { get; private set; }
        }

        [DataContract]
        internal class TransactionContextWaiter
        {
            private System.Activities.ActivityInstance waitingInstance;
            private bool isRequires;
            private RuntimeTransactionHandle handle;
            private object state;
            private ActivityExecutor.TransactionContextWaiterCallbackWrapper callbackWrapper;

            public TransactionContextWaiter(System.Activities.ActivityInstance instance, bool isRequires, RuntimeTransactionHandle handle, ActivityExecutor.TransactionContextWaiterCallbackWrapper callbackWrapper, object state)
            {
                this.WaitingInstance = instance;
                this.IsRequires = isRequires;
                this.Handle = handle;
                this.State = state;
                this.CallbackWrapper = callbackWrapper;
            }

            public System.Activities.ActivityInstance WaitingInstance
            {
                get => 
                    this.waitingInstance;
                private set => 
                    this.waitingInstance = value;
            }

            public bool IsRequires
            {
                get => 
                    this.isRequires;
                private set => 
                    this.isRequires = value;
            }

            public RuntimeTransactionHandle Handle
            {
                get => 
                    this.handle;
                private set => 
                    this.handle = value;
            }

            public object State
            {
                get => 
                    this.state;
                private set => 
                    this.state = value;
            }

            public ActivityExecutor.TransactionContextWaiterCallbackWrapper CallbackWrapper
            {
                get => 
                    this.callbackWrapper;
                private set => 
                    this.callbackWrapper = value;
            }

            [DataMember(Name="WaitingInstance")]
            internal System.Activities.ActivityInstance SerializedWaitingInstance
            {
                get => 
                    this.WaitingInstance;
                set => 
                    this.WaitingInstance = value;
            }

            [DataMember(EmitDefaultValue=false, Name="IsRequires")]
            internal bool SerializedIsRequires
            {
                get => 
                    this.IsRequires;
                set => 
                    this.IsRequires = value;
            }

            [DataMember(Name="Handle")]
            internal RuntimeTransactionHandle SerializedHandle
            {
                get => 
                    this.Handle;
                set => 
                    this.Handle = value;
            }

            [DataMember(EmitDefaultValue=false, Name="State")]
            internal object SerializedState
            {
                get => 
                    this.State;
                set => 
                    this.State = value;
            }

            [DataMember(Name="CallbackWrapper")]
            internal ActivityExecutor.TransactionContextWaiterCallbackWrapper SerializedCallbackWrapper
            {
                get => 
                    this.CallbackWrapper;
                set => 
                    this.CallbackWrapper = value;
            }
        }

        [DataContract]
        internal class TransactionContextWaiterCallbackWrapper : CallbackWrapper
        {
            private static readonly Type callbackType = typeof(Action<NativeActivityTransactionContext, object>);
            private static readonly Type[] transactionCallbackParameterTypes = new Type[] { typeof(NativeActivityTransactionContext), typeof(object) };

            public TransactionContextWaiterCallbackWrapper(Action<NativeActivityTransactionContext, object> action, System.Activities.ActivityInstance owningInstance) : base(action, owningInstance)
            {
            }

            [SecuritySafeCritical]
            public void Invoke(NativeActivityTransactionContext context, object value)
            {
                base.EnsureCallback(callbackType, transactionCallbackParameterTypes);
                Action<NativeActivityTransactionContext, object> callback = (Action<NativeActivityTransactionContext, object>) base.Callback;
                callback(context, value);
            }
        }

        [DataContract]
        internal class TransactionContextWorkItem : ActivityExecutionWorkItem
        {
            private ActivityExecutor.TransactionContextWaiter waiter;

            public TransactionContextWorkItem(ActivityExecutor.TransactionContextWaiter waiter) : base(waiter.WaitingInstance)
            {
                this.waiter = waiter;
                if (this.waiter.IsRequires)
                {
                    base.ExitNoPersistRequired = true;
                }
            }

            public override bool Execute(ActivityExecutor executor, BookmarkManager bookmarkManager)
            {
                NativeActivityTransactionContext context = null;
                try
                {
                    context = new NativeActivityTransactionContext(base.ActivityInstance, executor, bookmarkManager, this.waiter.Handle);
                    this.waiter.CallbackWrapper.Invoke(context, this.waiter.State);
                }
                catch (Exception exception)
                {
                    if (Fx.IsFatal(exception))
                    {
                        throw;
                    }
                    base.ExceptionToPropagate = exception;
                }
                finally
                {
                    if (context != null)
                    {
                        context.Dispose();
                    }
                }
                return true;
            }

            public override void TraceCompleted()
            {
                if (TD.CompleteTransactionContextWorkItemIsEnabled())
                {
                    TD.CompleteTransactionContextWorkItem(base.ActivityInstance.Activity.GetType().ToString(), base.ActivityInstance.Activity.DisplayName, base.ActivityInstance.Id);
                }
            }

            public override void TraceScheduled()
            {
                if (TD.ScheduleTransactionContextWorkItemIsEnabled())
                {
                    TD.ScheduleTransactionContextWorkItem(base.ActivityInstance.Activity.GetType().ToString(), base.ActivityInstance.Activity.DisplayName, base.ActivityInstance.Id);
                }
            }

            public override void TraceStarting()
            {
                if (TD.StartTransactionContextWorkItemIsEnabled())
                {
                    TD.StartTransactionContextWorkItem(base.ActivityInstance.Activity.GetType().ToString(), base.ActivityInstance.Activity.DisplayName, base.ActivityInstance.Id);
                }
            }

            [DataMember(Name="waiter")]
            internal ActivityExecutor.TransactionContextWaiter SerializedWaiter
            {
                get => 
                    this.waiter;
                set => 
                    this.waiter = value;
            }
        }
    }
}

