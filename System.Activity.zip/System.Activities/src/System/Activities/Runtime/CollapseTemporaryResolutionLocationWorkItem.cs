﻿namespace System.Activities.Runtime
{
    using System;
    using System.Activities;
    using System.Runtime.Serialization;

    [DataContract]
    internal class CollapseTemporaryResolutionLocationWorkItem : System.Activities.Runtime.WorkItem
    {
        private Location location;

        public CollapseTemporaryResolutionLocationWorkItem(Location location, System.Activities.ActivityInstance instance) : base(instance)
        {
            this.location = location;
        }

        public override bool Execute(ActivityExecutor executor, BookmarkManager bookmarkManager)
        {
            this.location.TemporaryResolutionEnvironment.CollapseTemporaryResolutionLocation(this.location);
            return true;
        }

        public override void PostProcess(ActivityExecutor executor)
        {
        }

        public override void TraceCompleted()
        {
            base.TraceRuntimeWorkItemCompleted();
        }

        public override void TraceScheduled()
        {
            base.TraceRuntimeWorkItemScheduled();
        }

        public override void TraceStarting()
        {
            base.TraceRuntimeWorkItemStarting();
        }

        public override bool IsValid =>
            true;

        public override System.Activities.ActivityInstance PropertyManagerOwner =>
            null;

        [DataMember(EmitDefaultValue=false, Name="location")]
        internal Location SerializedLocation
        {
            get => 
                this.location;
            set => 
                this.location = value;
        }
    }
}

