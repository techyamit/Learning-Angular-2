﻿namespace System.Activities.Runtime
{
    using System;
    using System.Activities;
    using System.Activities.Tracking;
    using System.Runtime;
    using System.Runtime.Serialization;

    [DataContract]
    internal class ExecuteSynchronousExpressionWorkItem : ActivityExecutionWorkItem, ActivityInstanceMap.IActivityReference
    {
        private ActivityWithResult expressionActivity;
        private long instanceId;
        private ResolveNextArgumentWorkItem nextArgumentWorkItem;
        private System.Activities.Location resultLocation;

        public ExecuteSynchronousExpressionWorkItem()
        {
            base.IsPooled = true;
        }

        private void EnsureActivityInfo(ref ActivityInfo activityInfo)
        {
            if (activityInfo == null)
            {
                activityInfo = new ActivityInfo(this.expressionActivity, this.instanceId);
            }
        }

        private void EvaluateNextArgument(ActivityExecutor executor)
        {
            if (executor.HasPendingTrackingRecords && this.nextArgumentWorkItem.CanExecuteUserCode())
            {
                executor.ScheduleItem(this.nextArgumentWorkItem);
            }
            else
            {
                executor.ExecuteSynchronousWorkItem(this.nextArgumentWorkItem);
            }
        }

        public override bool Execute(ActivityExecutor executor, BookmarkManager bookmarkManager)
        {
            ActivityInfo activityInfo = null;
            this.TrackExecuting(executor, ref activityInfo);
            try
            {
                executor.ExecuteInResolutionContextUntyped(base.ActivityInstance, this.expressionActivity, this.instanceId, this.resultLocation);
            }
            catch (Exception exception)
            {
                if (Fx.IsFatal(exception))
                {
                    throw;
                }
                this.TrackFaulted(executor, ref activityInfo);
                if (this.nextArgumentWorkItem != null)
                {
                    executor.ScheduleItem(this.nextArgumentWorkItem);
                }
                executor.ScheduleExpressionFaultPropagation(this.expressionActivity, this.instanceId, base.ActivityInstance, exception);
                return true;
            }
            finally
            {
                if (base.ActivityInstance.InstanceMap != null)
                {
                    base.ActivityInstance.InstanceMap.RemoveEntry(this);
                }
            }
            this.TrackClosed(executor, ref activityInfo);
            if (this.nextArgumentWorkItem != null)
            {
                this.EvaluateNextArgument(executor);
            }
            return true;
        }

        public void Initialize(System.Activities.ActivityInstance parentInstance, ActivityWithResult expressionActivity, long instanceId, System.Activities.Location resultLocation, ResolveNextArgumentWorkItem nextArgumentWorkItem)
        {
            this.Reinitialize(parentInstance);
            this.expressionActivity = expressionActivity;
            this.instanceId = instanceId;
            this.resultLocation = resultLocation;
            this.nextArgumentWorkItem = nextArgumentWorkItem;
        }

        protected override void ReleaseToPool(ActivityExecutor executor)
        {
            this.ClearForReuse();
            this.expressionActivity = null;
            this.instanceId = 0L;
            this.resultLocation = null;
            this.nextArgumentWorkItem = null;
            executor.ExecuteSynchronousExpressionWorkItemPool.Release(this);
        }

        void ActivityInstanceMap.IActivityReference.Load(Activity activity, ActivityInstanceMap instanceMap)
        {
            ActivityWithResult result = activity as ActivityWithResult;
            if (result == null)
            {
                throw System.Activities.FxTrace.Exception.AsError(new ValidationException(System.Activities.SR.ActivityTypeMismatch(activity.DisplayName, typeof(ActivityWithResult).Name)));
            }
            this.expressionActivity = result;
        }

        public override void TraceCompleted()
        {
            base.TraceRuntimeWorkItemCompleted();
        }

        public override void TraceScheduled()
        {
            base.TraceRuntimeWorkItemScheduled();
        }

        public override void TraceStarting()
        {
            base.TraceRuntimeWorkItemStarting();
        }

        private void TrackClosed(ActivityExecutor executor, ref ActivityInfo activityInfo)
        {
            if (executor.ShouldTrackActivityStateRecordsClosedState)
            {
                this.TrackState(executor, ActivityInstanceState.Closed, ref activityInfo);
            }
        }

        private void TrackExecuting(ActivityExecutor executor, ref ActivityInfo activityInfo)
        {
            if (executor.ShouldTrackActivityStateRecordsExecutingState)
            {
                this.TrackState(executor, ActivityInstanceState.Executing, ref activityInfo);
            }
        }

        private void TrackFaulted(ActivityExecutor executor, ref ActivityInfo activityInfo)
        {
            if (executor.ShouldTrackActivityStateRecords)
            {
                this.TrackState(executor, ActivityInstanceState.Faulted, ref activityInfo);
            }
        }

        private void TrackState(ActivityExecutor executor, ActivityInstanceState state, ref ActivityInfo activityInfo)
        {
            if (executor.ShouldTrackActivity(this.expressionActivity.DisplayName))
            {
                this.EnsureActivityInfo(ref activityInfo);
                executor.AddTrackingRecord(new ActivityStateRecord(executor.WorkflowInstanceId, activityInfo, state));
            }
        }

        [DataMember(EmitDefaultValue=false, Name="instanceId")]
        internal long SerializedInstanceId
        {
            get => 
                this.instanceId;
            set => 
                this.instanceId = value;
        }

        [DataMember(EmitDefaultValue=false, Name="nextArgumentWorkItem")]
        internal ResolveNextArgumentWorkItem SerializedNextArgumentWorkItem
        {
            get => 
                this.nextArgumentWorkItem;
            set => 
                this.nextArgumentWorkItem = value;
        }

        [DataMember(EmitDefaultValue=false, Name="resultLocation")]
        internal System.Activities.Location SerializedResultLocation
        {
            get => 
                this.resultLocation;
            set => 
                this.resultLocation = value;
        }

        Activity ActivityInstanceMap.IActivityReference.Activity =>
            this.expressionActivity;
    }
}

