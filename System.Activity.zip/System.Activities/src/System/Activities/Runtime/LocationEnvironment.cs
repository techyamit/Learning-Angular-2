﻿namespace System.Activities.Runtime
{
    using System;
    using System.Activities;
    using System.Activities.DynamicUpdate;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Runtime.Serialization;

    [DataContract]
    internal sealed class LocationEnvironment : ActivityInstanceMap.IActivityReferenceWithEnvironment, ActivityInstanceMap.IActivityReference
    {
        private static DummyLocation dummyLocation = new DummyLocation();
        private bool isDisposed;
        private bool hasHandles;
        private ActivityExecutor executor;
        private IList<Location> locationsToUnregister;
        private IList<LocationReference> locationsToRegister;
        private Location[] locations;
        private bool hasMappableLocations;
        private LocationEnvironment parent;
        private Location singleLocation;
        private List<Handle> handles;
        private int referenceCountMinusOne;
        private bool hasOwnerCompleted;

        internal LocationEnvironment(ActivityExecutor executor, Activity definition)
        {
            this.executor = executor;
            this.Definition = definition;
        }

        internal LocationEnvironment(LocationEnvironment parent, int capacity) : this(null, null, parent, capacity)
        {
        }

        internal LocationEnvironment(ActivityExecutor executor, Activity definition, LocationEnvironment parent, int capacity) : this(executor, definition)
        {
            this.parent = parent;
            if (capacity > 1)
            {
                this.locations = new Location[capacity];
            }
        }

        internal void AddHandle(Handle handleToAdd)
        {
            if (this.handles == null)
            {
                this.handles = new List<Handle>();
            }
            this.handles.Add(handleToAdd);
            this.hasHandles = true;
        }

        internal void AddReference()
        {
            this.referenceCountMinusOne++;
        }

        private void CleanupMappedLocations()
        {
            if (this.hasMappableLocations)
            {
                if (this.singleLocation != null)
                {
                    this.UnregisterLocation(this.singleLocation);
                }
                else if (this.locations != null)
                {
                    for (int i = 0; i < this.locations.Length; i++)
                    {
                        Location location = this.locations[i];
                        if (location.CanBeMapped)
                        {
                            this.UnregisterLocation(location);
                        }
                    }
                }
            }
        }

        internal void CollapseTemporaryResolutionLocation(Location location)
        {
            if (this.singleLocation == location)
            {
                this.CollapseTemporaryResolutionLocation(ref this.singleLocation);
            }
            else if (this.locations != null)
            {
                for (int i = 0; i < this.locations.Length; i++)
                {
                    if (this.locations[i] == location)
                    {
                        this.CollapseTemporaryResolutionLocation(ref this.locations[i]);
                    }
                }
            }
        }

        private void CollapseTemporaryResolutionLocation(ref Location location)
        {
            if (location.Value == null)
            {
                location = (Location) location.CreateDefaultValue();
            }
            else
            {
                location = ((Location) location.Value).CreateReference(location.BufferGetsOnCollapse);
            }
        }

        internal void CollapseTemporaryResolutionLocations()
        {
            if (this.locations == null)
            {
                if ((this.singleLocation != null) && (this.singleLocation.TemporaryResolutionEnvironment == this))
                {
                    this.CollapseTemporaryResolutionLocation(ref this.singleLocation);
                }
            }
            else
            {
                for (int i = 0; i < this.locations.Length; i++)
                {
                    Location location = this.locations[i];
                    if ((location != null) && (location.TemporaryResolutionEnvironment == this))
                    {
                        this.CollapseTemporaryResolutionLocation(ref this.locations[i]);
                    }
                }
            }
        }

        private void CopyRuntimeDelegateArguments(EnvironmentUpdateMap map, Location[] newLocations)
        {
            for (int i = 1; i <= map.RuntimeDelegateArgumentCount; i++)
            {
                newLocations[newLocations.Length - i] = this.locations[this.locations.Length - i];
            }
        }

        internal void Declare(LocationReference locationReference, Location location, System.Activities.ActivityInstance activityInstance)
        {
            this.RegisterLocation(location, locationReference, activityInstance);
            if (this.locations == null)
            {
                this.singleLocation = location;
            }
            else
            {
                this.locations[locationReference.Id] = location;
            }
        }

        internal void DeclareHandle(LocationReference locationReference, Location location, System.Activities.ActivityInstance activityInstance)
        {
            this.hasHandles = true;
            this.Declare(locationReference, location, activityInstance);
        }

        internal void DeclareTemporaryLocation<T>(LocationReference locationReference, System.Activities.ActivityInstance activityInstance, bool bufferGetsOnCollapse) where T: Location
        {
            Location location = new Location<T>();
            location.SetTemporaryResolutionData(this, bufferGetsOnCollapse);
            this.Declare(locationReference, location, activityInstance);
        }

        internal void Dispose()
        {
            this.isDisposed = true;
            this.CleanupMappedLocations();
        }

        private void FindVariablesToUnregister(bool forImplementation, EnvironmentUpdateMap map, int oldVariableCount, int offset, ref bool hasMappableLocationsRemaining)
        {
            for (int i = 0; i < oldVariableCount; i++)
            {
                Location data = this.locations[i + offset];
                if (data.CanBeMapped)
                {
                    if ((forImplementation && map.GetNewPrivateVariableIndex(i).HasValue) || (!forImplementation && map.GetNewVariableIndex(i).HasValue))
                    {
                        hasMappableLocationsRemaining = true;
                    }
                    else
                    {
                        ActivityUtilities.Add<Location>(ref this.locationsToUnregister, data);
                    }
                }
            }
        }

        internal Location GetSpecificLocation(int id)
        {
            if (this.locations == null)
            {
                return this.singleLocation;
            }
            return this.locations[id];
        }

        internal Location<T> GetSpecificLocation<T>(int id) => 
            this.GetSpecificLocation(id) as Location<T>;

        internal void OnDeserialized(ActivityExecutor executor, System.Activities.ActivityInstance handleScope)
        {
            this.executor = executor;
            if (this.Definition == null)
            {
                this.Definition = handleScope.Activity;
            }
            this.ReinitializeHandles(handleScope);
            this.RegisterUpdatedLocations(handleScope);
        }

        private void RegisterLocation(Location location, LocationReference locationReference, System.Activities.ActivityInstance activityInstance)
        {
            if (location.CanBeMapped)
            {
                this.hasMappableLocations = true;
                this.MappableObjectManager.Register(location, this.Definition, locationReference, activityInstance);
            }
        }

        private void RegisterUpdatedLocations(System.Activities.ActivityInstance activityInstance)
        {
            if (this.locationsToRegister != null)
            {
                foreach (LocationReference reference in this.locationsToRegister)
                {
                    this.RegisterLocation(this.GetSpecificLocation(reference.Id), reference, activityInstance);
                }
                this.locationsToRegister = null;
            }
            if (this.locationsToUnregister != null)
            {
                foreach (Location location in this.locationsToUnregister)
                {
                    this.UnregisterLocation(location);
                }
                this.locationsToUnregister = null;
            }
        }

        internal void ReinitializeHandles(System.Activities.ActivityInstance handleScope)
        {
            if (this.handles != null)
            {
                int count = this.handles.Count;
                for (int i = 0; i < count; i++)
                {
                    this.handles[i].Reinitialize(handleScope);
                    this.hasHandles = true;
                }
            }
        }

        internal void RemoveReference(bool isOwner)
        {
            if (isOwner)
            {
                this.hasOwnerCompleted = true;
            }
            this.referenceCountMinusOne--;
        }

        void ActivityInstanceMap.IActivityReference.Load(Activity activity, ActivityInstanceMap instanceMap)
        {
            this.Definition = activity;
        }

        void ActivityInstanceMap.IActivityReferenceWithEnvironment.UpdateEnvironment(EnvironmentUpdateMap map, Activity activity)
        {
            this.Update(map, activity);
        }

        private void ThrowIfDisposed()
        {
            if (this.isDisposed)
            {
                throw System.Activities.FxTrace.Exception.AsError(new ObjectDisposedException(base.GetType().FullName, System.Activities.SR.EnvironmentDisposed));
            }
        }

        internal bool TryGetLocation(int id, out Location value)
        {
            this.ThrowIfDisposed();
            value = null;
            if (this.locations == null)
            {
                if (id == 0)
                {
                    value = this.singleLocation;
                }
            }
            else if (this.locations.Length > id)
            {
                value = this.locations[id];
            }
            return (value > null);
        }

        internal bool TryGetLocation(int id, Activity environmentOwner, out Location value)
        {
            this.ThrowIfDisposed();
            LocationEnvironment parent = this;
            while ((parent != null) && (parent.Definition != environmentOwner))
            {
                parent = parent.Parent;
            }
            if (parent == null)
            {
                value = null;
                return false;
            }
            value = null;
            if ((id == 0) && (parent.locations == null))
            {
                value = parent.singleLocation;
            }
            else if ((parent.locations != null) && (parent.locations.Length > id))
            {
                value = parent.locations[id];
            }
            return (value > null);
        }

        internal void UninitializeHandles(System.Activities.ActivityInstance scope)
        {
            if (this.hasHandles)
            {
                using (HandleInitializationContext context = null)
                {
                    this.UninitializeHandles(scope, this.Definition.RuntimeVariables, ref context);
                    this.UninitializeHandles(scope, this.Definition.ImplementationVariables, ref context);
                    this.hasHandles = false;
                }
            }
        }

        private void UninitializeHandles(System.Activities.ActivityInstance scope, IList<Variable> variables, ref HandleInitializationContext context)
        {
            for (int i = 0; i < variables.Count; i++)
            {
                Variable variable = variables[i];
                if (variable.IsHandle)
                {
                    Location specificLocation = this.GetSpecificLocation(variable.Id);
                    if (specificLocation != null)
                    {
                        Handle handle = (Handle) specificLocation.Value;
                        if (handle != null)
                        {
                            if (context == null)
                            {
                                context = new HandleInitializationContext(this.executor, scope);
                            }
                            handle.Uninitialize(context);
                        }
                        specificLocation.Value = null;
                    }
                }
            }
        }

        private void UnregisterLocation(Location location)
        {
            this.MappableObjectManager.Unregister(location);
        }

        private void UnregisterRemovedVariables(EnvironmentUpdateMap map)
        {
            bool hasMappableLocationsRemaining = false;
            int oldArgumentCount = map.OldArgumentCount;
            this.FindVariablesToUnregister(false, map, map.OldVariableCount, oldArgumentCount, ref hasMappableLocationsRemaining);
            oldArgumentCount = map.OldArgumentCount + map.OldVariableCount;
            this.FindVariablesToUnregister(true, map, map.OldPrivateVariableCount, oldArgumentCount, ref hasMappableLocationsRemaining);
            this.hasMappableLocations = hasMappableLocationsRemaining;
        }

        internal void Update(EnvironmentUpdateMap map, Activity activity)
        {
            int length;
            int num = (activity.HandlerOf == null) ? 0 : activity.HandlerOf.RuntimeDelegateArguments.Count;
            if (((map.NewArgumentCount != activity.RuntimeArguments.Count) || (map.NewVariableCount != activity.RuntimeVariables.Count)) || ((map.NewPrivateVariableCount != activity.ImplementationVariables.Count) || (map.RuntimeDelegateArgumentCount != num)))
            {
                throw System.Activities.FxTrace.Exception.AsError(new InstanceUpdateException(System.Activities.SR.InvalidUpdateMap(System.Activities.SR.WrongEnvironmentCount(activity, map.NewArgumentCount, map.NewVariableCount, map.NewPrivateVariableCount, map.RuntimeDelegateArgumentCount, activity.RuntimeArguments.Count, activity.RuntimeVariables.Count, activity.ImplementationVariables.Count, num))));
            }
            int num2 = ((map.OldArgumentCount + map.OldVariableCount) + map.OldPrivateVariableCount) + map.RuntimeDelegateArgumentCount;
            if (this.locations == null)
            {
                if (this.singleLocation == null)
                {
                    length = 0;
                }
                else
                {
                    length = 1;
                    this.locations = new Location[] { this.singleLocation };
                    this.singleLocation = null;
                }
            }
            else
            {
                length = this.locations.Length;
            }
            if (num2 != length)
            {
                throw System.Activities.FxTrace.Exception.AsError(new InstanceUpdateException(System.Activities.SR.InvalidUpdateMap(System.Activities.SR.WrongOriginalEnvironmentCount(activity, map.OldArgumentCount, map.OldVariableCount, map.OldPrivateVariableCount, map.RuntimeDelegateArgumentCount, num2, length))));
            }
            Location[] newLocations = null;
            int num4 = ((map.NewArgumentCount + map.NewVariableCount) + map.NewPrivateVariableCount) + map.RuntimeDelegateArgumentCount;
            if (num4 > 0)
            {
                newLocations = new Location[num4];
            }
            this.UpdateArguments(map, newLocations);
            this.UnregisterRemovedVariables(map);
            this.UpdatePublicVariables(map, newLocations, activity);
            this.UpdatePrivateVariables(map, newLocations, activity);
            this.CopyRuntimeDelegateArguments(map, newLocations);
            Location location = null;
            if (num4 == 1)
            {
                location = newLocations[0];
                newLocations = null;
            }
            this.singleLocation = location;
            this.locations = newLocations;
        }

        private void UpdateArguments(EnvironmentUpdateMap map, Location[] newLocations)
        {
            if (map.HasArgumentEntries)
            {
                for (int j = 0; j < map.ArgumentEntries.Count; j++)
                {
                    EnvironmentUpdateMapEntry entry = map.ArgumentEntries[j];
                    if (entry.IsAddition)
                    {
                        newLocations[entry.NewOffset] = dummyLocation;
                    }
                    else
                    {
                        newLocations[entry.NewOffset] = this.locations[entry.OldOffset];
                    }
                }
            }
            for (int i = 0; i < map.NewArgumentCount; i++)
            {
                if (newLocations[i] == null)
                {
                    newLocations[i] = this.locations[i];
                }
                else if (newLocations[i] == dummyLocation)
                {
                    newLocations[i] = null;
                }
            }
        }

        private void UpdatePrivateVariables(EnvironmentUpdateMap map, Location[] newLocations, Activity activity)
        {
            this.UpdateVariables(map.NewArgumentCount + map.NewVariableCount, map.OldArgumentCount + map.OldVariableCount, map.NewPrivateVariableCount, map.OldPrivateVariableCount, map.PrivateVariableEntries, activity.ImplementationVariables, newLocations);
        }

        private void UpdatePublicVariables(EnvironmentUpdateMap map, Location[] newLocations, Activity activity)
        {
            this.UpdateVariables(map.NewArgumentCount, map.OldArgumentCount, map.NewVariableCount, map.OldVariableCount, map.VariableEntries, activity.RuntimeVariables, newLocations);
        }

        private void UpdateVariables(int newVariablesOffset, int oldVariablesOffset, int newVariableCount, int oldVariableCount, IList<EnvironmentUpdateMapEntry> variableEntries, IList<Variable> variables, Location[] newLocations)
        {
            if (variableEntries != null)
            {
                for (int j = 0; j < variableEntries.Count; j++)
                {
                    EnvironmentUpdateMapEntry entry = variableEntries[j];
                    if (entry.IsAddition)
                    {
                        Variable data = variables[entry.NewOffset];
                        Location location = data.CreateLocation();
                        newLocations[newVariablesOffset + entry.NewOffset] = location;
                        if (location.CanBeMapped)
                        {
                            ActivityUtilities.Add<LocationReference>(ref this.locationsToRegister, data);
                        }
                    }
                    else
                    {
                        newLocations[newVariablesOffset + entry.NewOffset] = this.locations[oldVariablesOffset + entry.OldOffset];
                    }
                }
            }
            for (int i = 0; i < newVariableCount; i++)
            {
                if (newLocations[newVariablesOffset + i] == null)
                {
                    newLocations[newVariablesOffset + i] = this.locations[oldVariablesOffset + i];
                }
            }
        }

        [DataMember(EmitDefaultValue=false, Name="locations")]
        internal Location[] SerializedLocations
        {
            get => 
                this.locations;
            set => 
                this.locations = value;
        }

        [DataMember(EmitDefaultValue=false, Name="hasMappableLocations")]
        internal bool SerializedHasMappableLocations
        {
            get => 
                this.hasMappableLocations;
            set => 
                this.hasMappableLocations = value;
        }

        [DataMember(EmitDefaultValue=false, Name="parent")]
        internal LocationEnvironment SerializedParent
        {
            get => 
                this.parent;
            set => 
                this.parent = value;
        }

        [DataMember(EmitDefaultValue=false, Name="singleLocation")]
        internal Location SerializedSingleLocation
        {
            get => 
                this.singleLocation;
            set => 
                this.singleLocation = value;
        }

        [DataMember(EmitDefaultValue=false, Name="handles")]
        internal List<Handle> SerializedHandles
        {
            get => 
                this.handles;
            set => 
                this.handles = value;
        }

        [DataMember(EmitDefaultValue=false, Name="referenceCountMinusOne")]
        internal int SerializedReferenceCountMinusOne
        {
            get => 
                this.referenceCountMinusOne;
            set => 
                this.referenceCountMinusOne = value;
        }

        [DataMember(EmitDefaultValue=false, Name="hasOwnerCompleted")]
        internal bool SerializedHasOwnerCompleted
        {
            get => 
                this.hasOwnerCompleted;
            set => 
                this.hasOwnerCompleted = value;
        }

        internal Activity Definition { get; private set; }

        internal LocationEnvironment Parent
        {
            get => 
                this.parent;
            set => 
                this.parent = value;
        }

        internal bool HasHandles =>
            this.hasHandles;

        private System.Activities.Runtime.MappableObjectManager MappableObjectManager =>
            this.executor.MappableObjectManager;

        internal bool ShouldDispose =>
            this.referenceCountMinusOne == -1;

        internal bool HasOwnerCompleted =>
            this.hasOwnerCompleted;

        Activity ActivityInstanceMap.IActivityReference.Activity =>
            this.Definition;

        internal List<Handle> Handles =>
            this.handles;

        private class DummyLocation : Location<object>
        {
        }

        private delegate int? GetNewVariableIndex(int oldIndex);
    }
}

