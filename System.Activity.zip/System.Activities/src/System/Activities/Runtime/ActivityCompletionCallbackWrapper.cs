﻿namespace System.Activities.Runtime
{
    using System;
    using System.Activities;
    using System.Runtime.Serialization;
    using System.Security;

    [DataContract]
    internal class ActivityCompletionCallbackWrapper : CompletionCallbackWrapper
    {
        private static readonly Type completionCallbackType = typeof(CompletionCallback);
        private static readonly Type[] completionCallbackParameters = new Type[] { typeof(NativeActivityContext), typeof(System.Activities.ActivityInstance) };

        public ActivityCompletionCallbackWrapper(CompletionCallback callback, System.Activities.ActivityInstance owningInstance) : base(callback, owningInstance)
        {
        }

        [SecuritySafeCritical]
        protected internal override void Invoke(NativeActivityContext context, System.Activities.ActivityInstance completedInstance)
        {
            base.EnsureCallback(completionCallbackType, completionCallbackParameters);
            CompletionCallback callback = (CompletionCallback) base.Callback;
            callback(context, completedInstance);
        }
    }
}

