﻿namespace System.Activities.Runtime
{
    using System;
    using System.Activities;
    using System.Collections.Generic;
    using System.Runtime.Serialization;

    [DataContract]
    internal class ResolveNextArgumentWorkItem : ActivityExecutionWorkItem
    {
        private int nextArgumentIndex;
        private IDictionary<string, object> argumentValueOverrides;
        private Location resultLocation;

        public ResolveNextArgumentWorkItem()
        {
            base.IsPooled = true;
        }

        internal bool CanExecuteUserCode()
        {
            Activity activity = base.ActivityInstance.Activity;
            for (int i = this.nextArgumentIndex; i < activity.RuntimeArguments.Count; i++)
            {
                RuntimeArgument argument = activity.RuntimeArguments[i];
                if (argument.IsBound && (argument.BoundArgument.Expression != null))
                {
                    return argument.BoundArgument.Expression.UseOldFastPath;
                }
            }
            return false;
        }

        public override bool Execute(ActivityExecutor executor, BookmarkManager bookmarkManager)
        {
            base.ActivityInstance.ResolveArguments(executor, this.argumentValueOverrides, this.resultLocation, this.nextArgumentIndex);
            return true;
        }

        public void Initialize(System.Activities.ActivityInstance activityInstance, int nextArgumentIndex, IDictionary<string, object> argumentValueOverrides, Location resultLocation)
        {
            base.Reinitialize(activityInstance);
            this.nextArgumentIndex = nextArgumentIndex;
            this.argumentValueOverrides = argumentValueOverrides;
            this.resultLocation = resultLocation;
        }

        protected override void ReleaseToPool(ActivityExecutor executor)
        {
            base.ClearForReuse();
            this.nextArgumentIndex = 0;
            this.resultLocation = null;
            this.argumentValueOverrides = null;
            executor.ResolveNextArgumentWorkItemPool.Release(this);
        }

        public override void TraceCompleted()
        {
            base.TraceRuntimeWorkItemCompleted();
        }

        public override void TraceScheduled()
        {
            base.TraceRuntimeWorkItemScheduled();
        }

        public override void TraceStarting()
        {
            base.TraceRuntimeWorkItemStarting();
        }

        [DataMember(EmitDefaultValue=false, Name="nextArgumentIndex")]
        internal int SerializedNextArgumentIndex
        {
            get => 
                this.nextArgumentIndex;
            set => 
                this.nextArgumentIndex = value;
        }

        [DataMember(EmitDefaultValue=false, Name="argumentValueOverrides")]
        internal IDictionary<string, object> SerializedArgumentValueOverrides
        {
            get => 
                this.argumentValueOverrides;
            set => 
                this.argumentValueOverrides = value;
        }

        [DataMember(EmitDefaultValue=false, Name="resultLocation")]
        internal Location SerializedResultLocation
        {
            get => 
                this.resultLocation;
            set => 
                this.resultLocation = value;
        }
    }
}

