﻿namespace System.Activities
{
    using System;
    using System.Activities.Expressions;
    using System.Activities.Runtime;
    using System.Activities.XamlIntegration;
    using System.ComponentModel;
    using System.Linq.Expressions;
    using System.Runtime.CompilerServices;
    using System.Windows.Markup;

    [ContentProperty("Expression"), TypeConverter(typeof(InArgumentConverter)), ValueSerializer(typeof(ArgumentValueSerializer))]
    public sealed class InArgument<T> : InArgument
    {
        public InArgument()
        {
            base.ArgumentType = typeof(T);
        }

        public InArgument(DelegateArgument delegateArgument) : this()
        {
            if (delegateArgument != null)
            {
                DelegateArgumentValue<T> value1 = new DelegateArgumentValue<T> {
                    DelegateArgument = delegateArgument
                };
                this.Expression = value1;
            }
        }

        public InArgument(Variable variable) : this()
        {
            if (variable != null)
            {
                VariableValue<T> value1 = new VariableValue<T> {
                    Variable = variable
                };
                this.Expression = value1;
            }
        }

        public InArgument(T constValue) : this()
        {
            Literal<T> literal1 = new Literal<T> {
                Value = constValue
            };
            this.Expression = literal1;
        }

        public InArgument(Activity<T> expression) : this()
        {
            this.Expression = expression;
        }

        public InArgument(Expression<Func<ActivityContext, T>> expression) : this()
        {
            if (expression != null)
            {
                this.Expression = new LambdaValue<T>(expression);
            }
        }

        internal override Location CreateDefaultLocation() => 
            CreateLocation<T>();

        internal override void Declare(LocationEnvironment targetEnvironment, System.Activities.ActivityInstance targetActivityInstance)
        {
            targetEnvironment.Declare(base.RuntimeArgument, this.CreateDefaultLocation(), targetActivityInstance);
        }

        public static InArgument<T> FromDelegateArgument(DelegateArgument delegateArgument)
        {
            if (delegateArgument == null)
            {
                throw FxTrace.Exception.ArgumentNull("delegateArgument");
            }
            return new InArgument<T>(delegateArgument);
        }

        public static InArgument<T> FromExpression(Activity<T> expression)
        {
            if (expression == null)
            {
                throw FxTrace.Exception.ArgumentNull("expression");
            }
            return new InArgument<T>(expression);
        }

        public static InArgument<T> FromValue(T constValue)
        {
            InArgument<T> argument1 = new InArgument<T>();
            Literal<T> literal1 = new Literal<T> {
                Value = constValue
            };
            argument1.Expression = literal1;
            return argument1;
        }

        public static InArgument<T> FromVariable(Variable variable)
        {
            if (variable == null)
            {
                throw FxTrace.Exception.ArgumentNull("variable");
            }
            return new InArgument<T>(variable);
        }

        public T Get(ActivityContext context) => 
            base.Get<T>(context);

        public static implicit operator InArgument<T>(Activity<T> expression) => 
            InArgument<T>.FromExpression(expression);

        public static implicit operator InArgument<T>(DelegateArgument delegateArgument) => 
            InArgument<T>.FromDelegateArgument(delegateArgument);

        public static implicit operator InArgument<T>(Variable variable) => 
            InArgument<T>.FromVariable(variable);

        public static implicit operator InArgument<T>(T constValue) => 
            InArgument<T>.FromValue(constValue);

        public void Set(ActivityContext context, T value)
        {
            if (context == null)
            {
                throw FxTrace.Exception.ArgumentNull("context");
            }
            context.SetValue<T>((InArgument<T>) this, value);
        }

        internal override bool TryPopulateValue(LocationEnvironment targetEnvironment, System.Activities.ActivityInstance activityInstance, ActivityExecutor executor)
        {
            Location<T> location = CreateLocation<T>();
            targetEnvironment.Declare(base.RuntimeArgument, location, activityInstance);
            if (this.Expression.UseOldFastPath)
            {
                location.Value = executor.ExecuteInResolutionContext<T>(activityInstance, this.Expression);
                return true;
            }
            return false;
        }

        [DefaultValue((string) null)]
        public Activity<T> Expression { get; set; }

        internal override ActivityWithResult ExpressionCore
        {
            get => 
                this.Expression;
            set
            {
                if (value == null)
                {
                    this.Expression = null;
                }
                else if (value is Activity<T>)
                {
                    this.Expression = (Activity<T>) value;
                }
                else
                {
                    this.Expression = new ActivityWithResultWrapper<T>(value);
                }
            }
        }
    }
}

