﻿namespace System.Activities.Statements
{
    using System;
    using System.Activities;
    using System.Activities.Validation;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.Linq;
    using System.Runtime.CompilerServices;
    using System.Windows.Markup;

    [ContentProperty("Body")]
    public sealed class NoPersistScope : NativeActivity
    {
        private static System.Activities.Validation.Constraint constraint;
        private Variable<NoPersistHandle> noPersistHandle = new Variable<NoPersistHandle>();

        public NoPersistScope()
        {
            base.Constraints.Add(Constraint);
        }

        protected override void CacheMetadata(NativeActivityMetadata metadata)
        {
            metadata.AddChild(this.Body);
            metadata.AddImplementationVariable(this.noPersistHandle);
        }

        protected override void Execute(NativeActivityContext context)
        {
            if (this.Body != null)
            {
                this.noPersistHandle.Get(context).Enter(context);
                context.ScheduleActivity(this.Body);
            }
        }

        private static System.Activities.Validation.Constraint NoPersistInScope()
        {
            DelegateInArgument<ValidationContext> argument = new DelegateInArgument<ValidationContext>("validationContext");
            DelegateInArgument<NoPersistScope> argument2 = new DelegateInArgument<NoPersistScope>("noPersistScope");
            Variable<bool> variable = new Variable<bool>("isConstraintSatisfied", true);
            Variable<IEnumerable<Activity>> variable2 = new Variable<IEnumerable<Activity>>("childActivities");
            Variable<string> variable3 = new Variable<string>("constraintViolationMessage");
            Constraint<NoPersistScope> constraint1 = new Constraint<NoPersistScope>();
            ActivityAction<NoPersistScope, ValidationContext> action1 = new ActivityAction<NoPersistScope, ValidationContext> {
                Argument1 = argument2,
                Argument2 = argument
            };
            Sequence sequence1 = new Sequence {
                Variables = { 
                    variable,
                    variable2,
                    variable3
                }
            };
            Assign<IEnumerable<Activity>> item = new Assign<IEnumerable<Activity>> {
                To = variable2
            };
            GetChildSubtree subtree1 = new GetChildSubtree {
                ValidationContext = argument
            };
            item.Value = subtree1;
            sequence1.Activities.Add(item);
            Assign<bool> assign2 = new Assign<bool> {
                To = variable
            };
            CheckNoPersistInDescendants descendants1 = new CheckNoPersistInDescendants {
                NoPersistScope = argument2,
                DescendantActivities = variable2,
                ConstraintViolationMessage = variable3
            };
            assign2.Value = descendants1;
            sequence1.Activities.Add(assign2);
            AssertValidation validation1 = new AssertValidation {
                Assertion = variable,
                Message = variable3
            };
            sequence1.Activities.Add(validation1);
            action1.Handler = sequence1;
            constraint1.Body = action1;
            return constraint1;
        }

        [DefaultValue((string) null)]
        public Activity Body { get; set; }

        private static System.Activities.Validation.Constraint Constraint
        {
            get
            {
                if (constraint == null)
                {
                    constraint = NoPersistInScope();
                }
                return constraint;
            }
        }

        private sealed class CheckNoPersistInDescendants : CodeActivity<bool>
        {
            protected override void CacheMetadata(CodeActivityMetadata metadata)
            {
                Collection<RuntimeArgument> arguments = new Collection<RuntimeArgument>();
                RuntimeArgument argument = new RuntimeArgument("NoPersistScope", typeof(System.Activities.Statements.NoPersistScope), ArgumentDirection.In);
                metadata.Bind(this.NoPersistScope, argument);
                arguments.Add(argument);
                RuntimeArgument argument2 = new RuntimeArgument("DescendantActivities", typeof(IEnumerable<Activity>), ArgumentDirection.In);
                metadata.Bind(this.DescendantActivities, argument2);
                arguments.Add(argument2);
                RuntimeArgument argument3 = new RuntimeArgument("ConstraintViolationMessage", typeof(string), ArgumentDirection.Out);
                metadata.Bind(this.ConstraintViolationMessage, argument3);
                arguments.Add(argument3);
                RuntimeArgument argument4 = new RuntimeArgument("Result", typeof(bool), ArgumentDirection.Out);
                metadata.Bind(base.Result, argument4);
                arguments.Add(argument4);
                metadata.SetArgumentsCollection(arguments);
            }

            protected override bool Execute(CodeActivityContext context)
            {
                Persist persist = this.DescendantActivities.Get(context).OfType<Persist>().FirstOrDefault<Persist>();
                if (persist != null)
                {
                    string str = System.Activities.SR.NoPersistScopeCannotContainPersist(this.NoPersistScope.Get(context).DisplayName, persist.DisplayName);
                    this.ConstraintViolationMessage.Set(context, str);
                    return false;
                }
                return true;
            }

            [RequiredArgument]
            public InArgument<System.Activities.Statements.NoPersistScope> NoPersistScope { get; set; }

            [RequiredArgument]
            public InArgument<IEnumerable<Activity>> DescendantActivities { get; set; }

            [RequiredArgument]
            public OutArgument<string> ConstraintViolationMessage { get; set; }
        }
    }
}

