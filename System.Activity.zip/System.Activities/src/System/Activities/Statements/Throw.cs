﻿namespace System.Activities.Statements
{
    using System;
    using System.Activities;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.Runtime.CompilerServices;
    using System.Windows.Markup;

    [ContentProperty("Exception")]
    public sealed class Throw : CodeActivity
    {
        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            RuntimeArgument argument = new RuntimeArgument("Exception", typeof(System.Exception), ArgumentDirection.In, true);
            metadata.Bind(this.Exception, argument);
            Collection<RuntimeArgument> arguments = new Collection<RuntimeArgument> {
                argument
            };
            metadata.SetArgumentsCollection(arguments);
        }

        protected override void Execute(CodeActivityContext context)
        {
            System.Exception exception = this.Exception.Get(context);
            if (exception == null)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.MemberCannotBeNull("Exception", base.GetType().Name, base.DisplayName)));
            }
            throw FxTrace.Exception.AsError(exception);
        }

        [RequiredArgument, DefaultValue((string) null)]
        public InArgument<System.Exception> Exception { get; set; }
    }
}

