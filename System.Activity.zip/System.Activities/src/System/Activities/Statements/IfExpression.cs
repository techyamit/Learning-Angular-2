﻿namespace System.Activities.Statements
{
    using System;
    using System.Activities;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Linq;
    using System.Runtime.CompilerServices;

    internal class IfExpression : CodeActivity<bool>
    {
        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            RuntimeArgument argument = new RuntimeArgument("Elements", typeof(IEnumerable<Activity>), ArgumentDirection.In);
            if (this.Elements == null)
            {
                this.Elements = new InArgument<IEnumerable<Activity>>();
            }
            metadata.Bind(this.Elements, argument);
            RuntimeArgument argument2 = new RuntimeArgument("Index", typeof(int), ArgumentDirection.In);
            if (this.Index == null)
            {
                this.Index = new InArgument<int>();
            }
            metadata.Bind(this.Index, argument2);
            RuntimeArgument argument3 = new RuntimeArgument("Result", typeof(bool), ArgumentDirection.Out);
            if (base.Result == null)
            {
                base.Result = new OutArgument<bool>();
            }
            metadata.Bind(base.Result, argument3);
            Collection<RuntimeArgument> arguments = new Collection<RuntimeArgument> {
                argument2,
                argument,
                argument3
            };
            metadata.SetArgumentsCollection(arguments);
        }

        protected override bool Execute(CodeActivityContext context) => 
            this.Elements.Get(context).ElementAt<Activity>(this.Index.Get(context)).GetType() == typeof(CompensationParticipant);

        public InArgument<IEnumerable<Activity>> Elements { get; set; }

        public InArgument<int> Index { get; set; }
    }
}

