﻿namespace System.Activities.Statements
{
    using System;
    using System.Activities;
    using System.Activities.Hosting;
    using System.Activities.Persistence;
    using System.Collections;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Runtime;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Xml.Linq;

    public class DurableTimerExtension : TimerExtension, IWorkflowInstanceExtension, IDisposable, ICancelable
    {
        private WorkflowInstanceProxy instance;
        private TimerTable registeredTimers;
        private Action<object> onTimerFiredCallback;
        private TimerPersistenceParticipant timerPersistenceParticipant;
        private static AsyncCallback onResumeBookmarkComplete = Fx.ThunkCallback(new AsyncCallback(DurableTimerExtension.OnResumeBookmarkComplete));
        private static readonly XName timerTableName = XNamespace.Get("urn:schemas-microsoft-com:System.Activities/4.0/properties").GetName("RegisteredTimers");
        private static readonly XName timerExpirationTimeName = XNamespace.Get("urn:schemas-microsoft-com:System.Activities/4.0/properties").GetName("TimerExpirationTime");
        private bool isDisposed;
        private object thisLock;

        public DurableTimerExtension()
        {
            this.onTimerFiredCallback = new Action<object>(this.OnTimerFired);
            this.thisLock = new object();
            this.timerPersistenceParticipant = new TimerPersistenceParticipant(this);
            this.isDisposed = false;
        }

        public void Dispose()
        {
            if (this.registeredTimers != null)
            {
                object thisLock = this.ThisLock;
                lock (thisLock)
                {
                    this.isDisposed = true;
                    if (this.registeredTimers != null)
                    {
                        this.registeredTimers.Dispose();
                    }
                }
            }
            GC.SuppressFinalize(this);
        }

        [IteratorStateMachine(typeof(<GetAdditionalExtensions>d__16))]
        public virtual IEnumerable<object> GetAdditionalExtensions() => 
            new <GetAdditionalExtensions>d__16(-2) { <>4__this = this };

        protected override void OnCancelTimer(Bookmark bookmark)
        {
            object thisLock = this.ThisLock;
            lock (thisLock)
            {
                this.RegisteredTimers.RemoveTimer(bookmark);
            }
        }

        internal void OnLoad(IDictionary<XName, object> readWriteValues)
        {
            object thisLock = this.ThisLock;
            lock (thisLock)
            {
                if ((readWriteValues != null) && readWriteValues.TryGetValue(timerTableName, out object obj3))
                {
                    this.registeredTimers = obj3 as TimerTable;
                    this.RegisteredTimers.OnLoad(this);
                }
            }
        }

        protected override void OnRegisterTimer(TimeSpan timeout, Bookmark bookmark)
        {
            if (timeout < TimeSpan.MaxValue)
            {
                object thisLock = this.ThisLock;
                lock (thisLock)
                {
                    this.RegisteredTimers.AddTimer(timeout, bookmark);
                }
            }
        }

        private static void OnResumeBookmarkComplete(IAsyncResult result)
        {
            if (!result.CompletedSynchronously)
            {
                BookmarkResumptionState asyncState = (BookmarkResumptionState) result.AsyncState;
                BookmarkResumptionResult result2 = asyncState.Instance.EndResumeBookmark(result);
                asyncState.TimerExtension.ProcessBookmarkResumptionResult(asyncState.TimerBookmark, result2);
            }
        }

        internal void OnSave(out IDictionary<XName, object> readWriteValues, out IDictionary<XName, object> writeOnlyValues)
        {
            readWriteValues = null;
            writeOnlyValues = null;
            object thisLock = this.ThisLock;
            lock (thisLock)
            {
                this.RegisteredTimers.MarkAsImmutable();
                if ((this.registeredTimers != null) && (this.registeredTimers.Count > 0))
                {
                    readWriteValues = new Dictionary<XName, object>(1);
                    writeOnlyValues = new Dictionary<XName, object>(1);
                    readWriteValues.Add(timerTableName, this.registeredTimers);
                    writeOnlyValues.Add(timerExpirationTimeName, this.registeredTimers.GetNextDueTime());
                }
            }
        }

        private void OnTimerFired(object state)
        {
            Bookmark bookmark = state as Bookmark;
            WorkflowInstanceProxy instance = this.instance;
            if (instance != null)
            {
                IAsyncResult result2 = null;
                result2 = instance.BeginResumeBookmark(bookmark, null, TimeSpan.MaxValue, onResumeBookmarkComplete, new BookmarkResumptionState(bookmark, this, instance));
                if (result2.CompletedSynchronously && (result2 != null))
                {
                    try
                    {
                        BookmarkResumptionResult result = instance.EndResumeBookmark(result2);
                        this.ProcessBookmarkResumptionResult(bookmark, result);
                    }
                    catch (TimeoutException)
                    {
                        this.ProcessBookmarkResumptionResult(bookmark, BookmarkResumptionResult.NotReady);
                    }
                }
            }
        }

        internal void PersistenceDone()
        {
            object thisLock = this.ThisLock;
            lock (thisLock)
            {
                this.RegisteredTimers.MarkAsMutable();
            }
        }

        private void ProcessBookmarkResumptionResult(Bookmark timerBookmark, BookmarkResumptionResult result)
        {
            if (result > BookmarkResumptionResult.NotFound)
            {
                if (result != BookmarkResumptionResult.NotReady)
                {
                    return;
                }
            }
            else
            {
                object obj2 = this.ThisLock;
                lock (obj2)
                {
                    if (!this.isDisposed)
                    {
                        this.RegisteredTimers.RemoveTimer(timerBookmark);
                    }
                    return;
                }
            }
            object thisLock = this.ThisLock;
            lock (thisLock)
            {
                this.RegisteredTimers.RetryTimer(timerBookmark);
            }
        }

        public virtual void SetInstance(WorkflowInstanceProxy instance)
        {
            if ((this.instance != null) && (instance != null))
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.TimerExtensionAlreadyAttached));
            }
            this.instance = instance;
        }

        void ICancelable.Cancel()
        {
            this.Dispose();
        }

        private object ThisLock =>
            this.thisLock;

        internal Action<object> OnTimerFiredCallback =>
            this.onTimerFiredCallback;

        internal TimerTable RegisteredTimers
        {
            get
            {
                if (this.registeredTimers == null)
                {
                    this.registeredTimers = new TimerTable(this);
                }
                return this.registeredTimers;
            }
        }

        [CompilerGenerated]
        private sealed class <GetAdditionalExtensions>d__16 : IEnumerable<object>, IEnumerable, IEnumerator<object>, IDisposable, IEnumerator
        {
            private int <>1__state;
            private object <>2__current;
            private int <>l__initialThreadId;
            public DurableTimerExtension <>4__this;

            [DebuggerHidden]
            public <GetAdditionalExtensions>d__16(int <>1__state)
            {
                this.<>1__state = <>1__state;
                this.<>l__initialThreadId = Environment.CurrentManagedThreadId;
            }

            private bool MoveNext()
            {
                int num = this.<>1__state;
                DurableTimerExtension extension = this.<>4__this;
                switch (num)
                {
                    case 0:
                        this.<>1__state = -1;
                        this.<>2__current = extension.timerPersistenceParticipant;
                        this.<>1__state = 1;
                        return true;

                    case 1:
                        this.<>1__state = -1;
                        break;
                }
                return false;
            }

            [DebuggerHidden]
            IEnumerator<object> IEnumerable<object>.GetEnumerator()
            {
                if ((this.<>1__state == -2) && (this.<>l__initialThreadId == Environment.CurrentManagedThreadId))
                {
                    this.<>1__state = 0;
                    return this;
                }
                return new DurableTimerExtension.<GetAdditionalExtensions>d__16(0) { <>4__this = this.<>4__this };
            }

            [DebuggerHidden]
            IEnumerator IEnumerable.GetEnumerator() => 
                this.System.Collections.Generic.IEnumerable<System.Object>.GetEnumerator();

            [DebuggerHidden]
            void IEnumerator.Reset()
            {
                throw new NotSupportedException();
            }

            [DebuggerHidden]
            void IDisposable.Dispose()
            {
            }

            object IEnumerator<object>.Current =>
                this.<>2__current;

            object IEnumerator.Current =>
                this.<>2__current;
        }

        private class BookmarkResumptionState
        {
            public BookmarkResumptionState(Bookmark timerBookmark, DurableTimerExtension timerExtension, WorkflowInstanceProxy instance)
            {
                this.TimerBookmark = timerBookmark;
                this.TimerExtension = timerExtension;
                this.Instance = instance;
            }

            public Bookmark TimerBookmark { get; private set; }

            public DurableTimerExtension TimerExtension { get; private set; }

            public WorkflowInstanceProxy Instance { get; private set; }
        }

        private class TimerPersistenceParticipant : PersistenceIOParticipant
        {
            private DurableTimerExtension defaultTimerExtension;

            public TimerPersistenceParticipant(DurableTimerExtension timerExtension) : base(false, false)
            {
                this.defaultTimerExtension = timerExtension;
            }

            protected override void Abort()
            {
                this.defaultTimerExtension.PersistenceDone();
            }

            protected override IAsyncResult BeginOnSave(IDictionary<XName, object> readWriteValues, IDictionary<XName, object> writeOnlyValues, TimeSpan timeout, AsyncCallback callback, object state)
            {
                this.defaultTimerExtension.PersistenceDone();
                return base.BeginOnSave(readWriteValues, writeOnlyValues, timeout, callback, state);
            }

            protected override void CollectValues(out IDictionary<XName, object> readWriteValues, out IDictionary<XName, object> writeOnlyValues)
            {
                this.defaultTimerExtension.OnSave(out readWriteValues, out writeOnlyValues);
            }

            protected override void PublishValues(IDictionary<XName, object> readWriteValues)
            {
                this.defaultTimerExtension.OnLoad(readWriteValues);
            }
        }
    }
}

