﻿namespace System.Activities.Statements
{
    using System;
    using System.Activities;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Linq;
    using System.Runtime.CompilerServices;

    internal class WhileExpression : CodeActivity<bool>
    {
        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            RuntimeArgument argument = new RuntimeArgument("AssertFlag", typeof(bool), ArgumentDirection.In);
            if (this.AssertFlag == null)
            {
                this.AssertFlag = new InArgument<bool>();
            }
            metadata.Bind(this.AssertFlag, argument);
            RuntimeArgument argument2 = new RuntimeArgument("Index", typeof(int), ArgumentDirection.In);
            if (this.Index == null)
            {
                this.Index = new InArgument<int>();
            }
            metadata.Bind(this.Index, argument2);
            RuntimeArgument argument3 = new RuntimeArgument("Elements", typeof(IEnumerable<Activity>), ArgumentDirection.In);
            if (this.Elements == null)
            {
                this.Elements = new InArgument<IEnumerable<Activity>>();
            }
            metadata.Bind(this.Elements, argument3);
            RuntimeArgument argument4 = new RuntimeArgument("Result", typeof(bool), ArgumentDirection.Out);
            if (base.Result == null)
            {
                base.Result = new OutArgument<bool>();
            }
            metadata.Bind(base.Result, argument4);
            Collection<RuntimeArgument> arguments = new Collection<RuntimeArgument> {
                argument,
                argument2,
                argument3,
                argument4
            };
            metadata.SetArgumentsCollection(arguments);
        }

        protected override bool Execute(CodeActivityContext context) => 
            this.AssertFlag.Get(context) && (this.Index.Get(context) < this.Elements.Get(context).Count<Activity>());

        public InArgument<bool> AssertFlag { get; set; }

        public InArgument<int> Index { get; set; }

        public InArgument<IEnumerable<Activity>> Elements { get; set; }
    }
}

