﻿namespace System.Activities.Statements
{
    using System;
    using System.Activities;
    using System.Collections.Generic;
    using System.Runtime;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Runtime.Serialization;

    [DataContract]
    internal class TimerTable : IDisposable
    {
        private SortedTimerList sortedTimerList = new SortedTimerList();
        private bool isImmutable;
        private DurableTimerExtension timerExtension;
        private HybridCollection<Bookmark> pendingRemoveBookmark;
        private HybridCollection<Bookmark> pendingRetryBookmark;

        public TimerTable(DurableTimerExtension timerExtension)
        {
            this.timerExtension = timerExtension;
        }

        public void AddTimer(TimeSpan timeout, Bookmark bookmark)
        {
            DateTime expirationTime = TimeoutHelper.Add(DateTime.UtcNow, timeout);
            TimerData timerData = new TimerData(bookmark, expirationTime) {
                IOThreadTimer = new IOThreadTimer(this.timerExtension.OnTimerFiredCallback, bookmark, false, 0)
            };
            timerData.IOThreadTimer.Set(timeout);
            this.sortedTimerList.Add(timerData);
        }

        public void Dispose()
        {
            foreach (TimerData data in this.sortedTimerList.Timers)
            {
                data.IOThreadTimer.Cancel();
            }
            this.sortedTimerList.Clear();
            this.pendingRemoveBookmark = null;
            this.pendingRetryBookmark = null;
        }

        public DateTime GetNextDueTime()
        {
            if (this.sortedTimerList.Count > 0)
            {
                return this.sortedTimerList.Timers[0].ExpirationTime;
            }
            return DateTime.MaxValue;
        }

        public void MarkAsImmutable()
        {
            this.isImmutable = true;
        }

        public void MarkAsMutable()
        {
            if (this.isImmutable)
            {
                int num = 0;
                this.isImmutable = false;
                if (this.pendingRemoveBookmark != null)
                {
                    for (num = 0; num < this.pendingRemoveBookmark.Count; num++)
                    {
                        this.RemoveTimer(this.pendingRemoveBookmark[num]);
                    }
                    this.pendingRemoveBookmark = null;
                }
                if (this.pendingRetryBookmark != null)
                {
                    for (num = 0; num < this.pendingRemoveBookmark.Count; num++)
                    {
                        this.RetryTimer(this.pendingRetryBookmark[num]);
                    }
                    this.pendingRetryBookmark = null;
                }
            }
        }

        public void OnLoad(DurableTimerExtension timerExtension)
        {
            this.timerExtension = timerExtension;
            this.sortedTimerList.OnLoad();
            foreach (TimerData data in this.sortedTimerList.Timers)
            {
                data.IOThreadTimer = new IOThreadTimer(this.timerExtension.OnTimerFiredCallback, data.Bookmark, false, 0);
                if (data.ExpirationTime <= DateTime.UtcNow)
                {
                    timerExtension.OnTimerFiredCallback(data.Bookmark);
                }
                else
                {
                    data.IOThreadTimer.Set((TimeSpan) (data.ExpirationTime - DateTime.UtcNow));
                }
            }
        }

        public void RemoveTimer(Bookmark bookmark)
        {
            if (!this.isImmutable)
            {
                if (this.sortedTimerList.TryGetValue(bookmark, out TimerData data))
                {
                    this.sortedTimerList.Remove(bookmark);
                    data.IOThreadTimer.Cancel();
                }
            }
            else if (this.pendingRemoveBookmark == null)
            {
                this.pendingRemoveBookmark = new HybridCollection<Bookmark>(bookmark);
            }
            else
            {
                this.pendingRemoveBookmark.Add(bookmark);
            }
        }

        public void RetryTimer(Bookmark bookmark)
        {
            if (!this.isImmutable)
            {
                if (this.sortedTimerList.ContainsKey(bookmark))
                {
                    this.RemoveTimer(bookmark);
                    this.AddTimer(TimeSpan.FromSeconds(10.0), bookmark);
                }
            }
            else if (this.pendingRetryBookmark == null)
            {
                this.pendingRetryBookmark = new HybridCollection<Bookmark>(bookmark);
            }
            else
            {
                this.pendingRetryBookmark.Add(bookmark);
            }
        }

        public int Count =>
            this.sortedTimerList.Count;

        [DataMember(Name="sortedTimerList")]
        internal SortedTimerList SerializedSortedTimerList
        {
            get => 
                this.sortedTimerList;
            set => 
                this.sortedTimerList = value;
        }

        [DataContract]
        internal class SortedTimerList
        {
            private List<TimerTable.TimerData> list = new List<TimerTable.TimerData>();
            private Dictionary<Bookmark, TimerTable.TimerData> dictionary = new Dictionary<Bookmark, TimerTable.TimerData>();

            public void Add(TimerTable.TimerData timerData)
            {
                int num = this.list.BinarySearch(timerData, TimerTable.TimerComparer.Instance);
                if (num < 0)
                {
                    this.list.Insert(~num, timerData);
                    this.dictionary.Add(timerData.Bookmark, timerData);
                }
            }

            public void Clear()
            {
                this.list.Clear();
                this.dictionary.Clear();
            }

            public bool ContainsKey(Bookmark bookmark) => 
                this.dictionary.ContainsKey(bookmark);

            public void OnLoad()
            {
                if (this.dictionary == null)
                {
                    this.dictionary = new Dictionary<Bookmark, TimerTable.TimerData>();
                    for (int i = 0; i < this.list.Count; i++)
                    {
                        this.dictionary.Add(this.list[i].Bookmark, this.list[i]);
                    }
                }
            }

            public void Remove(Bookmark bookmark)
            {
                if (this.dictionary.TryGetValue(bookmark, out TimerTable.TimerData data))
                {
                    int index = this.list.BinarySearch(data, TimerTable.TimerComparer.Instance);
                    this.list.RemoveAt(index);
                    this.dictionary.Remove(bookmark);
                }
            }

            public bool TryGetValue(Bookmark bookmark, out TimerTable.TimerData timerData) => 
                this.dictionary.TryGetValue(bookmark, out timerData);

            public List<TimerTable.TimerData> Timers =>
                this.list;

            public int Count =>
                this.list.Count;

            [DataMember(Name="list")]
            internal List<TimerTable.TimerData> SerializedList
            {
                get => 
                    this.list;
                set => 
                    this.list = value;
            }

            [DataMember(Name="dictionary")]
            internal Dictionary<Bookmark, TimerTable.TimerData> SerializedDictionary
            {
                get => 
                    this.dictionary;
                set => 
                    this.dictionary = value;
            }
        }

        private class TimerComparer : IComparer<TimerTable.TimerData>
        {
            internal static readonly TimerTable.TimerComparer Instance = new TimerTable.TimerComparer();

            public int Compare(TimerTable.TimerData x, TimerTable.TimerData y)
            {
                if (x == y)
                {
                    return 0;
                }
                if (x == null)
                {
                    return -1;
                }
                if (y == null)
                {
                    return 1;
                }
                if (!(x.ExpirationTime == y.ExpirationTime))
                {
                    return x.ExpirationTime.CompareTo(y.ExpirationTime);
                }
                if (x.Bookmark.IsNamed)
                {
                    if (y.Bookmark.IsNamed)
                    {
                        return string.Compare(x.Bookmark.Name, y.Bookmark.Name, StringComparison.OrdinalIgnoreCase);
                    }
                    return 1;
                }
                if (y.Bookmark.IsNamed)
                {
                    return -1;
                }
                return x.Bookmark.Id.CompareTo(y.Bookmark.Id);
            }
        }

        [DataContract]
        internal class TimerData
        {
            private System.Activities.Bookmark bookmark;
            private DateTime expirationTime;

            public TimerData(System.Activities.Bookmark timerBookmark, DateTime expirationTime)
            {
                this.Bookmark = timerBookmark;
                this.ExpirationTime = expirationTime;
            }

            public System.Activities.Bookmark Bookmark
            {
                get => 
                    this.bookmark;
                private set => 
                    this.bookmark = value;
            }

            public DateTime ExpirationTime
            {
                get => 
                    this.expirationTime;
                private set => 
                    this.expirationTime = value;
            }

            public System.Runtime.IOThreadTimer IOThreadTimer { get; set; }

            [DataMember(Name="Bookmark")]
            internal System.Activities.Bookmark SerializedBookmark
            {
                get => 
                    this.Bookmark;
                set => 
                    this.Bookmark = value;
            }

            [DataMember(Name="ExpirationTime")]
            internal DateTime SerializedExpirationTime
            {
                get => 
                    this.ExpirationTime;
                set => 
                    this.ExpirationTime = value;
            }
        }
    }
}

