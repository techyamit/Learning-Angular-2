﻿namespace System.Activities.Statements
{
    using System;
    using System.Runtime.Serialization;

    [DataContract]
    internal enum CompensationState
    {
        [EnumMember]
        Creating = 0,
        [EnumMember]
        Active = 1,
        [EnumMember]
        Completed = 2,
        [EnumMember]
        Confirming = 3,
        [EnumMember]
        Confirmed = 4,
        [EnumMember]
        Compensating = 5,
        [EnumMember]
        Compensated = 6,
        [EnumMember]
        Canceling = 7,
        [EnumMember]
        Canceled = 8
    }
}

