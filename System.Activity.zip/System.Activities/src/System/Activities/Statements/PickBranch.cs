﻿namespace System.Activities.Statements
{
    using System;
    using System.Activities;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.Runtime.Collections;
    using System.Runtime.CompilerServices;
    using System.Windows.Markup;

    [ContentProperty("Action")]
    public sealed class PickBranch
    {
        private Collection<Variable> variables;
        private string displayName = "PickBranch";

        public Collection<Variable> Variables
        {
            get
            {
                if (this.variables == null)
                {
                    ValidatingCollection<Variable> collection1 = new ValidatingCollection<Variable> {
                        OnAddValidationCallback = delegate (Variable item) {
                            if (item == null)
                            {
                                throw FxTrace.Exception.ArgumentNull("item");
                            }
                        }
                    };
                    this.variables = collection1;
                }
                return this.variables;
            }
        }

        [DefaultValue((string) null), DependsOn("Variables")]
        public Activity Trigger { get; set; }

        [DefaultValue((string) null), DependsOn("Trigger")]
        public Activity Action { get; set; }

        [DefaultValue("PickBranch")]
        public string DisplayName
        {
            get => 
                this.displayName;
            set => 
                this.displayName = value;
        }

        [Serializable, CompilerGenerated]
        private sealed class <>c
        {
            public static readonly PickBranch.<>c <>9 = new PickBranch.<>c();
            public static Action<Variable> <>9__4_0;

            internal void <get_Variables>b__4_0(Variable item)
            {
                if (item == null)
                {
                    throw FxTrace.Exception.ArgumentNull("item");
                }
            }
        }
    }
}

