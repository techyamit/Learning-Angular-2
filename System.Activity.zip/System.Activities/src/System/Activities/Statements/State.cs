﻿namespace System.Activities.Statements
{
    using System;
    using System.Activities;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.Runtime.Collections;
    using System.Runtime.CompilerServices;
    using System.Windows.Markup;

    public sealed class State
    {
        private System.Activities.Statements.InternalState internalState;
        private Collection<Transition> transitions;
        private NoOp nullTrigger;
        private Collection<Variable> variables;

        internal void ClearInternalState()
        {
            this.internalState = null;
        }

        public string DisplayName { get; set; }

        [DefaultValue((string) null)]
        public Activity Entry { get; set; }

        [DependsOn("Entry"), DefaultValue((string) null)]
        public Activity Exit { get; set; }

        [DependsOn("Exit")]
        public Collection<Transition> Transitions
        {
            get
            {
                if (this.transitions == null)
                {
                    ValidatingCollection<Transition> collection1 = new ValidatingCollection<Transition> {
                        OnAddValidationCallback = delegate (Transition item) {
                            if (item == null)
                            {
                                throw FxTrace.Exception.AsError(new ArgumentNullException("item"));
                            }
                        }
                    };
                    this.transitions = collection1;
                }
                return this.transitions;
            }
        }

        [DependsOn("Transitions")]
        public Collection<Variable> Variables
        {
            get
            {
                if (this.variables == null)
                {
                    ValidatingCollection<Variable> collection1 = new ValidatingCollection<Variable> {
                        OnAddValidationCallback = delegate (Variable item) {
                            if (item == null)
                            {
                                throw FxTrace.Exception.AsError(new ArgumentNullException("item"));
                            }
                        }
                    };
                    this.variables = collection1;
                }
                return this.variables;
            }
        }

        [DefaultValue(false)]
        public bool IsFinal { get; set; }

        internal System.Activities.Statements.InternalState InternalState
        {
            get
            {
                if (this.internalState == null)
                {
                    this.internalState = new System.Activities.Statements.InternalState(this);
                }
                return this.internalState;
            }
        }

        internal uint PassNumber { get; set; }

        internal bool Reachable { get; set; }

        internal string StateId { get; set; }

        internal string StateMachineName { get; set; }

        internal NoOp NullTrigger
        {
            get
            {
                if (this.nullTrigger == null)
                {
                    NoOp op1 = new NoOp {
                        DisplayName = "Null Trigger"
                    };
                    this.nullTrigger = op1;
                }
                return this.nullTrigger;
            }
        }

        [Serializable, CompilerGenerated]
        private sealed class <>c
        {
            public static readonly System.Activities.Statements.State.<>c <>9 = new System.Activities.Statements.State.<>c();
            public static Action<Transition> <>9__17_0;
            public static Action<Variable> <>9__19_0;

            internal void <get_Transitions>b__17_0(Transition item)
            {
                if (item == null)
                {
                    throw FxTrace.Exception.AsError(new ArgumentNullException("item"));
                }
            }

            internal void <get_Variables>b__19_0(Variable item)
            {
                if (item == null)
                {
                    throw FxTrace.Exception.AsError(new ArgumentNullException("item"));
                }
            }
        }

        internal sealed class NoOp : CodeActivity
        {
            protected override void Execute(CodeActivityContext context)
            {
            }
        }
    }
}

