﻿namespace System.Activities.Statements
{
    using System;
    using System.Activities;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;

    public abstract class FlowNode
    {
        private Flowchart owner;
        private int cacheId;

        internal FlowNode()
        {
            this.Index = -1;
        }

        internal void GetChildActivities(ICollection<Activity> children)
        {
            if (this.ChildActivity != null)
            {
                children.Add(this.ChildActivity);
            }
        }

        internal abstract void GetConnectedNodes(IList<FlowNode> connections);
        internal abstract void OnOpen(Flowchart owner, NativeActivityMetadata metadata);
        internal bool Open(Flowchart owner, NativeActivityMetadata metadata)
        {
            if (this.cacheId == owner.CacheId)
            {
                if (this.owner != owner)
                {
                    metadata.AddValidationError(System.Activities.SR.FlowNodeCannotBeShared(this.owner.DisplayName, owner.DisplayName));
                }
                return false;
            }
            if (!owner.ValidateUnconnectedNodes)
            {
                this.OnOpen(owner, metadata);
            }
            this.owner = owner;
            this.cacheId = owner.CacheId;
            this.Index = -1;
            return true;
        }

        internal abstract Activity ChildActivity { get; }

        internal int Index { get; set; }

        internal bool IsOpen =>
            this.owner > null;

        internal Flowchart Owner =>
            this.owner;
    }
}

