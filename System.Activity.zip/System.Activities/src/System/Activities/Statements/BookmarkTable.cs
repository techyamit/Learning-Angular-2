﻿namespace System.Activities.Statements
{
    using System;
    using System.Activities;
    using System.Reflection;
    using System.Runtime.Serialization;

    [DataContract]
    internal class BookmarkTable
    {
        private static int tableSize = Enum.GetValues(typeof(CompensationBookmarkName)).Length;
        private Bookmark[] bookmarkTable = new Bookmark[tableSize];

        public Bookmark this[CompensationBookmarkName bookmarkName]
        {
            get => 
                this.bookmarkTable[(int) bookmarkName];
            set => 
                this.bookmarkTable[(int) bookmarkName] = value;
        }

        [DataMember(Name="bookmarkTable")]
        internal Bookmark[] SerializedBookmarkTable
        {
            get => 
                this.bookmarkTable;
            set => 
                this.bookmarkTable = value;
        }
    }
}

