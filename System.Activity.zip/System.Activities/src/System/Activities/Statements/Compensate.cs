﻿namespace System.Activities.Statements
{
    using System;
    using System.Activities;
    using System.Activities.Expressions;
    using System.Activities.Validation;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.Linq.Expressions;
    using System.Reflection;
    using System.Runtime.CompilerServices;

    public sealed class Compensate : NativeActivity
    {
        private static Constraint compensateWithNoTarget = CompensateWithNoTarget();
        private System.Activities.Statements.InternalCompensate internalCompensate;
        private System.Activities.Statements.DefaultCompensation defaultCompensation;
        private Variable<CompensationToken> currentCompensationToken = new Variable<CompensationToken>();

        protected override void CacheMetadata(NativeActivityMetadata metadata)
        {
            RuntimeArgument argument = new RuntimeArgument("Target", typeof(CompensationToken), ArgumentDirection.In);
            metadata.Bind(this.Target, argument);
            Collection<RuntimeArgument> arguments = new Collection<RuntimeArgument> {
                argument
            };
            metadata.SetArgumentsCollection(arguments);
            Collection<Variable> implementationVariables = new Collection<Variable> {
                this.currentCompensationToken
            };
            metadata.SetImplementationVariablesCollection(implementationVariables);
            Collection<Activity> implementationChildren = new Collection<Activity> {
                this.DefaultCompensation,
                this.InternalCompensate
            };
            metadata.SetImplementationChildrenCollection(implementationChildren);
        }

        protected override void Cancel(NativeActivityContext context)
        {
        }

        private static Constraint CompensateWithNoTarget()
        {
            <>c__DisplayClass15_0 class_;
            ParameterExpression expression;
            DelegateInArgument<Compensate> element = new DelegateInArgument<Compensate> {
                Name = "element"
            };
            DelegateInArgument<ValidationContext> argument = new DelegateInArgument<ValidationContext> {
                Name = "validationContext"
            };
            Variable<bool> assertFlag = new Variable<bool> {
                Name = "assertFlag"
            };
            Variable<IEnumerable<Activity>> elements = new Variable<IEnumerable<Activity>> {
                Name = "elements"
            };
            Variable<int> index = new Variable<int> {
                Name = "index"
            };
            Constraint<Compensate> constraint = new Constraint<Compensate>();
            ActivityAction<Compensate, ValidationContext> action = new ActivityAction<Compensate, ValidationContext> {
                Argument1 = element,
                Argument2 = argument
            };
            Sequence sequence = new Sequence {
                Variables = { 
                    assertFlag,
                    elements,
                    index
                }
            };
            If item = new If();
            Expression[] arguments = new Expression[] { expression = Expression.Parameter(typeof(ActivityContext), "env") };
            ParameterExpression[] parameters = new ParameterExpression[] { expression };
            item.Condition = new InArgument<bool>(Expression.Lambda<Func<ActivityContext, bool>>(Expression.NotEqual(Expression.Property(Expression.Call(Expression.Field(Expression.Constant(class_, typeof(<>c__DisplayClass15_0)), fieldof(<>c__DisplayClass15_0.element)), (MethodInfo) methodof(DelegateInArgument<Compensate>.Get, DelegateInArgument<Compensate>), arguments), (MethodInfo) methodof(Compensate.get_Target)), Expression.Constant(null, typeof(object))), parameters));
            Assign<bool> assign1 = new Assign<bool> {
                To = assertFlag,
                Value = 1
            };
            item.Then = assign1;
            Sequence sequence2 = new Sequence();
            Assign<IEnumerable<Activity>> assign2 = new Assign<IEnumerable<Activity>> {
                To = elements
            };
            GetParentChain chain1 = new GetParentChain {
                ValidationContext = argument
            };
            assign2.Value = chain1;
            sequence2.Activities.Add(assign2);
            Expression[] expressionArray3 = new Expression[] { expression = Expression.Parameter(typeof(ActivityContext), "env") };
            Expression[] expressionArray4 = new Expression[] { expression };
            Expression[] expressionArray5 = new Expression[1];
            Expression[] expressionArray6 = new Expression[] { expression };
            expressionArray5[0] = Expression.Call(Expression.Field(Expression.Constant(class_, typeof(<>c__DisplayClass15_0)), fieldof(<>c__DisplayClass15_0.elements)), (MethodInfo) methodof(Variable<IEnumerable<Activity>>.Get, Variable<IEnumerable<Activity>>), expressionArray6);
            ParameterExpression[] expressionArray7 = new ParameterExpression[] { expression };
            While @while = new While(Expression.Lambda<Func<ActivityContext, bool>>(Expression.AndAlso(Expression.NotEqual(Expression.Call(Expression.Field(Expression.Constant(class_, typeof(<>c__DisplayClass15_0)), fieldof(<>c__DisplayClass15_0.assertFlag)), (MethodInfo) methodof(Variable<bool>.Get, Variable<bool>), expressionArray3), Expression.Constant(true, typeof(bool))), Expression.LessThan(Expression.Call(Expression.Field(Expression.Constant(class_, typeof(<>c__DisplayClass15_0)), fieldof(<>c__DisplayClass15_0.index)), (MethodInfo) methodof(Variable<int>.Get, Variable<int>), expressionArray4), Expression.Call(null, (MethodInfo) methodof(Enumerable.Count), expressionArray5))), expressionArray7));
            Sequence sequence3 = new Sequence();
            Expression[] expressionArray8 = new Expression[2];
            Expression[] expressionArray9 = new Expression[] { expression = Expression.Parameter(typeof(ActivityContext), "env") };
            expressionArray8[0] = Expression.Call(Expression.Field(Expression.Constant(class_, typeof(<>c__DisplayClass15_0)), fieldof(<>c__DisplayClass15_0.elements)), (MethodInfo) methodof(Variable<IEnumerable<Activity>>.Get, Variable<IEnumerable<Activity>>), expressionArray9);
            Expression[] expressionArray10 = new Expression[] { expression };
            expressionArray8[1] = Expression.Call(Expression.Field(Expression.Constant(class_, typeof(<>c__DisplayClass15_0)), fieldof(<>c__DisplayClass15_0.index)), (MethodInfo) methodof(Variable<int>.Get, Variable<int>), expressionArray10);
            ParameterExpression[] expressionArray11 = new ParameterExpression[] { expression };
            If if1 = new If(Expression.Lambda<Func<ActivityContext, bool>>(Expression.Equal(Expression.Call(Expression.Call(null, (MethodInfo) methodof(Enumerable.ElementAt), expressionArray8), (MethodInfo) methodof(object.GetType), new Expression[0]), Expression.Constant(typeof(CompensationParticipant), typeof(Type)), false, (MethodInfo) methodof(Type.op_Equality)), expressionArray11));
            Assign<bool> assign3 = new Assign<bool> {
                To = assertFlag,
                Value = 1
            };
            if1.Then = assign3;
            sequence3.Activities.Add(if1);
            Assign<int> assign = new Assign<int> {
                To = index
            };
            Expression[] expressionArray12 = new Expression[] { expression = Expression.Parameter(typeof(ActivityContext), "env") };
            ParameterExpression[] expressionArray13 = new ParameterExpression[] { expression };
            assign.Value = new InArgument<int>(Expression.Lambda<Func<ActivityContext, int>>(Expression.Add(Expression.Call(Expression.Field(Expression.Constant(class_, typeof(<>c__DisplayClass15_0)), fieldof(<>c__DisplayClass15_0.index)), (MethodInfo) methodof(Variable<int>.Get, Variable<int>), expressionArray12), Expression.Constant(1, typeof(int))), expressionArray13));
            sequence3.Activities.Add(assign);
            @while.Body = sequence3;
            sequence2.Activities.Add(@while);
            item.Else = sequence2;
            sequence.Activities.Add(item);
            AssertValidation validation1 = new AssertValidation {
                Assertion = new InArgument<bool>(assertFlag),
                Message = new InArgument<string>(System.Activities.SR.CompensateWithNoTargetConstraint)
            };
            sequence.Activities.Add(validation1);
            action.Handler = sequence;
            constraint.Body = action;
            return constraint;
        }

        protected override void Execute(NativeActivityContext context)
        {
            CompensationExtension extension = context.GetExtension<CompensationExtension>();
            if (extension == null)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.CompensateWithoutCompensableActivity(base.DisplayName)));
            }
            if (this.Target.IsEmpty)
            {
                CompensationToken token = (CompensationToken) context.Properties.Find("System.Compensation.CompensationToken");
                CompensationTokenData data = (token == null) ? null : extension.Get(token.CompensationId);
                if ((data == null) || !data.IsTokenValidInSecondaryRoot)
                {
                    throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.InvalidCompensateActivityUsage(base.DisplayName)));
                }
                this.currentCompensationToken.Set(context, token);
                if (data.ExecutionTracker.Count > 0)
                {
                    context.ScheduleActivity(this.DefaultCompensation);
                }
            }
            else
            {
                CompensationToken token2 = this.Target.Get(context);
                CompensationTokenData data2 = (token2 == null) ? null : extension.Get(token2.CompensationId);
                if (token2 == null)
                {
                    throw FxTrace.Exception.Argument("Target", System.Activities.SR.InvalidCompensationToken(base.DisplayName));
                }
                if (!token2.CompensateCalled)
                {
                    if ((data2 == null) || (data2.CompensationState != CompensationState.Completed))
                    {
                        throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.CompensableActivityAlreadyConfirmedOrCompensated));
                    }
                    data2.CompensationState = CompensationState.Compensating;
                    token2.CompensateCalled = true;
                    context.ScheduleActivity(this.InternalCompensate);
                }
            }
        }

        internal override IList<Constraint> InternalGetConstraints() => 
            new List<Constraint>(1) { compensateWithNoTarget };

        [DefaultValue((string) null)]
        public InArgument<CompensationToken> Target { get; set; }

        private System.Activities.Statements.DefaultCompensation DefaultCompensation
        {
            get
            {
                if (this.defaultCompensation == null)
                {
                    System.Activities.Statements.DefaultCompensation compensation1 = new System.Activities.Statements.DefaultCompensation {
                        Target = new InArgument<CompensationToken>(this.currentCompensationToken)
                    };
                    this.defaultCompensation = compensation1;
                }
                return this.defaultCompensation;
            }
        }

        private System.Activities.Statements.InternalCompensate InternalCompensate
        {
            get
            {
                if (this.internalCompensate == null)
                {
                    System.Activities.Statements.InternalCompensate compensate1 = new System.Activities.Statements.InternalCompensate();
                    ArgumentValue<CompensationToken> expression = new ArgumentValue<CompensationToken> {
                        ArgumentName = "Target"
                    };
                    compensate1.Target = new InArgument<CompensationToken>(expression);
                    this.internalCompensate = compensate1;
                }
                return this.internalCompensate;
            }
        }
    }
}

