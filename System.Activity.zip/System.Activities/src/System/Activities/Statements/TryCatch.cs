﻿namespace System.Activities.Statements
{
    using System;
    using System.Activities;
    using System.Activities.DynamicUpdate;
    using System.Activities.Runtime;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.Runtime.Collections;
    using System.Runtime.CompilerServices;
    using System.Runtime.Serialization;
    using System.Windows.Markup;

    public sealed class TryCatch : NativeActivity
    {
        private CatchList catches;
        private Collection<Variable> variables;
        private Variable<TryCatchState> state = new Variable<TryCatchState>();
        private FaultCallback exceptionFromCatchOrFinallyHandler;
        internal const string FaultContextId = "{35ABC8C3-9AF1-4426-8293-A6DDBB6ED91D}";

        protected override void CacheMetadata(NativeActivityMetadata metadata)
        {
            if (this.Try != null)
            {
                metadata.AddChild(this.Try);
            }
            if (this.Finally != null)
            {
                metadata.AddChild(this.Finally);
            }
            Collection<ActivityDelegate> delegates = new Collection<ActivityDelegate>();
            if (this.catches != null)
            {
                foreach (Catch @catch in this.catches)
                {
                    ActivityDelegate action = @catch.GetAction();
                    if (action != null)
                    {
                        delegates.Add(action);
                    }
                }
            }
            metadata.AddImplementationVariable(this.state);
            metadata.SetDelegatesCollection(delegates);
            metadata.SetVariablesCollection(this.Variables);
            if ((this.Finally == null) && (this.Catches.Count == 0))
            {
                metadata.AddValidationError(System.Activities.SR.CatchOrFinallyExpected(base.DisplayName));
            }
        }

        protected override void Cancel(NativeActivityContext context)
        {
            if (!this.state.Get(context).SuppressCancel)
            {
                context.CancelChildren();
            }
        }

        protected override void Execute(NativeActivityContext context)
        {
            ExceptionPersistenceExtension extension = context.GetExtension<ExceptionPersistenceExtension>();
            if (((extension != null) && !extension.PersistExceptions) && !(context.Properties.FindAtCurrentScope("System.Activities.NoPersistProperty") is NoPersistProperty))
            {
                NoPersistProperty property = new NoPersistProperty(context.CurrentExecutor);
                context.Properties.Add("System.Activities.NoPersistProperty", property);
            }
            this.state.Set(context, new TryCatchState());
            if (this.Try != null)
            {
                context.ScheduleActivity(this.Try, new CompletionCallback(this.OnTryComplete), new FaultCallback(this.OnExceptionFromTry));
            }
            else
            {
                this.OnTryComplete(context, null);
            }
        }

        private Catch FindCatch(Exception exception)
        {
            Type c = exception.GetType();
            Catch @catch = null;
            foreach (Catch catch2 in this.Catches)
            {
                if (catch2.ExceptionType == c)
                {
                    return catch2;
                }
                if (catch2.ExceptionType.IsAssignableFrom(c))
                {
                    if (@catch != null)
                    {
                        if (catch2.ExceptionType.IsSubclassOf(@catch.ExceptionType))
                        {
                            @catch = catch2;
                        }
                    }
                    else
                    {
                        @catch = catch2;
                    }
                }
            }
            return @catch;
        }

        internal static Catch FindCatchActivity(Type typeToMatch, IList<Catch> catches)
        {
            foreach (Catch @catch in catches)
            {
                if (@catch.ExceptionType == typeToMatch)
                {
                    return @catch;
                }
            }
            return null;
        }

        private void OnCatchComplete(NativeActivityContext context, System.Activities.ActivityInstance completedInstance)
        {
            TryCatchState state = this.state.Get(context);
            state.SuppressCancel = true;
            if ((completedInstance != null) && (completedInstance.State != ActivityInstanceState.Closed))
            {
                state.ExceptionHandled = false;
            }
            context.Properties.Remove("{35ABC8C3-9AF1-4426-8293-A6DDBB6ED91D}");
            if (this.Finally != null)
            {
                context.ScheduleActivity(this.Finally, new CompletionCallback(this.OnFinallyComplete), this.ExceptionFromCatchOrFinallyHandler);
            }
            else
            {
                this.OnFinallyComplete(context, null);
            }
        }

        protected override void OnCreateDynamicUpdateMap(NativeActivityUpdateMapMetadata metadata, Activity originalActivity)
        {
            metadata.AllowUpdateInsideThisActivity();
        }

        private void OnExceptionFromCatchOrFinally(NativeActivityFaultContext context, Exception propagatedException, System.Activities.ActivityInstance propagatedFrom)
        {
            if (TD.TryCatchExceptionFromCatchOrFinallyIsEnabled())
            {
                TD.TryCatchExceptionFromCatchOrFinally(base.DisplayName);
            }
            this.state.Get(context).SuppressCancel = false;
        }

        private void OnExceptionFromTry(NativeActivityFaultContext context, Exception propagatedException, System.Activities.ActivityInstance propagatedFrom)
        {
            if (propagatedFrom.IsCancellationRequested)
            {
                if (TD.TryCatchExceptionDuringCancelationIsEnabled())
                {
                    TD.TryCatchExceptionDuringCancelation(base.DisplayName);
                }
                context.Abort(propagatedException);
                context.HandleFault();
            }
            else if (this.FindCatch(propagatedException) != null)
            {
                if (TD.TryCatchExceptionFromTryIsEnabled())
                {
                    TD.TryCatchExceptionFromTry(base.DisplayName, propagatedException.GetType().ToString());
                }
                context.CancelChild(propagatedFrom);
                TryCatchState state = this.state.Get(context);
                ExceptionPersistenceExtension extension = context.GetExtension<ExceptionPersistenceExtension>();
                if ((extension != null) && !extension.PersistExceptions)
                {
                    NoPersistProperty property = (NoPersistProperty) context.Properties.FindAtCurrentScope("System.Activities.NoPersistProperty");
                    if (property != null)
                    {
                        property.Enter();
                    }
                }
                state.CaughtException = context.CreateFaultContext();
                context.HandleFault();
            }
        }

        private void OnFinallyComplete(NativeActivityContext context, System.Activities.ActivityInstance completedInstance)
        {
            TryCatchState state = this.state.Get(context);
            if (context.IsCancellationRequested && !state.ExceptionHandled)
            {
                context.MarkCanceled();
            }
        }

        private void OnTryComplete(NativeActivityContext context, System.Activities.ActivityInstance completedInstance)
        {
            TryCatchState state = this.state.Get(context);
            state.SuppressCancel = true;
            if (state.CaughtException != null)
            {
                Catch @catch = this.FindCatch(state.CaughtException.Exception);
                if (@catch != null)
                {
                    state.ExceptionHandled = true;
                    if (@catch.GetAction() != null)
                    {
                        context.Properties.Add("{35ABC8C3-9AF1-4426-8293-A6DDBB6ED91D}", state.CaughtException, true);
                        @catch.ScheduleAction(context, state.CaughtException.Exception, new CompletionCallback(this.OnCatchComplete), this.ExceptionFromCatchOrFinallyHandler);
                        return;
                    }
                }
            }
            this.OnCatchComplete(context, null);
        }

        protected override void UpdateInstance(NativeActivityUpdateContext updateContext)
        {
            TryCatchState state = updateContext.GetValue<TryCatchState>(this.state);
            if (((state != null) && !state.SuppressCancel) && ((state.CaughtException != null) && (this.FindCatch(state.CaughtException.Exception) == null)))
            {
                updateContext.DisallowUpdate(System.Activities.SR.TryCatchInvalidStateForUpdate(state.CaughtException.Exception));
            }
        }

        public Collection<Variable> Variables
        {
            get
            {
                if (this.variables == null)
                {
                    ValidatingCollection<Variable> collection1 = new ValidatingCollection<Variable> {
                        OnAddValidationCallback = delegate (Variable item) {
                            if (item == null)
                            {
                                throw System.Activities.FxTrace.Exception.ArgumentNull("item");
                            }
                        }
                    };
                    this.variables = collection1;
                }
                return this.variables;
            }
        }

        [DefaultValue((string) null), DependsOn("Variables")]
        public Activity Try { get; set; }

        [DependsOn("Try")]
        public Collection<Catch> Catches
        {
            get
            {
                if (this.catches == null)
                {
                    this.catches = new CatchList();
                }
                return this.catches;
            }
        }

        [DefaultValue((string) null), DependsOn("Catches")]
        public Activity Finally { get; set; }

        private FaultCallback ExceptionFromCatchOrFinallyHandler
        {
            get
            {
                if (this.exceptionFromCatchOrFinallyHandler == null)
                {
                    this.exceptionFromCatchOrFinallyHandler = new FaultCallback(this.OnExceptionFromCatchOrFinally);
                }
                return this.exceptionFromCatchOrFinallyHandler;
            }
        }

        [Serializable, CompilerGenerated]
        private sealed class <>c
        {
            public static readonly TryCatch.<>c <>9 = new TryCatch.<>c();
            public static Action<Variable> <>9__7_0;

            internal void <get_Variables>b__7_0(Variable item)
            {
                if (item == null)
                {
                    throw System.Activities.FxTrace.Exception.ArgumentNull("item");
                }
            }
        }

        private class CatchList : ValidatingCollection<Catch>
        {
            public CatchList()
            {
                base.OnAddValidationCallback = delegate (Catch item) {
                    if (item == null)
                    {
                        throw System.Activities.FxTrace.Exception.ArgumentNull("item");
                    }
                };
            }

            protected override void InsertItem(int index, Catch item)
            {
                if (item == null)
                {
                    throw System.Activities.FxTrace.Exception.ArgumentNull("item");
                }
                if (TryCatch.FindCatchActivity(item.ExceptionType, base.Items) != null)
                {
                    throw System.Activities.FxTrace.Exception.Argument("item", System.Activities.SR.DuplicateCatchClause(item.ExceptionType.FullName));
                }
                base.InsertItem(index, item);
            }

            protected override void SetItem(int index, Catch item)
            {
                if (item == null)
                {
                    throw System.Activities.FxTrace.Exception.ArgumentNull("item");
                }
                Catch @catch = TryCatch.FindCatchActivity(item.ExceptionType, base.Items);
                if ((@catch != null) && (base[index] != @catch))
                {
                    throw System.Activities.FxTrace.Exception.Argument("item", System.Activities.SR.DuplicateCatchClause(item.ExceptionType.FullName));
                }
                base.SetItem(index, item);
            }

            [Serializable, CompilerGenerated]
            private sealed class <>c
            {
                public static readonly TryCatch.CatchList.<>c <>9 = new TryCatch.CatchList.<>c();
                public static Action<Catch> <>9__0_0;

                internal void <.ctor>b__0_0(Catch item)
                {
                    if (item == null)
                    {
                        throw System.Activities.FxTrace.Exception.ArgumentNull("item");
                    }
                }
            }
        }

        [DataContract]
        internal class TryCatchState
        {
            [DataMember(EmitDefaultValue=false)]
            public bool SuppressCancel { get; set; }

            [DataMember(EmitDefaultValue=false)]
            public FaultContext CaughtException { get; set; }

            [DataMember(EmitDefaultValue=false)]
            public bool ExceptionHandled { get; set; }
        }
    }
}

