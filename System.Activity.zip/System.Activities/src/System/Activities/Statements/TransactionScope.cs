﻿namespace System.Activities.Statements
{
    using System;
    using System.Activities;
    using System.Activities.Expressions;
    using System.Activities.Validation;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.Linq.Expressions;
    using System.Runtime.CompilerServices;
    using System.Transactions;
    using System.Windows.Markup;

    [ContentProperty("Body")]
    public sealed class TransactionScope : NativeActivity
    {
        private const System.Transactions.IsolationLevel defaultIsolationLevel = System.Transactions.IsolationLevel.Serializable;
        private InArgument<TimeSpan> timeout = new InArgument<TimeSpan>(TimeSpan.FromMinutes(1.0));
        private bool isTimeoutSetExplicitly;
        private Variable<RuntimeTransactionHandle> runtimeTransactionHandle = new Variable<RuntimeTransactionHandle>();
        private bool abortInstanceOnTransactionFailure = true;
        private bool abortInstanceFlagWasExplicitlySet;
        private Delay nestedScopeTimeoutWorkflow;
        private Variable<bool> delayWasScheduled = new Variable<bool>();
        private Variable<TimeSpan> nestedScopeTimeout = new Variable<TimeSpan>();
        private Variable<System.Activities.ActivityInstance> nestedScopeTimeoutActivityInstance = new Variable<System.Activities.ActivityInstance>();
        private static string runtimeTransactionHandlePropertyName = typeof(RuntimeTransactionHandle).FullName;
        private const string AbortInstanceOnTransactionFailurePropertyName = "AbortInstanceOnTransactionFailure";
        private const string IsolationLevelPropertyName = "IsolationLevel";
        private const string BodyPropertyName = "Body";

        public TransactionScope()
        {
            base.Constraints.Add(this.ProcessParentChainConstraints());
            base.Constraints.Add(this.ProcessChildSubtreeConstraints());
        }

        protected override void CacheMetadata(NativeActivityMetadata metadata)
        {
            RuntimeArgument argument = new RuntimeArgument("Timeout", typeof(TimeSpan), ArgumentDirection.In, false);
            metadata.Bind(this.Timeout, argument);
            Collection<RuntimeArgument> arguments = new Collection<RuntimeArgument> {
                argument
            };
            metadata.SetArgumentsCollection(arguments);
            metadata.AddImplementationChild(this.NestedScopeTimeoutWorkflow);
            if (this.Body != null)
            {
                metadata.AddChild(this.Body);
            }
            metadata.AddImplementationVariable(this.runtimeTransactionHandle);
            metadata.AddImplementationVariable(this.nestedScopeTimeout);
            metadata.AddImplementationVariable(this.delayWasScheduled);
            metadata.AddImplementationVariable(this.nestedScopeTimeoutActivityInstance);
        }

        protected override void Execute(NativeActivityContext context)
        {
            RuntimeTransactionHandle property = this.runtimeTransactionHandle.Get(context);
            RuntimeTransactionHandle handle2 = context.Properties.Find(runtimeTransactionHandlePropertyName) as RuntimeTransactionHandle;
            if (handle2 == null)
            {
                property.AbortInstanceOnTransactionFailure = this.AbortInstanceOnTransactionFailure;
                context.Properties.Add(property.ExecutionPropertyName, property);
            }
            else
            {
                if ((!handle2.IsRuntimeOwnedTransaction && this.abortInstanceFlagWasExplicitlySet) && (handle2.AbortInstanceOnTransactionFailure != this.AbortInstanceOnTransactionFailure))
                {
                    throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.AbortInstanceOnTransactionFailureDoesNotMatch));
                }
                if (handle2.SuppressTransaction)
                {
                    throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.CannotNestTransactionScopeWhenAmbientHandleIsSuppressed(base.DisplayName)));
                }
                property = handle2;
            }
            Transaction currentTransaction = property.GetCurrentTransaction(context);
            if (currentTransaction == null)
            {
                property.RequestTransactionContext(context, new Action<NativeActivityTransactionContext, object>(this.OnContextAcquired), null);
            }
            else
            {
                if (currentTransaction.IsolationLevel != this.IsolationLevel)
                {
                    throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.IsolationLevelValidation));
                }
                if (this.isTimeoutSetExplicitly)
                {
                    TimeSpan span = this.Timeout.Get(context);
                    this.delayWasScheduled.Set(context, true);
                    this.nestedScopeTimeout.Set(context, span);
                    this.nestedScopeTimeoutActivityInstance.Set(context, context.ScheduleActivity(this.NestedScopeTimeoutWorkflow, new CompletionCallback(this.OnDelayCompletion)));
                }
                this.ScheduleBody(context);
            }
        }

        private void OnCompletion(NativeActivityContext context, System.Activities.ActivityInstance instance)
        {
            RuntimeTransactionHandle handle = this.runtimeTransactionHandle.Get(context);
            if (this.delayWasScheduled.Get(context))
            {
                handle.CompleteTransaction(context, new BookmarkCallback(this.OnTransactionComplete));
            }
            else
            {
                handle.CompleteTransaction(context);
            }
        }

        private void OnContextAcquired(NativeActivityTransactionContext context, object state)
        {
            TimeSpan span = this.Timeout.Get(context);
            TransactionOptions options = new TransactionOptions {
                IsolationLevel = this.IsolationLevel,
                Timeout = span
            };
            context.SetRuntimeTransaction(new CommittableTransaction(options));
            this.ScheduleBody(context);
        }

        private void OnDelayCompletion(NativeActivityContext context, System.Activities.ActivityInstance instance)
        {
            if (instance.State == ActivityInstanceState.Closed)
            {
                RuntimeTransactionHandle handle = context.Properties.Find(runtimeTransactionHandlePropertyName) as RuntimeTransactionHandle;
                handle.GetCurrentTransaction(context).Rollback();
            }
        }

        private void OnTransactionComplete(NativeActivityContext context, Bookmark bookmark, object state)
        {
            System.Activities.ActivityInstance activityInstance = this.nestedScopeTimeoutActivityInstance.Get(context);
            if (activityInstance != null)
            {
                context.CancelChild(activityInstance);
            }
        }

        private Constraint ProcessChildSubtreeConstraints()
        {
            ParameterExpression expression;
            DelegateInArgument<System.Activities.Statements.TransactionScope> argument = new DelegateInArgument<System.Activities.Statements.TransactionScope> {
                Name = "element"
            };
            DelegateInArgument<ValidationContext> argument2 = new DelegateInArgument<ValidationContext> {
                Name = "validationContext"
            };
            DelegateInArgument<Activity> delegateArgument = new DelegateInArgument<Activity> {
                Name = "child"
            };
            Variable<bool> variable = new Variable<bool>();
            Constraint<System.Activities.Statements.TransactionScope> constraint = new Constraint<System.Activities.Statements.TransactionScope>();
            ActivityAction<System.Activities.Statements.TransactionScope, ValidationContext> action = new ActivityAction<System.Activities.Statements.TransactionScope, ValidationContext> {
                Argument1 = argument,
                Argument2 = argument2
            };
            Sequence sequence = new Sequence {
                Variables = { variable }
            };
            ForEach<Activity> item = new ForEach<Activity>();
            GetChildSubtree subtree1 = new GetChildSubtree {
                ValidationContext = argument2
            };
            item.Values = subtree1;
            ActivityAction<Activity> action2 = new ActivityAction<Activity> {
                Argument = delegateArgument
            };
            Sequence sequence2 = new Sequence();
            If @if = new If();
            Equal<Type, Type, bool> equal = new Equal<Type, Type, bool>();
            ObtainType type1 = new ObtainType {
                Input = new InArgument<Activity>(delegateArgument)
            };
            equal.Left = type1;
            ParameterExpression[] parameters = new ParameterExpression[] { expression = Expression.Parameter(typeof(ActivityContext), "context") };
            equal.Right = new InArgument<Type>(Expression.Lambda<Func<ActivityContext, Type>>(Expression.Constant(typeof(CompensableActivity), typeof(Type)), parameters));
            @if.Condition = equal;
            Assign<bool> assign1 = new Assign<bool> {
                To = new OutArgument<bool>(variable),
                Value = new InArgument<bool>(true)
            };
            @if.Then = assign1;
            sequence2.Activities.Add(@if);
            action2.Handler = sequence2;
            item.Body = action2;
            sequence.Activities.Add(item);
            AssertValidation validation1 = new AssertValidation();
            Not<bool, bool> not1 = new Not<bool, bool>();
            VariableValue<bool> value1 = new VariableValue<bool> {
                Variable = variable
            };
            not1.Operand = value1;
            validation1.Assertion = new InArgument<bool>(not1);
            validation1.Message = new InArgument<string>(System.Activities.SR.CompensableActivityInsideTransactionScopeActivity);
            validation1.PropertyName = "Body";
            sequence.Activities.Add(validation1);
            action.Handler = sequence;
            constraint.Body = action;
            return constraint;
        }

        private Constraint ProcessParentChainConstraints()
        {
            ParameterExpression expression;
            DelegateInArgument<System.Activities.Statements.TransactionScope> delegateArgument = new DelegateInArgument<System.Activities.Statements.TransactionScope> {
                Name = "element"
            };
            DelegateInArgument<ValidationContext> argument2 = new DelegateInArgument<ValidationContext> {
                Name = "validationContext"
            };
            DelegateInArgument<Activity> argument3 = new DelegateInArgument<Activity> {
                Name = "parent"
            };
            Constraint<System.Activities.Statements.TransactionScope> constraint = new Constraint<System.Activities.Statements.TransactionScope>();
            ActivityAction<System.Activities.Statements.TransactionScope, ValidationContext> action = new ActivityAction<System.Activities.Statements.TransactionScope, ValidationContext> {
                Argument1 = delegateArgument,
                Argument2 = argument2
            };
            Sequence sequence = new Sequence();
            ForEach<Activity> item = new ForEach<Activity>();
            GetParentChain chain1 = new GetParentChain {
                ValidationContext = argument2
            };
            item.Values = chain1;
            ActivityAction<Activity> action2 = new ActivityAction<Activity> {
                Argument = argument3
            };
            Sequence sequence2 = new Sequence();
            If @if = new If();
            Equal<Type, Type, bool> equal = new Equal<Type, Type, bool>();
            ObtainType type1 = new ObtainType {
                Input = argument3
            };
            equal.Left = type1;
            ParameterExpression[] parameters = new ParameterExpression[] { expression = Expression.Parameter(typeof(ActivityContext), "context") };
            equal.Right = new InArgument<Type>(Expression.Lambda<Func<ActivityContext, Type>>(Expression.Constant(typeof(System.Activities.Statements.TransactionScope), typeof(Type)), parameters));
            @if.Condition = equal;
            Sequence sequence1 = new Sequence();
            AssertValidation validation1 = new AssertValidation {
                IsWarning = 1
            };
            AbortInstanceFlagValidator validator1 = new AbortInstanceFlagValidator {
                ParentActivity = argument3,
                TransactionScope = new InArgument<System.Activities.Statements.TransactionScope>(delegateArgument)
            };
            validation1.Assertion = validator1;
            validation1.Message = new InArgument<string>(System.Activities.SR.AbortInstanceOnTransactionFailureDoesNotMatch);
            validation1.PropertyName = "AbortInstanceOnTransactionFailure";
            sequence1.Activities.Add(validation1);
            AssertValidation validation2 = new AssertValidation();
            IsolationLevelValidator validator2 = new IsolationLevelValidator {
                ParentActivity = argument3
            };
            InArgument<System.Transactions.IsolationLevel> argument6 = new InArgument<System.Transactions.IsolationLevel>();
            IsolationLevelValue value1 = new IsolationLevelValue {
                Scope = delegateArgument
            };
            argument6.Expression = value1;
            validator2.CurrentIsolationLevel = argument6;
            validation2.Assertion = validator2;
            validation2.Message = new InArgument<string>(System.Activities.SR.IsolationLevelValidation);
            validation2.PropertyName = "IsolationLevel";
            sequence1.Activities.Add(validation2);
            @if.Then = sequence1;
            sequence2.Activities.Add(@if);
            action2.Handler = sequence2;
            item.Body = action2;
            sequence.Activities.Add(item);
            action.Handler = sequence;
            constraint.Body = action;
            return constraint;
        }

        private void ScheduleBody(NativeActivityContext context)
        {
            if (this.Body != null)
            {
                context.ScheduleActivity(this.Body, new CompletionCallback(this.OnCompletion));
            }
        }

        [EditorBrowsable(EditorBrowsableState.Never)]
        public bool ShouldSerializeIsolationLevel() => 
            this.IsolationLevel > System.Transactions.IsolationLevel.Serializable;

        [EditorBrowsable(EditorBrowsableState.Never)]
        public bool ShouldSerializeTimeout() => 
            this.isTimeoutSetExplicitly;

        [DefaultValue((string) null)]
        public Activity Body { get; set; }

        [DefaultValue(true)]
        public bool AbortInstanceOnTransactionFailure
        {
            get => 
                this.abortInstanceOnTransactionFailure;
            set
            {
                this.abortInstanceOnTransactionFailure = value;
                this.abortInstanceFlagWasExplicitlySet = true;
            }
        }

        public System.Transactions.IsolationLevel IsolationLevel { get; set; }

        public InArgument<TimeSpan> Timeout
        {
            get => 
                this.timeout;
            set
            {
                this.timeout = value;
                this.isTimeoutSetExplicitly = true;
            }
        }

        private Delay NestedScopeTimeoutWorkflow
        {
            get
            {
                if (this.nestedScopeTimeoutWorkflow == null)
                {
                    Delay delay1 = new Delay {
                        Duration = new InArgument<TimeSpan>(this.nestedScopeTimeout)
                    };
                    this.nestedScopeTimeoutWorkflow = delay1;
                }
                return this.nestedScopeTimeoutWorkflow;
            }
        }

        protected override bool CanInduceIdle =>
            true;

        private class AbortInstanceFlagValidator : CodeActivity<bool>
        {
            protected override void CacheMetadata(CodeActivityMetadata metadata)
            {
                RuntimeArgument argument = new RuntimeArgument("ParentActivity", typeof(Activity), ArgumentDirection.In);
                if (this.ParentActivity == null)
                {
                    this.ParentActivity = new InArgument<Activity>();
                }
                metadata.Bind(this.ParentActivity, argument);
                RuntimeArgument argument2 = new RuntimeArgument("TransactionScope", typeof(System.Activities.Statements.TransactionScope), ArgumentDirection.In);
                if (this.TransactionScope == null)
                {
                    this.TransactionScope = new InArgument<System.Activities.Statements.TransactionScope>();
                }
                metadata.Bind(this.TransactionScope, argument2);
                RuntimeArgument argument3 = new RuntimeArgument("Result", typeof(bool), ArgumentDirection.Out);
                if (base.Result == null)
                {
                    base.Result = new OutArgument<bool>();
                }
                metadata.Bind(base.Result, argument3);
                Collection<RuntimeArgument> arguments = new Collection<RuntimeArgument> {
                    argument,
                    argument2,
                    argument3
                };
                metadata.SetArgumentsCollection(arguments);
            }

            protected override bool Execute(CodeActivityContext context)
            {
                Activity activity = this.ParentActivity.Get(context);
                if (activity == null)
                {
                    return true;
                }
                System.Activities.Statements.TransactionScope scope = activity as System.Activities.Statements.TransactionScope;
                System.Activities.Statements.TransactionScope scope2 = this.TransactionScope.Get(context);
                return ((scope.AbortInstanceOnTransactionFailure == scope2.AbortInstanceOnTransactionFailure) || !scope2.abortInstanceFlagWasExplicitlySet);
            }

            public InArgument<Activity> ParentActivity { get; set; }

            public InArgument<System.Activities.Statements.TransactionScope> TransactionScope { get; set; }
        }

        private class IsolationLevelValidator : CodeActivity<bool>
        {
            protected override void CacheMetadata(CodeActivityMetadata metadata)
            {
                RuntimeArgument argument = new RuntimeArgument("ParentActivity", typeof(Activity), ArgumentDirection.In);
                if (this.ParentActivity == null)
                {
                    this.ParentActivity = new InArgument<Activity>();
                }
                metadata.Bind(this.ParentActivity, argument);
                RuntimeArgument argument2 = new RuntimeArgument("CurrentIsolationLevel", typeof(IsolationLevel), ArgumentDirection.In);
                if (this.CurrentIsolationLevel == null)
                {
                    this.CurrentIsolationLevel = new InArgument<IsolationLevel>();
                }
                metadata.Bind(this.CurrentIsolationLevel, argument2);
                RuntimeArgument argument3 = new RuntimeArgument("Result", typeof(bool), ArgumentDirection.Out);
                if (base.Result == null)
                {
                    base.Result = new OutArgument<bool>();
                }
                metadata.Bind(base.Result, argument3);
                Collection<RuntimeArgument> arguments = new Collection<RuntimeArgument> {
                    argument,
                    argument2,
                    argument3
                };
                metadata.SetArgumentsCollection(arguments);
            }

            protected override bool Execute(CodeActivityContext context)
            {
                Activity activity = this.ParentActivity.Get(context);
                if (activity != null)
                {
                    System.Activities.Statements.TransactionScope scope = activity as System.Activities.Statements.TransactionScope;
                    if (scope.IsolationLevel != ((IsolationLevel) this.CurrentIsolationLevel.Get(context)))
                    {
                        return false;
                    }
                }
                return true;
            }

            public InArgument<Activity> ParentActivity { get; set; }

            public InArgument<IsolationLevel> CurrentIsolationLevel { get; set; }
        }

        private class IsolationLevelValue : CodeActivity<IsolationLevel>
        {
            protected override void CacheMetadata(CodeActivityMetadata metadata)
            {
                RuntimeArgument argument = new RuntimeArgument("Scope", typeof(System.Activities.Statements.TransactionScope), ArgumentDirection.In);
                if (this.Scope == null)
                {
                    this.Scope = new InArgument<System.Activities.Statements.TransactionScope>();
                }
                metadata.Bind(this.Scope, argument);
                RuntimeArgument argument2 = new RuntimeArgument("Result", typeof(IsolationLevel), ArgumentDirection.Out);
                if (base.Result == null)
                {
                    base.Result = new OutArgument<IsolationLevel>();
                }
                metadata.Bind(base.Result, argument2);
                Collection<RuntimeArgument> arguments = new Collection<RuntimeArgument> {
                    argument,
                    argument2
                };
                metadata.SetArgumentsCollection(arguments);
            }

            protected override IsolationLevel Execute(CodeActivityContext context) => 
                this.Scope.Get(context).IsolationLevel;

            public InArgument<System.Activities.Statements.TransactionScope> Scope { get; set; }
        }

        private class ObtainType : CodeActivity<Type>
        {
            protected override void CacheMetadata(CodeActivityMetadata metadata)
            {
                RuntimeArgument argument = new RuntimeArgument("Input", typeof(Activity), ArgumentDirection.In);
                if (this.Input == null)
                {
                    this.Input = new InArgument<Activity>();
                }
                metadata.Bind(this.Input, argument);
                RuntimeArgument argument2 = new RuntimeArgument("Result", typeof(Type), ArgumentDirection.Out);
                if (base.Result == null)
                {
                    base.Result = new OutArgument<Type>();
                }
                metadata.Bind(base.Result, argument2);
                Collection<RuntimeArgument> arguments = new Collection<RuntimeArgument> {
                    argument,
                    argument2
                };
                metadata.SetArgumentsCollection(arguments);
            }

            protected override Type Execute(CodeActivityContext context) => 
                this.Input.Get(context).GetType();

            public InArgument<Activity> Input { get; set; }
        }
    }
}

