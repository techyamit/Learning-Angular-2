﻿namespace System.Activities.Statements
{
    using System;
    using System.Activities;
    using System.Activities.DynamicUpdate;
    using System.Activities.Statements.Tracking;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.Linq;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;

    internal sealed class InternalState : NativeActivity<string>
    {
        private System.Activities.Statements.State state;
        private Collection<InternalTransition> internalTransitions;
        private Variable<int> currentRunningTriggers;
        private Variable<bool> isExiting;
        private Variable<Bookmark> evaluateConditionBookmark;
        private CompletionCallback onEntryComplete;
        private CompletionCallback onTriggerComplete;
        private CompletionCallback<bool> onConditionComplete;
        private CompletionCallback onExitComplete;
        private BookmarkCallback evaluateConditionCallback;
        private Dictionary<Activity, InternalTransition> triggerInternalTransitionMapping = new Dictionary<Activity, InternalTransition>();

        public InternalState(System.Activities.Statements.State state)
        {
            this.state = state;
            base.DisplayName = state.DisplayName;
            this.onEntryComplete = new CompletionCallback(this.OnEntryComplete);
            this.onTriggerComplete = new CompletionCallback(this.OnTriggerComplete);
            this.onConditionComplete = new CompletionCallback<bool>(this.OnConditionComplete);
            this.onExitComplete = new CompletionCallback(this.OnExitComplete);
            this.evaluateConditionCallback = new BookmarkCallback(this.StartEvaluateCondition);
            this.currentRunningTriggers = new Variable<int>();
            this.isExiting = new Variable<bool>();
            this.evaluateConditionBookmark = new Variable<Bookmark>();
            this.internalTransitions = new Collection<InternalTransition>();
            this.triggerInternalTransitionMapping = new Dictionary<Activity, InternalTransition>();
        }

        protected override void Abort(NativeActivityAbortContext context)
        {
            this.RemoveActiveBookmark(context);
            base.Abort(context);
        }

        private void AddEvaluateConditionBookmark(NativeActivityContext context)
        {
            Bookmark bookmark = context.CreateBookmark(this.evaluateConditionCallback, BookmarkOptions.MultipleResume);
            this.evaluateConditionBookmark.Set(context, bookmark);
            this.EventManager.Get(context).AddActiveBookmark(bookmark);
        }

        private static void AddTransitionData(NativeActivityMetadata metadata, InternalTransition internalTransition, Transition transition)
        {
            TransitionData item = new TransitionData();
            Activity<bool> condition = transition.Condition;
            item.Condition = condition;
            if (condition != null)
            {
                metadata.AddChild(condition);
            }
            Activity action = transition.Action;
            item.Action = action;
            if (action != null)
            {
                metadata.AddChild(action);
            }
            if (transition.To != null)
            {
                item.To = transition.To.InternalState;
            }
            internalTransition.TransitionDataList.Add(item);
        }

        protected override void CacheMetadata(NativeActivityMetadata metadata)
        {
            this.internalTransitions.Clear();
            if (this.Entry != null)
            {
                metadata.AddChild(this.Entry);
            }
            if (this.Exit != null)
            {
                metadata.AddChild(this.Exit);
            }
            this.ProcessTransitions(metadata);
            metadata.SetVariablesCollection(this.Variables);
            RuntimeArgument argument = new RuntimeArgument("EventManager", this.EventManager.ArgumentType, ArgumentDirection.In);
            metadata.Bind(this.EventManager, argument);
            Collection<RuntimeArgument> arguments = new Collection<RuntimeArgument> {
                argument
            };
            metadata.SetArgumentsCollection(arguments);
            metadata.AddImplementationVariable(this.currentRunningTriggers);
            metadata.AddImplementationVariable(this.isExiting);
            metadata.AddImplementationVariable(this.evaluateConditionBookmark);
        }

        protected override void Cancel(NativeActivityContext context)
        {
            this.RemoveActiveBookmark(context);
            base.Cancel(context);
        }

        protected override void Execute(NativeActivityContext context)
        {
            this.EventManager.Get(context).CurrentBeingProcessedEvent = null;
            this.isExiting.Set(context, false);
            this.ScheduleEntry(context);
        }

        private Activity<bool> GetCondition(int triggerIndex, int conditionIndex) => 
            this.internalTransitions[triggerIndex].TransitionDataList[conditionIndex].Condition;

        private InternalTransition GetInternalTransition(int triggerIndex) => 
            this.internalTransitions[triggerIndex];

        private string GetTo(int triggerIndex, int conditionIndex = 0) => 
            this.internalTransitions[triggerIndex].TransitionDataList[conditionIndex].To.StateId;

        private void OnConditionComplete(NativeActivityContext context, System.Activities.ActivityInstance completedInstance, bool result)
        {
            StateMachineEventManager eventManager = this.EventManager.Get(context);
            int triggedId = eventManager.CurrentBeingProcessedEvent.TriggedId;
            if (result)
            {
                this.TakeTransition(context, eventManager, triggedId);
            }
            else
            {
                int currentConditionIndex = eventManager.CurrentConditionIndex;
                InternalTransition internalTransition = this.GetInternalTransition(triggedId);
                currentConditionIndex++;
                if (currentConditionIndex < internalTransition.TransitionDataList.Count)
                {
                    eventManager.CurrentConditionIndex = currentConditionIndex;
                    context.ScheduleActivity<bool>(internalTransition.TransitionDataList[currentConditionIndex].Condition, this.onConditionComplete, null);
                }
                else
                {
                    context.ScheduleActivity(internalTransition.Trigger, this.onTriggerComplete);
                    this.currentRunningTriggers.Set(context, this.currentRunningTriggers.Get(context) + 1);
                    ProcessNextTriggerCompletedEvent(context, eventManager);
                }
            }
        }

        protected override void OnCreateDynamicUpdateMap(NativeActivityUpdateMapMetadata metadata, Activity originalActivity)
        {
            InternalState state = (InternalState) originalActivity;
            Activity match = metadata.GetMatch(this.Entry);
            Activity activity2 = metadata.GetMatch(this.Exit);
            if (((match != null) && (match != state.Entry)) || ((activity2 != null) && (activity2 != state.Exit)))
            {
                metadata.DisallowUpdateInsideThisActivity(System.Activities.SR.MovingActivitiesInStateBlockDU);
            }
            else
            {
                int num = 0;
                foreach (InternalTransition transition in state.internalTransitions)
                {
                    if (metadata.IsReferenceToImportedChild(transition.Trigger))
                    {
                        metadata.DisallowUpdateInsideThisActivity(System.Activities.SR.TriggerOrConditionIsReferenced);
                        return;
                    }
                    if (!transition.IsUnconditional)
                    {
                        foreach (TransitionData data in transition.TransitionDataList)
                        {
                            if (metadata.IsReferenceToImportedChild(data.Condition))
                            {
                                metadata.DisallowUpdateInsideThisActivity(System.Activities.SR.TriggerOrConditionIsReferenced);
                                return;
                            }
                        }
                    }
                }
                foreach (InternalTransition transition2 in this.internalTransitions)
                {
                    if (metadata.IsReferenceToImportedChild(transition2.Trigger))
                    {
                        metadata.DisallowUpdateInsideThisActivity(System.Activities.SR.TriggerOrConditionIsReferenced);
                        return;
                    }
                    Activity key = metadata.GetMatch(transition2.Trigger);
                    if (key != null)
                    {
                        if (state.triggerInternalTransitionMapping.TryGetValue(key, out InternalTransition transition3))
                        {
                            num++;
                            if (transition3.IsUnconditional)
                            {
                                if (ValidateDUInUnconditionalTransition(metadata, transition2, transition3, out string str))
                                {
                                    continue;
                                }
                                metadata.DisallowUpdateInsideThisActivity(str);
                            }
                            else if (transition2.IsUnconditional)
                            {
                                metadata.DisallowUpdateInsideThisActivity(System.Activities.SR.ChangeConditionalTransitionToUnconditionalBlockDU);
                            }
                            else
                            {
                                if (ValidateDUInConditionTransition(metadata, transition2, transition3, out string str2))
                                {
                                    continue;
                                }
                                metadata.DisallowUpdateInsideThisActivity(str2);
                            }
                        }
                        else
                        {
                            metadata.DisallowUpdateInsideThisActivity(System.Activities.SR.MovingActivitiesInStateBlockDU);
                        }
                        return;
                    }
                    foreach (TransitionData data2 in transition2.TransitionDataList)
                    {
                        if (((data2.Condition != null) && (metadata.GetMatch(data2.Condition) != null)) || ((data2.Action != null) && (metadata.GetMatch(data2.Action) != null)))
                        {
                            metadata.DisallowUpdateInsideThisActivity(System.Activities.SR.ChangingTriggerOrUseOriginalConditionActionBlockDU);
                            return;
                        }
                    }
                }
                if (num != state.internalTransitions.Count)
                {
                    metadata.DisallowUpdateInsideThisActivity(System.Activities.SR.RemovingTransitionsBlockDU);
                }
            }
        }

        private void OnEntryComplete(NativeActivityContext context, System.Activities.ActivityInstance instance)
        {
            ProcessNextTriggerCompletedEvent(context, this.EventManager.Get(context));
            this.ScheduleTriggers(context);
        }

        private void OnExitComplete(NativeActivityContext context, System.Activities.ActivityInstance instance)
        {
            this.ScheduleAction(context);
        }

        private void OnTriggerComplete(NativeActivityContext context, System.Activities.ActivityInstance completedInstance)
        {
            int num = this.currentRunningTriggers.Get(context);
            this.currentRunningTriggers.Set(context, --num);
            bool flag = this.isExiting.Get(context);
            if ((!context.IsCancellationRequested && (num == 0)) & flag)
            {
                this.ScheduleExit(context);
            }
            else if (completedInstance.State == ActivityInstanceState.Closed)
            {
                InternalTransition transition = null;
                this.triggerInternalTransitionMapping.TryGetValue(completedInstance.Activity, out transition);
                StateMachineEventManager eventManager = this.EventManager.Get(context);
                TriggerCompletedEvent completedEvent = new TriggerCompletedEvent {
                    Bookmark = this.evaluateConditionBookmark.Get(context),
                    TriggedId = transition.InternalTransitionIndex
                };
                eventManager.RegisterCompletedEvent(completedEvent, out bool flag2);
                if (flag2)
                {
                    ProcessNextTriggerCompletedEvent(context, eventManager);
                }
            }
        }

        private void PrepareForExit(NativeActivityContext context, string targetStateId)
        {
            ReadOnlyCollection<System.Activities.ActivityInstance> children = context.GetChildren();
            base.Result.Set(context, targetStateId);
            this.isExiting.Set(context, true);
            if (children.Count > 0)
            {
                context.CancelChildren();
            }
            else
            {
                this.ScheduleExit(context);
            }
        }

        private static void ProcessNextTriggerCompletedEvent(NativeActivityContext context, StateMachineEventManager eventManager)
        {
            eventManager.CurrentBeingProcessedEvent = null;
            eventManager.OnTransition = false;
            TriggerCompletedEvent nextCompletedEvent = eventManager.GetNextCompletedEvent();
            if (nextCompletedEvent != null)
            {
                context.GetExtension<StateMachineExtension>().ResumeBookmark(nextCompletedEvent.Bookmark);
            }
        }

        private void ProcessTransitions(NativeActivityMetadata metadata)
        {
            for (int i = 0; i < this.Transitions.Count; i++)
            {
                Transition transition = this.Transitions[i];
                InternalTransition transition2 = null;
                Activity activeTrigger = transition.ActiveTrigger;
                if (!this.triggerInternalTransitionMapping.TryGetValue(activeTrigger, out transition2))
                {
                    metadata.AddChild(activeTrigger);
                    transition2 = new InternalTransition {
                        Trigger = activeTrigger,
                        InternalTransitionIndex = this.internalTransitions.Count
                    };
                    this.triggerInternalTransitionMapping.Add(activeTrigger, transition2);
                    this.internalTransitions.Add(transition2);
                }
                AddTransitionData(metadata, transition2, transition);
            }
        }

        private void RemoveActiveBookmark(ActivityContext context)
        {
            StateMachineEventManager manager = this.EventManager.Get(context);
            Bookmark bookmark = this.evaluateConditionBookmark.Get(context);
            if (bookmark != null)
            {
                manager.RemoveActiveBookmark(bookmark);
            }
        }

        private void RemoveBookmarks(NativeActivityContext context)
        {
            context.RemoveAllBookmarks();
            this.RemoveActiveBookmark(context);
        }

        private void RescheduleNewlyAddedTriggers(NativeActivityUpdateContext updateContext)
        {
            List<Activity> list = new List<Activity>();
            foreach (InternalTransition transition in this.internalTransitions)
            {
                if (updateContext.IsNewlyAdded(transition.Trigger))
                {
                    list.Add(transition.Trigger);
                }
            }
            foreach (Activity activity in list)
            {
                updateContext.ScheduleActivity(activity, this.onTriggerComplete);
            }
            updateContext.SetValue<int>(this.currentRunningTriggers, updateContext.GetValue<int>(this.currentRunningTriggers) + list.Count);
        }

        private void ScheduleAction(NativeActivityContext context)
        {
            StateMachineEventManager manager = this.EventManager.Get(context);
            if (manager.IsReferredByBeingProcessedEvent(this.evaluateConditionBookmark.Get(context)))
            {
                Activity action = this.GetInternalTransition(manager.CurrentBeingProcessedEvent.TriggedId).TransitionDataList[(-1 == manager.CurrentConditionIndex) ? 0 : manager.CurrentConditionIndex].Action;
                if (action != null)
                {
                    context.ScheduleActivity(action);
                }
            }
            this.RemoveBookmarks(context);
        }

        private void ScheduleEntry(NativeActivityContext context)
        {
            StateMachineStateRecord record = new StateMachineStateRecord {
                StateMachineName = this.StateMachineName,
                StateName = base.DisplayName
            };
            context.Track(record);
            if (this.Entry != null)
            {
                context.ScheduleActivity(this.Entry, this.onEntryComplete);
            }
            else
            {
                this.onEntryComplete(context, null);
            }
        }

        private void ScheduleExit(NativeActivityContext context)
        {
            if (this.Exit != null)
            {
                context.ScheduleActivity(this.Exit, this.onExitComplete);
            }
            else
            {
                this.onExitComplete(context, null);
            }
        }

        private void ScheduleTriggers(NativeActivityContext context)
        {
            if (!this.IsFinal)
            {
                this.AddEvaluateConditionBookmark(context);
            }
            if (this.internalTransitions.Count > 0)
            {
                foreach (InternalTransition transition in this.internalTransitions)
                {
                    context.ScheduleActivity(transition.Trigger, this.onTriggerComplete);
                }
                this.currentRunningTriggers.Set(context, this.currentRunningTriggers.Get(context) + this.internalTransitions.Count);
            }
        }

        private void StartEvaluateCondition(NativeActivityContext context, Bookmark bookmark, object value)
        {
            StateMachineEventManager eventManager = this.EventManager.Get(context);
            int triggedId = eventManager.CurrentBeingProcessedEvent.TriggedId;
            if (this.GetInternalTransition(triggedId).IsUnconditional)
            {
                eventManager.CurrentConditionIndex = -1;
                this.TakeTransition(context, eventManager, triggedId);
            }
            else
            {
                eventManager.CurrentConditionIndex = 0;
                context.ScheduleActivity<bool>(this.GetCondition(triggedId, eventManager.CurrentConditionIndex), this.onConditionComplete, null);
            }
        }

        private void TakeTransition(NativeActivityContext context, StateMachineEventManager eventManager, int triggerId)
        {
            this.EventManager.Get(context).OnTransition = true;
            if (this.GetInternalTransition(triggerId).IsUnconditional)
            {
                this.PrepareForExit(context, this.GetTo(triggerId, 0));
            }
            else
            {
                this.PrepareForExit(context, this.GetTo(triggerId, eventManager.CurrentConditionIndex));
            }
        }

        private bool UpdateEventManager(NativeActivityUpdateContext updateContext, StateMachineEventManager eventManager)
        {
            int num = 0;
            int triggedId = -2147483648;
            int currentConditionIndex = -2147483648;
            bool flag = eventManager.CurrentBeingProcessedEvent == null;
            foreach (InternalTransition transition in this.internalTransitions)
            {
                object savedOriginalValue = updateContext.GetSavedOriginalValue(transition.Trigger);
                if (savedOriginalValue != null)
                {
                    if ((eventManager.CurrentBeingProcessedEvent != null) && (eventManager.CurrentBeingProcessedEvent.TriggedId == ((int) savedOriginalValue)))
                    {
                        if (eventManager.CurrentConditionIndex == -1)
                        {
                            if (!transition.IsUnconditional)
                            {
                                updateContext.DisallowUpdate(System.Activities.SR.ChangeTransitionTypeDuringTransitioningBlockDU);
                                return false;
                            }
                            triggedId = eventManager.CurrentBeingProcessedEvent.TriggedId;
                            currentConditionIndex = 0;
                            eventManager.CurrentBeingProcessedEvent.TriggedId = transition.InternalTransitionIndex;
                            if (updateContext.GetValue<bool>(this.isExiting))
                            {
                                updateContext.SetValue(base.Result, this.GetTo(transition.InternalTransitionIndex, 0));
                            }
                            flag = true;
                        }
                        else if ((eventManager.CurrentConditionIndex >= 0) && !transition.IsUnconditional)
                        {
                            for (int i = 0; i < transition.TransitionDataList.Count; i++)
                            {
                                Activity condition = transition.TransitionDataList[i].Condition;
                                int? nullable2 = updateContext.GetSavedOriginalValue(condition) as int?;
                                if ((eventManager.CurrentConditionIndex == nullable2.GetValueOrDefault()) ? nullable2.HasValue : false)
                                {
                                    triggedId = eventManager.CurrentBeingProcessedEvent.TriggedId;
                                    currentConditionIndex = eventManager.CurrentConditionIndex;
                                    eventManager.CurrentBeingProcessedEvent.TriggedId = transition.InternalTransitionIndex;
                                    eventManager.CurrentConditionIndex = i;
                                    if (updateContext.GetValue<bool>(this.isExiting))
                                    {
                                        updateContext.SetValue(base.Result, this.GetTo(transition.InternalTransitionIndex, i));
                                    }
                                    flag = true;
                                    break;
                                }
                            }
                        }
                    }
                    foreach (TriggerCompletedEvent event2 in eventManager.Queue)
                    {
                        if (((int) savedOriginalValue) == event2.TriggedId)
                        {
                            event2.TriggedId = transition.InternalTransitionIndex;
                            num++;
                        }
                    }
                }
            }
            if (eventManager.Queue.Count<TriggerCompletedEvent>() != num)
            {
                return false;
            }
            return flag;
        }

        protected override void UpdateInstance(NativeActivityUpdateContext updateContext)
        {
            StateMachineEventManager eventManager = updateContext.GetValue(this.EventManager) as StateMachineEventManager;
            if ((eventManager.CurrentBeingProcessedEvent != null) || eventManager.Queue.Any<TriggerCompletedEvent>())
            {
                if (!this.UpdateEventManager(updateContext, eventManager))
                {
                    updateContext.DisallowUpdate(System.Activities.SR.DUTriggerOrConditionChangedDuringTransitioning);
                }
                else if (!updateContext.GetValue<bool>(this.isExiting))
                {
                    this.RescheduleNewlyAddedTriggers(updateContext);
                }
            }
            else if (updateContext.GetValue<int>(this.currentRunningTriggers) > 0)
            {
                this.RescheduleNewlyAddedTriggers(updateContext);
            }
        }

        private static bool ValidateDUInConditionTransition(NativeActivityUpdateMapMetadata metadata, InternalTransition updatedTransition, InternalTransition originalTransition, out string errorMessage)
        {
            errorMessage = string.Empty;
            foreach (TransitionData data in updatedTransition.TransitionDataList)
            {
                if (metadata.IsReferenceToImportedChild(data.Condition))
                {
                    errorMessage = System.Activities.SR.TriggerOrConditionIsReferenced;
                    return false;
                }
                Activity match = metadata.GetMatch(data.Condition);
                if ((match == null) && (metadata.GetMatch(data.Action) != null))
                {
                    errorMessage = System.Activities.SR.MovingActivitiesInStateBlockDU;
                    return false;
                }
                if (match != null)
                {
                    bool flag2 = false;
                    for (int i = 0; i < originalTransition.TransitionDataList.Count; i++)
                    {
                        if (originalTransition.TransitionDataList[i].Condition == match)
                        {
                            flag2 = true;
                            TransitionData data2 = originalTransition.TransitionDataList[i];
                            Activity action = data2.Action;
                            Activity activity3 = metadata.GetMatch(data.Action);
                            if ((activity3 != null) && (action != activity3))
                            {
                                errorMessage = System.Activities.SR.MovingActivitiesInStateBlockDU;
                                return false;
                            }
                            metadata.SaveOriginalValue(updatedTransition.Trigger, originalTransition.InternalTransitionIndex);
                            metadata.SaveOriginalValue(data.Condition, i);
                        }
                    }
                    if (!flag2)
                    {
                        errorMessage = System.Activities.SR.DUDisallowIfCannotFindingMatchingCondition;
                        return false;
                    }
                }
            }
            return true;
        }

        private static bool ValidateDUInUnconditionalTransition(NativeActivityUpdateMapMetadata metadata, InternalTransition updatedTransition, InternalTransition originalTransition, out string errorMessage)
        {
            Activity action = originalTransition.TransitionDataList[0].Action;
            foreach (TransitionData data in updatedTransition.TransitionDataList)
            {
                Activity updatedChild = data.Action;
                Activity match = metadata.GetMatch(updatedChild);
                Activity activity4 = metadata.GetMatch(data.Condition);
                if (((action == null) && (match != null)) || (((action != null) && (match != null)) && (action != match)))
                {
                    errorMessage = System.Activities.SR.MovingActivitiesInStateBlockDU;
                    return false;
                }
            }
            errorMessage = string.Empty;
            metadata.SaveOriginalValue(updatedTransition.Trigger, originalTransition.InternalTransitionIndex);
            return true;
        }

        [RequiredArgument]
        public InArgument<StateMachineEventManager> EventManager { get; set; }

        public Activity Entry =>
            this.state.Entry;

        public Activity Exit =>
            this.state.Exit;

        [DefaultValue(false)]
        public bool IsFinal =>
            this.state.IsFinal;

        public string StateId =>
            this.state.StateId;

        public Collection<Transition> Transitions =>
            this.state.Transitions;

        public Collection<Variable> Variables =>
            this.state.Variables;

        public string StateMachineName =>
            this.state.StateMachineName;

        protected override bool CanInduceIdle =>
            true;
    }
}

