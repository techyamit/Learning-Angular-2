﻿namespace System.Activities.Statements
{
    using System;
    using System.Activities;
    using System.Activities.DynamicUpdate;
    using System.Collections.ObjectModel;
    using System.Runtime.Collections;
    using System.Runtime.CompilerServices;
    using System.Windows.Markup;

    [ContentProperty("Activities")]
    public sealed class Sequence : NativeActivity
    {
        private Collection<Activity> activities;
        private Collection<Variable> variables;
        private Variable<int> lastIndexHint = new Variable<int>();
        private CompletionCallback onChildComplete;

        public Sequence()
        {
            this.onChildComplete = new CompletionCallback(this.InternalExecute);
        }

        protected override void CacheMetadata(NativeActivityMetadata metadata)
        {
            metadata.SetChildrenCollection(this.Activities);
            metadata.SetVariablesCollection(this.Variables);
            metadata.AddImplementationVariable(this.lastIndexHint);
        }

        protected override void Execute(NativeActivityContext context)
        {
            if ((this.activities != null) && (this.Activities.Count > 0))
            {
                Activity activity = this.Activities[0];
                context.ScheduleActivity(activity, this.onChildComplete);
            }
        }

        private void InternalExecute(NativeActivityContext context, System.Activities.ActivityInstance completedInstance)
        {
            int index = this.lastIndexHint.Get(context);
            if ((index >= this.Activities.Count) || (this.Activities[index] != completedInstance.Activity))
            {
                index = this.Activities.IndexOf(completedInstance.Activity);
            }
            int num2 = index + 1;
            if (num2 != this.Activities.Count)
            {
                Activity activity = this.Activities[num2];
                context.ScheduleActivity(activity, this.onChildComplete);
                this.lastIndexHint.Set(context, num2);
            }
        }

        protected override void OnCreateDynamicUpdateMap(NativeActivityUpdateMapMetadata metadata, Activity originalActivity)
        {
            for (int i = 0; i < (this.Activities.Count - 1); i++)
            {
                for (int j = i + 1; j < this.Activities.Count; j++)
                {
                    if (this.Activities[i] == this.Activities[j])
                    {
                        metadata.DisallowUpdateInsideThisActivity(System.Activities.SR.SequenceDuplicateReferences);
                        break;
                    }
                }
            }
        }

        public Collection<Variable> Variables
        {
            get
            {
                if (this.variables == null)
                {
                    ValidatingCollection<Variable> collection1 = new ValidatingCollection<Variable> {
                        OnAddValidationCallback = delegate (Variable item) {
                            if (item == null)
                            {
                                throw FxTrace.Exception.ArgumentNull("item");
                            }
                        }
                    };
                    this.variables = collection1;
                }
                return this.variables;
            }
        }

        [DependsOn("Variables")]
        public Collection<Activity> Activities
        {
            get
            {
                if (this.activities == null)
                {
                    ValidatingCollection<Activity> collection1 = new ValidatingCollection<Activity> {
                        OnAddValidationCallback = delegate (Activity item) {
                            if (item == null)
                            {
                                throw FxTrace.Exception.ArgumentNull("item");
                            }
                        }
                    };
                    this.activities = collection1;
                }
                return this.activities;
            }
        }

        [Serializable, CompilerGenerated]
        private sealed class <>c
        {
            public static readonly Sequence.<>c <>9 = new Sequence.<>c();
            public static Action<Variable> <>9__6_0;
            public static Action<Activity> <>9__8_0;

            internal void <get_Activities>b__8_0(Activity item)
            {
                if (item == null)
                {
                    throw FxTrace.Exception.ArgumentNull("item");
                }
            }

            internal void <get_Variables>b__6_0(Variable item)
            {
                if (item == null)
                {
                    throw FxTrace.Exception.ArgumentNull("item");
                }
            }
        }
    }
}

