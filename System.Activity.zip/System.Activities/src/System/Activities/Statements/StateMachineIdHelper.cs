﻿namespace System.Activities.Statements
{
    using System;
    using System.Globalization;

    internal static class StateMachineIdHelper
    {
        internal const char StateIdSeparator = ':';

        public static string GenerateStateId(string parentId, int index) => 
            parentId + ":" + index.ToString(CultureInfo.InvariantCulture);

        public static string GenerateTransitionId(string stateid, int transitionIndex) => 
            stateid + ":" + transitionIndex.ToString(CultureInfo.InvariantCulture);

        public static int GetChildStateIndex(string stateId, string descendantId)
        {
            char[] separator = new char[] { ':' };
            string[] strArray = descendantId.Split(separator);
            char[] chArray2 = new char[] { ':' };
            string[] strArray2 = stateId.Split(chArray2);
            return int.Parse(strArray[strArray2.Length], CultureInfo.InvariantCulture);
        }

        public static bool IsAncestor(string state1Id, string state2Id)
        {
            if (string.IsNullOrEmpty(state2Id))
            {
                return false;
            }
            return state2Id.StartsWith(state1Id + ":", StringComparison.Ordinal);
        }
    }
}

