﻿namespace System.Activities.Statements
{
    using System;
    using System.Activities;
    using System.Activities.Expressions;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Globalization;
    using System.Linq;
    using System.Reflection;
    using System.Runtime;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Threading;

    internal sealed class MethodResolver
    {
        private static readonly BindingFlags staticBindingFlags = (BindingFlags.InvokeMethod | BindingFlags.Public | BindingFlags.Static);
        private static readonly BindingFlags instanceBindingFlags = (BindingFlags.InvokeMethod | BindingFlags.Public | BindingFlags.Instance);
        private static readonly string staticString = "static";
        private static readonly string instanceString = "instance";
        private MethodInfo syncMethod;
        private MethodInfo beginMethod;
        private MethodInfo endMethod;

        public void DetermineMethodInfo(CodeActivityMetadata metadata, MruCache<MethodInfo, Func<object, object[], object>> funcCache, ReaderWriterLockSlim locker, ref MethodExecutor methodExecutor)
        {
            bool flag = false;
            MethodExecutor executor = methodExecutor;
            methodExecutor = null;
            if (string.IsNullOrEmpty(this.MethodName))
            {
                metadata.AddValidationError(System.Activities.SR.ActivityPropertyMustBeSet("MethodName", this.Parent.DisplayName));
                flag = true;
            }
            Type targetType = this.TargetType;
            if (((targetType != null) && (this.TargetObject != null)) && !this.TargetObject.IsEmpty)
            {
                metadata.AddValidationError(System.Activities.SR.TargetTypeAndTargetObjectAreMutuallyExclusive(this.Parent.GetType().Name, this.Parent.DisplayName));
                flag = true;
            }
            BindingFlags bindingFlags = (this.TargetType != null) ? staticBindingFlags : instanceBindingFlags;
            string str = (bindingFlags == staticBindingFlags) ? staticString : instanceString;
            if (targetType == null)
            {
                if ((this.TargetObject != null) && !this.TargetObject.IsEmpty)
                {
                    targetType = this.TargetObject.ArgumentType;
                }
                else
                {
                    metadata.AddValidationError(System.Activities.SR.OneOfTwoPropertiesMustBeSet("TargetObject", "TargetType", this.Parent.GetType().Name, this.Parent.DisplayName));
                    flag = true;
                }
            }
            if (!flag)
            {
                MethodInfo info;
                Type[] parameterTypes = this.Parameters.Select<Argument, Type>(delegate (Argument argument) {
                    if (argument.Direction != ArgumentDirection.In)
                    {
                        return argument.ArgumentType.MakeByRefType();
                    }
                    return argument.ArgumentType;
                }).ToArray<Type>();
                Type[] genericTypeArguments = this.GenericTypeArguments.ToArray<Type>();
                InheritanceAndParamArrayAwareBinder methodBinder = new InheritanceAndParamArrayAwareBinder(targetType, genericTypeArguments, this.Parent);
                Type resultType = this.ResultType;
                if (this.RunAsynchronously)
                {
                    int length = parameterTypes.Length;
                    Type[] typeArray3 = new Type[length + 2];
                    for (int i = 0; i < length; i++)
                    {
                        typeArray3[i] = parameterTypes[i];
                    }
                    typeArray3[length] = typeof(AsyncCallback);
                    typeArray3[length + 1] = typeof(object);
                    Type[] typeArray4 = new Type[] { typeof(IAsyncResult) };
                    this.beginMethod = this.Resolve(targetType, "Begin" + this.MethodName, bindingFlags, methodBinder, typeArray3, genericTypeArguments, true);
                    if ((this.beginMethod != null) && !this.beginMethod.ReturnType.Equals(typeof(IAsyncResult)))
                    {
                        this.beginMethod = null;
                    }
                    this.endMethod = this.Resolve(targetType, "End" + this.MethodName, bindingFlags, methodBinder, typeArray4, genericTypeArguments, true);
                    if (((this.endMethod != null) && (resultType != null)) && !System.Runtime.TypeHelper.AreTypesCompatible(this.endMethod.ReturnType, resultType))
                    {
                        metadata.AddValidationError(System.Activities.SR.ReturnTypeIncompatible(this.endMethod.ReturnType.Name, this.MethodName, targetType.Name, this.Parent.DisplayName, resultType.Name));
                        this.endMethod = null;
                        return;
                    }
                    if (((this.beginMethod != null) && (this.endMethod != null)) && (this.beginMethod.IsStatic == this.endMethod.IsStatic))
                    {
                        if (!(executor is AsyncPatternMethodExecutor) || !((AsyncPatternMethodExecutor) executor).IsTheSame(this.beginMethod, this.endMethod))
                        {
                            methodExecutor = new AsyncPatternMethodExecutor(metadata, this.beginMethod, this.endMethod, this.Parent, this.TargetType, this.TargetObject, this.Parameters, this.Result, funcCache, locker);
                            return;
                        }
                        methodExecutor = new AsyncPatternMethodExecutor((AsyncPatternMethodExecutor) executor, this.TargetType, this.TargetObject, this.Parameters, this.Result);
                        return;
                    }
                }
                try
                {
                    info = this.Resolve(targetType, this.MethodName, bindingFlags, methodBinder, parameterTypes, genericTypeArguments, false);
                }
                catch (AmbiguousMatchException)
                {
                    metadata.AddValidationError(System.Activities.SR.DuplicateMethodFound(targetType.Name, str, this.MethodName, this.Parent.DisplayName));
                    return;
                }
                if (info == null)
                {
                    metadata.AddValidationError(System.Activities.SR.PublicMethodWithMatchingParameterDoesNotExist(targetType.Name, str, this.MethodName, this.Parent.DisplayName));
                }
                else if ((resultType != null) && !System.Runtime.TypeHelper.AreTypesCompatible(info.ReturnType, resultType))
                {
                    metadata.AddValidationError(System.Activities.SR.ReturnTypeIncompatible(info.ReturnType.Name, this.MethodName, targetType.Name, this.Parent.DisplayName, resultType.Name));
                }
                else
                {
                    this.syncMethod = info;
                    if (this.RunAsynchronously)
                    {
                        if (!(executor is AsyncWaitCallbackMethodExecutor) || !((AsyncWaitCallbackMethodExecutor) executor).IsTheSame(this.syncMethod))
                        {
                            methodExecutor = new AsyncWaitCallbackMethodExecutor(metadata, this.syncMethod, this.Parent, this.TargetType, this.TargetObject, this.Parameters, this.Result, funcCache, locker);
                        }
                        else
                        {
                            methodExecutor = new AsyncWaitCallbackMethodExecutor((AsyncWaitCallbackMethodExecutor) executor, this.TargetType, this.TargetObject, this.Parameters, this.Result);
                        }
                    }
                    else if (!(executor is SyncMethodExecutor) || !((SyncMethodExecutor) executor).IsTheSame(this.syncMethod))
                    {
                        methodExecutor = new SyncMethodExecutor(metadata, this.syncMethod, this.Parent, this.TargetType, this.TargetObject, this.Parameters, this.Result, funcCache, locker);
                    }
                    else
                    {
                        methodExecutor = new SyncMethodExecutor((SyncMethodExecutor) executor, this.TargetType, this.TargetObject, this.Parameters, this.Result);
                    }
                }
            }
        }

        private static bool HaveParameterArray(ParameterInfo[] parameters)
        {
            if (parameters.Length != 0)
            {
                ParameterInfo info = parameters[parameters.Length - 1];
                return (info.GetCustomAttributes(typeof(ParamArrayAttribute), true).Length != 0);
            }
            return false;
        }

        private static MethodInfo Instantiate(MethodInfo method, Type[] genericTypeArguments)
        {
            if (method.ContainsGenericParameters && (method.GetGenericArguments().Length == genericTypeArguments.Length))
            {
                try
                {
                    return method.MakeGenericMethod(genericTypeArguments);
                }
                catch (ArgumentException)
                {
                    return null;
                }
            }
            return null;
        }

        public void RegisterParameters(IList<RuntimeArgument> arguments)
        {
            bool flag = (this.RunAsynchronously && (this.beginMethod != null)) && (this.endMethod != null);
            if ((this.syncMethod != null) | flag)
            {
                ParameterInfo[] parameters;
                int length;
                string name = "";
                bool flag2 = false;
                if (flag)
                {
                    parameters = this.beginMethod.GetParameters();
                    length = parameters.Length - 2;
                }
                else
                {
                    parameters = this.syncMethod.GetParameters();
                    flag2 = HaveParameterArray(parameters);
                    if (flag2)
                    {
                        length = parameters.Length - 1;
                        name = parameters[length].Name;
                    }
                    else
                    {
                        length = parameters.Length;
                    }
                }
                for (int i = 0; i < length; i++)
                {
                    string name = parameters[i].Name;
                    if (string.IsNullOrEmpty(name))
                    {
                        name = "Parameter" + i;
                    }
                    RuntimeArgument argument = new RuntimeArgument(name, this.Parameters[i].ArgumentType, this.Parameters[i].Direction, true);
                    Argument.Bind(this.Parameters[i], argument);
                    arguments.Add(argument);
                    if (((!flag & flag2) && name.StartsWith(name, false, null)) && int.TryParse(name.Substring(name.Length), NumberStyles.Integer, NumberFormatInfo.CurrentInfo, out _))
                    {
                        name = name + "_";
                    }
                }
                if (!flag & flag2)
                {
                    int num4 = this.Parameters.Count - length;
                    for (int j = 0; j < num4; j++)
                    {
                        string name = name + j;
                        int num6 = length + j;
                        RuntimeArgument argument = new RuntimeArgument(name, this.Parameters[num6].ArgumentType, this.Parameters[num6].Direction, true);
                        Argument.Bind(this.Parameters[num6], argument);
                        arguments.Add(argument);
                    }
                }
            }
            else
            {
                for (int i = 0; i < this.Parameters.Count; i++)
                {
                    RuntimeArgument argument = new RuntimeArgument("argument" + i, this.Parameters[i].ArgumentType, this.Parameters[i].Direction, true);
                    Argument.Bind(this.Parameters[i], argument);
                    arguments.Add(argument);
                }
            }
        }

        private MethodInfo Resolve(Type targetType, string methodName, BindingFlags bindingFlags, InheritanceAndParamArrayAwareBinder methodBinder, Type[] parameterTypes, Type[] genericTypeArguments, bool suppressAmbiguityException)
        {
            MethodInfo info;
            try
            {
                methodBinder.SelectMethodCalled = false;
                info = targetType.GetMethod(methodName, bindingFlags, methodBinder, CallingConventions.Any, parameterTypes, null);
            }
            catch (AmbiguousMatchException)
            {
                if (!suppressAmbiguityException)
                {
                    throw;
                }
                return null;
            }
            if (((info != null) && !methodBinder.SelectMethodCalled) && (genericTypeArguments.Length != 0))
            {
                info = Instantiate(info, genericTypeArguments);
            }
            return info;
        }

        public void Trace()
        {
            if ((this.RunAsynchronously && (this.beginMethod != null)) && (this.endMethod != null))
            {
                if (TD.InvokeMethodUseAsyncPatternIsEnabled())
                {
                    TD.InvokeMethodUseAsyncPattern(this.Parent.DisplayName, this.beginMethod.ToString(), this.endMethod.ToString());
                }
            }
            else if (this.RunAsynchronously && TD.InvokeMethodDoesNotUseAsyncPatternIsEnabled())
            {
                TD.InvokeMethodDoesNotUseAsyncPattern(this.Parent.DisplayName);
            }
        }

        public Collection<Type> GenericTypeArguments { get; set; }

        public string MethodName { get; set; }

        public Collection<Argument> Parameters { get; set; }

        public RuntimeArgument Result { get; set; }

        public InArgument TargetObject { get; set; }

        public Type TargetType { get; set; }

        public bool RunAsynchronously { get; set; }

        public Activity Parent { get; set; }

        internal Type ResultType { get; set; }

        [Serializable, CompilerGenerated]
        private sealed class <>c
        {
            public static readonly MethodResolver.<>c <>9 = new MethodResolver.<>c();
            public static Func<Argument, Type> <>9__47_0;

            internal Type <DetermineMethodInfo>b__47_0(Argument argument)
            {
                if (argument.Direction != ArgumentDirection.In)
                {
                    return argument.ArgumentType.MakeByRefType();
                }
                return argument.ArgumentType;
            }
        }

        private class AsyncPatternMethodExecutor : MethodExecutor
        {
            private MethodInfo beginMethod;
            private MethodInfo endMethod;
            private Func<object, object[], object> beginFunc;
            private Func<object, object[], object> endFunc;

            public AsyncPatternMethodExecutor(MethodResolver.AsyncPatternMethodExecutor copy, Type targetType, InArgument targetObject, Collection<Argument> parameters, RuntimeArgument returnObject) : base(copy.invokingActivity, targetType, targetObject, parameters, returnObject)
            {
                this.beginMethod = copy.beginMethod;
                this.endMethod = copy.endMethod;
                this.beginFunc = copy.beginFunc;
                this.endFunc = copy.endFunc;
            }

            public AsyncPatternMethodExecutor(CodeActivityMetadata metadata, MethodInfo beginMethod, MethodInfo endMethod, Activity invokingActivity, Type targetType, InArgument targetObject, Collection<Argument> parameters, RuntimeArgument returnObject, MruCache<MethodInfo, Func<object, object[], object>> funcCache, ReaderWriterLockSlim locker) : base(invokingActivity, targetType, targetObject, parameters, returnObject)
            {
                this.beginMethod = beginMethod;
                this.endMethod = endMethod;
                this.beginFunc = MethodCallExpressionHelper.GetFunc(metadata, beginMethod, funcCache, locker, false);
                this.endFunc = MethodCallExpressionHelper.GetFunc(metadata, endMethod, funcCache, locker, false);
            }

            protected override IAsyncResult BeginMakeMethodCall(AsyncCodeActivityContext context, object target, AsyncCallback callback, object state)
            {
                MethodResolver.InvokeMethodInstanceData data = new MethodResolver.InvokeMethodInstanceData {
                    TargetObject = target,
                    ActualParameters = base.EvaluateAndPackParameters(context, this.beginMethod, true)
                };
                int length = data.ActualParameters.Length;
                data.ActualParameters[length - 2] = callback;
                data.ActualParameters[length - 1] = state;
                context.UserState = data;
                return (IAsyncResult) base.InvokeAndUnwrapExceptions(this.beginFunc, target, data.ActualParameters);
            }

            protected override void EndMakeMethodCall(AsyncCodeActivityContext context, IAsyncResult result)
            {
                MethodResolver.InvokeMethodInstanceData userState = (MethodResolver.InvokeMethodInstanceData) context.UserState;
                object[] actualParameters = new object[] { result };
                userState.ReturnValue = base.InvokeAndUnwrapExceptions(this.endFunc, userState.TargetObject, actualParameters);
                base.SetOutArgumentAndReturnValue(context, userState.ReturnValue, userState.ActualParameters);
            }

            public bool IsTheSame(MethodInfo newBeginMethod, MethodInfo newEndMethod) => 
                !MethodCallExpressionHelper.NeedRetrieve(newBeginMethod, this.beginMethod, this.beginFunc) && !MethodCallExpressionHelper.NeedRetrieve(newEndMethod, this.endMethod, this.endFunc);

            public override bool MethodIsStatic =>
                this.beginMethod.IsStatic;
        }

        private class AsyncWaitCallbackMethodExecutor : MethodExecutor
        {
            private MethodInfo asyncMethod;
            private Func<object, object[], object> asyncFunc;

            public AsyncWaitCallbackMethodExecutor(MethodResolver.AsyncWaitCallbackMethodExecutor copy, Type targetType, InArgument targetObject, Collection<Argument> parameters, RuntimeArgument returnObject) : base(copy.invokingActivity, targetType, targetObject, parameters, returnObject)
            {
                this.asyncMethod = copy.asyncMethod;
                this.asyncFunc = copy.asyncFunc;
            }

            public AsyncWaitCallbackMethodExecutor(CodeActivityMetadata metadata, MethodInfo asyncMethod, Activity invokingActivity, Type targetType, InArgument targetObject, Collection<Argument> parameters, RuntimeArgument returnObject, MruCache<MethodInfo, Func<object, object[], object>> funcCache, ReaderWriterLockSlim locker) : base(invokingActivity, targetType, targetObject, parameters, returnObject)
            {
                this.asyncMethod = asyncMethod;
                this.asyncFunc = MethodCallExpressionHelper.GetFunc(metadata, asyncMethod, funcCache, locker, false);
            }

            protected override IAsyncResult BeginMakeMethodCall(AsyncCodeActivityContext context, object target, AsyncCallback callback, object state)
            {
                MethodResolver.InvokeMethodInstanceData instance = new MethodResolver.InvokeMethodInstanceData {
                    TargetObject = target,
                    ActualParameters = base.EvaluateAndPackParameters(context, this.asyncMethod, false)
                };
                return new ExecuteAsyncResult(instance, this, callback, state);
            }

            protected override void EndMakeMethodCall(AsyncCodeActivityContext context, IAsyncResult result)
            {
                MethodResolver.InvokeMethodInstanceData data = ExecuteAsyncResult.End(result);
                if (data.ExceptionWasThrown)
                {
                    throw FxTrace.Exception.AsError(data.Exception);
                }
                base.SetOutArgumentAndReturnValue(context, data.ReturnValue, data.ActualParameters);
            }

            public bool IsTheSame(MethodInfo newMethodInfo) => 
                !MethodCallExpressionHelper.NeedRetrieve(newMethodInfo, this.asyncMethod, this.asyncFunc);

            public override bool MethodIsStatic =>
                this.asyncMethod.IsStatic;

            private class ExecuteAsyncResult : AsyncResult
            {
                private static Action<object> asyncExecute = new Action<object>(MethodResolver.AsyncWaitCallbackMethodExecutor.ExecuteAsyncResult.AsyncExecute);
                private MethodResolver.InvokeMethodInstanceData instance;
                private MethodResolver.AsyncWaitCallbackMethodExecutor executor;

                public ExecuteAsyncResult(MethodResolver.InvokeMethodInstanceData instance, MethodResolver.AsyncWaitCallbackMethodExecutor executor, AsyncCallback callback, object state) : base(callback, state)
                {
                    this.instance = instance;
                    this.executor = executor;
                    ActionItem.Schedule(asyncExecute, this);
                }

                private static void AsyncExecute(object state)
                {
                    ((MethodResolver.AsyncWaitCallbackMethodExecutor.ExecuteAsyncResult) state).AsyncExecuteCore();
                }

                private void AsyncExecuteCore()
                {
                    try
                    {
                        this.instance.ReturnValue = this.executor.InvokeAndUnwrapExceptions(this.executor.asyncFunc, this.instance.TargetObject, this.instance.ActualParameters);
                    }
                    catch (Exception exception)
                    {
                        if (Fx.IsFatal(exception))
                        {
                            throw;
                        }
                        this.instance.Exception = exception;
                        this.instance.ExceptionWasThrown = true;
                    }
                    base.Complete(false);
                }

                public static MethodResolver.InvokeMethodInstanceData End(IAsyncResult result) => 
                    AsyncResult.End<MethodResolver.AsyncWaitCallbackMethodExecutor.ExecuteAsyncResult>(result).instance;
            }
        }

        private class InheritanceAndParamArrayAwareBinder : Binder
        {
            private Type[] genericTypeArguments;
            private Type declaringType;
            internal bool SelectMethodCalled;
            private Activity parentActivity;

            public InheritanceAndParamArrayAwareBinder(Type declaringType, Type[] genericTypeArguments, Activity parentActivity)
            {
                this.declaringType = declaringType;
                this.genericTypeArguments = genericTypeArguments;
                this.parentActivity = parentActivity;
            }

            public override FieldInfo BindToField(BindingFlags bindingAttr, FieldInfo[] match, object value, CultureInfo culture)
            {
                throw FxTrace.Exception.AsError(new NotImplementedException());
            }

            public override MethodBase BindToMethod(BindingFlags bindingAttr, MethodBase[] match, ref object[] args, ParameterModifier[] modifiers, CultureInfo culture, string[] names, out object state)
            {
                throw FxTrace.Exception.AsError(new NotImplementedException());
            }

            public override object ChangeType(object value, Type type, CultureInfo culture)
            {
                throw FxTrace.Exception.AsError(new NotImplementedException());
            }

            private MethodBase FindMatch(MethodBase[] methodCandidates, BindingFlags bindingAttr, Type[] types, ParameterModifier[] modifiers)
            {
                MethodBase base2 = Type.DefaultBinder.SelectMethod(bindingAttr, methodCandidates, types, modifiers);
                if (base2 == null)
                {
                    foreach (MethodBase base3 in methodCandidates)
                    {
                        MethodInfo info = base3 as MethodInfo;
                        ParameterInfo[] parameters = info.GetParameters();
                        if (MethodResolver.HaveParameterArray(parameters))
                        {
                            Type elementType = parameters[parameters.Length - 1].ParameterType.GetElementType();
                            bool flag = true;
                            for (int i = parameters.Length - 1; i < (types.Length - 1); i++)
                            {
                                if (!System.Runtime.TypeHelper.AreTypesCompatible(types[i], elementType))
                                {
                                    flag = false;
                                    break;
                                }
                            }
                            if (flag)
                            {
                                Type[] typeArray = new Type[parameters.Length];
                                for (int j = 0; j < (typeArray.Length - 1); j++)
                                {
                                    typeArray[j] = types[j];
                                }
                                typeArray[typeArray.Length - 1] = elementType.MakeArrayType();
                                MethodBase[] match = new MethodBase[] { info };
                                MethodBase base4 = Type.DefaultBinder.SelectMethod(bindingAttr, match, typeArray, modifiers);
                                if ((base2 != null) && (base4 != null))
                                {
                                    string name = base4.ReflectedType.Name;
                                    string str2 = base4.Name;
                                    string str3 = (bindingAttr == MethodResolver.staticBindingFlags) ? MethodResolver.staticString : MethodResolver.instanceString;
                                    throw FxTrace.Exception.AsError(new AmbiguousMatchException(System.Activities.SR.DuplicateMethodFound(name, str3, str2, this.parentActivity.DisplayName)));
                                }
                                base2 = base4;
                            }
                        }
                    }
                }
                return base2;
            }

            public override void ReorderArgumentArray(ref object[] args, object state)
            {
                throw FxTrace.Exception.AsError(new NotImplementedException());
            }

            public override MethodBase SelectMethod(BindingFlags bindingAttr, MethodBase[] match, Type[] types, ParameterModifier[] modifiers)
            {
                MethodBase[] baseArray;
                this.SelectMethodCalled = true;
                if (this.genericTypeArguments.Length != 0)
                {
                    Collection<MethodBase> source = new Collection<MethodBase>();
                    foreach (MethodBase base3 in match)
                    {
                        MethodInfo item = MethodResolver.Instantiate((MethodInfo) base3, this.genericTypeArguments);
                        if (item != null)
                        {
                            source.Add(item);
                        }
                    }
                    baseArray = source.ToArray<MethodBase>();
                }
                else
                {
                    baseArray = (from m in match
                        where !m.ContainsGenericParameters
                        select m).ToArray<MethodBase>();
                }
                if (baseArray.Length == 0)
                {
                    return null;
                }
                Type declaringType = this.declaringType;
                MethodBase base2 = null;
                do
                {
                    MethodBase[] methodCandidates = (from mb in baseArray
                        where mb.DeclaringType == declaringType
                        select mb).ToArray<MethodBase>();
                    if (methodCandidates.Length != 0)
                    {
                        base2 = this.FindMatch(methodCandidates, bindingAttr, types, modifiers);
                    }
                    declaringType = declaringType.BaseType;
                }
                while ((declaringType != null) && (base2 == null));
                return base2;
            }

            public override PropertyInfo SelectProperty(BindingFlags bindingAttr, PropertyInfo[] match, Type returnType, Type[] indexes, ParameterModifier[] modifiers)
            {
                throw FxTrace.Exception.AsError(new NotImplementedException());
            }

            [Serializable, CompilerGenerated]
            private sealed class <>c
            {
                public static readonly MethodResolver.InheritanceAndParamArrayAwareBinder.<>c <>9 = new MethodResolver.InheritanceAndParamArrayAwareBinder.<>c();
                public static Func<MethodBase, bool> <>9__9_0;

                internal bool <SelectMethod>b__9_0(MethodBase m) => 
                    !m.ContainsGenericParameters;
            }
        }

        private class InvokeMethodInstanceData
        {
            public object TargetObject { get; set; }

            public object[] ActualParameters { get; set; }

            public object ReturnValue { get; set; }

            public bool ExceptionWasThrown { get; set; }

            public System.Exception Exception { get; set; }
        }

        private class SyncMethodExecutor : MethodExecutor
        {
            private MethodInfo syncMethod;
            private Func<object, object[], object> func;

            public SyncMethodExecutor(MethodResolver.SyncMethodExecutor copy, Type targetType, InArgument targetObject, Collection<Argument> parameters, RuntimeArgument returnObject) : base(copy.invokingActivity, targetType, targetObject, parameters, returnObject)
            {
                this.syncMethod = copy.syncMethod;
                this.func = copy.func;
            }

            public SyncMethodExecutor(CodeActivityMetadata metadata, MethodInfo syncMethod, Activity invokingActivity, Type targetType, InArgument targetObject, Collection<Argument> parameters, RuntimeArgument returnObject, MruCache<MethodInfo, Func<object, object[], object>> funcCache, ReaderWriterLockSlim locker) : base(invokingActivity, targetType, targetObject, parameters, returnObject)
            {
                this.syncMethod = syncMethod;
                this.func = MethodCallExpressionHelper.GetFunc(metadata, this.syncMethod, funcCache, locker, false);
            }

            protected override IAsyncResult BeginMakeMethodCall(AsyncCodeActivityContext context, object target, AsyncCallback callback, object state)
            {
                object[] actualParameters = base.EvaluateAndPackParameters(context, this.syncMethod, false);
                object obj2 = base.InvokeAndUnwrapExceptions(this.func, target, actualParameters);
                base.SetOutArgumentAndReturnValue(context, obj2, actualParameters);
                return new CompletedAsyncResult(callback, state);
            }

            protected override void EndMakeMethodCall(AsyncCodeActivityContext context, IAsyncResult result)
            {
                CompletedAsyncResult.End(result);
            }

            public bool IsTheSame(MethodInfo newMethod) => 
                !MethodCallExpressionHelper.NeedRetrieve(newMethod, this.syncMethod, this.func);

            public override bool MethodIsStatic =>
                this.syncMethod.IsStatic;
        }
    }
}

