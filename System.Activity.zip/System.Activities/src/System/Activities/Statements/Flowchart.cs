﻿namespace System.Activities.Statements
{
    using System;
    using System.Activities;
    using System.Activities.DynamicUpdate;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.Linq;
    using System.Runtime.Collections;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Windows.Markup;

    [ContentProperty("Nodes")]
    public sealed class Flowchart : NativeActivity
    {
        private Collection<Variable> variables;
        private Collection<FlowNode> nodes;
        private Collection<FlowNode> reachableNodes = new Collection<FlowNode>();
        private CompletionCallback onStepCompleted;
        private CompletionCallback<bool> onDecisionCompleted;
        private Variable<int> currentNode = new Variable<int>();

        protected override void CacheMetadata(NativeActivityMetadata metadata)
        {
            metadata.SetVariablesCollection(this.Variables);
            metadata.AddImplementationVariable(this.currentNode);
            this.GatherReachableNodes(metadata);
            if (this.ValidateUnconnectedNodes && (this.reachableNodes.Count < this.Nodes.Count))
            {
                metadata.AddValidationError(System.Activities.SR.FlowchartContainsUnconnectedNodes(base.DisplayName));
            }
            HashSet<Activity> children = new HashSet<Activity>();
            IEnumerable<FlowNode> enumerable = this.ValidateUnconnectedNodes ? this.Nodes.Distinct<FlowNode>() : this.reachableNodes;
            foreach (FlowNode node in enumerable)
            {
                if (this.ValidateUnconnectedNodes)
                {
                    node.OnOpen(this, metadata);
                }
                node.GetChildActivities(children);
            }
            List<Activity> list = new List<Activity>(children.Count);
            foreach (Activity activity in children)
            {
                list.Add(activity);
            }
            metadata.SetChildrenCollection(new Collection<Activity>(list));
        }

        private void DepthFirstVisitNodes(Func<FlowNode, bool> visitNodeCallback, FlowNode start)
        {
            List<FlowNode> connections = new List<FlowNode>();
            Stack<FlowNode> stack = new Stack<FlowNode>();
            if (start != null)
            {
                stack.Push(start);
                while (stack.Count > 0)
                {
                    FlowNode arg = stack.Pop();
                    if ((arg != null) && visitNodeCallback(arg))
                    {
                        connections.Clear();
                        arg.GetConnectedNodes(connections);
                        for (int i = 0; i < connections.Count; i++)
                        {
                            stack.Push(connections[i]);
                        }
                    }
                }
            }
        }

        protected override void Execute(NativeActivityContext context)
        {
            if (this.StartNode != null)
            {
                if (TD.FlowchartStartIsEnabled())
                {
                    TD.FlowchartStart(base.DisplayName);
                }
                this.ExecuteNodeChain(context, this.StartNode, null);
            }
            else if (TD.FlowchartEmptyIsEnabled())
            {
                TD.FlowchartEmpty(base.DisplayName);
            }
        }

        private void ExecuteNodeChain(NativeActivityContext context, FlowNode node, System.Activities.ActivityInstance completedInstance)
        {
            if (node == null)
            {
                if (context.IsCancellationRequested && (completedInstance.State != ActivityInstanceState.Closed))
                {
                    context.MarkCanceled();
                }
            }
            else if (context.IsCancellationRequested)
            {
                context.MarkCanceled();
            }
            else
            {
                FlowNode node2 = node;
                do
                {
                    if (this.ExecuteSingleNode(context, node2, out FlowNode node3))
                    {
                        node2 = node3;
                    }
                    else
                    {
                        this.currentNode.Set(context, node2.Index);
                        node2 = null;
                    }
                }
                while (node2 != null);
            }
        }

        private bool ExecuteSingleNode(NativeActivityContext context, FlowNode node, out FlowNode nextNode)
        {
            FlowStep step = node as FlowStep;
            if (step != null)
            {
                if (this.onStepCompleted == null)
                {
                    this.onStepCompleted = new CompletionCallback(this.OnStepCompleted);
                }
                return step.Execute(context, this.onStepCompleted, out nextNode);
            }
            nextNode = null;
            FlowDecision decision = node as FlowDecision;
            if (decision != null)
            {
                if (this.onDecisionCompleted == null)
                {
                    this.onDecisionCompleted = new CompletionCallback<bool>(this.OnDecisionCompleted);
                }
                return decision.Execute(context, this.onDecisionCompleted);
            }
            IFlowSwitch switch2 = node as IFlowSwitch;
            return switch2.Execute(context, this);
        }

        private void GatherReachableNodes(NativeActivityMetadata metadata)
        {
            this.reachableNodes.Clear();
            if ((this.StartNode == null) && (this.Nodes.Count > 0))
            {
                metadata.AddValidationError(System.Activities.SR.FlowchartMissingStartNode(base.DisplayName));
            }
            else
            {
                this.DepthFirstVisitNodes(n => this.VisitNode(n, metadata), this.StartNode);
            }
        }

        private FlowNode GetCurrentNode(NativeActivityContext context)
        {
            int num = this.currentNode.Get(context);
            return this.reachableNodes[num];
        }

        protected override void OnCreateDynamicUpdateMap(NativeActivityUpdateMapMetadata metadata, Activity originalActivity)
        {
            Flowchart flowchart = (Flowchart) originalActivity;
            Dictionary<Activity, int> dictionary = new Dictionary<Activity, int>();
            foreach (FlowNode node in flowchart.reachableNodes)
            {
                if (node.ChildActivity != null)
                {
                    if (metadata.IsReferenceToImportedChild(node.ChildActivity))
                    {
                        metadata.DisallowUpdateInsideThisActivity(System.Activities.SR.FlowchartContainsReferences);
                        return;
                    }
                    if (dictionary.ContainsKey(node.ChildActivity))
                    {
                        metadata.DisallowUpdateInsideThisActivity(System.Activities.SR.MultipleFlowNodesSharingSameChildBlockDU);
                        return;
                    }
                    dictionary[node.ChildActivity] = node.Index;
                }
            }
            HashSet<Activity> set = new HashSet<Activity>();
            foreach (FlowNode node2 in this.reachableNodes)
            {
                if (node2.ChildActivity != null)
                {
                    if (metadata.IsReferenceToImportedChild(node2.ChildActivity))
                    {
                        metadata.DisallowUpdateInsideThisActivity(System.Activities.SR.FlowchartContainsReferences);
                        break;
                    }
                    if (set.Contains(node2.ChildActivity))
                    {
                        metadata.DisallowUpdateInsideThisActivity(System.Activities.SR.MultipleFlowNodesSharingSameChildBlockDU);
                        break;
                    }
                    set.Add(node2.ChildActivity);
                    Activity match = metadata.GetMatch(node2.ChildActivity);
                    if ((match != null) && dictionary.TryGetValue(match, out int num))
                    {
                        if (flowchart.reachableNodes[num].GetType() != node2.GetType())
                        {
                            metadata.DisallowUpdateInsideThisActivity(System.Activities.SR.CannotMoveChildAcrossDifferentFlowNodeTypes);
                            break;
                        }
                        if (num != node2.Index)
                        {
                            metadata.SaveOriginalValue(node2.ChildActivity, num);
                        }
                    }
                }
            }
        }

        private void OnDecisionCompleted(NativeActivityContext context, System.Activities.ActivityInstance completedInstance, bool result)
        {
            FlowDecision currentNode = this.GetCurrentNode(context) as FlowDecision;
            FlowNode node = result ? currentNode.True : currentNode.False;
            this.ExecuteNodeChain(context, node, completedInstance);
        }

        private void OnStepCompleted(NativeActivityContext context, System.Activities.ActivityInstance completedInstance)
        {
            FlowStep currentNode = this.GetCurrentNode(context) as FlowStep;
            FlowNode next = currentNode.Next;
            this.ExecuteNodeChain(context, next, completedInstance);
        }

        internal void OnSwitchCompleted<T>(NativeActivityContext context, System.Activities.ActivityInstance completedInstance, T result)
        {
            FlowNode nextNode = (this.GetCurrentNode(context) as IFlowSwitch).GetNextNode(result);
            this.ExecuteNodeChain(context, nextNode, completedInstance);
        }

        protected override void UpdateInstance(NativeActivityUpdateContext updateContext)
        {
            int num = updateContext.GetValue<int>(this.currentNode);
            foreach (FlowNode node in this.reachableNodes)
            {
                if (node.ChildActivity != null)
                {
                    object savedOriginalValue = updateContext.GetSavedOriginalValue(node.ChildActivity);
                    if (savedOriginalValue != null)
                    {
                        int num2 = (int) savedOriginalValue;
                        if (num2 == num)
                        {
                            updateContext.SetValue<int>(this.currentNode, node.Index);
                            break;
                        }
                    }
                }
            }
        }

        private bool VisitNode(FlowNode node, NativeActivityMetadata metadata)
        {
            if (node.Open(this, metadata))
            {
                node.Index = this.reachableNodes.Count;
                this.reachableNodes.Add(node);
                return true;
            }
            return false;
        }

        [DefaultValue(false)]
        public bool ValidateUnconnectedNodes { get; set; }

        public Collection<Variable> Variables
        {
            get
            {
                if (this.variables == null)
                {
                    ValidatingCollection<Variable> collection1 = new ValidatingCollection<Variable> {
                        OnAddValidationCallback = delegate (Variable item) {
                            if (item == null)
                            {
                                throw FxTrace.Exception.ArgumentNull("item");
                            }
                        }
                    };
                    this.variables = collection1;
                }
                return this.variables;
            }
        }

        [DependsOn("Variables")]
        public FlowNode StartNode { get; set; }

        [DependsOn("StartNode")]
        public Collection<FlowNode> Nodes
        {
            get
            {
                if (this.nodes == null)
                {
                    ValidatingCollection<FlowNode> collection1 = new ValidatingCollection<FlowNode> {
                        OnAddValidationCallback = delegate (FlowNode item) {
                            if (item == null)
                            {
                                throw FxTrace.Exception.ArgumentNull("item");
                            }
                        }
                    };
                    this.nodes = collection1;
                }
                return this.nodes;
            }
        }

        [Serializable, CompilerGenerated]
        private sealed class <>c
        {
            public static readonly Flowchart.<>c <>9 = new Flowchart.<>c();
            public static Action<Variable> <>9__12_0;
            public static Action<FlowNode> <>9__18_0;

            internal void <get_Nodes>b__18_0(FlowNode item)
            {
                if (item == null)
                {
                    throw FxTrace.Exception.ArgumentNull("item");
                }
            }

            internal void <get_Variables>b__12_0(Variable item)
            {
                if (item == null)
                {
                    throw FxTrace.Exception.ArgumentNull("item");
                }
            }
        }
    }
}

