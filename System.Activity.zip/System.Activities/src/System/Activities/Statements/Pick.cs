﻿namespace System.Activities.Statements
{
    using System;
    using System.Activities;
    using System.Activities.DynamicUpdate;
    using System.Activities.Validation;
    using System.Collections.ObjectModel;
    using System.Runtime.Collections;
    using System.Runtime.CompilerServices;
    using System.Runtime.Serialization;
    using System.Windows.Markup;

    [ContentProperty("Branches")]
    public sealed class Pick : NativeActivity
    {
        private const string pickStateProperty = "System.Activities.Statements.Pick.PickState";
        private Collection<PickBranch> branches;
        private Variable<PickState> pickStateVariable = new Variable<PickState>();
        private Collection<Activity> branchBodies;

        protected override void CacheMetadata(NativeActivityMetadata metadata)
        {
            if (this.branchBodies == null)
            {
                this.branchBodies = new Collection<Activity>();
            }
            else
            {
                this.branchBodies.Clear();
            }
            foreach (PickBranch branch in this.Branches)
            {
                if (branch.Trigger == null)
                {
                    metadata.AddValidationError(new ValidationError(System.Activities.SR.PickBranchRequiresTrigger(branch.DisplayName), false, null, branch));
                }
                PickBranchBody item = new PickBranchBody {
                    Action = branch.Action,
                    DisplayName = branch.DisplayName,
                    Trigger = branch.Trigger,
                    Variables = branch.Variables
                };
                this.branchBodies.Add(item);
                metadata.AddChild(item, branch);
            }
            metadata.AddImplementationVariable(this.pickStateVariable);
        }

        protected override void Cancel(NativeActivityContext context)
        {
            context.CancelChildren();
        }

        protected override void Execute(NativeActivityContext context)
        {
            if (this.branchBodies.Count != 0)
            {
                PickState state = new PickState();
                this.pickStateVariable.Set(context, state);
                state.TriggerCompletionBookmark = context.CreateBookmark(new BookmarkCallback(this.OnTriggerComplete));
                context.Properties.Add("System.Activities.Statements.Pick.PickState", state);
                CompletionCallback onCompleted = new CompletionCallback(this.OnBranchComplete);
                for (int i = this.branchBodies.Count - 1; i >= 0; i--)
                {
                    context.ScheduleActivity(this.branchBodies[i], onCompleted);
                }
            }
        }

        private void OnBranchComplete(NativeActivityContext context, System.Activities.ActivityInstance completedInstance)
        {
            PickState pickState = this.pickStateVariable.Get(context);
            ReadOnlyCollection<System.Activities.ActivityInstance> children = context.GetChildren();
            ActivityInstanceState state = completedInstance.State;
            if (state != ActivityInstanceState.Closed)
            {
                if (((state - 2) <= ActivityInstanceState.Closed) && ((context.IsCancellationRequested && (children.Count == 0)) && !pickState.HasBranchCompletedSuccessfully))
                {
                    context.MarkCanceled();
                    context.RemoveAllBookmarks();
                }
            }
            else
            {
                pickState.HasBranchCompletedSuccessfully = true;
            }
            if ((children.Count == 1) && (pickState.ExecuteActionBookmark != null))
            {
                this.ResumeExecutionActionBookmark(pickState, context);
            }
        }

        protected override void OnCreateDynamicUpdateMap(NativeActivityUpdateMapMetadata metadata, Activity originalActivity)
        {
            metadata.AllowUpdateInsideThisActivity();
        }

        private void OnTriggerComplete(NativeActivityContext context, Bookmark bookmark, object state)
        {
            PickState pickState = this.pickStateVariable.Get(context);
            string str = (string) state;
            ReadOnlyCollection<System.Activities.ActivityInstance> children = context.GetChildren();
            bool flag = true;
            for (int i = 0; i < children.Count; i++)
            {
                System.Activities.ActivityInstance activityInstance = children[i];
                if (activityInstance.Id != str)
                {
                    context.CancelChild(activityInstance);
                    flag = false;
                }
            }
            if (flag)
            {
                this.ResumeExecutionActionBookmark(pickState, context);
            }
        }

        private void ResumeExecutionActionBookmark(PickState pickState, NativeActivityContext context)
        {
            context.ResumeBookmark(pickState.ExecuteActionBookmark, null);
            pickState.ExecuteActionBookmark = null;
        }

        protected override void UpdateInstance(NativeActivityUpdateContext updateContext)
        {
            PickState state = updateContext.GetValue<PickState>(this.pickStateVariable);
            if (!updateContext.IsCancellationRequested && (state.TriggerCompletionBookmark != null))
            {
                CompletionCallback onCompleted = new CompletionCallback(this.OnBranchComplete);
                foreach (PickBranchBody body in this.branchBodies)
                {
                    if (updateContext.IsNewlyAdded(body))
                    {
                        updateContext.ScheduleActivity(body, onCompleted, null);
                    }
                }
            }
        }

        protected override bool CanInduceIdle =>
            true;

        public Collection<PickBranch> Branches
        {
            get
            {
                if (this.branches == null)
                {
                    ValidatingCollection<PickBranch> collection1 = new ValidatingCollection<PickBranch> {
                        OnAddValidationCallback = delegate (PickBranch item) {
                            if (item == null)
                            {
                                throw System.Activities.FxTrace.Exception.ArgumentNull("item");
                            }
                        }
                    };
                    this.branches = collection1;
                }
                return this.branches;
            }
        }

        [Serializable, CompilerGenerated]
        private sealed class <>c
        {
            public static readonly Pick.<>c <>9 = new Pick.<>c();
            public static Action<PickBranch> <>9__8_0;

            internal void <get_Branches>b__8_0(PickBranch item)
            {
                if (item == null)
                {
                    throw System.Activities.FxTrace.Exception.ArgumentNull("item");
                }
            }
        }

        private class PickBranchBody : NativeActivity
        {
            protected override void CacheMetadata(NativeActivityMetadata metadata)
            {
                Collection<Activity> collection = null;
                if (this.Trigger != null)
                {
                    ActivityUtilities.Add<Activity>(ref collection, this.Trigger);
                }
                if (this.Action != null)
                {
                    ActivityUtilities.Add<Activity>(ref collection, this.Action);
                }
                metadata.SetChildrenCollection(collection);
                metadata.SetVariablesCollection(this.Variables);
            }

            protected override void Execute(NativeActivityContext context)
            {
                context.ScheduleActivity(this.Trigger, new CompletionCallback(this.OnTriggerCompleted));
            }

            protected override void OnCreateDynamicUpdateMap(NativeActivityUpdateMapMetadata metadata, Activity originalActivity)
            {
                Pick.PickBranchBody body = (Pick.PickBranchBody) originalActivity;
                if (((body.Action != null) && (metadata.GetMatch(this.Trigger) == body.Action)) || ((this.Action != null) && (metadata.GetMatch(this.Action) == body.Trigger)))
                {
                    metadata.DisallowUpdateInsideThisActivity(System.Activities.SR.PickBranchTriggerActionSwapped);
                }
                else
                {
                    metadata.AllowUpdateInsideThisActivity();
                }
            }

            private void OnExecuteAction(NativeActivityContext context, Bookmark bookmark, object state)
            {
                if (this.Action != null)
                {
                    context.ScheduleActivity(this.Action);
                }
            }

            private void OnTriggerCompleted(NativeActivityContext context, System.Activities.ActivityInstance completedInstance)
            {
                Pick.PickState state = (Pick.PickState) context.Properties.Find("System.Activities.Statements.Pick.PickState");
                if ((completedInstance.State == ActivityInstanceState.Closed) && (state.TriggerCompletionBookmark != null))
                {
                    context.ResumeBookmark(state.TriggerCompletionBookmark, context.ActivityInstanceId);
                    state.TriggerCompletionBookmark = null;
                    state.ExecuteActionBookmark = context.CreateBookmark(new BookmarkCallback(this.OnExecuteAction));
                }
                else if (!context.IsCancellationRequested)
                {
                    context.CreateBookmark();
                }
            }

            protected override bool CanInduceIdle =>
                true;

            public Collection<Variable> Variables { get; set; }

            public Activity Trigger { get; set; }

            public Activity Action { get; set; }
        }

        [DataContract]
        internal class PickState
        {
            [DataMember(EmitDefaultValue=false)]
            public bool HasBranchCompletedSuccessfully { get; set; }

            [DataMember(EmitDefaultValue=false)]
            public Bookmark TriggerCompletionBookmark { get; set; }

            [DataMember(EmitDefaultValue=false)]
            public Bookmark ExecuteActionBookmark { get; set; }
        }
    }
}

