﻿namespace System.Activities.Statements
{
    using System;
    using System.Activities;
    using System.Activities.DynamicUpdate;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.Runtime.Collections;
    using System.Runtime.CompilerServices;
    using System.Windows.Markup;

    [ContentProperty("Branches")]
    public sealed class Parallel : NativeActivity
    {
        private CompletionCallback<bool> onConditionComplete;
        private Collection<Activity> branches;
        private Collection<Variable> variables;
        private Variable<bool> hasCompleted;

        protected override void CacheMetadata(NativeActivityMetadata metadata)
        {
            Collection<Activity> children = new Collection<Activity>();
            foreach (Activity activity in this.Branches)
            {
                children.Add(activity);
            }
            if (this.CompletionCondition != null)
            {
                children.Add(this.CompletionCondition);
            }
            metadata.SetChildrenCollection(children);
            metadata.SetVariablesCollection(this.Variables);
            if (this.CompletionCondition != null)
            {
                if (this.hasCompleted == null)
                {
                    this.hasCompleted = new Variable<bool>("hasCompletedVar");
                }
                metadata.AddImplementationVariable(this.hasCompleted);
            }
        }

        protected override void Cancel(NativeActivityContext context)
        {
            if (this.CompletionCondition == null)
            {
                base.Cancel(context);
            }
            else
            {
                context.CancelChildren();
            }
        }

        protected override void Execute(NativeActivityContext context)
        {
            if ((this.branches != null) && (this.Branches.Count != 0))
            {
                CompletionCallback onCompleted = new CompletionCallback(this.OnBranchComplete);
                for (int i = this.Branches.Count - 1; i >= 0; i--)
                {
                    context.ScheduleActivity(this.Branches[i], onCompleted);
                }
            }
        }

        private void OnBranchComplete(NativeActivityContext context, System.Activities.ActivityInstance completedInstance)
        {
            if ((this.CompletionCondition != null) && !this.hasCompleted.Get(context))
            {
                if ((completedInstance.State != ActivityInstanceState.Closed) && context.IsCancellationRequested)
                {
                    context.MarkCanceled();
                    this.hasCompleted.Set(context, true);
                }
                else
                {
                    if (this.onConditionComplete == null)
                    {
                        this.onConditionComplete = new CompletionCallback<bool>(this.OnConditionComplete);
                    }
                    context.ScheduleActivity<bool>(this.CompletionCondition, this.onConditionComplete, null);
                }
            }
        }

        private void OnConditionComplete(NativeActivityContext context, System.Activities.ActivityInstance completedInstance, bool result)
        {
            if (result)
            {
                context.CancelChildren();
                this.hasCompleted.Set(context, true);
            }
        }

        protected override void OnCreateDynamicUpdateMap(NativeActivityUpdateMapMetadata metadata, Activity originalActivity)
        {
            metadata.AllowUpdateInsideThisActivity();
        }

        protected override void UpdateInstance(NativeActivityUpdateContext updateContext)
        {
            if ((!updateContext.IsCancellationRequested && (this.branches != null)) && ((this.CompletionCondition == null) || !updateContext.GetValue<bool>(this.hasCompleted)))
            {
                CompletionCallback onCompleted = new CompletionCallback(this.OnBranchComplete);
                foreach (Activity activity in this.branches)
                {
                    if (updateContext.IsNewlyAdded(activity))
                    {
                        updateContext.ScheduleActivity(activity, onCompleted);
                    }
                }
            }
        }

        public Collection<Variable> Variables
        {
            get
            {
                if (this.variables == null)
                {
                    ValidatingCollection<Variable> collection1 = new ValidatingCollection<Variable> {
                        OnAddValidationCallback = delegate (Variable item) {
                            if (item == null)
                            {
                                throw FxTrace.Exception.ArgumentNull("item");
                            }
                        }
                    };
                    this.variables = collection1;
                }
                return this.variables;
            }
        }

        [DefaultValue((string) null), DependsOn("Variables")]
        public Activity<bool> CompletionCondition { get; set; }

        [DependsOn("CompletionCondition")]
        public Collection<Activity> Branches
        {
            get
            {
                if (this.branches == null)
                {
                    ValidatingCollection<Activity> collection1 = new ValidatingCollection<Activity> {
                        OnAddValidationCallback = delegate (Activity item) {
                            if (item == null)
                            {
                                throw FxTrace.Exception.ArgumentNull("item");
                            }
                        }
                    };
                    this.branches = collection1;
                }
                return this.branches;
            }
        }

        [Serializable, CompilerGenerated]
        private sealed class <>c
        {
            public static readonly Parallel.<>c <>9 = new Parallel.<>c();
            public static Action<Variable> <>9__6_0;
            public static Action<Activity> <>9__12_0;

            internal void <get_Branches>b__12_0(Activity item)
            {
                if (item == null)
                {
                    throw FxTrace.Exception.ArgumentNull("item");
                }
            }

            internal void <get_Variables>b__6_0(Variable item)
            {
                if (item == null)
                {
                    throw FxTrace.Exception.ArgumentNull("item");
                }
            }
        }
    }
}

