﻿namespace System.Activities.Statements
{
    using System;
    using System.Activities;
    using System.Activities.DynamicUpdate;
    using System.Activities.Expressions;
    using System.Activities.Validation;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.Runtime.Collections;
    using System.Runtime.CompilerServices;
    using System.Windows.Markup;

    [ContentProperty("Body")]
    public sealed class CompensableActivity : NativeActivity<CompensationToken>
    {
        private static Constraint noCompensableActivityInSecondaryRoot = NoCompensableActivityInSecondaryRoot();
        private Collection<Variable> variables;
        private System.Activities.Statements.CompensationParticipant compensationParticipant;
        private Variable<long> currentCompensationId = new Variable<long>();
        private Variable<CompensationToken> currentCompensationToken = new Variable<CompensationToken>();
        private Variable<long> compensationId = new Variable<long>();

        private void AppCompletionCleanup(NativeActivityContext context, CompensationExtension compensationExtension, CompensationTokenData compensationToken)
        {
            if (compensationToken.ParentCompensationId != 0)
            {
                compensationExtension.Get(compensationToken.ParentCompensationId).ExecutionTracker.Remove(compensationToken);
            }
            else
            {
                compensationExtension.Get(0L).ExecutionTracker.Remove(compensationToken);
            }
            compensationToken.RemoveBookmark(context, CompensationBookmarkName.Canceled);
            compensationToken.RemoveBookmark(context, CompensationBookmarkName.Compensated);
            compensationExtension.Remove(compensationToken.CompensationId);
        }

        protected override void CacheMetadata(NativeActivityMetadata metadata)
        {
            metadata.SetVariablesCollection(this.Variables);
            Collection<Variable> implementationVariables = new Collection<Variable> {
                this.currentCompensationId,
                this.currentCompensationToken,
                this.compensationId
            };
            metadata.SetImplementationVariablesCollection(implementationVariables);
            if (this.Body != null)
            {
                Collection<Activity> children = new Collection<Activity> {
                    this.Body
                };
                metadata.SetChildrenCollection(children);
            }
            if (this.CompensationHandler != null)
            {
                metadata.AddImportedChild(this.CompensationHandler);
            }
            if (this.ConfirmationHandler != null)
            {
                metadata.AddImportedChild(this.ConfirmationHandler);
            }
            if (this.CancellationHandler != null)
            {
                metadata.AddImportedChild(this.CancellationHandler);
            }
            Collection<Activity> implementationChildren = new Collection<Activity>();
            if (!base.IsSingletonActivityDeclared("Activities.Compensation.WorkflowImplicitCompensationBehavior"))
            {
                WorkflowCompensationBehavior activity = new WorkflowCompensationBehavior();
                base.DeclareSingletonActivity("Activities.Compensation.WorkflowImplicitCompensationBehavior", activity);
                implementationChildren.Add(activity);
                metadata.AddDefaultExtensionProvider<CompensationExtension>(new Func<CompensationExtension>(this.CreateCompensationExtension));
            }
            this.CompensationParticipant = null;
            implementationChildren.Add(this.CompensationParticipant);
            metadata.SetImplementationChildrenCollection(implementationChildren);
        }

        protected override void Cancel(NativeActivityContext context)
        {
            context.CancelChildren();
        }

        private CompensationExtension CreateCompensationExtension() => 
            new CompensationExtension();

        protected override void Execute(NativeActivityContext context)
        {
            CompensationExtension compensationExtension = context.GetExtension<CompensationExtension>();
            if (compensationExtension.IsWorkflowCompensationBehaviorScheduled)
            {
                this.ScheduleBody(context, compensationExtension);
            }
            else
            {
                compensationExtension.SetupWorkflowCompensationBehavior(context, new BookmarkCallback(this.OnWorkflowCompensationBehaviorScheduled), base.GetSingletonActivity("Activities.Compensation.WorkflowImplicitCompensationBehavior"));
            }
        }

        internal override IList<Constraint> InternalGetConstraints() => 
            new List<Constraint>(1) { noCompensableActivityInSecondaryRoot };

        private static Constraint NoCompensableActivityInSecondaryRoot()
        {
            DelegateInArgument<ValidationContext> argument = new DelegateInArgument<ValidationContext> {
                Name = "validationContext"
            };
            DelegateInArgument<CompensableActivity> argument2 = new DelegateInArgument<CompensableActivity> {
                Name = "element"
            };
            Variable<bool> variable = new Variable<bool> {
                Name = "assertFlag",
                Default = 1
            };
            Variable<IEnumerable<Activity>> variable2 = new Variable<IEnumerable<Activity>> {
                Name = "elements"
            };
            Variable<int> variable3 = new Variable<int> {
                Name = "index"
            };
            Constraint<CompensableActivity> constraint1 = new Constraint<CompensableActivity>();
            ActivityAction<CompensableActivity, ValidationContext> action1 = new ActivityAction<CompensableActivity, ValidationContext> {
                Argument1 = argument2,
                Argument2 = argument
            };
            Sequence sequence1 = new Sequence {
                Variables = { 
                    variable,
                    variable2,
                    variable3
                }
            };
            Assign<IEnumerable<Activity>> item = new Assign<IEnumerable<Activity>> {
                To = variable2
            };
            GetParentChain chain1 = new GetParentChain {
                ValidationContext = argument
            };
            item.Value = chain1;
            sequence1.Activities.Add(item);
            While while1 = new While();
            WhileExpression expression1 = new WhileExpression {
                DisplayName = "env => (assertFlag.Get(env) != false) && index.Get(env) < elements.Get(env).Count())",
                AssertFlag = new InArgument<bool>(variable),
                Index = new InArgument<int>(variable3),
                Elements = new InArgument<IEnumerable<Activity>>(variable2)
            };
            while1.Condition = expression1;
            Sequence sequence2 = new Sequence();
            If if1 = new If();
            IfExpression expression2 = new IfExpression {
                DisplayName = "env => (elements.Get(env).ElementAt(index.Get(env))).GetType() == typeof(CompensationParticipant)",
                Elements = new InArgument<IEnumerable<Activity>>(variable2),
                Index = new InArgument<int>(variable3)
            };
            if1.Condition = expression2;
            Assign<bool> assign2 = new Assign<bool> {
                To = variable,
                Value = 0
            };
            if1.Then = assign2;
            sequence2.Activities.Add(if1);
            Assign<int> assign3 = new Assign<int> {
                To = variable3
            };
            InArgument<int> argument4 = new InArgument<int>();
            Add<int, int, int> add1 = new Add<int, int, int> {
                DisplayName = "(env => index.Get(env) + 1)"
            };
            VariableValue<int> value1 = new VariableValue<int> {
                Variable = variable3
            };
            add1.Left = value1;
            add1.Right = 1;
            argument4.Expression = add1;
            assign3.Value = argument4;
            sequence2.Activities.Add(assign3);
            while1.Body = sequence2;
            sequence1.Activities.Add(while1);
            AssertValidation validation1 = new AssertValidation {
                Assertion = new InArgument<bool>(variable),
                Message = new InArgument<string>(System.Activities.SR.NoCAInSecondaryRoot)
            };
            sequence1.Activities.Add(validation1);
            action1.Handler = sequence1;
            constraint1.Body = action1;
            return constraint1;
        }

        private void OnBodyExecutionComplete(NativeActivityContext context, System.Activities.ActivityInstance completedInstance)
        {
            CompensationExtension compensationExtension = context.GetExtension<CompensationExtension>();
            CompensationTokenData token = compensationExtension.Get(this.currentCompensationId.Get(context));
            if (completedInstance.State == ActivityInstanceState.Closed)
            {
                token.CompensationState = CompensationState.Completed;
                if (TD.CompensationStateIsEnabled())
                {
                    TD.CompensationState(token.DisplayName, token.CompensationState.ToString());
                }
                if (context.IsCancellationRequested)
                {
                    token.CompensationState = CompensationState.Compensating;
                }
            }
            else if ((completedInstance.State == ActivityInstanceState.Canceled) || (completedInstance.State == ActivityInstanceState.Faulted))
            {
                token.CompensationState = CompensationState.Canceling;
            }
            this.ScheduleSecondaryRoot(context, compensationExtension, token);
        }

        private void OnCanceledOrCompensated(NativeActivityContext context, Bookmark bookmark, object value)
        {
            CompensationExtension compensationExtension = context.GetExtension<CompensationExtension>();
            long compensationId = (long) value;
            CompensationTokenData compensationToken = compensationExtension.Get(compensationId);
            switch (compensationToken.CompensationState)
            {
                case CompensationState.Compensating:
                    compensationToken.CompensationState = CompensationState.Compensated;
                    break;

                case CompensationState.Canceling:
                    compensationToken.CompensationState = CompensationState.Canceled;
                    break;
            }
            if (TD.CompensationStateIsEnabled())
            {
                TD.CompensationState(compensationToken.DisplayName, compensationToken.CompensationState.ToString());
            }
            this.AppCompletionCleanup(context, compensationExtension, compensationToken);
            context.MarkCanceled();
        }

        protected override void OnCreateDynamicUpdateMap(NativeActivityUpdateMapMetadata metadata, Activity originalActivity)
        {
            metadata.AllowUpdateInsideThisActivity();
        }

        private void OnSecondaryRootScheduled(NativeActivityContext context, Bookmark bookmark, object value)
        {
            CompensationExtension extension = context.GetExtension<CompensationExtension>();
            long compensationId = (long) value;
            CompensationTokenData data = extension.Get(compensationId);
            if (data.CompensationState == CompensationState.Canceling)
            {
                data.BookmarkTable[CompensationBookmarkName.Canceled] = context.CreateBookmark(new BookmarkCallback(this.OnCanceledOrCompensated));
                extension.NotifyMessage(context, data.CompensationId, CompensationBookmarkName.OnCancellation);
            }
            else if (data.CompensationState == CompensationState.Compensating)
            {
                data.BookmarkTable[CompensationBookmarkName.Compensated] = context.CreateBookmark(new BookmarkCallback(this.OnCanceledOrCompensated));
                extension.NotifyMessage(context, data.CompensationId, CompensationBookmarkName.OnCompensation);
            }
        }

        private void OnWorkflowCompensationBehaviorScheduled(NativeActivityContext context, Bookmark bookmark, object value)
        {
            CompensationExtension compensationExtension = context.GetExtension<CompensationExtension>();
            this.ScheduleBody(context, compensationExtension);
        }

        private void ScheduleBody(NativeActivityContext context, CompensationExtension compensationExtension)
        {
            CompensationToken token = null;
            long parentCompensationId = 0L;
            token = (CompensationToken) context.Properties.Find("System.Compensation.CompensationToken");
            if (token != null)
            {
                if (compensationExtension.Get(token.CompensationId).IsTokenValidInSecondaryRoot)
                {
                    throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.NoCAInSecondaryRoot));
                }
                parentCompensationId = token.CompensationId;
            }
            CompensationTokenData tokenData = new CompensationTokenData(compensationExtension.GetNextId(), parentCompensationId) {
                CompensationState = CompensationState.Active,
                DisplayName = base.DisplayName
            };
            CompensationToken property = new CompensationToken(tokenData);
            context.Properties.Add("System.Compensation.CompensationToken", property);
            this.currentCompensationId.Set(context, property.CompensationId);
            this.currentCompensationToken.Set(context, property);
            compensationExtension.Add(property.CompensationId, tokenData);
            if (TD.CompensationStateIsEnabled())
            {
                TD.CompensationState(tokenData.DisplayName, tokenData.CompensationState.ToString());
            }
            if (this.Body != null)
            {
                context.ScheduleActivity(this.Body, new CompletionCallback(this.OnBodyExecutionComplete));
            }
            else
            {
                tokenData.CompensationState = CompensationState.Completed;
                if (TD.CompensationStateIsEnabled())
                {
                    TD.CompensationState(tokenData.DisplayName, tokenData.CompensationState.ToString());
                }
                this.ScheduleSecondaryRoot(context, compensationExtension, tokenData);
            }
        }

        private void ScheduleSecondaryRoot(NativeActivityContext context, CompensationExtension compensationExtension, CompensationTokenData token)
        {
            if (token.ParentCompensationId != 0)
            {
                compensationExtension.Get(token.ParentCompensationId).ExecutionTracker.Add(token);
            }
            else
            {
                compensationExtension.Get(0L).ExecutionTracker.Add(token);
            }
            if ((base.Result != null) && (token.CompensationState == CompensationState.Completed))
            {
                base.Result.Set(context, this.currentCompensationToken.Get(context));
            }
            token.BookmarkTable[CompensationBookmarkName.OnSecondaryRootScheduled] = context.CreateBookmark(new BookmarkCallback(this.OnSecondaryRootScheduled));
            this.compensationId.Set(context, token.CompensationId);
            context.ScheduleSecondaryRoot(this.CompensationParticipant, context.Environment);
        }

        public Collection<Variable> Variables
        {
            get
            {
                if (this.variables == null)
                {
                    ValidatingCollection<Variable> collection1 = new ValidatingCollection<Variable> {
                        OnAddValidationCallback = delegate (Variable item) {
                            if (item == null)
                            {
                                throw FxTrace.Exception.ArgumentNull("item");
                            }
                        }
                    };
                    this.variables = collection1;
                }
                return this.variables;
            }
        }

        [DefaultValue((string) null), DependsOn("Variables")]
        public Activity Body { get; set; }

        [DefaultValue((string) null), DependsOn("Body")]
        public Activity CancellationHandler { get; set; }

        [DefaultValue((string) null), DependsOn("CancellationHandler")]
        public Activity CompensationHandler { get; set; }

        [DefaultValue((string) null), DependsOn("CompensationHandler")]
        public Activity ConfirmationHandler { get; set; }

        protected override bool CanInduceIdle =>
            true;

        private System.Activities.Statements.CompensationParticipant CompensationParticipant
        {
            get
            {
                if (this.compensationParticipant == null)
                {
                    this.compensationParticipant = new System.Activities.Statements.CompensationParticipant(this.compensationId);
                    if (this.CompensationHandler != null)
                    {
                        this.compensationParticipant.CompensationHandler = this.CompensationHandler;
                    }
                    if (this.ConfirmationHandler != null)
                    {
                        this.compensationParticipant.ConfirmationHandler = this.ConfirmationHandler;
                    }
                    if (this.CancellationHandler != null)
                    {
                        this.compensationParticipant.CancellationHandler = this.CancellationHandler;
                    }
                }
                return this.compensationParticipant;
            }
            set => 
                this.compensationParticipant = value;
        }

        [Serializable, CompilerGenerated]
        private sealed class <>c
        {
            public static readonly CompensableActivity.<>c <>9 = new CompensableActivity.<>c();
            public static Action<Variable> <>9__8_0;

            internal void <get_Variables>b__8_0(Variable item)
            {
                if (item == null)
                {
                    throw FxTrace.Exception.ArgumentNull("item");
                }
            }
        }
    }
}

