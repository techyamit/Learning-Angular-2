﻿namespace System.Activities.Statements
{
    using System;
    using System.Activities;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Runtime.Collections;
    using System.Runtime.CompilerServices;
    using System.Windows.Markup;

    [ContentProperty("Action")]
    public sealed class InvokeAction : NativeActivity
    {
        private IList<Argument> actionArguments;

        public InvokeAction()
        {
            ValidatingCollection<Argument> collection1 = new ValidatingCollection<Argument> {
                OnAddValidationCallback = delegate (Argument item) {
                    if (item == null)
                    {
                        throw FxTrace.Exception.ArgumentNull("item");
                    }
                }
            };
            this.actionArguments = collection1;
        }

        protected override void CacheMetadata(NativeActivityMetadata metadata)
        {
            metadata.AddDelegate(this.Action);
        }

        protected override void Execute(NativeActivityContext context)
        {
            if ((this.Action != null) && (this.Action.Handler != null))
            {
                context.ScheduleAction(this.Action, null, null);
            }
        }

        [DefaultValue((string) null)]
        public ActivityAction Action { get; set; }

        [Serializable, CompilerGenerated]
        private sealed class <>c
        {
            public static readonly InvokeAction.<>c <>9 = new InvokeAction.<>c();
            public static Action<Argument> <>9__1_0;

            internal void <.ctor>b__1_0(Argument item)
            {
                if (item == null)
                {
                    throw FxTrace.Exception.ArgumentNull("item");
                }
            }
        }
    }
}

