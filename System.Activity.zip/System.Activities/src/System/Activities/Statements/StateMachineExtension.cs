﻿namespace System.Activities.Statements
{
    using System;
    using System.Activities;
    using System.Activities.Hosting;
    using System.Collections.Generic;
    using System.Runtime;

    internal class StateMachineExtension : IWorkflowInstanceExtension
    {
        private WorkflowInstanceProxy instance;

        public IEnumerable<object> GetAdditionalExtensions() => 
            null;

        private static void OnResumeBookmarkCompleted(IAsyncResult result)
        {
            if (!result.CompletedSynchronously)
            {
                (result.AsyncState as WorkflowInstanceProxy).EndResumeBookmark(result);
            }
        }

        public void ResumeBookmark(Bookmark bookmark)
        {
            IAsyncResult result = this.instance.BeginResumeBookmark(bookmark, null, Fx.ThunkCallback(new AsyncCallback(StateMachineExtension.OnResumeBookmarkCompleted)), this.instance);
            if (result.CompletedSynchronously)
            {
                this.instance.EndResumeBookmark(result);
            }
        }

        public void SetInstance(WorkflowInstanceProxy instance)
        {
            this.instance = instance;
        }
    }
}

