﻿namespace System.Activities.Statements
{
    using System;
    using System.Activities;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Linq;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Runtime.Serialization;

    [DataContract]
    internal class StateMachineEventManager
    {
        private const int MaxQueueLength = 0x2000000;
        private Queue<TriggerCompletedEvent> queue = new Queue<TriggerCompletedEvent>();
        private Collection<Bookmark> activeBookmarks = new Collection<Bookmark>();

        public void AddActiveBookmark(Bookmark bookmark)
        {
            this.activeBookmarks.Add(bookmark);
        }

        public TriggerCompletedEvent GetNextCompletedEvent()
        {
            while (this.queue.Any<TriggerCompletedEvent>())
            {
                TriggerCompletedEvent event2 = this.queue.Dequeue();
                if (this.activeBookmarks.Contains(event2.Bookmark))
                {
                    this.CurrentBeingProcessedEvent = event2;
                    return event2;
                }
            }
            return null;
        }

        public bool IsReferredByBeingProcessedEvent(Bookmark bookmark) => 
            (this.CurrentBeingProcessedEvent != null) && (this.CurrentBeingProcessedEvent.Bookmark == bookmark);

        public void RegisterCompletedEvent(TriggerCompletedEvent completedEvent, out bool canBeProcessedImmediately)
        {
            canBeProcessedImmediately = this.CanProcessEventImmediately;
            this.queue.Enqueue(completedEvent);
        }

        public void RemoveActiveBookmark(Bookmark bookmark)
        {
            this.activeBookmarks.Remove(bookmark);
        }

        [DataMember(EmitDefaultValue=false)]
        public TriggerCompletedEvent CurrentBeingProcessedEvent { get; set; }

        [DataMember(EmitDefaultValue=false)]
        public int CurrentConditionIndex { get; set; }

        [DataMember(EmitDefaultValue=false)]
        public bool OnTransition { get; set; }

        public IEnumerable<TriggerCompletedEvent> Queue =>
            this.queue;

        private bool CanProcessEventImmediately =>
            ((this.CurrentBeingProcessedEvent == null) && !this.OnTransition) && (this.queue.Count == 0);

        [DataMember(EmitDefaultValue=false, Name="queue")]
        internal Queue<TriggerCompletedEvent> SerializedQueue
        {
            get => 
                this.queue;
            set => 
                this.queue = value;
        }

        [DataMember(EmitDefaultValue=false, Name="activeBookmarks")]
        internal Collection<Bookmark> SerializedActiveBookmarks
        {
            get => 
                this.activeBookmarks;
            set => 
                this.activeBookmarks = value;
        }
    }
}

