﻿namespace System.Activities.Statements
{
    using System;

    internal static class CompensationActivityStrings
    {
        public const string WorkflowImplicitCompensationBehavior = "Activities.Compensation.WorkflowImplicitCompensationBehavior";
    }
}

