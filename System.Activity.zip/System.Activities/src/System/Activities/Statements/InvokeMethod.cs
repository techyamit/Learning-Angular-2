﻿namespace System.Activities.Statements
{
    using System;
    using System.Activities;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.Runtime;
    using System.Runtime.Collections;
    using System.Runtime.CompilerServices;
    using System.Threading;
    using System.Windows.Markup;

    [ContentProperty("Parameters")]
    public sealed class InvokeMethod : AsyncCodeActivity
    {
        private Collection<Argument> parameters;
        private Collection<Type> genericTypeArguments;
        private MethodResolver methodResolver;
        private MethodExecutor methodExecutor;
        private RuntimeArgument resultArgument;
        private static MruCache<MethodInfo, Func<object, object[], object>> funcCache = new MruCache<MethodInfo, Func<object, object[], object>>(500);
        private static ReaderWriterLockSlim locker = new ReaderWriterLockSlim();

        protected override IAsyncResult BeginExecute(AsyncCodeActivityContext context, AsyncCallback callback, object state) => 
            this.methodExecutor.BeginExecuteMethod(context, callback, state);

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            Collection<RuntimeArgument> arguments = new Collection<RuntimeArgument>();
            Type objectType = TypeHelper.ObjectType;
            if (this.TargetObject != null)
            {
                objectType = this.TargetObject.ArgumentType;
            }
            RuntimeArgument argument = new RuntimeArgument("TargetObject", objectType, ArgumentDirection.In);
            metadata.Bind(this.TargetObject, argument);
            arguments.Add(argument);
            Type argumentType = TypeHelper.ObjectType;
            if (this.Result != null)
            {
                argumentType = this.Result.ArgumentType;
            }
            this.resultArgument = new RuntimeArgument("Result", argumentType, ArgumentDirection.Out);
            metadata.Bind(this.Result, this.resultArgument);
            arguments.Add(this.resultArgument);
            this.methodResolver = this.CreateMethodResolver();
            this.methodResolver.DetermineMethodInfo(metadata, funcCache, locker, ref this.methodExecutor);
            this.methodResolver.RegisterParameters(arguments);
            metadata.SetArgumentsCollection(arguments);
            this.methodResolver.Trace();
            if (this.methodExecutor != null)
            {
                this.methodExecutor.Trace(this);
            }
        }

        private MethodResolver CreateMethodResolver()
        {
            MethodResolver resolver = new MethodResolver {
                MethodName = this.MethodName,
                RunAsynchronously = this.RunAsynchronously,
                TargetType = this.TargetType,
                TargetObject = this.TargetObject,
                GenericTypeArguments = this.GenericTypeArguments,
                Parameters = this.Parameters,
                Result = this.resultArgument,
                Parent = this
            };
            if (this.Result != null)
            {
                resolver.ResultType = this.Result.ArgumentType;
                return resolver;
            }
            resolver.ResultType = typeof(object);
            return resolver;
        }

        protected override void EndExecute(AsyncCodeActivityContext context, IAsyncResult result)
        {
            this.methodExecutor.EndExecuteMethod(context, result);
        }

        public Collection<Type> GenericTypeArguments
        {
            get
            {
                if (this.genericTypeArguments == null)
                {
                    ValidatingCollection<Type> collection1 = new ValidatingCollection<Type> {
                        OnAddValidationCallback = delegate (Type item) {
                            if (item == null)
                            {
                                throw FxTrace.Exception.ArgumentNull("item");
                            }
                        }
                    };
                    this.genericTypeArguments = collection1;
                }
                return this.genericTypeArguments;
            }
        }

        public string MethodName { get; set; }

        public Collection<Argument> Parameters
        {
            get
            {
                if (this.parameters == null)
                {
                    ValidatingCollection<Argument> collection1 = new ValidatingCollection<Argument> {
                        OnAddValidationCallback = delegate (Argument item) {
                            if (item == null)
                            {
                                throw FxTrace.Exception.ArgumentNull("item");
                            }
                        }
                    };
                    this.parameters = collection1;
                }
                return this.parameters;
            }
        }

        [DefaultValue((string) null)]
        public OutArgument Result { get; set; }

        [DefaultValue((string) null)]
        public InArgument TargetObject { get; set; }

        [DefaultValue((string) null)]
        public Type TargetType { get; set; }

        [DefaultValue(false)]
        public bool RunAsynchronously { get; set; }

        [Serializable, CompilerGenerated]
        private sealed class <>c
        {
            public static readonly InvokeMethod.<>c <>9 = new InvokeMethod.<>c();
            public static Action<Type> <>9__8_0;
            public static Action<Argument> <>9__14_0;

            internal void <get_GenericTypeArguments>b__8_0(Type item)
            {
                if (item == null)
                {
                    throw FxTrace.Exception.ArgumentNull("item");
                }
            }

            internal void <get_Parameters>b__14_0(Argument item)
            {
                if (item == null)
                {
                    throw FxTrace.Exception.ArgumentNull("item");
                }
            }
        }
    }
}

