﻿namespace System.Activities.Statements
{
    using System;
    using System.Activities;
    using System.Activities.DynamicUpdate;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.Runtime.Collections;
    using System.Runtime.CompilerServices;
    using System.Windows.Markup;

    [ContentProperty("Body")]
    public sealed class CancellationScope : NativeActivity
    {
        private Collection<Variable> variables;
        private Variable<bool> suppressCancel = new Variable<bool>();

        protected override void CacheMetadata(NativeActivityMetadata metadata)
        {
            metadata.AddChild(this.Body);
            metadata.AddChild(this.CancellationHandler);
            metadata.SetVariablesCollection(this.Variables);
            metadata.AddImplementationVariable(this.suppressCancel);
        }

        protected override void Cancel(NativeActivityContext context)
        {
            if (!this.suppressCancel.Get(context))
            {
                context.CancelChildren();
            }
        }

        protected override void Execute(NativeActivityContext context)
        {
            if (this.Body != null)
            {
                context.ScheduleActivity(this.Body, new CompletionCallback(this.OnBodyComplete));
            }
        }

        private void OnBodyComplete(NativeActivityContext context, System.Activities.ActivityInstance completedInstance)
        {
            if ((completedInstance.State == ActivityInstanceState.Canceled) || (context.IsCancellationRequested && (completedInstance.State == ActivityInstanceState.Faulted)))
            {
                this.suppressCancel.Set(context, true);
                context.MarkCanceled();
                if (this.CancellationHandler != null)
                {
                    context.ScheduleActivity(this.CancellationHandler, new FaultCallback(this.OnExceptionFromCancelHandler));
                }
            }
        }

        protected override void OnCreateDynamicUpdateMap(NativeActivityUpdateMapMetadata metadata, Activity originalActivity)
        {
            metadata.AllowUpdateInsideThisActivity();
        }

        private void OnExceptionFromCancelHandler(NativeActivityFaultContext context, Exception propagatedException, System.Activities.ActivityInstance propagatedFrom)
        {
            this.suppressCancel.Set(context, false);
        }

        public Collection<Variable> Variables
        {
            get
            {
                if (this.variables == null)
                {
                    ValidatingCollection<Variable> collection1 = new ValidatingCollection<Variable> {
                        OnAddValidationCallback = delegate (Variable item) {
                            if (item == null)
                            {
                                throw FxTrace.Exception.ArgumentNull("item");
                            }
                        }
                    };
                    this.variables = collection1;
                }
                return this.variables;
            }
        }

        [DefaultValue((string) null), DependsOn("Variables")]
        public Activity Body { get; set; }

        [DefaultValue((string) null), DependsOn("Body")]
        public Activity CancellationHandler { get; set; }

        [Serializable, CompilerGenerated]
        private sealed class <>c
        {
            public static readonly CancellationScope.<>c <>9 = new CancellationScope.<>c();
            public static Action<Variable> <>9__4_0;

            internal void <get_Variables>b__4_0(Variable item)
            {
                if (item == null)
                {
                    throw FxTrace.Exception.ArgumentNull("item");
                }
            }
        }
    }
}

