﻿namespace System.Activities.Statements
{
    using System;
    using System.Activities;
    using System.Collections.ObjectModel;
    using System.Runtime.CompilerServices;

    internal sealed class DefaultCompensation : NativeActivity
    {
        private Activity body;
        private Variable<CompensationToken> toCompensateToken = new Variable<CompensationToken>();
        private CompletionCallback onChildCompensated;

        public DefaultCompensation()
        {
            InternalCompensate compensate1 = new InternalCompensate {
                Target = new InArgument<CompensationToken>(this.toCompensateToken)
            };
            this.body = compensate1;
        }

        protected override void CacheMetadata(NativeActivityMetadata metadata)
        {
            RuntimeArgument argument = new RuntimeArgument("Target", typeof(CompensationToken), ArgumentDirection.In);
            metadata.Bind(this.Target, argument);
            Collection<RuntimeArgument> arguments = new Collection<RuntimeArgument> {
                argument
            };
            metadata.SetArgumentsCollection(arguments);
            Collection<Variable> implementationVariables = new Collection<Variable> {
                this.toCompensateToken
            };
            metadata.SetImplementationVariablesCollection(implementationVariables);
            Collection<Activity> implementationChildren = new Collection<Activity> {
                this.Body
            };
            metadata.SetImplementationChildrenCollection(implementationChildren);
        }

        protected override void Cancel(NativeActivityContext context)
        {
        }

        protected override void Execute(NativeActivityContext context)
        {
            this.InternalExecute(context, null);
        }

        private void InternalExecute(NativeActivityContext context, System.Activities.ActivityInstance completedInstance)
        {
            CompensationExtension extension = context.GetExtension<CompensationExtension>();
            if (extension == null)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.CompensateWithoutCompensableActivity(base.DisplayName)));
            }
            CompensationToken token = this.Target.Get(context);
            CompensationTokenData data = (token == null) ? null : extension.Get(token.CompensationId);
            if (data.ExecutionTracker.Count > 0)
            {
                if (this.onChildCompensated == null)
                {
                    this.onChildCompensated = new CompletionCallback(this.InternalExecute);
                }
                this.toCompensateToken.Set(context, new CompensationToken(data.ExecutionTracker.Get()));
                context.ScheduleActivity(this.Body, this.onChildCompensated);
            }
        }

        public InArgument<CompensationToken> Target { get; set; }

        private Activity Body =>
            this.body;
    }
}

