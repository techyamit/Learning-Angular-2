﻿namespace System.Activities
{
    using System;
    using System.Runtime.Serialization;

    [DataContract]
    internal class TypedLocationWrapper<T> : Location<T>
    {
        private Location innerLocation;

        public TypedLocationWrapper(Location innerLocation)
        {
            this.innerLocation = innerLocation;
        }

        public override string ToString() => 
            this.innerLocation.ToString();

        internal override bool CanBeMapped =>
            this.innerLocation.CanBeMapped;

        public override T Value
        {
            get => 
                (T) this.innerLocation.Value;
            set => 
                this.innerLocation.Value = value;
        }

        [DataMember(Name="innerLocation")]
        internal Location SerializedInnerLocation
        {
            get => 
                this.innerLocation;
            set => 
                this.innerLocation = value;
        }
    }
}

