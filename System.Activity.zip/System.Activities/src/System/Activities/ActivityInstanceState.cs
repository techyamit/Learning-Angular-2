﻿namespace System.Activities
{
    using System;
    using System.Runtime.Serialization;

    [DataContract]
    public enum ActivityInstanceState
    {
        [EnumMember]
        Executing = 0,
        [EnumMember]
        Closed = 1,
        [EnumMember]
        Canceled = 2,
        [EnumMember]
        Faulted = 3
    }
}

