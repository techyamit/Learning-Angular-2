﻿namespace System.Activities
{
    using System;

    public enum ArgumentDirection
    {
        In,
        Out,
        InOut
    }
}

