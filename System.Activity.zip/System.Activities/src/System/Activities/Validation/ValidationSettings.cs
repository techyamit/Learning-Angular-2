﻿namespace System.Activities.Validation
{
    using System;
    using System.Activities;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;
    using System.Threading;

    public class ValidationSettings
    {
        private IDictionary<Type, IList<Constraint>> additionalConstraints;

        public System.Threading.CancellationToken CancellationToken { get; set; }

        public bool SingleLevel { get; set; }

        public bool SkipValidatingRootConfiguration { get; set; }

        public bool OnlyUseAdditionalConstraints { get; set; }

        public bool PrepareForRuntime { get; set; }

        public LocationReferenceEnvironment Environment { get; set; }

        internal bool HasAdditionalConstraints =>
            (this.additionalConstraints != null) && (this.additionalConstraints.Count > 0);

        public IDictionary<Type, IList<Constraint>> AdditionalConstraints
        {
            get
            {
                if (this.additionalConstraints == null)
                {
                    this.additionalConstraints = new Dictionary<Type, IList<Constraint>>();
                }
                return this.additionalConstraints;
            }
        }
    }
}

