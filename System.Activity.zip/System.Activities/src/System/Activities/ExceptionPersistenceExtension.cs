﻿namespace System.Activities
{
    using System;

    public class ExceptionPersistenceExtension
    {
        private bool persistExceptions = true;

        public bool PersistExceptions
        {
            get => 
                this.persistExceptions;
            set => 
                this.persistExceptions = value;
        }
    }
}

