﻿namespace System.Activities
{
    using System;
    using System.Activities.DynamicUpdate;
    using System.Collections.Generic;
    using System.Runtime;
    using System.Runtime.CompilerServices;
    using System.Runtime.DurableInstancing;
    using System.Runtime.InteropServices;
    using System.Threading;

    public class WorkflowApplicationInstance
    {
        private int state;

        internal WorkflowApplicationInstance(System.Activities.WorkflowApplication.PersistenceManagerBase persistenceManager, IDictionary<XName, InstanceValue> values, WorkflowIdentity definitionIdentity)
        {
            this.PersistenceManager = persistenceManager;
            this.Values = values;
            this.DefinitionIdentity = definitionIdentity;
            this.state = 0;
        }

        public void Abandon()
        {
            this.Abandon(ActivityDefaults.DeleteTimeout);
        }

        public void Abandon(TimeSpan timeout)
        {
            System.Runtime.TimeoutHelper.ThrowIfNegativeArgument(timeout);
            this.MarkAsAbandoned();
            System.Activities.WorkflowApplication.DiscardInstance(this.PersistenceManager, timeout);
        }

        public IAsyncResult BeginAbandon(AsyncCallback callback, object state) => 
            this.BeginAbandon(ActivityDefaults.DeleteTimeout, callback, state);

        public IAsyncResult BeginAbandon(TimeSpan timeout, AsyncCallback callback, object state)
        {
            System.Runtime.TimeoutHelper.ThrowIfNegativeArgument(timeout);
            this.MarkAsAbandoned();
            return System.Activities.WorkflowApplication.BeginDiscardInstance(this.PersistenceManager, timeout, callback, state);
        }

        public bool CanApplyUpdate(DynamicUpdateMap updateMap, out IList<ActivityBlockingUpdate> activitiesBlockingUpdate)
        {
            if (updateMap == null)
            {
                throw FxTrace.Exception.ArgumentNull("updateMap");
            }
            activitiesBlockingUpdate = System.Activities.WorkflowApplication.GetActivitiesBlockingUpdate(this, updateMap);
            if (activitiesBlockingUpdate != null)
            {
                return (activitiesBlockingUpdate.Count == 0);
            }
            return true;
        }

        public void EndAbandon(IAsyncResult asyncResult)
        {
            System.Activities.WorkflowApplication.EndDiscardInstance(asyncResult);
        }

        private void MarkAsAbandoned()
        {
            int num = Interlocked.CompareExchange(ref this.state, 2, 0);
            this.ThrowIfLoadedOrAbandoned((State) num);
        }

        internal void MarkAsLoaded()
        {
            int num = Interlocked.CompareExchange(ref this.state, 1, 0);
            this.ThrowIfLoadedOrAbandoned((State) num);
        }

        private void ThrowIfLoadedOrAbandoned(State oldState)
        {
            if (oldState == State.Loaded)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.WorkflowApplicationInstanceLoaded));
            }
            if (oldState == State.Aborted)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.WorkflowApplicationInstanceAbandoned));
            }
        }

        public WorkflowIdentity DefinitionIdentity { get; private set; }

        public System.Runtime.DurableInstancing.InstanceStore InstanceStore =>
            this.PersistenceManager.InstanceStore;

        public Guid InstanceId =>
            this.PersistenceManager.InstanceId;

        internal System.Activities.WorkflowApplication.PersistenceManagerBase PersistenceManager { get; private set; }

        internal IDictionary<XName, InstanceValue> Values { get; private set; }

        private enum State
        {
            Initialized,
            Loaded,
            Aborted
        }
    }
}

