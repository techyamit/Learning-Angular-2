﻿namespace System.Activities
{
    using System;
    using System.Activities.DynamicUpdate;
    using System.Activities.Runtime;
    using System.Runtime.Serialization;

    public abstract class NativeActivity<TResult> : Activity<TResult>, IInstanceUpdatable
    {
        protected NativeActivity()
        {
        }

        protected virtual void Abort(NativeActivityAbortContext context)
        {
        }

        protected sealed override void CacheMetadata(ActivityMetadata metadata)
        {
            throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.WrongCacheMetadataForNativeActivity));
        }

        protected virtual void CacheMetadata(NativeActivityMetadata metadata)
        {
            Activity.ReflectedInformation information = new Activity.ReflectedInformation(this);
            base.SetArgumentsCollection(information.GetArguments(), metadata.CreateEmptyBindings);
            base.SetChildrenCollection(information.GetChildren());
            base.SetDelegatesCollection(information.GetDelegates());
            base.SetVariablesCollection(information.GetVariables());
        }

        protected virtual void Cancel(NativeActivityContext context)
        {
            if (!context.IsCancellationRequested)
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.DefaultCancelationRequiresCancelHasBeenRequested));
            }
            context.Cancel();
        }

        protected abstract void Execute(NativeActivityContext context);
        internal override void InternalAbort(System.Activities.ActivityInstance instance, ActivityExecutor executor, Exception terminationReason)
        {
            using (NativeActivityAbortContext context = new NativeActivityAbortContext(instance, executor, terminationReason))
            {
                this.Abort(context);
            }
        }

        internal override void InternalCancel(System.Activities.ActivityInstance instance, ActivityExecutor executor, BookmarkManager bookmarkManager)
        {
            NativeActivityContext context = executor.NativeActivityContextPool.Acquire();
            try
            {
                context.Initialize(instance, executor, bookmarkManager);
                this.Cancel(context);
            }
            finally
            {
                context.Dispose();
                executor.NativeActivityContextPool.Release(context);
            }
        }

        internal override void InternalExecute(System.Activities.ActivityInstance instance, ActivityExecutor executor, BookmarkManager bookmarkManager)
        {
            NativeActivityContext context = executor.NativeActivityContextPool.Acquire();
            try
            {
                context.Initialize(instance, executor, bookmarkManager);
                this.Execute(context);
            }
            finally
            {
                context.Dispose();
                executor.NativeActivityContextPool.Release(context);
            }
        }

        protected virtual void OnCreateDynamicUpdateMap(NativeActivityUpdateMapMetadata metadata, Activity originalActivity)
        {
            if (!metadata.IsUpdateExplicitlyAllowedOrDisallowed && !NativeActivity.DoPublicChildrenMatch(metadata, this, originalActivity))
            {
                metadata.DisallowUpdateInsideThisActivity(System.Activities.SR.PublicChildrenChangeBlockDU);
            }
        }

        protected sealed override void OnCreateDynamicUpdateMap(UpdateMapMetadata metadata, Activity originalActivity)
        {
            throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.WrongOnCreateDynamicUpdateMapForNativeActivity));
        }

        internal sealed override void OnInternalCacheMetadataExceptResult(bool createEmptyBindings)
        {
            NativeActivityMetadata metadata = new NativeActivityMetadata(this, base.GetParentEnvironment(), createEmptyBindings);
            this.CacheMetadata(metadata);
            metadata.Dispose();
        }

        internal sealed override void OnInternalCreateDynamicUpdateMap(DynamicUpdateMapBuilder.Finalizer finalizer, DynamicUpdateMapBuilder.IDefinitionMatcher matcher, Activity originalActivity)
        {
            using (NativeActivityUpdateMapMetadata metadata = new NativeActivityUpdateMapMetadata(finalizer, matcher, this))
            {
                this.OnCreateDynamicUpdateMap(metadata, originalActivity);
            }
        }

        void IInstanceUpdatable.InternalUpdateInstance(NativeActivityUpdateContext updateContext)
        {
            this.UpdateInstance(updateContext);
        }

        protected virtual void UpdateInstance(NativeActivityUpdateContext updateContext)
        {
        }

        protected internal sealed override Version ImplementationVersion
        {
            get => 
                null;
            set
            {
                if (value != null)
                {
                    throw System.Activities.FxTrace.Exception.AsError(new NotSupportedException());
                }
            }
        }

        [IgnoreDataMember]
        protected sealed override Func<Activity> Implementation
        {
            get => 
                null;
            set
            {
                if (value != null)
                {
                    throw System.Activities.FxTrace.Exception.AsError(new NotSupportedException());
                }
            }
        }

        protected virtual bool CanInduceIdle =>
            false;

        internal override bool InternalCanInduceIdle =>
            this.CanInduceIdle;
    }
}

