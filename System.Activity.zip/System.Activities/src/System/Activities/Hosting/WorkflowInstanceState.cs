﻿namespace System.Activities.Hosting
{
    using System;

    public enum WorkflowInstanceState
    {
        Idle,
        Runnable,
        Complete,
        Aborted
    }
}

