﻿namespace System.Activities.Hosting
{
    using System;
    using System.Runtime;
    using System.Runtime.CompilerServices;

    internal abstract class WorkflowInstanceExtensionProvider
    {
        protected WorkflowInstanceExtensionProvider()
        {
        }

        public bool IsMatch<TTarget>(object value) where TTarget: class => 
            (value is TTarget) && (this.GeneratedTypeMatchesDeclaredType || TypeHelper.AreReferenceTypesCompatible(this.Type, typeof(TTarget)));

        public abstract object ProvideValue();

        public System.Type Type { get; protected set; }

        protected bool GeneratedTypeMatchesDeclaredType { get; set; }
    }
}

