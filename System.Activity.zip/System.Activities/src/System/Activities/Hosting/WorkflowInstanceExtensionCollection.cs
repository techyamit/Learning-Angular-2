﻿namespace System.Activities.Hosting
{
    using System;
    using System.Activities;
    using System.Collections;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Linq;
    using System.Runtime;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;

    internal class WorkflowInstanceExtensionCollection
    {
        private List<KeyValuePair<WorkflowInstanceExtensionProvider, object>> instanceExtensions;
        private List<object> additionalInstanceExtensions;
        private List<object> allSingletonExtensions;
        private bool hasTrackingParticipant;
        private bool hasPersistenceModule;
        private bool shouldSetInstanceForInstanceExtensions;
        private Dictionary<Type, object> singleTypeCache;
        private List<IWorkflowInstanceExtension> workflowInstanceExtensions;
        private Type lastTypeCached;
        private object lastObjectCached;
        private WorkflowInstanceExtensionManager extensionManager;

        internal WorkflowInstanceExtensionCollection(Activity workflowDefinition, WorkflowInstanceExtensionManager extensionManager)
        {
            this.extensionManager = extensionManager;
            int capacity = 0;
            if (extensionManager != null)
            {
                capacity = extensionManager.ExtensionProviders.Count;
                this.hasTrackingParticipant = extensionManager.HasSingletonTrackingParticipant;
                this.hasPersistenceModule = extensionManager.HasSingletonPersistenceModule;
                this.allSingletonExtensions = this.extensionManager.GetAllSingletonExtensions();
            }
            else
            {
                this.allSingletonExtensions = WorkflowInstanceExtensionManager.EmptySingletonExtensions;
            }
            Dictionary<Type, WorkflowInstanceExtensionProvider> dictionary2 = null;
            if (workflowDefinition.GetActivityExtensionInformation(out Dictionary<Type, WorkflowInstanceExtensionProvider> dictionary, out HashSet<Type> set))
            {
                HashSet<Type> extensionTypes = new HashSet<Type>();
                if (extensionManager != null)
                {
                    extensionManager.AddAllExtensionTypes(extensionTypes);
                }
                if (dictionary != null)
                {
                    dictionary2 = new Dictionary<Type, WorkflowInstanceExtensionProvider>(dictionary.Count);
                    foreach (KeyValuePair<Type, WorkflowInstanceExtensionProvider> pair in dictionary)
                    {
                        Type key = pair.Key;
                        if (!System.Runtime.TypeHelper.ContainsCompatibleType(extensionTypes, key))
                        {
                            List<Type> list = null;
                            bool flag = false;
                            foreach (Type type2 in dictionary2.Keys)
                            {
                                if (System.Runtime.TypeHelper.AreReferenceTypesCompatible(type2, key))
                                {
                                    flag = true;
                                    break;
                                }
                                if (System.Runtime.TypeHelper.AreReferenceTypesCompatible(key, type2))
                                {
                                    if (list == null)
                                    {
                                        list = new List<Type>();
                                    }
                                    list.Add(type2);
                                }
                            }
                            if (list != null)
                            {
                                for (int i = 0; i < list.Count; i++)
                                {
                                    dictionary2.Remove(list[i]);
                                }
                            }
                            if (!flag)
                            {
                                dictionary2.Add(key, pair.Value);
                            }
                        }
                    }
                    if (dictionary2.Count > 0)
                    {
                        extensionTypes.UnionWith(dictionary2.Keys);
                        capacity += dictionary2.Count;
                    }
                }
                if ((set != null) && (set.Count > 0))
                {
                    foreach (Type type3 in set)
                    {
                        if (!System.Runtime.TypeHelper.ContainsCompatibleType(extensionTypes, type3))
                        {
                            throw FxTrace.Exception.AsError(new ValidationException(System.Activities.SR.RequiredExtensionTypeNotFound(type3.ToString())));
                        }
                    }
                }
            }
            if (capacity > 0)
            {
                this.instanceExtensions = new List<KeyValuePair<WorkflowInstanceExtensionProvider, object>>(capacity);
                if (extensionManager != null)
                {
                    List<KeyValuePair<Type, WorkflowInstanceExtensionProvider>> extensionProviders = extensionManager.ExtensionProviders;
                    for (int i = 0; i < extensionProviders.Count; i++)
                    {
                        KeyValuePair<Type, WorkflowInstanceExtensionProvider> pair2 = extensionProviders[i];
                        this.AddInstanceExtension(pair2.Value);
                    }
                }
                if (dictionary2 != null)
                {
                    foreach (WorkflowInstanceExtensionProvider provider in dictionary2.Values)
                    {
                        this.AddInstanceExtension(provider);
                    }
                }
            }
        }

        private void AddInstanceExtension(WorkflowInstanceExtensionProvider extensionProvider)
        {
            object obj2 = extensionProvider.ProvideValue();
            if (obj2 is SymbolResolver)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.SymbolResolverMustBeSingleton));
            }
            if (!this.shouldSetInstanceForInstanceExtensions && (obj2 is IWorkflowInstanceExtension))
            {
                this.shouldSetInstanceForInstanceExtensions = true;
            }
            if (!this.hasTrackingParticipant && extensionProvider.IsMatch<TrackingParticipant>(obj2))
            {
                this.hasTrackingParticipant = true;
            }
            if (!this.hasPersistenceModule && extensionProvider.IsMatch<IPersistencePipelineModule>(obj2))
            {
                this.hasPersistenceModule = true;
            }
            this.instanceExtensions.Add(new KeyValuePair<WorkflowInstanceExtensionProvider, object>(extensionProvider, obj2));
            WorkflowInstanceExtensionManager.AddExtensionClosure(obj2, ref this.additionalInstanceExtensions, ref this.hasTrackingParticipant, ref this.hasPersistenceModule);
        }

        private void CacheExtension<T>(T extension) where T: class
        {
            if (extension != null)
            {
                this.CacheExtension(typeof(T), extension);
            }
        }

        private void CacheExtension(Type extensionType, object extension)
        {
            if (extension != null)
            {
                if (this.singleTypeCache == null)
                {
                    this.singleTypeCache = new Dictionary<Type, object>();
                }
                this.lastTypeCached = extensionType;
                this.lastObjectCached = extension;
                this.singleTypeCache[extensionType] = extension;
            }
        }

        public void Cancel()
        {
            foreach (ICancelable cancelable in this.GetInstanceExtensions<ICancelable>(true))
            {
                cancelable.Cancel();
            }
        }

        public void Dispose()
        {
            foreach (IDisposable disposable in this.GetInstanceExtensions<IDisposable>(true))
            {
                disposable.Dispose();
            }
        }

        public T Find<T>() where T: class
        {
            T local2;
            T extension = default(T);
            if (this.TryGetCachedExtension(typeof(T), out object obj2))
            {
                return (T) obj2;
            }
            try
            {
                for (int i = 0; i < this.allSingletonExtensions.Count; i++)
                {
                    object obj3 = this.allSingletonExtensions[i];
                    extension = obj3 as T;
                    if (extension != null)
                    {
                        return extension;
                    }
                }
                if (this.instanceExtensions != null)
                {
                    for (int j = 0; j < this.instanceExtensions.Count; j++)
                    {
                        KeyValuePair<WorkflowInstanceExtensionProvider, object> pair = this.instanceExtensions[j];
                        if (pair.Key.IsMatch<T>(pair.Value))
                        {
                            return (T) pair.Value;
                        }
                    }
                    if (this.additionalInstanceExtensions != null)
                    {
                        for (int k = 0; k < this.additionalInstanceExtensions.Count; k++)
                        {
                            object obj4 = this.additionalInstanceExtensions[k];
                            extension = obj4 as T;
                            if (extension != null)
                            {
                                return extension;
                            }
                        }
                    }
                }
                local2 = extension;
            }
            finally
            {
                this.CacheExtension<T>(extension);
            }
            return local2;
        }

        public IEnumerable<T> FindAll<T>() where T: class => 
            this.FindAll<T>(false);

        [IteratorStateMachine(typeof(<FindAll>d__25))]
        private IEnumerable<T> FindAll<T>(bool useObjectTypeForComparison) where T: class => 
            new <FindAll>d__25<T>(-2) { 
                <>4__this = this,
                <>3__useObjectTypeForComparison = useObjectTypeForComparison
            };

        [IteratorStateMachine(typeof(<GetInstanceExtensions>d__26))]
        private IEnumerable<T> GetInstanceExtensions<T>(bool useObjectTypeForComparison) where T: class => 
            new <GetInstanceExtensions>d__26<T>(-2) { 
                <>4__this = this,
                <>3__useObjectTypeForComparison = useObjectTypeForComparison
            };

        internal void Initialize()
        {
            if ((this.extensionManager != null) && this.extensionManager.HasSingletonIWorkflowInstanceExtensions)
            {
                this.SetInstance(this.extensionManager.SingletonExtensions);
                if (this.extensionManager.HasAdditionalSingletonIWorkflowInstanceExtensions)
                {
                    this.SetInstance(this.extensionManager.AdditionalSingletonExtensions);
                }
            }
            if (this.shouldSetInstanceForInstanceExtensions)
            {
                for (int i = 0; i < this.instanceExtensions.Count; i++)
                {
                    KeyValuePair<WorkflowInstanceExtensionProvider, object> pair = this.instanceExtensions[i];
                    IWorkflowInstanceExtension item = pair.Value as IWorkflowInstanceExtension;
                    if (item != null)
                    {
                        if (this.workflowInstanceExtensions == null)
                        {
                            this.workflowInstanceExtensions = new List<IWorkflowInstanceExtension>();
                        }
                        this.workflowInstanceExtensions.Add(item);
                    }
                }
                if (this.additionalInstanceExtensions != null)
                {
                    this.SetInstance(this.additionalInstanceExtensions);
                }
            }
        }

        private void SetInstance(List<object> extensionsList)
        {
            for (int i = 0; i < extensionsList.Count; i++)
            {
                object obj2 = extensionsList[i];
                if (obj2 is IWorkflowInstanceExtension)
                {
                    if (this.workflowInstanceExtensions == null)
                    {
                        this.workflowInstanceExtensions = new List<IWorkflowInstanceExtension>();
                    }
                    this.workflowInstanceExtensions.Add((IWorkflowInstanceExtension) obj2);
                }
            }
        }

        private bool TryGetCachedExtension(Type type, out object extension)
        {
            if (this.singleTypeCache == null)
            {
                extension = null;
                return false;
            }
            if (type == this.lastTypeCached)
            {
                extension = this.lastObjectCached;
                return true;
            }
            return this.singleTypeCache.TryGetValue(type, out extension);
        }

        internal bool HasPersistenceModule =>
            this.hasPersistenceModule;

        internal bool HasTrackingParticipant =>
            this.hasTrackingParticipant;

        public bool HasWorkflowInstanceExtensions =>
            (this.workflowInstanceExtensions != null) && (this.workflowInstanceExtensions.Count > 0);

        public List<IWorkflowInstanceExtension> WorkflowInstanceExtensions =>
            this.workflowInstanceExtensions;

        [CompilerGenerated]
        private sealed class <FindAll>d__25<T> : IEnumerable<T>, IEnumerable, IEnumerator<T>, IDisposable, IEnumerator where T: class
        {
            private int <>1__state;
            private T <>2__current;
            private int <>l__initialThreadId;
            public WorkflowInstanceExtensionCollection <>4__this;
            private T <lastExtension>5__1;
            private bool useObjectTypeForComparison;
            public bool <>3__useObjectTypeForComparison;
            private bool <hasMultiple>5__2;
            private IEnumerator<T> <>7__wrap1;

            [DebuggerHidden]
            public <FindAll>d__25(int <>1__state)
            {
                this.<>1__state = <>1__state;
                this.<>l__initialThreadId = Environment.CurrentManagedThreadId;
            }

            private void <>m__Finally1()
            {
                this.<>1__state = -1;
                if (this.<>7__wrap1 != null)
                {
                    this.<>7__wrap1.Dispose();
                }
            }

            private void <>m__Finally2()
            {
                this.<>1__state = -1;
                if (this.<>7__wrap1 != null)
                {
                    this.<>7__wrap1.Dispose();
                }
            }

            private bool MoveNext()
            {
                bool flag;
                try
                {
                    int num = this.<>1__state;
                    WorkflowInstanceExtensionCollection extensions = this.<>4__this;
                    switch (num)
                    {
                        case 0:
                            this.<>1__state = -1;
                            if (!extensions.TryGetCachedExtension(typeof(T), out object obj2))
                            {
                                break;
                            }
                            this.<>2__current = (T) obj2;
                            this.<>1__state = 1;
                            return true;

                        case 1:
                            this.<>1__state = -1;
                            goto Label_01A3;

                        case 2:
                            goto Label_00E0;

                        case 3:
                            goto Label_0161;

                        default:
                            return false;
                    }
                    this.<lastExtension>5__1 = default(T);
                    this.<hasMultiple>5__2 = false;
                    this.<>7__wrap1 = extensions.allSingletonExtensions.OfType<T>().GetEnumerator();
                    this.<>1__state = -3;
                    while (this.<>7__wrap1.MoveNext())
                    {
                        T current = this.<>7__wrap1.Current;
                        if (this.<lastExtension>5__1 == null)
                        {
                            this.<lastExtension>5__1 = current;
                        }
                        else
                        {
                            this.<hasMultiple>5__2 = true;
                        }
                        this.<>2__current = current;
                        this.<>1__state = 2;
                        return true;
                    Label_00E0:
                        this.<>1__state = -3;
                    }
                    this.<>m__Finally1();
                    this.<>7__wrap1 = null;
                    this.<>7__wrap1 = extensions.GetInstanceExtensions<T>(this.useObjectTypeForComparison).GetEnumerator();
                    this.<>1__state = -4;
                    while (this.<>7__wrap1.MoveNext())
                    {
                        T current = this.<>7__wrap1.Current;
                        if (this.<lastExtension>5__1 == null)
                        {
                            this.<lastExtension>5__1 = current;
                        }
                        else
                        {
                            this.<hasMultiple>5__2 = true;
                        }
                        this.<>2__current = current;
                        this.<>1__state = 3;
                        return true;
                    Label_0161:
                        this.<>1__state = -4;
                    }
                    this.<>m__Finally2();
                    this.<>7__wrap1 = null;
                    if (!this.<hasMultiple>5__2)
                    {
                        extensions.CacheExtension<T>(this.<lastExtension>5__1);
                    }
                    this.<lastExtension>5__1 = default(T);
                Label_01A3:
                    flag = false;
                }
                fault
                {
                    this.System.IDisposable.Dispose();
                }
                return flag;
            }

            [DebuggerHidden]
            IEnumerator<T> IEnumerable<T>.GetEnumerator()
            {
                WorkflowInstanceExtensionCollection.<FindAll>d__25<T> d__;
                if ((this.<>1__state == -2) && (this.<>l__initialThreadId == Environment.CurrentManagedThreadId))
                {
                    this.<>1__state = 0;
                    d__ = (WorkflowInstanceExtensionCollection.<FindAll>d__25<T>) this;
                }
                else
                {
                    d__ = new WorkflowInstanceExtensionCollection.<FindAll>d__25<T>(0) {
                        <>4__this = this.<>4__this
                    };
                }
                d__.useObjectTypeForComparison = this.<>3__useObjectTypeForComparison;
                return d__;
            }

            [DebuggerHidden]
            IEnumerator IEnumerable.GetEnumerator() => 
                this.System.Collections.Generic.IEnumerable<T>.GetEnumerator();

            [DebuggerHidden]
            void IEnumerator.Reset()
            {
                throw new NotSupportedException();
            }

            [DebuggerHidden]
            void IDisposable.Dispose()
            {
                int num = this.<>1__state;
                if (num <= -3)
                {
                    if (num == -4)
                    {
                        goto Label_002A;
                    }
                    if (num != -3)
                    {
                        return;
                    }
                }
                else if (num != 2)
                {
                    if (num != 3)
                    {
                        return;
                    }
                    goto Label_002A;
                }
                try
                {
                    return;
                }
                finally
                {
                    this.<>m__Finally1();
                }
            Label_002A:;
                try
                {
                }
                finally
                {
                    this.<>m__Finally2();
                }
            }

            T IEnumerator<T>.Current =>
                this.<>2__current;

            object IEnumerator.Current =>
                this.<>2__current;
        }

        [CompilerGenerated]
        private sealed class <GetInstanceExtensions>d__26<T> : IEnumerable<T>, IEnumerable, IEnumerator<T>, IDisposable, IEnumerator where T: class
        {
            private int <>1__state;
            private T <>2__current;
            private int <>l__initialThreadId;
            public WorkflowInstanceExtensionCollection <>4__this;
            private bool useObjectTypeForComparison;
            public bool <>3__useObjectTypeForComparison;
            private int <i>5__1;
            private List<object>.Enumerator <>7__wrap1;

            [DebuggerHidden]
            public <GetInstanceExtensions>d__26(int <>1__state)
            {
                this.<>1__state = <>1__state;
                this.<>l__initialThreadId = Environment.CurrentManagedThreadId;
            }

            private void <>m__Finally1()
            {
                this.<>1__state = -1;
                this.<>7__wrap1.Dispose();
            }

            private bool MoveNext()
            {
                bool flag;
                try
                {
                    KeyValuePair<WorkflowInstanceExtensionProvider, object> pair;
                    int num2;
                    int num = this.<>1__state;
                    WorkflowInstanceExtensionCollection extensions = this.<>4__this;
                    switch (num)
                    {
                        case 0:
                            this.<>1__state = -1;
                            if (extensions.instanceExtensions == null)
                            {
                                goto Label_0146;
                            }
                            this.<i>5__1 = 0;
                            goto Label_00B8;

                        case 1:
                            goto Label_009F;

                        case 2:
                            goto Label_011F;

                        default:
                            return false;
                    }
                Label_0042:
                    pair = extensions.instanceExtensions[this.<i>5__1];
                    if ((!this.useObjectTypeForComparison || !(pair.Value is T)) && !pair.Key.IsMatch<T>(pair.Value))
                    {
                        goto Label_00A6;
                    }
                    this.<>2__current = (T) pair.Value;
                    this.<>1__state = 1;
                    return true;
                Label_009F:
                    this.<>1__state = -1;
                Label_00A6:
                    num2 = this.<i>5__1;
                    this.<i>5__1 = num2 + 1;
                Label_00B8:
                    if (this.<i>5__1 < extensions.instanceExtensions.Count)
                    {
                        goto Label_0042;
                    }
                    if (extensions.additionalInstanceExtensions != null)
                    {
                        this.<>7__wrap1 = extensions.additionalInstanceExtensions.GetEnumerator();
                        this.<>1__state = -3;
                        while (this.<>7__wrap1.MoveNext())
                        {
                            object current = this.<>7__wrap1.Current;
                            if (!(current is T))
                            {
                                continue;
                            }
                            this.<>2__current = (T) current;
                            this.<>1__state = 2;
                            return true;
                        Label_011F:
                            this.<>1__state = -3;
                        }
                        this.<>m__Finally1();
                        this.<>7__wrap1 = new List<object>.Enumerator();
                    }
                Label_0146:
                    flag = false;
                }
                fault
                {
                    this.System.IDisposable.Dispose();
                }
                return flag;
            }

            [DebuggerHidden]
            IEnumerator<T> IEnumerable<T>.GetEnumerator()
            {
                WorkflowInstanceExtensionCollection.<GetInstanceExtensions>d__26<T> d__;
                if ((this.<>1__state == -2) && (this.<>l__initialThreadId == Environment.CurrentManagedThreadId))
                {
                    this.<>1__state = 0;
                    d__ = (WorkflowInstanceExtensionCollection.<GetInstanceExtensions>d__26<T>) this;
                }
                else
                {
                    d__ = new WorkflowInstanceExtensionCollection.<GetInstanceExtensions>d__26<T>(0) {
                        <>4__this = this.<>4__this
                    };
                }
                d__.useObjectTypeForComparison = this.<>3__useObjectTypeForComparison;
                return d__;
            }

            [DebuggerHidden]
            IEnumerator IEnumerable.GetEnumerator() => 
                this.System.Collections.Generic.IEnumerable<T>.GetEnumerator();

            [DebuggerHidden]
            void IEnumerator.Reset()
            {
                throw new NotSupportedException();
            }

            [DebuggerHidden]
            void IDisposable.Dispose()
            {
                switch (this.<>1__state)
                {
                    case -3:
                    case 2:
                        try
                        {
                        }
                        finally
                        {
                            this.<>m__Finally1();
                        }
                        break;
                }
            }

            T IEnumerator<T>.Current =>
                this.<>2__current;

            object IEnumerator.Current =>
                this.<>2__current;
        }
    }
}

