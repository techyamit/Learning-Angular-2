﻿namespace System.Activities.Hosting
{
    using System;

    internal class WorkflowInstanceExtensionProvider<T> : WorkflowInstanceExtensionProvider where T: class
    {
        private Func<T> providerFunction;
        private bool hasGeneratedValue;

        public WorkflowInstanceExtensionProvider(Func<T> providerFunction)
        {
            this.providerFunction = providerFunction;
            base.Type = typeof(T);
        }

        public override object ProvideValue()
        {
            T local = this.providerFunction();
            if (!this.hasGeneratedValue)
            {
                base.GeneratedTypeMatchesDeclaredType = local.GetType() == base.Type;
                this.hasGeneratedValue = true;
            }
            return local;
        }
    }
}

