﻿namespace System.Activities.Hosting
{
    using System;
    using System.Runtime.Serialization;

    [DataContract]
    public sealed class LocationInfo
    {
        private string name;
        private string ownerDisplayName;
        private object value;

        internal LocationInfo(string name, string ownerDisplayName, object value)
        {
            this.Name = name;
            this.OwnerDisplayName = ownerDisplayName;
            this.Value = value;
        }

        public string Name
        {
            get => 
                this.name;
            private set => 
                this.name = value;
        }

        public string OwnerDisplayName
        {
            get => 
                this.ownerDisplayName;
            private set => 
                this.ownerDisplayName = value;
        }

        public object Value
        {
            get => 
                this.value;
            private set => 
                this.value = value;
        }

        [DataMember(Name="Name")]
        internal string SerializedName
        {
            get => 
                this.Name;
            set => 
                this.Name = value;
        }

        [DataMember(EmitDefaultValue=false, Name="OwnerDisplayName")]
        internal string SerializedOwnerDisplayName
        {
            get => 
                this.OwnerDisplayName;
            set => 
                this.OwnerDisplayName = value;
        }

        [DataMember(EmitDefaultValue=false, Name="Value")]
        internal object SerializedValue
        {
            get => 
                this.Value;
            set => 
                this.Value = value;
        }
    }
}

