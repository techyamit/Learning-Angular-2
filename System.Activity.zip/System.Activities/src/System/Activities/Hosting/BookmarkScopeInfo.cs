﻿namespace System.Activities.Hosting
{
    using System;
    using System.Runtime.Serialization;

    [DataContract]
    public sealed class BookmarkScopeInfo
    {
        private Guid id;
        private string temporaryId;

        internal BookmarkScopeInfo(Guid id)
        {
            this.Id = id;
        }

        internal BookmarkScopeInfo(string temporaryId)
        {
            this.TemporaryId = temporaryId;
        }

        public bool IsInitialized =>
            this.TemporaryId == null;

        public Guid Id
        {
            get => 
                this.id;
            private set => 
                this.id = value;
        }

        public string TemporaryId
        {
            get => 
                this.temporaryId;
            private set => 
                this.temporaryId = value;
        }

        [DataMember(EmitDefaultValue=false, Name="Id")]
        internal Guid SerializedId
        {
            get => 
                this.Id;
            set => 
                this.Id = value;
        }

        [DataMember(EmitDefaultValue=false, Name="TemporaryId")]
        internal string SerializedTemporaryId
        {
            get => 
                this.TemporaryId;
            set => 
                this.TemporaryId = value;
        }
    }
}

