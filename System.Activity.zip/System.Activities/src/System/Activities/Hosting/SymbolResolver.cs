﻿namespace System.Activities.Hosting
{
    using System;
    using System.Activities;
    using System.Collections;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Reflection;
    using System.Runtime;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;

    public sealed class SymbolResolver : IDictionary<string, object>, ICollection<KeyValuePair<string, object>>, IEnumerable<KeyValuePair<string, object>>, IEnumerable
    {
        private Dictionary<string, ExternalLocationReference> symbols = new Dictionary<string, ExternalLocationReference>();

        public void Add(KeyValuePair<string, object> item)
        {
            this.Add(item.Key, item.Value);
        }

        public void Add(string key, object value)
        {
            this.symbols.Add(key, this.CreateReference(key, value));
        }

        public void Add(string key, Type type)
        {
            if (type == null)
            {
                throw FxTrace.Exception.ArgumentNull("type");
            }
            this.symbols.Add(key, new ExternalLocationReference(key, type, TypeHelper.GetDefaultValueForType(type)));
        }

        public void Add(string key, object value, Type type)
        {
            if (type == null)
            {
                throw FxTrace.Exception.ArgumentNull("type");
            }
            if (!TypeHelper.AreTypesCompatible(value, type))
            {
                throw FxTrace.Exception.Argument("value", System.Activities.SR.ValueMustBeAssignableToType);
            }
            this.symbols.Add(key, new ExternalLocationReference(key, type, value));
        }

        public LocationReferenceEnvironment AsLocationReferenceEnvironment() => 
            new SymbolResolverLocationReferenceEnvironment(this);

        public void Clear()
        {
            this.symbols.Clear();
        }

        public bool Contains(KeyValuePair<string, object> item) => 
            this.symbols.TryGetValue(item.Key, out ExternalLocationReference reference) && (item.Value == reference.Value);

        public bool ContainsKey(string key) => 
            this.symbols.ContainsKey(key);

        public void CopyTo(KeyValuePair<string, object>[] array, int arrayIndex)
        {
            if (array == null)
            {
                throw FxTrace.Exception.ArgumentNull("array");
            }
            if (arrayIndex < 0)
            {
                throw FxTrace.Exception.ArgumentOutOfRange("arrayIndex", arrayIndex, System.Activities.SR.CopyToIndexOutOfRange);
            }
            if (array.Rank > 1)
            {
                throw FxTrace.Exception.Argument("array", System.Activities.SR.CopyToRankMustBeOne);
            }
            if (this.symbols.Count > (array.Length - arrayIndex))
            {
                throw FxTrace.Exception.Argument("array", System.Activities.SR.CopyToNotEnoughSpaceInArray);
            }
            foreach (KeyValuePair<string, ExternalLocationReference> pair in this.symbols)
            {
                array[arrayIndex] = new KeyValuePair<string, object>(pair.Key, pair.Value.Value);
                arrayIndex++;
            }
        }

        private ExternalLocationReference CreateReference(string name, object value)
        {
            Type objectType = TypeHelper.ObjectType;
            if (value != null)
            {
                objectType = value.GetType();
            }
            return new ExternalLocationReference(name, objectType, value);
        }

        [IteratorStateMachine(typeof(<GetEnumerator>d__22))]
        public IEnumerator<KeyValuePair<string, object>> GetEnumerator() => 
            new <GetEnumerator>d__22(0) { <>4__this = this };

        private System.Activities.Location GetLocation(string name, Type type)
        {
            if (!this.symbols.TryGetValue(name, out ExternalLocationReference reference) || (reference.Type != type))
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.SymbolResolverDoesNotHaveSymbol(name, type)));
            }
            return reference.Location;
        }

        [IteratorStateMachine(typeof(<GetLocationReferenceEnumerator>d__23))]
        internal IEnumerable<KeyValuePair<string, LocationReference>> GetLocationReferenceEnumerator() => 
            new <GetLocationReferenceEnumerator>d__23(-2) { <>4__this = this };

        internal bool IsVisible(LocationReference locationReference)
        {
            if (locationReference.Name == null)
            {
                return false;
            }
            return (this.symbols.TryGetValue(locationReference.Name, out ExternalLocationReference reference) && (reference.Type == locationReference.Type));
        }

        public bool Remove(KeyValuePair<string, object> item)
        {
            if (this.symbols.TryGetValue(item.Key, out ExternalLocationReference reference) && (reference.Value == item.Value))
            {
                this.symbols.Remove(item.Key);
                return true;
            }
            return false;
        }

        public bool Remove(string key) => 
            this.symbols.Remove(key);

        IEnumerator IEnumerable.GetEnumerator() => 
            this.GetEnumerator();

        internal bool TryGetLocationReference(string name, out LocationReference result)
        {
            if (this.symbols.TryGetValue(name, out ExternalLocationReference reference))
            {
                result = reference;
                return true;
            }
            result = null;
            return false;
        }

        public bool TryGetValue(string key, out object value)
        {
            if (this.symbols.TryGetValue(key, out ExternalLocationReference reference))
            {
                value = reference.Value;
                return true;
            }
            value = null;
            return false;
        }

        public int Count =>
            this.symbols.Count;

        public bool IsReadOnly =>
            false;

        public ICollection<string> Keys =>
            this.symbols.Keys;

        public ICollection<object> Values
        {
            get
            {
                List<object> list = new List<object>(this.symbols.Count);
                foreach (ExternalLocationReference reference in this.symbols.Values)
                {
                    list.Add(reference.Value);
                }
                return list;
            }
        }

        public object this[string key]
        {
            get => 
                this.symbols[key].Value;
            set => 
                this.symbols[key] = this.CreateReference(key, value);
        }

        [CompilerGenerated]
        private sealed class <GetEnumerator>d__22 : IEnumerator<KeyValuePair<string, object>>, IDisposable, IEnumerator
        {
            private int <>1__state;
            private KeyValuePair<string, object> <>2__current;
            public SymbolResolver <>4__this;
            private Dictionary<string, SymbolResolver.ExternalLocationReference>.Enumerator <>7__wrap1;

            [DebuggerHidden]
            public <GetEnumerator>d__22(int <>1__state)
            {
                this.<>1__state = <>1__state;
            }

            private void <>m__Finally1()
            {
                this.<>1__state = -1;
                this.<>7__wrap1.Dispose();
            }

            private bool MoveNext()
            {
                try
                {
                    int num = this.<>1__state;
                    SymbolResolver resolver = this.<>4__this;
                    if (num == 0)
                    {
                        this.<>1__state = -1;
                        this.<>7__wrap1 = resolver.symbols.GetEnumerator();
                        this.<>1__state = -3;
                        while (this.<>7__wrap1.MoveNext())
                        {
                            KeyValuePair<string, SymbolResolver.ExternalLocationReference> current = this.<>7__wrap1.Current;
                            this.<>2__current = new KeyValuePair<string, object>(current.Key, current.Value.Value);
                            this.<>1__state = 1;
                            return true;
                        Label_0073:
                            this.<>1__state = -3;
                        }
                        this.<>m__Finally1();
                        this.<>7__wrap1 = new Dictionary<string, SymbolResolver.ExternalLocationReference>.Enumerator();
                        return false;
                    }
                    if (num != 1)
                    {
                        return false;
                    }
                    goto Label_0073;
                }
                fault
                {
                    this.System.IDisposable.Dispose();
                }
            }

            [DebuggerHidden]
            void IEnumerator.Reset()
            {
                throw new NotSupportedException();
            }

            [DebuggerHidden]
            void IDisposable.Dispose()
            {
                switch (this.<>1__state)
                {
                    case -3:
                    case 1:
                        try
                        {
                        }
                        finally
                        {
                            this.<>m__Finally1();
                        }
                        break;
                }
            }

            KeyValuePair<string, object> IEnumerator<KeyValuePair<string, object>>.Current =>
                this.<>2__current;

            object IEnumerator.Current =>
                this.<>2__current;
        }

        [CompilerGenerated]
        private sealed class <GetLocationReferenceEnumerator>d__23 : IEnumerable<KeyValuePair<string, LocationReference>>, IEnumerable, IEnumerator<KeyValuePair<string, LocationReference>>, IDisposable, IEnumerator
        {
            private int <>1__state;
            private KeyValuePair<string, LocationReference> <>2__current;
            private int <>l__initialThreadId;
            public SymbolResolver <>4__this;
            private Dictionary<string, SymbolResolver.ExternalLocationReference>.Enumerator <>7__wrap1;

            [DebuggerHidden]
            public <GetLocationReferenceEnumerator>d__23(int <>1__state)
            {
                this.<>1__state = <>1__state;
                this.<>l__initialThreadId = Environment.CurrentManagedThreadId;
            }

            private void <>m__Finally1()
            {
                this.<>1__state = -1;
                this.<>7__wrap1.Dispose();
            }

            private bool MoveNext()
            {
                try
                {
                    int num = this.<>1__state;
                    SymbolResolver resolver = this.<>4__this;
                    if (num == 0)
                    {
                        this.<>1__state = -1;
                        this.<>7__wrap1 = resolver.symbols.GetEnumerator();
                        this.<>1__state = -3;
                        while (this.<>7__wrap1.MoveNext())
                        {
                            KeyValuePair<string, SymbolResolver.ExternalLocationReference> current = this.<>7__wrap1.Current;
                            this.<>2__current = new KeyValuePair<string, LocationReference>(current.Key, current.Value);
                            this.<>1__state = 1;
                            return true;
                        Label_006E:
                            this.<>1__state = -3;
                        }
                        this.<>m__Finally1();
                        this.<>7__wrap1 = new Dictionary<string, SymbolResolver.ExternalLocationReference>.Enumerator();
                        return false;
                    }
                    if (num != 1)
                    {
                        return false;
                    }
                    goto Label_006E;
                }
                fault
                {
                    this.System.IDisposable.Dispose();
                }
            }

            [DebuggerHidden]
            IEnumerator<KeyValuePair<string, LocationReference>> IEnumerable<KeyValuePair<string, LocationReference>>.GetEnumerator()
            {
                if ((this.<>1__state == -2) && (this.<>l__initialThreadId == Environment.CurrentManagedThreadId))
                {
                    this.<>1__state = 0;
                    return this;
                }
                return new SymbolResolver.<GetLocationReferenceEnumerator>d__23(0) { <>4__this = this.<>4__this };
            }

            [DebuggerHidden]
            IEnumerator IEnumerable.GetEnumerator() => 
                this.System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<System.String,System.Activities.LocationReference>>.GetEnumerator();

            [DebuggerHidden]
            void IEnumerator.Reset()
            {
                throw new NotSupportedException();
            }

            [DebuggerHidden]
            void IDisposable.Dispose()
            {
                switch (this.<>1__state)
                {
                    case -3:
                    case 1:
                        try
                        {
                        }
                        finally
                        {
                            this.<>m__Finally1();
                        }
                        break;
                }
            }

            KeyValuePair<string, LocationReference> IEnumerator<KeyValuePair<string, LocationReference>>.Current =>
                this.<>2__current;

            object IEnumerator.Current =>
                this.<>2__current;
        }

        private class ExternalLocationReference : LocationReference
        {
            private ExternalLocation location;
            private string name;
            private Type type;

            public ExternalLocationReference(string name, Type type, object value)
            {
                this.name = name;
                this.type = type;
                this.location = new ExternalLocation(this.type, value);
            }

            public override System.Activities.Location GetLocation(ActivityContext context)
            {
                SymbolResolver extension = context.GetExtension<SymbolResolver>();
                if (extension == null)
                {
                    throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.CanNotFindSymbolResolverInWorkflowInstanceExtensions));
                }
                return extension.GetLocation(base.Name, base.Type);
            }

            public object Value =>
                this.location.Value;

            public System.Activities.Location Location =>
                this.location;

            protected override string NameCore =>
                this.name;

            protected override Type TypeCore =>
                this.type;

            private class ExternalLocation : System.Activities.Location
            {
                private Type type;
                private object value;

                public ExternalLocation(Type type, object value)
                {
                    this.type = type;
                    this.value = value;
                }

                public override Type LocationType =>
                    this.type;

                protected override object ValueCore
                {
                    get => 
                        this.value;
                    set
                    {
                        throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.ExternalLocationsGetOnly));
                    }
                }
            }
        }

        private class SymbolResolverLocationReferenceEnvironment : LocationReferenceEnvironment
        {
            private SymbolResolver symbolResolver;

            public SymbolResolverLocationReferenceEnvironment(SymbolResolver symbolResolver)
            {
                this.symbolResolver = symbolResolver;
            }

            public override IEnumerable<LocationReference> GetLocationReferences()
            {
                List<LocationReference> list = new List<LocationReference>();
                foreach (SymbolResolver.ExternalLocationReference reference in this.symbolResolver.symbols.Values)
                {
                    list.Add(reference);
                }
                return list;
            }

            public override bool IsVisible(LocationReference locationReference)
            {
                if (locationReference == null)
                {
                    throw FxTrace.Exception.ArgumentNull("locationReference");
                }
                return this.symbolResolver.IsVisible(locationReference);
            }

            public override bool TryGetLocationReference(string name, out LocationReference result)
            {
                if (string.IsNullOrEmpty(name))
                {
                    throw FxTrace.Exception.ArgumentNullOrEmpty("name");
                }
                return this.symbolResolver.TryGetLocationReference(name, out result);
            }

            public override Activity Root =>
                null;
        }
    }
}

