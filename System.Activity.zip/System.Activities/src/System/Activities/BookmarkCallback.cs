﻿namespace System.Activities
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void BookmarkCallback(NativeActivityContext context, Bookmark bookmark, object value);
}

