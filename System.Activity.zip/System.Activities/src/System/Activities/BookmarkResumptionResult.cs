﻿namespace System.Activities
{
    using System;

    public enum BookmarkResumptionResult
    {
        Success,
        NotFound,
        NotReady
    }
}

