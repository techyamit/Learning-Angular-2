﻿namespace System.Activities
{
    using System;
    using System.Collections.Generic;
    using System.Runtime;
    using System.Runtime.CompilerServices;
    using System.Runtime.Diagnostics;
    using System.Security;

    internal static class FxTrace
    {
        private const string baseEventSourceName = "System.Activities";
        private const string EventSourceVersion = "4.0.0.0";
        private static Guid etwProviderId;
        private static string eventSourceName;
        private static ExceptionTrace exceptionTrace;
        private static bool[] enabledEvents;
        private static SortedSet<ushort> end2EndEvents;
        [SecurityCritical]
        private static EventDescriptor[] eventDescriptors;
        private static object lockObject = new object();
        private static bool tracingEnabled = true;
        private static bool shouldTraceVerbose = true;
        private static bool shouldTraceInformation = true;
        private static bool shouldTraceWarning = true;
        private static bool shouldTraceError = true;
        private static bool shouldTraceCritical = true;
        private static bool shouldTraceVerboseToTraceSource = true;
        private static bool shouldTraceInformationToTraceSource = true;
        private static bool shouldTraceWarningToTraceSource = true;
        private static bool shouldTraceErrorToTraceSource = true;
        private static bool shouldTraceCriticalToTraceSource = true;
        private static EtwDiagnosticTrace diagnosticTrace;

        private static void EnsureEtwProviderInitialized()
        {
            if (diagnosticTrace == null)
            {
                object lockObject = FxTrace.lockObject;
                lock (lockObject)
                {
                    if (diagnosticTrace == null)
                    {
                        diagnosticTrace = InitializeTracing();
                    }
                }
            }
        }

        [SecuritySafeCritical]
        private static EtwDiagnosticTrace InitializeTracing()
        {
            etwProviderId = EtwDiagnosticTrace.DefaultEtwProviderId;
            EtwDiagnosticTrace trace = new EtwDiagnosticTrace("System.Activities", etwProviderId);
            if (trace.EtwProvider != null)
            {
                trace.RefreshState = (Action) Delegate.Combine(trace.RefreshState, delegate {
                    UpdateLevel();
                });
            }
            UpdateLevel(trace);
            return trace;
        }

        public static bool IsEventEnabled(int index)
        {
            if (enabledEvents != null)
            {
                return enabledEvents[index];
            }
            return true;
        }

        [SecuritySafeCritical]
        private static void UpdateEnabledEventsList(EtwDiagnosticTrace trace)
        {
            object lockObject = FxTrace.lockObject;
            lock (lockObject)
            {
                int level = -1;
                EventDescriptor[] eventDescriptors = FxTrace.eventDescriptors;
                if (eventDescriptors != null)
                {
                    if (enabledEvents == null)
                    {
                        enabledEvents = new bool[eventDescriptors.Length];
                    }
                    for (int i = 0; i < enabledEvents.Length; i++)
                    {
                        EventDescriptor eventDescriptor = eventDescriptors[i];
                        bool flag2 = Trace.IsEtwEventEnabled(ref eventDescriptor);
                        enabledEvents[i] = flag2;
                        if ((flag2 && !Trace.IsEnd2EndActivityTracingEnabled) && end2EndEvents.Contains((ushort) eventDescriptor.EventId))
                        {
                            Trace.SetEnd2EndActivityTracingEnabled(true);
                        }
                        if (flag2 && (level < eventDescriptor.Level))
                        {
                            level = eventDescriptor.Level;
                        }
                    }
                    shouldTraceCritical = shouldTraceCriticalToTraceSource || (trace.ShouldTraceToEtw(TraceEventLevel.Critical) && (level >= 1));
                    shouldTraceError = shouldTraceErrorToTraceSource || (trace.ShouldTraceToEtw(TraceEventLevel.Error) && (level >= 2));
                    shouldTraceWarning = shouldTraceWarningToTraceSource || (trace.ShouldTraceToEtw(TraceEventLevel.Warning) && (level >= 3));
                    shouldTraceInformation = shouldTraceInformationToTraceSource || (trace.ShouldTraceToEtw(TraceEventLevel.Informational) && (level >= 4));
                    shouldTraceVerbose = shouldTraceVerboseToTraceSource || (trace.ShouldTraceToEtw(TraceEventLevel.Verbose) && (level >= 5));
                }
            }
        }

        [SecuritySafeCritical]
        public static void UpdateEventDefinitions(EventDescriptor[] eventDescriptors, ushort[] end2EndEvents)
        {
            EnsureEtwProviderInitialized();
            FxTrace.eventDescriptors = eventDescriptors;
            FxTrace.end2EndEvents = new SortedSet<ushort>(end2EndEvents);
            UpdateEnabledEventsList(diagnosticTrace);
        }

        private static void UpdateLevel()
        {
            UpdateLevel(Trace);
        }

        private static void UpdateLevel(EtwDiagnosticTrace trace)
        {
            if (trace != null)
            {
                tracingEnabled = trace.TracingEnabled;
                shouldTraceCriticalToTraceSource = trace.ShouldTraceToTraceSource(TraceEventLevel.Critical);
                shouldTraceErrorToTraceSource = trace.ShouldTraceToTraceSource(TraceEventLevel.Error);
                shouldTraceWarningToTraceSource = trace.ShouldTraceToTraceSource(TraceEventLevel.Warning);
                shouldTraceInformationToTraceSource = trace.ShouldTraceToTraceSource(TraceEventLevel.Informational);
                shouldTraceVerboseToTraceSource = trace.ShouldTraceToTraceSource(TraceEventLevel.Verbose);
                shouldTraceCritical = shouldTraceCriticalToTraceSource || trace.ShouldTraceToEtw(TraceEventLevel.Critical);
                shouldTraceError = shouldTraceErrorToTraceSource || trace.ShouldTraceToEtw(TraceEventLevel.Error);
                shouldTraceWarning = shouldTraceWarningToTraceSource || trace.ShouldTraceToEtw(TraceEventLevel.Warning);
                shouldTraceInformation = shouldTraceInformationToTraceSource || trace.ShouldTraceToEtw(TraceEventLevel.Informational);
                shouldTraceVerbose = shouldTraceVerboseToTraceSource || trace.ShouldTraceToEtw(TraceEventLevel.Verbose);
                UpdateEnabledEventsList(trace);
            }
        }

        public static bool ShouldTraceCritical =>
            shouldTraceCritical;

        public static bool TracingEnabled =>
            tracingEnabled;

        public static bool ShouldTraceError =>
            shouldTraceError;

        public static bool ShouldTraceInformation =>
            shouldTraceInformation;

        public static bool ShouldTraceVerbose =>
            shouldTraceVerbose;

        public static bool ShouldTraceWarning =>
            shouldTraceWarning;

        public static bool ShouldTraceCriticalToTraceSource =>
            shouldTraceCriticalToTraceSource;

        public static bool ShouldTraceErrorToTraceSource =>
            shouldTraceErrorToTraceSource;

        public static bool ShouldTraceInformationToTraceSource =>
            shouldTraceInformationToTraceSource;

        public static bool ShouldTraceVerboseToTraceSource =>
            shouldTraceVerboseToTraceSource;

        public static bool ShouldTraceWarningToTraceSource =>
            shouldTraceWarningToTraceSource;

        public static ExceptionTrace Exception
        {
            get
            {
                if (exceptionTrace == null)
                {
                    exceptionTrace = new ExceptionTrace(EventSourceName, Trace);
                }
                return exceptionTrace;
            }
        }

        public static EtwDiagnosticTrace Trace
        {
            get
            {
                EnsureEtwProviderInitialized();
                return diagnosticTrace;
            }
        }

        public static EventLogger EventLog =>
            new EventLogger(EventSourceName, Trace);

        private static string EventSourceName
        {
            get
            {
                if (eventSourceName == null)
                {
                    eventSourceName = "System.Activities" + " " + "4.0.0.0";
                }
                return eventSourceName;
            }
        }

        [Serializable, CompilerGenerated]
        private sealed class <>c
        {
            public static readonly FxTrace.<>c <>9 = new FxTrace.<>c();
            public static Action <>9__54_0;

            internal void <InitializeTracing>b__54_0()
            {
                FxTrace.UpdateLevel();
            }
        }
    }
}

