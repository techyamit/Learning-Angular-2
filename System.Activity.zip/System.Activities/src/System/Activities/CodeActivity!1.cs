﻿namespace System.Activities
{
    using System;
    using System.Activities.DynamicUpdate;
    using System.Activities.Runtime;
    using System.Runtime.Serialization;

    public abstract class CodeActivity<TResult> : Activity<TResult>
    {
        protected CodeActivity()
        {
        }

        protected sealed override void CacheMetadata(ActivityMetadata metadata)
        {
            throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.WrongCacheMetadataForCodeActivity));
        }

        protected virtual void CacheMetadata(CodeActivityMetadata metadata)
        {
            base.SetArgumentsCollection(Activity.ReflectedInformation.GetArguments(this), metadata.CreateEmptyBindings);
        }

        protected abstract TResult Execute(CodeActivityContext context);
        internal sealed override void InternalAbort(System.Activities.ActivityInstance instance, ActivityExecutor executor, Exception terminationReason)
        {
        }

        internal sealed override void InternalCancel(System.Activities.ActivityInstance instance, ActivityExecutor executor, BookmarkManager bookmarkManager)
        {
        }

        internal sealed override void InternalExecute(System.Activities.ActivityInstance instance, ActivityExecutor executor, BookmarkManager bookmarkManager)
        {
            CodeActivityContext context = executor.CodeActivityContextPool.Acquire();
            try
            {
                context.Initialize(instance, executor);
                TResult local = this.Execute(context);
                base.Result.Set(context, local);
            }
            finally
            {
                context.Dispose();
                executor.CodeActivityContextPool.Release(context);
            }
        }

        internal sealed override TResult InternalExecuteInResolutionContext(CodeActivityContext context) => 
            this.Execute(context);

        protected sealed override void OnCreateDynamicUpdateMap(UpdateMapMetadata metadata, Activity originalActivity)
        {
        }

        internal sealed override void OnInternalCacheMetadataExceptResult(bool createEmptyBindings)
        {
            CodeActivityMetadata metadata = new CodeActivityMetadata(this, base.GetParentEnvironment(), createEmptyBindings);
            this.CacheMetadata(metadata);
            metadata.Dispose();
            if (((base.RuntimeArguments == null) || (base.RuntimeArguments.Count == 0)) || ((base.RuntimeArguments.Count == 1) && (base.RuntimeArguments[0].Name == "Result")))
            {
                base.SkipArgumentResolution = true;
            }
        }

        internal sealed override void OnInternalCreateDynamicUpdateMap(DynamicUpdateMapBuilder.Finalizer finalizer, DynamicUpdateMapBuilder.IDefinitionMatcher matcher, Activity originalActivity)
        {
        }

        protected internal sealed override Version ImplementationVersion
        {
            get => 
                null;
            set
            {
                if (value != null)
                {
                    throw System.Activities.FxTrace.Exception.AsError(new NotSupportedException());
                }
            }
        }

        [IgnoreDataMember]
        protected sealed override Func<Activity> Implementation
        {
            get => 
                null;
            set
            {
                if (value != null)
                {
                    throw System.Activities.FxTrace.Exception.AsError(new NotSupportedException());
                }
            }
        }
    }
}

