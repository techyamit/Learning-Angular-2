﻿namespace System.Activities
{
    using System;
    using System.Activities.Runtime;
    using System.Diagnostics;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Runtime.Serialization;

    [DataContract, DebuggerDisplay("{Value}")]
    public abstract class Location
    {
        private TemporaryResolutionData temporaryResolutionData;

        protected Location()
        {
        }

        internal virtual object CreateDefaultValue() => 
            null;

        internal virtual Location CreateReference(bool bufferGets)
        {
            if (this.CanBeMapped | bufferGets)
            {
                return new ReferenceLocation(this, bufferGets);
            }
            return this;
        }

        internal void SetTemporaryResolutionData(LocationEnvironment resolutionEnvironment, bool bufferGetsOnCollapse)
        {
            TemporaryResolutionData data = new TemporaryResolutionData {
                TemporaryResolutionEnvironment = resolutionEnvironment,
                BufferGetsOnCollapse = bufferGetsOnCollapse
            };
            this.temporaryResolutionData = data;
        }

        public abstract Type LocationType { get; }

        public object Value
        {
            get => 
                this.ValueCore;
            set => 
                this.ValueCore = value;
        }

        [DataMember(EmitDefaultValue=false, Name="temporaryResolutionData")]
        internal TemporaryResolutionData SerializedTemporaryResolutionData
        {
            get => 
                this.temporaryResolutionData;
            set => 
                this.temporaryResolutionData = value;
        }

        internal virtual bool CanBeMapped =>
            false;

        internal LocationEnvironment TemporaryResolutionEnvironment =>
            this.temporaryResolutionData.TemporaryResolutionEnvironment;

        internal bool BufferGetsOnCollapse =>
            this.temporaryResolutionData.BufferGetsOnCollapse;

        protected abstract object ValueCore { get; set; }

        [DataContract]
        internal class ReferenceLocation : Location
        {
            private Location innerLocation;
            private bool bufferGets;
            private object bufferedValue;

            public ReferenceLocation(Location innerLocation, bool bufferGets)
            {
                this.innerLocation = innerLocation;
                this.bufferGets = bufferGets;
            }

            public override string ToString()
            {
                if (this.bufferGets)
                {
                    return base.ToString();
                }
                return this.innerLocation.ToString();
            }

            public override Type LocationType =>
                this.innerLocation.LocationType;

            protected override object ValueCore
            {
                get
                {
                    if (this.bufferGets)
                    {
                        return this.bufferedValue;
                    }
                    return this.innerLocation.Value;
                }
                set
                {
                    this.innerLocation.Value = value;
                    this.bufferedValue = value;
                }
            }

            [DataMember(Name="innerLocation")]
            internal Location SerializedInnerLocation
            {
                get => 
                    this.innerLocation;
                set => 
                    this.innerLocation = value;
            }

            [DataMember(EmitDefaultValue=false, Name="bufferGets")]
            internal bool SerializedBufferGets
            {
                get => 
                    this.bufferGets;
                set => 
                    this.bufferGets = value;
            }

            [DataMember(EmitDefaultValue=false, Name="bufferedValue")]
            internal object SerializedBufferedValue
            {
                get => 
                    this.bufferedValue;
                set => 
                    this.bufferedValue = value;
            }
        }

        [StructLayout(LayoutKind.Sequential), DataContract]
        internal struct TemporaryResolutionData
        {
            [DataMember(EmitDefaultValue=false)]
            public LocationEnvironment TemporaryResolutionEnvironment { get; set; }
            [DataMember(EmitDefaultValue=false)]
            public bool BufferGetsOnCollapse { get; set; }
        }
    }
}

