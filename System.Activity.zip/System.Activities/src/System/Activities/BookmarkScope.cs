﻿namespace System.Activities
{
    using System;
    using System.Activities.Hosting;
    using System.Globalization;
    using System.Runtime.Serialization;

    [DataContract]
    public sealed class BookmarkScope : IEquatable<BookmarkScope>
    {
        private static BookmarkScope defaultBookmarkScope;
        private long temporaryId;
        private Guid id;
        private int handleReferenceCount;

        private BookmarkScope()
        {
        }

        public BookmarkScope(Guid id)
        {
            this.id = id;
        }

        internal BookmarkScope(long temporaryId)
        {
            this.temporaryId = temporaryId;
        }

        internal int DecrementHandleReferenceCount()
        {
            int num = this.handleReferenceCount - 1;
            this.handleReferenceCount = num;
            return num;
        }

        public bool Equals(BookmarkScope other)
        {
            if (other == null)
            {
                return false;
            }
            if (this == other)
            {
                return true;
            }
            if (this.IsDefault)
            {
                return other.IsDefault;
            }
            if (this.IsInitialized)
            {
                return (other.id == this.id);
            }
            return (other.temporaryId == this.temporaryId);
        }

        internal BookmarkScopeInfo GenerateScopeInfo()
        {
            if (this.IsInitialized)
            {
                return new BookmarkScopeInfo(this.Id);
            }
            return new BookmarkScopeInfo(this.temporaryId.ToString(CultureInfo.InvariantCulture));
        }

        public override int GetHashCode()
        {
            if (this.IsInitialized)
            {
                return this.id.GetHashCode();
            }
            return this.temporaryId.GetHashCode();
        }

        internal int IncrementHandleReferenceCount()
        {
            int num = this.handleReferenceCount + 1;
            this.handleReferenceCount = num;
            return num;
        }

        public void Initialize(NativeActivityContext context, Guid id)
        {
            if (context == null)
            {
                throw System.Activities.FxTrace.Exception.ArgumentNull("context");
            }
            if (id == Guid.Empty)
            {
                throw System.Activities.FxTrace.Exception.ArgumentNullOrEmpty("id");
            }
            if (this.IsInitialized)
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.BookmarkScopeAlreadyInitialized));
            }
            context.InitializeBookmarkScope(this, id);
        }

        public bool IsInitialized =>
            this.temporaryId == 0L;

        public Guid Id
        {
            get => 
                this.id;
            internal set
            {
                this.id = value;
                this.temporaryId = 0L;
            }
        }

        [DataMember(EmitDefaultValue=false, Name="temporaryId")]
        internal long SerializedTemporaryId
        {
            get => 
                this.temporaryId;
            set => 
                this.temporaryId = value;
        }

        [DataMember(EmitDefaultValue=false, Name="id")]
        internal Guid SerializedId
        {
            get => 
                this.id;
            set => 
                this.id = value;
        }

        internal long TemporaryId =>
            this.temporaryId;

        public static BookmarkScope Default
        {
            get
            {
                if (defaultBookmarkScope == null)
                {
                    defaultBookmarkScope = new BookmarkScope();
                }
                return defaultBookmarkScope;
            }
        }

        internal bool IsDefault =>
            this.IsInitialized && (this.id == Guid.Empty);
    }
}

