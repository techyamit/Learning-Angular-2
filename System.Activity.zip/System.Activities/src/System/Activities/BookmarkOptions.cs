﻿namespace System.Activities
{
    using System;

    [Flags]
    public enum BookmarkOptions
    {
        None,
        MultipleResume,
        NonBlocking
    }
}

