﻿namespace System.Activities
{
    using System;
    using System.Runtime;
    using System.Threading;

    internal static class SynchronizationContextHelper
    {
        private static WFDefaultSynchronizationContext defaultContext;

        public static SynchronizationContext CloneSynchronizationContext(SynchronizationContext context)
        {
            if (context is WFDefaultSynchronizationContext)
            {
                return defaultContext;
            }
            return context.CreateCopy();
        }

        public static SynchronizationContext GetDefaultSynchronizationContext()
        {
            if (defaultContext == null)
            {
                defaultContext = new WFDefaultSynchronizationContext();
            }
            return defaultContext;
        }

        private class WFDefaultSynchronizationContext : SynchronizationContext
        {
            public override void Post(SendOrPostCallback d, object state)
            {
                ActionItem.Schedule(s => d(s), state);
            }

            public override void Send(SendOrPostCallback d, object state)
            {
                d(state);
            }
        }
    }
}

