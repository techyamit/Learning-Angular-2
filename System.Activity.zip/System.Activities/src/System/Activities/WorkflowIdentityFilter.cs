﻿namespace System.Activities
{
    using System;

    public enum WorkflowIdentityFilter
    {
        Exact,
        Any,
        AnyRevision
    }
}

