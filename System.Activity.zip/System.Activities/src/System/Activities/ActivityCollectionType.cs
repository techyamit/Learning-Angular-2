﻿namespace System.Activities
{
    using System;

    internal enum ActivityCollectionType
    {
        Public,
        Imports,
        Implementation
    }
}

