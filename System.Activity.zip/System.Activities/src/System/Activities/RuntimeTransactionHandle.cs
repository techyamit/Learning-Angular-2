﻿namespace System.Activities
{
    using System;
    using System.Activities.Runtime;
    using System.Runtime;
    using System.Runtime.Serialization;
    using System.Transactions;

    [DataContract]
    public sealed class RuntimeTransactionHandle : Handle, IExecutionProperty, IPropertyRegistrationCallback
    {
        private ActivityExecutor executor;
        private bool isHandleInitialized;
        private bool doNotAbort;
        private bool isPropertyRegistered;
        private bool isSuppressed;
        private TransactionScope scope;
        private Transaction rootTransaction;

        public RuntimeTransactionHandle()
        {
        }

        public RuntimeTransactionHandle(Transaction rootTransaction)
        {
            if (rootTransaction == null)
            {
                throw System.Activities.FxTrace.Exception.ArgumentNull("rootTransaction");
            }
            this.rootTransaction = rootTransaction;
            this.AbortInstanceOnTransactionFailure = false;
        }

        public void CompleteTransaction(NativeActivityContext context)
        {
            this.CompleteTransactionCore(context, null);
        }

        public void CompleteTransaction(NativeActivityContext context, BookmarkCallback callback)
        {
            if (callback == null)
            {
                throw System.Activities.FxTrace.Exception.ArgumentNull("callback");
            }
            this.CompleteTransactionCore(context, callback);
        }

        private void CompleteTransactionCore(NativeActivityContext context, BookmarkCallback callback)
        {
            context.ThrowIfDisposed();
            if (this.rootTransaction != null)
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.CannotCompleteRuntimeOwnedTransaction));
            }
            if (!context.HasRuntimeTransaction)
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.NoRuntimeTransactionExists));
            }
            if (!this.isHandleInitialized)
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.UnInitializedRuntimeTransactionHandle));
            }
            if (this.SuppressTransaction)
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.RuntimeTransactionIsSuppressed));
            }
            context.CompleteTransaction(this, callback);
        }

        public Transaction GetCurrentTransaction(AsyncCodeActivityContext context) => 
            this.GetCurrentTransactionCore(context);

        public Transaction GetCurrentTransaction(CodeActivityContext context) => 
            this.GetCurrentTransactionCore(context);

        public Transaction GetCurrentTransaction(NativeActivityContext context) => 
            this.GetCurrentTransactionCore(context);

        private Transaction GetCurrentTransactionCore(ActivityContext context)
        {
            if (context == null)
            {
                throw System.Activities.FxTrace.Exception.ArgumentNull("context");
            }
            context.ThrowIfDisposed();
            if (this.rootTransaction == null)
            {
                this.ThrowIfNotRegistered(System.Activities.SR.RuntimeTransactionHandleNotRegisteredAsExecutionProperty("GetCurrentTransaction"));
            }
            if (!this.isHandleInitialized)
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.UnInitializedRuntimeTransactionHandle));
            }
            if (this.SuppressTransaction)
            {
                return null;
            }
            return this.executor.CurrentTransaction;
        }

        protected override void OnInitialize(HandleInitializationContext context)
        {
            this.executor = context.Executor;
            this.isHandleInitialized = true;
            if (this.rootTransaction != null)
            {
                this.executor.SetTransaction(this, this.rootTransaction, null, null);
            }
            base.OnInitialize(context);
        }

        protected override void OnUninitialize(HandleInitializationContext context)
        {
            if (this.rootTransaction != null)
            {
                this.executor.ExitNoPersist();
            }
            this.isHandleInitialized = false;
            base.OnUninitialize(context);
        }

        private void RequestOrRequireTransactionContextCore(NativeActivityContext context, Action<NativeActivityTransactionContext, object> callback, object state, bool isRequires)
        {
            if (context == null)
            {
                throw System.Activities.FxTrace.Exception.ArgumentNull("context");
            }
            context.ThrowIfDisposed();
            if (context.HasRuntimeTransaction)
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.RuntimeTransactionAlreadyExists));
            }
            if (context.IsInNoPersistScope)
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.CannotSetRuntimeTransactionInNoPersist));
            }
            if (!this.isHandleInitialized)
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.UnInitializedRuntimeTransactionHandle));
            }
            if (this.SuppressTransaction)
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.RuntimeTransactionIsSuppressed));
            }
            if (isRequires)
            {
                if (context.RequiresTransactionContextWaiterExists)
                {
                    throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.OnlyOneRequireTransactionContextAllowed));
                }
                this.ThrowIfNotRegistered(System.Activities.SR.RuntimeTransactionHandleNotRegisteredAsExecutionProperty("RequireTransactionContext"));
            }
            else
            {
                this.ThrowIfNotRegistered(System.Activities.SR.RuntimeTransactionHandleNotRegisteredAsExecutionProperty("RequestTransactionContext"));
            }
            context.RequestTransactionContext(isRequires, this, callback, state);
        }

        public void RequestTransactionContext(NativeActivityContext context, Action<NativeActivityTransactionContext, object> callback, object state)
        {
            this.RequestOrRequireTransactionContextCore(context, callback, state, false);
        }

        public void RequireTransactionContext(NativeActivityContext context, Action<NativeActivityTransactionContext, object> callback, object state)
        {
            this.RequestOrRequireTransactionContextCore(context, callback, state, true);
        }

        void IExecutionProperty.CleanupWorkflowThread()
        {
            TransactionHelper.CompleteTransactionScope(ref this.scope);
        }

        void IExecutionProperty.SetupWorkflowThread()
        {
            if (this.SuppressTransaction)
            {
                this.scope = new TransactionScope(TransactionScopeOption.Suppress);
            }
            else if ((this.executor != null) && this.executor.HasRuntimeTransaction)
            {
                this.scope = TransactionHelper.CreateTransactionScope(this.executor.CurrentTransaction);
            }
        }

        void IPropertyRegistrationCallback.Register(RegistrationContext context)
        {
            if (!this.isHandleInitialized)
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.UnInitializedRuntimeTransactionHandle));
            }
            RuntimeTransactionHandle handle = (RuntimeTransactionHandle) context.FindProperty(typeof(RuntimeTransactionHandle).FullName);
            if ((handle != null) && handle.SuppressTransaction)
            {
                this.isSuppressed = true;
            }
            this.isPropertyRegistered = true;
        }

        void IPropertyRegistrationCallback.Unregister(RegistrationContext context)
        {
            this.isPropertyRegistered = false;
        }

        private void ThrowIfNotRegistered(string message)
        {
            if (!this.isPropertyRegistered)
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(message));
            }
        }

        private void ThrowIfRegistered(string message)
        {
            if (this.isPropertyRegistered)
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(message));
            }
        }

        public bool AbortInstanceOnTransactionFailure
        {
            get => 
                !this.doNotAbort;
            set
            {
                this.ThrowIfRegistered(System.Activities.SR.CannotChangeAbortInstanceFlagAfterPropertyRegistration);
                this.doNotAbort = !value;
            }
        }

        public bool SuppressTransaction
        {
            get => 
                this.isSuppressed;
            set
            {
                this.ThrowIfRegistered(System.Activities.SR.CannotSuppressAlreadyRegisteredHandle);
                this.isSuppressed = value;
            }
        }

        [DataMember(Name="executor")]
        internal ActivityExecutor SerializedExecutor
        {
            get => 
                this.executor;
            set => 
                this.executor = value;
        }

        [DataMember(EmitDefaultValue=false, Name="isHandleInitialized")]
        internal bool SerializedIsHandleInitialized
        {
            get => 
                this.isHandleInitialized;
            set => 
                this.isHandleInitialized = value;
        }

        [DataMember(EmitDefaultValue=false, Name="doNotAbort")]
        internal bool SerializedDoNotAbort
        {
            get => 
                this.doNotAbort;
            set => 
                this.doNotAbort = value;
        }

        [DataMember(EmitDefaultValue=false, Name="isPropertyRegistered")]
        internal bool SerializedIsPropertyRegistered
        {
            get => 
                this.isPropertyRegistered;
            set => 
                this.isPropertyRegistered = value;
        }

        [DataMember(EmitDefaultValue=false, Name="isSuppressed")]
        internal bool SerializedIsSuppressed
        {
            get => 
                this.isSuppressed;
            set => 
                this.isSuppressed = value;
        }

        internal bool IsRuntimeOwnedTransaction =>
            this.rootTransaction != null;
    }
}

