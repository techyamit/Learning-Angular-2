﻿namespace System.Activities
{
    using System;
    using System.Globalization;
    using System.Resources;

    internal class SR
    {
        private static System.Resources.ResourceManager resourceManager;
        private static CultureInfo resourceCulture;

        private SR()
        {
        }

        internal static string ActivityBlockingUpdate(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("ActivityBlockingUpdate", Culture), args);
        }

        internal static string ActivityCannotBeReferenced(object param0, object param1, object param2, object param3)
        {
            object[] args = new object[] { param0, param1, param2, param3 };
            return string.Format(Culture, ResourceManager.GetString("ActivityCannotBeReferenced", Culture), args);
        }

        internal static string ActivityCannotBeReferencedWithoutTarget(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("ActivityCannotBeReferencedWithoutTarget", Culture), args);
        }

        internal static string ActivityCannotReferenceItself(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("ActivityCannotReferenceItself", Culture), args);
        }

        internal static string ActivityDefinitionCannotBeShared(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("ActivityDefinitionCannotBeShared", Culture), args);
        }

        internal static string ActivityDelegateAlreadyOpened(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("ActivityDelegateAlreadyOpened", Culture), args);
        }

        internal static string ActivityDelegateCannotBeReferenced(object param0, object param1, object param2, object param3)
        {
            object[] args = new object[] { param0, param1, param2, param3 };
            return string.Format(Culture, ResourceManager.GetString("ActivityDelegateCannotBeReferenced", Culture), args);
        }

        internal static string ActivityDelegateCannotBeReferencedNoHandler(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("ActivityDelegateCannotBeReferencedNoHandler", Culture), args);
        }

        internal static string ActivityDelegateCannotBeReferencedWithoutTarget(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("ActivityDelegateCannotBeReferencedWithoutTarget", Culture), args);
        }

        internal static string ActivityDelegateCannotBeReferencedWithoutTargetNoHandler(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("ActivityDelegateCannotBeReferencedWithoutTargetNoHandler", Culture), args);
        }

        internal static string ActivityDelegateHandlersMustBeDeclarations(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("ActivityDelegateHandlersMustBeDeclarations", Culture), args);
        }

        internal static string ActivityDelegateNotOpened(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("ActivityDelegateNotOpened", Culture), args);
        }

        internal static string ActivityDelegateOwnerEnvironmentMissing(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("ActivityDelegateOwnerEnvironmentMissing", Culture), args);
        }

        internal static string ActivityDelegateOwnerMissing(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("ActivityDelegateOwnerMissing", Culture), args);
        }

        internal static string ActivityDelegateOwnerNotInParentScope(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("ActivityDelegateOwnerNotInParentScope", Culture), args);
        }

        internal static string ActivityHasNoImplementation(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("ActivityHasNoImplementation", Culture), args);
        }

        internal static string ActivityNotFound(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("ActivityNotFound", Culture), args);
        }

        internal static string ActivityNotPartOfThisTree(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("ActivityNotPartOfThisTree", Culture), args);
        }

        internal static string ActivityPropertyMustBeSet(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("ActivityPropertyMustBeSet", Culture), args);
        }

        internal static string ActivityPropertyNotSet(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("ActivityPropertyNotSet", Culture), args);
        }

        internal static string ActivityPropertyRequiresName(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("ActivityPropertyRequiresName", Culture), args);
        }

        internal static string ActivityPropertyRequiresType(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("ActivityPropertyRequiresType", Culture), args);
        }

        internal static string ActivityTypeMismatch(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("ActivityTypeMismatch", Culture), args);
        }

        internal static string ActivityXamlServicesCompilationFailed(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("ActivityXamlServicesCompilationFailed", Culture), args);
        }

        internal static string ActivityXamlServicesRequiresActivity(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("ActivityXamlServicesRequiresActivity", Culture), args);
        }

        internal static string AddedIdleArgumentBlockDU(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("AddedIdleArgumentBlockDU", Culture), args);
        }

        internal static string AddedIdleVariableDefaultBlockDU(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("AddedIdleVariableDefaultBlockDU", Culture), args);
        }

        internal static string AddMatchActivityNewAndOldParentMismatch(object param0, object param1, object param2, object param3)
        {
            object[] args = new object[] { param0, param1, param2, param3 };
            return string.Format(Culture, ResourceManager.GetString("AddMatchActivityNewAndOldParentMismatch", Culture), args);
        }

        internal static string AddMatchActivityNewParentMismatch(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("AddMatchActivityNewParentMismatch", Culture), args);
        }

        internal static string AddMatchActivityPrivateChild(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("AddMatchActivityPrivateChild", Culture), args);
        }

        internal static string AddMatchVariableNewAndOldParentMismatch(object param0, object param1, object param2, object param3)
        {
            object[] args = new object[] { param0, param1, param2, param3 };
            return string.Format(Culture, ResourceManager.GetString("AddMatchVariableNewAndOldParentMismatch", Culture), args);
        }

        internal static string AddMatchVariableNewParentMismatch(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("AddMatchVariableNewParentMismatch", Culture), args);
        }

        internal static string AddMatchVariablePrivateChild(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("AddMatchVariablePrivateChild", Culture), args);
        }

        internal static string AddMatchVariableSignatureMismatch(object param0, object param1, object param2, object param3, object param4, object param5, object param6)
        {
            object[] args = new object[] { param0, param1, param2, param3, param4, param5, param6 };
            return string.Format(Culture, ResourceManager.GetString("AddMatchVariableSignatureMismatch", Culture), args);
        }

        internal static string AddValidationErrorMustBeCalledFromConstraint(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("AddValidationErrorMustBeCalledFromConstraint", Culture), args);
        }

        internal static string AmbiguousVBVariableReference(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("AmbiguousVBVariableReference", Culture), args);
        }

        internal static string ArgumentAlreadyInitialized(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("ArgumentAlreadyInitialized", Culture), args);
        }

        internal static string ArgumentAlreadyInUse(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("ArgumentAlreadyInUse", Culture), args);
        }

        internal static string ArgumentDirectionMismatch(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("ArgumentDirectionMismatch", Culture), args);
        }

        internal static string ArgumentDoesNotExist(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("ArgumentDoesNotExist", Culture), args);
        }

        internal static string ArgumentDoesNotExistInEnvironment(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("ArgumentDoesNotExistInEnvironment", Culture), args);
        }

        internal static string ArgumentIsAddedMoreThanOnce(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("ArgumentIsAddedMoreThanOnce", Culture), args);
        }

        internal static string ArgumentLocationExpressionTypeMismatch(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("ArgumentLocationExpressionTypeMismatch", Culture), args);
        }

        internal static string ArgumentNotFound(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("ArgumentNotFound", Culture), args);
        }

        internal static string ArgumentNotInTree(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("ArgumentNotInTree", Culture), args);
        }

        internal static string ArgumentNumberRequiresTheSameAsParameterNumber(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("ArgumentNumberRequiresTheSameAsParameterNumber", Culture), args);
        }

        internal static string ArgumentRequired(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("ArgumentRequired", Culture), args);
        }

        internal static string ArgumentTypeMismatch(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("ArgumentTypeMismatch", Culture), args);
        }

        internal static string ArgumentTypeMustBeCompatible(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("ArgumentTypeMustBeCompatible", Culture), args);
        }

        internal static string ArgumentValueExpressionTypeMismatch(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("ArgumentValueExpressionTypeMismatch", Culture), args);
        }

        internal static string ArgumentViolationsFound(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("ArgumentViolationsFound", Culture), args);
        }

        internal static string BinaryExpressionActivityRequiresArgument(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("BinaryExpressionActivityRequiresArgument", Culture), args);
        }

        internal static string BookmarkAlreadyExists(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("BookmarkAlreadyExists", Culture), args);
        }

        internal static string BookmarkNotRegistered(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("BookmarkNotRegistered", Culture), args);
        }

        internal static string BookmarkScopeNotFound(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("BookmarkScopeNotFound", Culture), args);
        }

        internal static string BookmarkScopeWithIdAlreadyExists(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("BookmarkScopeWithIdAlreadyExists", Culture), args);
        }

        internal static string CallbackExceptionFromHostAbort(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("CallbackExceptionFromHostAbort", Culture), args);
        }

        internal static string CallbackExceptionFromHostGetExtension(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("CallbackExceptionFromHostGetExtension", Culture), args);
        }

        internal static string CancellationHandlerFatalException(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("CancellationHandlerFatalException", Culture), args);
        }

        internal static string CanInduceIdleActivityInArgumentExpression(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("CanInduceIdleActivityInArgumentExpression", Culture), args);
        }

        internal static string CanInduceIdleNotSpecified(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("CanInduceIdleNotSpecified", Culture), args);
        }

        internal static string CannotDereferenceNull(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("CannotDereferenceNull", Culture), args);
        }

        internal static string CannotGenerateSchemaForXmlSerializable(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("CannotGenerateSchemaForXmlSerializable", Culture), args);
        }

        internal static string CannotNestTransactionScopeWhenAmbientHandleIsSuppressed(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("CannotNestTransactionScopeWhenAmbientHandleIsSuppressed", Culture), args);
        }

        internal static string CannotPropagateExceptionWhileCanceling(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("CannotPropagateExceptionWhileCanceling", Culture), args);
        }

        internal static string CannotRemoveExecutingActivityUpdateError(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("CannotRemoveExecutingActivityUpdateError", Culture), args);
        }

        internal static string CannotSaveOriginalValueForNewActivity(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("CannotSaveOriginalValueForNewActivity", Culture), args);
        }

        internal static string CannotSerializeExpression(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("CannotSerializeExpression", Culture), args);
        }

        internal static string CannotSetValueToLocation(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("CannotSetValueToLocation", Culture), args);
        }

        internal static string CannotValidateNullObject(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("CannotValidateNullObject", Culture), args);
        }

        internal static string CanOnlyGetOwnedArguments(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("CanOnlyGetOwnedArguments", Culture), args);
        }

        internal static string CanOnlyScheduleDirectChildren(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("CanOnlyScheduleDirectChildren", Culture), args);
        }

        internal static string CatchOrFinallyExpected(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("CatchOrFinallyExpected", Culture), args);
        }

        internal static string CollectionActivityRequiresCollection(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("CollectionActivityRequiresCollection", Culture), args);
        }

        internal static string ColumnNumberTooLarge(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("ColumnNumberTooLarge", Culture), args);
        }

        internal static string CompensateWithoutCompensableActivity(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("CompensateWithoutCompensableActivity", Culture), args);
        }

        internal static string CompensationHandlerFatalException(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("CompensationHandlerFatalException", Culture), args);
        }

        internal static string CompiledExpressionIdNotFound(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("CompiledExpressionIdNotFound", Culture), args);
        }

        internal static string CompiledExpressionsActivityException(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("CompiledExpressionsActivityException", Culture), args);
        }

        internal static string CompiledExpressionsCacheMetadataException(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("CompiledExpressionsCacheMetadataException", Culture), args);
        }

        internal static string CompiledExpressionsDuplicateName(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("CompiledExpressionsDuplicateName", Culture), args);
        }

        internal static string CompiledExpressionsIgnoringInvalidIdentifierVariable(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("CompiledExpressionsIgnoringInvalidIdentifierVariable", Culture), args);
        }

        internal static string CompiledExpressionsNoCompiledRoot(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("CompiledExpressionsNoCompiledRoot", Culture), args);
        }

        internal static string CompiledLocationNoDefaultConstructor(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("CompiledLocationNoDefaultConstructor", Culture), args);
        }

        internal static string CompilerErrorSpecificExpression(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("CompilerErrorSpecificExpression", Culture), args);
        }

        internal static string CompletionConditionSetButNoBody(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("CompletionConditionSetButNoBody", Culture), args);
        }

        internal static string ConfirmationHandlerFatalException(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("ConfirmationHandlerFatalException", Culture), args);
        }

        internal static string ConfirmWithoutCompensableActivity(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("ConfirmWithoutCompensableActivity", Culture), args);
        }

        internal static string ConstructorInfoNotFound(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("ConstructorInfoNotFound", Culture), args);
        }

        internal static string ConvertVariableToValueExpressionFailed(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("ConvertVariableToValueExpressionFailed", Culture), args);
        }

        internal static string DebugInfoCannotEvaluateExpression(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("DebugInfoCannotEvaluateExpression", Culture), args);
        }

        internal static string DebugInfoExceptionCaught(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("DebugInfoExceptionCaught", Culture), args);
        }

        internal static string DebugInstrumentationFailed(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("DebugInstrumentationFailed", Culture), args);
        }

        internal static string DelegateArgumentAlreadyInUseOnActivity(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("DelegateArgumentAlreadyInUseOnActivity", Culture), args);
        }

        internal static string DelegateArgumentDoesNotExist(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("DelegateArgumentDoesNotExist", Culture), args);
        }

        internal static string DelegateArgumentMustBeReferenced(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("DelegateArgumentMustBeReferenced", Culture), args);
        }

        internal static string DelegateArgumentNotVisible(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("DelegateArgumentNotVisible", Culture), args);
        }

        internal static string DelegateArgumentTypeInvalid(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("DelegateArgumentTypeInvalid", Culture), args);
        }

        internal static string DelegateHandlersCannotBeScheduledDirectly(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("DelegateHandlersCannotBeScheduledDirectly", Culture), args);
        }

        internal static string DelegateInArgumentTypeMismatch(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("DelegateInArgumentTypeMismatch", Culture), args);
        }

        internal static string DelegateOutArgumentTypeMismatch(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("DelegateOutArgumentTypeMismatch", Culture), args);
        }

        internal static string DelegateParameterCannotBeModifiedAfterOpen(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("DelegateParameterCannotBeModifiedAfterOpen", Culture), args);
        }

        internal static string DelegateParameterDirectionalityMismatch(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("DelegateParameterDirectionalityMismatch", Culture), args);
        }

        internal static string DoNotSupportArrayIndexerOnNonArrayType(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("DoNotSupportArrayIndexerOnNonArrayType", Culture), args);
        }

        internal static string DoNotSupportArrayIndexerReferenceWithDifferentArrayTypeAndResultType(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("DoNotSupportArrayIndexerReferenceWithDifferentArrayTypeAndResultType", Culture), args);
        }

        internal static string DoNotSupportArrayIndexerValueWithIncompatibleArrayTypeAndResultType(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("DoNotSupportArrayIndexerValueWithIncompatibleArrayTypeAndResultType", Culture), args);
        }

        internal static string DoNotSupportArrayIndexerWithDifferentArrayTypeAndResultType(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("DoNotSupportArrayIndexerWithDifferentArrayTypeAndResultType", Culture), args);
        }

        internal static string DoNotSupportArrayIndexerWithNonIntIndex(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("DoNotSupportArrayIndexerWithNonIntIndex", Culture), args);
        }

        internal static string DoWhileRequiresCondition(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("DoWhileRequiresCondition", Culture), args);
        }

        internal static string DUActivityTypeMismatch(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("DUActivityTypeMismatch", Culture), args);
        }

        internal static string DuplicateAnnotationName(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("DuplicateAnnotationName", Culture), args);
        }

        internal static string DuplicateCatchClause(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("DuplicateCatchClause", Culture), args);
        }

        internal static string DuplicateEvaluationOrderValues(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("DuplicateEvaluationOrderValues", Culture), args);
        }

        internal static string DuplicateImportAttribute(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("DuplicateImportAttribute", Culture), args);
        }

        internal static string DuplicateInstrumentation(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("DuplicateInstrumentation", Culture), args);
        }

        internal static string DuplicateMethodFound(object param0, object param1, object param2, object param3)
        {
            object[] args = new object[] { param0, param1, param2, param3 };
            return string.Format(Culture, ResourceManager.GetString("DuplicateMethodFound", Culture), args);
        }

        internal static string DuplicateOriginActivityActivity(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("DuplicateOriginActivityActivity", Culture), args);
        }

        internal static string DuplicateOriginActivityVariable(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("DuplicateOriginActivityVariable", Culture), args);
        }

        internal static string DuplicateOriginVariableVariable(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("DuplicateOriginVariableVariable", Culture), args);
        }

        internal static string DurationIsNegative(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("DurationIsNegative", Culture), args);
        }

        internal static string DynamicActivityDuplicatePropertyDetected(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("DynamicActivityDuplicatePropertyDetected", Culture), args);
        }

        internal static string DynamicActivityMultipleExpressionLanguages(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("DynamicActivityMultipleExpressionLanguages", Culture), args);
        }

        internal static string EmptyIdReturnedFromHost(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("EmptyIdReturnedFromHost", Culture), args);
        }

        internal static string ErrorExtractingValuesForLambdaRewrite(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("ErrorExtractingValuesForLambdaRewrite", Culture), args);
        }

        internal static string ExecutionPropertyAlreadyDefined(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("ExecutionPropertyAlreadyDefined", Culture), args);
        }

        internal static string ExtraOverloadGroupPropertiesConfigured(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("ExtraOverloadGroupPropertiesConfigured", Culture), args);
        }

        internal static string FaultContextNotFound(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("FaultContextNotFound", Culture), args);
        }

        internal static string FinalStateCannotHaveProperty(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("FinalStateCannotHaveProperty", Culture), args);
        }

        internal static string FinalStateCannotHaveTransition(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("FinalStateCannotHaveTransition", Culture), args);
        }

        internal static string FlowchartContainsUnconnectedNodes(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("FlowchartContainsUnconnectedNodes", Culture), args);
        }

        internal static string FlowchartMissingStartNode(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("FlowchartMissingStartNode", Culture), args);
        }

        internal static string FlowDecisionRequiresCondition(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("FlowDecisionRequiresCondition", Culture), args);
        }

        internal static string FlowNodeCannotBeShared(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("FlowNodeCannotBeShared", Culture), args);
        }

        internal static string FlowNodeLockedForRuntime(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("FlowNodeLockedForRuntime", Culture), args);
        }

        internal static string FlowSwitchRequiresExpression(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("FlowSwitchRequiresExpression", Culture), args);
        }

        internal static string ForEachRequiresNonNullValues(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("ForEachRequiresNonNullValues", Culture), args);
        }

        internal static string GetLocationOnPublicAccessReference(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("GetLocationOnPublicAccessReference", Culture), args);
        }

        internal static string HostIdDoesNotMatchInstance(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("HostIdDoesNotMatchInstance", Culture), args);
        }

        internal static string IdNotFoundInWorkflow(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("IdNotFoundInWorkflow", Culture), args);
        }

        internal static string ImplementationVersionMismatch(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("ImplementationVersionMismatch", Culture), args);
        }

        internal static string IncompatibleTypeForMultidimensionalArrayItemReference(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("IncompatibleTypeForMultidimensionalArrayItemReference", Culture), args);
        }

        internal static string IncorrectIndexForArgument(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("IncorrectIndexForArgument", Culture), args);
        }

        internal static string IndexOutOfBounds(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("IndexOutOfBounds", Culture), args);
        }

        internal static string IndicesAreNeeded(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("IndicesAreNeeded", Culture), args);
        }

        internal static string InitialStateCannotBeFinalState(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("InitialStateCannotBeFinalState", Culture), args);
        }

        internal static string InitialStateNotInStatesCollection(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("InitialStateNotInStatesCollection", Culture), args);
        }

        internal static string InlinedLocationReferenceOnlyAccessibleByOwner(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("InlinedLocationReferenceOnlyAccessibleByOwner", Culture), args);
        }

        internal static string InputParametersCountMismatch(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("InputParametersCountMismatch", Culture), args);
        }

        internal static string InputParametersMissing(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("InputParametersMissing", Culture), args);
        }

        internal static string InputParametersTypeMismatch(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("InputParametersTypeMismatch", Culture), args);
        }

        internal static string InsufficientArraySize(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("InsufficientArraySize", Culture), args);
        }

        internal static string InternalConstraintException(object param0, object param1, object param2, object param3)
        {
            object[] args = new object[] { param0, param1, param2, param3 };
            return string.Format(Culture, ResourceManager.GetString("InternalConstraintException", Culture), args);
        }

        internal static string InvalidActivityToBlockUpdate(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("InvalidActivityToBlockUpdate", Culture), args);
        }

        internal static string InvalidActivityToBlockUpdateServices(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("InvalidActivityToBlockUpdateServices", Culture), args);
        }

        internal static string InvalidArgumentExpression(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("InvalidArgumentExpression", Culture), args);
        }

        internal static string InvalidAsyncBeginMethodSignature(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("InvalidAsyncBeginMethodSignature", Culture), args);
        }

        internal static string InvalidAsyncCancelMethodSignature(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("InvalidAsyncCancelMethodSignature", Culture), args);
        }

        internal static string InvalidAsyncEndMethodSignature(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("InvalidAsyncEndMethodSignature", Culture), args);
        }

        internal static string InvalidCallbackState(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("InvalidCallbackState", Culture), args);
        }

        internal static string InvalidCompensateActivityUsage(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("InvalidCompensateActivityUsage", Culture), args);
        }

        internal static string InvalidCompensationToken(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("InvalidCompensationToken", Culture), args);
        }

        internal static string InvalidConfirmActivityUsage(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("InvalidConfirmActivityUsage", Culture), args);
        }

        internal static string InvalidDirectionForArgument(object param0, object param1, object param2, object param3)
        {
            object[] args = new object[] { param0, param1, param2, param3 };
            return string.Format(Culture, ResourceManager.GetString("InvalidDirectionForArgument", Culture), args);
        }

        internal static string InvalidDynamicActivityProperty(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("InvalidDynamicActivityProperty", Culture), args);
        }

        internal static string InvalidExecutionCallback(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("InvalidExecutionCallback", Culture), args);
        }

        internal static string InvalidExpressionForLocation(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("InvalidExpressionForLocation", Culture), args);
        }

        internal static string InvalidExpressionProperty(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("InvalidExpressionProperty", Culture), args);
        }

        internal static string InvalidFileName(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("InvalidFileName", Culture), args);
        }

        internal static string InvalidGenericTypeInfo(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("InvalidGenericTypeInfo", Culture), args);
        }

        internal static string InvalidImplementationMap(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("InvalidImplementationMap", Culture), args);
        }

        internal static string InvalidImplementationMapAssociation(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("InvalidImplementationMapAssociation", Culture), args);
        }

        internal static string InvalidImplementationMapAssociationServices(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("InvalidImplementationMapAssociationServices", Culture), args);
        }

        internal static string InvalidMergeMap(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("InvalidMergeMap", Culture), args);
        }

        internal static string InvalidMergeMapArgumentCount(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("InvalidMergeMapArgumentCount", Culture), args);
        }

        internal static string InvalidMergeMapEnvironmentCount(object param0, object param1, object param2, object param3, object param4, object param5)
        {
            object[] args = new object[] { param0, param1, param2, param3, param4, param5 };
            return string.Format(Culture, ResourceManager.GetString("InvalidMergeMapEnvironmentCount", Culture), args);
        }

        internal static string InvalidMergeMapForImplementation(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("InvalidMergeMapForImplementation", Culture), args);
        }

        internal static string InvalidMergeMapMemberCount(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("InvalidMergeMapMemberCount", Culture), args);
        }

        internal static string InvalidParameterInfo(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("InvalidParameterInfo", Culture), args);
        }

        internal static string InvalidProperty(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("InvalidProperty", Culture), args);
        }

        internal static string InvalidPropertyType(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("InvalidPropertyType", Culture), args);
        }

        internal static string InvalidRootMergeMap(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("InvalidRootMergeMap", Culture), args);
        }

        internal static string InvalidSourceLocationColumn(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("InvalidSourceLocationColumn", Culture), args);
        }

        internal static string InvalidSourceLocationLineNumber(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("InvalidSourceLocationLineNumber", Culture), args);
        }

        internal static string InvalidTypeForArgument(object param0, object param1, object param2, object param3)
        {
            object[] args = new object[] { param0, param1, param2, param3 };
            return string.Format(Culture, ResourceManager.GetString("InvalidTypeForArgument", Culture), args);
        }

        internal static string InvalidUpdateMap(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("InvalidUpdateMap", Culture), args);
        }

        internal static string InvalidXamlMember(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("InvalidXamlMember", Culture), args);
        }

        internal static string LineNumberTooLarge(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("LineNumberTooLarge", Culture), args);
        }

        internal static string LiteralsMustBeValueTypesOrImmutableTypes(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("LiteralsMustBeValueTypesOrImmutableTypes", Culture), args);
        }

        internal static string LocationExpressionCouldNotBeResolved(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("LocationExpressionCouldNotBeResolved", Culture), args);
        }

        internal static string LocationTypeMismatch(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("LocationTypeMismatch", Culture), args);
        }

        internal static string MapEntryNotFound(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("MapEntryNotFound", Culture), args);
        }

        internal static string MemberCannotBeNull(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("MemberCannotBeNull", Culture), args);
        }

        internal static string MemberIsReadOnly(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("MemberIsReadOnly", Culture), args);
        }

        internal static string MemberNotFound(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("MemberNotFound", Culture), args);
        }

        internal static string MemberNotSupportedByActivityXamlServices(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("MemberNotSupportedByActivityXamlServices", Culture), args);
        }

        internal static string MethodInfoRequired(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("MethodInfoRequired", Culture), args);
        }

        internal static string MethodNameRequired(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("MethodNameRequired", Culture), args);
        }

        internal static string MissingArgument(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("MissingArgument", Culture), args);
        }

        internal static string MissingNameProperty(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("MissingNameProperty", Culture), args);
        }

        internal static string MissingSetAccessorForIndexer(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("MissingSetAccessorForIndexer", Culture), args);
        }

        internal static string MultipleOverloadGroupsConfigured(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("MultipleOverloadGroupsConfigured", Culture), args);
        }

        internal static string NativeActivityUpdateInstanceThrewException(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("NativeActivityUpdateInstanceThrewException", Culture), args);
        }

        internal static string NoNamespace(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("NoNamespace", Culture), args);
        }

        internal static string NoOutputLocationWasFound(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("NoOutputLocationWasFound", Culture), args);
        }

        internal static string NoPersistScopeCannotContainPersist(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("NoPersistScopeCannotContainPersist", Culture), args);
        }

        internal static string NullReferencedMemberAccess(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("NullReferencedMemberAccess", Culture), args);
        }

        internal static string OneOfTwoPropertiesMustBeSet(object param0, object param1, object param2, object param3)
        {
            object[] args = new object[] { param0, param1, param2, param3 };
            return string.Format(Culture, ResourceManager.GetString("OneOfTwoPropertiesMustBeSet", Culture), args);
        }

        internal static string OptionalExtensionTypeMatchedMultiple(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("OptionalExtensionTypeMatchedMultiple", Culture), args);
        }

        internal static string OriginalActivityReusedInModifiedDefinition(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("OriginalActivityReusedInModifiedDefinition", Culture), args);
        }

        internal static string OriginalVariableReusedInModifiedDefinition(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("OriginalVariableReusedInModifiedDefinition", Culture), args);
        }

        internal static string OriginCannotBeRuntimeIntrinsic(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("OriginCannotBeRuntimeIntrinsic", Culture), args);
        }

        internal static string OutArgumentCannotHaveInputValue(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("OutArgumentCannotHaveInputValue", Culture), args);
        }

        internal static string OutOfRangeSourceLocationEndColumn(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("OutOfRangeSourceLocationEndColumn", Culture), args);
        }

        internal static string OutOfRangeSourceLocationEndLine(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("OutOfRangeSourceLocationEndLine", Culture), args);
        }

        internal static string OverloadGroupHasSubsets(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("OverloadGroupHasSubsets", Culture), args);
        }

        internal static string OverloadGroupsAreEquivalent(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("OverloadGroupsAreEquivalent", Culture), args);
        }

        internal static string ParallelForEachRequiresNonNullValues(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("ParallelForEachRequiresNonNullValues", Culture), args);
        }

        internal static string PermissionArgumentWrongType(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("PermissionArgumentWrongType", Culture), args);
        }

        internal static string PickBranchRequiresTrigger(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("PickBranchRequiresTrigger", Culture), args);
        }

        internal static string PropertyCannotBeModified(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("PropertyCannotBeModified", Culture), args);
        }

        internal static string PropertyMemberNotSupportedByActivityXamlServices(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("PropertyMemberNotSupportedByActivityXamlServices", Culture), args);
        }

        internal static string PropertyReadOnlyInWorkflowDataContext(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("PropertyReadOnlyInWorkflowDataContext", Culture), args);
        }

        internal static string PropertyReferenceNotFound(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("PropertyReferenceNotFound", Culture), args);
        }

        internal static string PublicMethodWithMatchingParameterDoesNotExist(object param0, object param1, object param2, object param3)
        {
            object[] args = new object[] { param0, param1, param2, param3 };
            return string.Format(Culture, ResourceManager.GetString("PublicMethodWithMatchingParameterDoesNotExist", Culture), args);
        }

        internal static string PublicReferencesOnActivityRequiringArgumentResolution(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("PublicReferencesOnActivityRequiringArgumentResolution", Culture), args);
        }

        internal static string QueryActivityIsInImplementation(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("QueryActivityIsInImplementation", Culture), args);
        }

        internal static string QueryActivityIsPublic(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("QueryActivityIsPublic", Culture), args);
        }

        internal static string QueryVariableIsInImplementation(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("QueryVariableIsInImplementation", Culture), args);
        }

        internal static string QueryVariableIsPublic(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("QueryVariableIsPublic", Culture), args);
        }

        internal static string ReadAccessToWriteOnlyPublicReference(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("ReadAccessToWriteOnlyPublicReference", Culture), args);
        }

        internal static string ReadonlyPropertyCannotBeSet(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("ReadonlyPropertyCannotBeSet", Culture), args);
        }

        internal static string RequiredArgumentValueNotSupplied(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("RequiredArgumentValueNotSupplied", Culture), args);
        }

        internal static string RequiredExtensionTypeNotFound(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("RequiredExtensionTypeNotFound", Culture), args);
        }

        internal static string RequiredVariableCoundNotBeExtracted(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("RequiredVariableCoundNotBeExtracted", Culture), args);
        }

        internal static string RequireExtensionOnlyAcceptsReferenceTypes(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("RequireExtensionOnlyAcceptsReferenceTypes", Culture), args);
        }

        internal static string ResultArgumentHasRequiredTypeAndDirection(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("ResultArgumentHasRequiredTypeAndDirection", Culture), args);
        }

        internal static string ResultArgumentMustBeSpecificType(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("ResultArgumentMustBeSpecificType", Culture), args);
        }

        internal static string RethrowMustBeAPublicChild(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("RethrowMustBeAPublicChild", Culture), args);
        }

        internal static string RethrowNotInATryCatch(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("RethrowNotInATryCatch", Culture), args);
        }

        internal static string ReturnTypeIncompatible(object param0, object param1, object param2, object param3, object param4)
        {
            object[] args = new object[] { param0, param1, param2, param3, param4 };
            return string.Format(Culture, ResourceManager.GetString("ReturnTypeIncompatible", Culture), args);
        }

        internal static string RootActivityAlreadyAssociatedWithInstance(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("RootActivityAlreadyAssociatedWithInstance", Culture), args);
        }

        internal static string RootActivityCannotBeReferenced(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("RootActivityCannotBeReferenced", Culture), args);
        }

        internal static string RuntimeArgumentBindingInvalid(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("RuntimeArgumentBindingInvalid", Culture), args);
        }

        internal static string RuntimeArgumentChangeBlockDU(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("RuntimeArgumentChangeBlockDU", Culture), args);
        }

        internal static string RuntimeArgumentNotOpen(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("RuntimeArgumentNotOpen", Culture), args);
        }

        internal static string RuntimeTransactionHandleNotRegisteredAsExecutionProperty(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("RuntimeTransactionHandleNotRegisteredAsExecutionProperty", Culture), args);
        }

        internal static string SchemaContextFromBeforeInitializeComponentXBTExtensionCannotBeGeneric(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("SchemaContextFromBeforeInitializeComponentXBTExtensionCannotBeGeneric", Culture), args);
        }

        internal static string SchemaContextFromBeforeInitializeComponentXBTExtensionNotFound(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("SchemaContextFromBeforeInitializeComponentXBTExtensionNotFound", Culture), args);
        }

        internal static string SimpleStateMustHaveOneTransition(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("SimpleStateMustHaveOneTransition", Culture), args);
        }

        internal static string SpecialMethodNotFound(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("SpecialMethodNotFound", Culture), args);
        }

        internal static string StateCannotBeAddedTwice(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("StateCannotBeAddedTwice", Culture), args);
        }

        internal static string StateCannotBeSerialized(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("StateCannotBeSerialized", Culture), args);
        }

        internal static string StateMachineMustHaveInitialState(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("StateMachineMustHaveInitialState", Culture), args);
        }

        internal static string StateNotBelongToAnyParent(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("StateNotBelongToAnyParent", Culture), args);
        }

        internal static string SubexpressionResultWasNotVisible(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("SubexpressionResultWasNotVisible", Culture), args);
        }

        internal static string SubexpressionResultWasNull(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("SubexpressionResultWasNull", Culture), args);
        }

        internal static string SwitchCaseKeyTypesMustMatchExpressionType(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("SwitchCaseKeyTypesMustMatchExpressionType", Culture), args);
        }

        internal static string SwitchCaseNullWithValueType(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("SwitchCaseNullWithValueType", Culture), args);
        }

        internal static string SwitchCaseTypeMismatch(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("SwitchCaseTypeMismatch", Culture), args);
        }

        internal static string SymbolNamesMustBeUnique(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("SymbolNamesMustBeUnique", Culture), args);
        }

        internal static string SymbolResolverDoesNotHaveSymbol(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("SymbolResolverDoesNotHaveSymbol", Culture), args);
        }

        internal static string TargetTypeAndTargetObjectAreMutuallyExclusive(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("TargetTypeAndTargetObjectAreMutuallyExclusive", Culture), args);
        }

        internal static string TargetTypeCannotBeEnum(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("TargetTypeCannotBeEnum", Culture), args);
        }

        internal static string TargetTypeIsValueType(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("TargetTypeIsValueType", Culture), args);
        }

        internal static string TextExpressionCompilerNoCodebase(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("TextExpressionCompilerNoCodebase", Culture), args);
        }

        internal static string TextExpressionCompilerUnableToLoadAssembly(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("TextExpressionCompilerUnableToLoadAssembly", Culture), args);
        }

        internal static string TextExpressionMetadataRequiresCompilation(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("TextExpressionMetadataRequiresCompilation", Culture), args);
        }

        internal static string TimeoutOnOperation(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("TimeoutOnOperation", Culture), args);
        }

        internal static string TransitionCannotBeAddedTwice(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("TransitionCannotBeAddedTwice", Culture), args);
        }

        internal static string TransitionTargetCannotBeNull(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("TransitionTargetCannotBeNull", Culture), args);
        }

        internal static string TryCatchInvalidStateForUpdate(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("TryCatchInvalidStateForUpdate", Culture), args);
        }

        internal static string TypeConverterHelperCacheAddFailed(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("TypeConverterHelperCacheAddFailed", Culture), args);
        }

        internal static string TypeMismatchForAssign(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("TypeMismatchForAssign", Culture), args);
        }

        internal static string TypeMustbeValueType(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("TypeMustbeValueType", Culture), args);
        }

        internal static string TypeNotAssignableTo(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("TypeNotAssignableTo", Culture), args);
        }

        internal static string UnableToLocateCompiledLocationContext(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("UnableToLocateCompiledLocationContext", Culture), args);
        }

        internal static string UnconditionalTransitionShouldNotShareNullTriggersWithOthers(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("UnconditionalTransitionShouldNotShareNullTriggersWithOthers", Culture), args);
        }

        internal static string UnconditionalTransitionShouldNotShareTriggersWithOthers(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("UnconditionalTransitionShouldNotShareTriggersWithOthers", Culture), args);
        }

        internal static string UnexpectedArgumentCount(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("UnexpectedArgumentCount", Culture), args);
        }

        internal static string UnexpectedExpressionNodeType(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("UnexpectedExpressionNodeType", Culture), args);
        }

        internal static string UnknownExpressionCompilationError(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("UnknownExpressionCompilationError", Culture), args);
        }

        internal static string UnknownLanguage(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("UnknownLanguage", Culture), args);
        }

        internal static string UnopenedActivitiesCannotBeExecuted(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("UnopenedActivitiesCannotBeExecuted", Culture), args);
        }

        internal static string UnsupportedExpressionType(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("UnsupportedExpressionType", Culture), args);
        }

        internal static string UnsupportedMemberExpressionWithType(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("UnsupportedMemberExpressionWithType", Culture), args);
        }

        internal static string UnsupportedReferenceExpressionType(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("UnsupportedReferenceExpressionType", Culture), args);
        }

        internal static string UnusedInputArguments(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("UnusedInputArguments", Culture), args);
        }

        internal static string UpdateMapBuilderRequiredProperty(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("UpdateMapBuilderRequiredProperty", Culture), args);
        }

        internal static string ValidationContextCannotBeNull(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("ValidationContextCannotBeNull", Culture), args);
        }

        internal static string ValidationErrorPrefixForHiddenActivity(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("ValidationErrorPrefixForHiddenActivity", Culture), args);
        }

        internal static string ValidationErrorPrefixForPublicActivityWithHiddenParent(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("ValidationErrorPrefixForPublicActivityWithHiddenParent", Culture), args);
        }

        internal static string VariableAlreadyInUseOnActivity(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("VariableAlreadyInUseOnActivity", Culture), args);
        }

        internal static string VariableCannotBePopulatedInLocationEnvironment(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("VariableCannotBePopulatedInLocationEnvironment", Culture), args);
        }

        internal static string VariableDoesNotExist(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("VariableDoesNotExist", Culture), args);
        }

        internal static string VariableExpressionTypeMismatch(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("VariableExpressionTypeMismatch", Culture), args);
        }

        internal static string VariableIsReadOnly(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("VariableIsReadOnly", Culture), args);
        }

        internal static string VariableNameNotAnIdentifier(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("VariableNameNotAnIdentifier", Culture), args);
        }

        internal static string VariableNotOpen(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("VariableNotOpen", Culture), args);
        }

        internal static string VariableNotVisible(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("VariableNotVisible", Culture), args);
        }

        internal static string VariableOnlyAccessibleAtScopeOfDeclaration(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("VariableOnlyAccessibleAtScopeOfDeclaration", Culture), args);
        }

        internal static string VariableOrArgumentDoesNotExist(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("VariableOrArgumentDoesNotExist", Culture), args);
        }

        internal static string VariableShouldBeOpen(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("VariableShouldBeOpen", Culture), args);
        }

        internal static string VariableTypeInvalid(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("VariableTypeInvalid", Culture), args);
        }

        internal static string VariableTypeNotMatchLocationType(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("VariableTypeNotMatchLocationType", Culture), args);
        }

        internal static string VBExpressionTamperedSinceLastCompiled(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("VBExpressionTamperedSinceLastCompiled", Culture), args);
        }

        internal static string WhileRequiresCondition(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("WhileRequiresCondition", Culture), args);
        }

        internal static string WorkflowAbortedReason(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("WorkflowAbortedReason", Culture), args);
        }

        internal static string WorkflowApplicationAborted(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("WorkflowApplicationAborted", Culture), args);
        }

        internal static string WorkflowApplicationCompleted(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("WorkflowApplicationCompleted", Culture), args);
        }

        internal static string WorkflowApplicationTerminated(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("WorkflowApplicationTerminated", Culture), args);
        }

        internal static string WorkflowApplicationUnloaded(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("WorkflowApplicationUnloaded", Culture), args);
        }

        internal static string WorkflowIdentityNullHostId(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("WorkflowIdentityNullHostId", Culture), args);
        }

        internal static string WorkflowIdentityNullStateId(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("WorkflowIdentityNullStateId", Culture), args);
        }

        internal static string WorkflowIdentityStateIdHostIdMismatch(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("WorkflowIdentityStateIdHostIdMismatch", Culture), args);
        }

        internal static string WorkflowInstanceAborted(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("WorkflowInstanceAborted", Culture), args);
        }

        internal static string WorkflowInstanceIsReadOnly(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("WorkflowInstanceIsReadOnly", Culture), args);
        }

        internal static string WorkflowInstanceNotFoundInStore(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("WorkflowInstanceNotFoundInStore", Culture), args);
        }

        internal static string WorkflowInstanceUnlocked(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("WorkflowInstanceUnlocked", Culture), args);
        }

        internal static string WriteAccessToReadOnlyPublicReference(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("WriteAccessToReadOnlyPublicReference", Culture), args);
        }

        internal static string WriteonlyPropertyCannotBeRead(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("WriteonlyPropertyCannotBeRead", Culture), args);
        }

        internal static string WrongArgumentType(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("WrongArgumentType", Culture), args);
        }

        internal static string WrongEnvironmentCount(object param0, object param1, object param2, object param3, object param4, object param5, object param6, object param7, object param8)
        {
            object[] args = new object[] { param0, param1, param2, param3, param4, param5, param6, param7, param8 };
            return string.Format(Culture, ResourceManager.GetString("WrongEnvironmentCount", Culture), args);
        }

        internal static string WrongMemberCount(object param0, object param1, object param2)
        {
            object[] args = new object[] { param0, param1, param2 };
            return string.Format(Culture, ResourceManager.GetString("WrongMemberCount", Culture), args);
        }

        internal static string WrongOriginalEnvironmentCount(object param0, object param1, object param2, object param3, object param4, object param5, object param6)
        {
            object[] args = new object[] { param0, param1, param2, param3, param4, param5, param6 };
            return string.Format(Culture, ResourceManager.GetString("WrongOriginalEnvironmentCount", Culture), args);
        }

        internal static string XamlBuildTaskResourceNotFound(object param0)
        {
            object[] args = new object[] { param0 };
            return string.Format(Culture, ResourceManager.GetString("XamlBuildTaskResourceNotFound", Culture), args);
        }

        internal static string XamlElementExpectedAt(object param0, object param1)
        {
            object[] args = new object[] { param0, param1 };
            return string.Format(Culture, ResourceManager.GetString("XamlElementExpectedAt", Culture), args);
        }

        internal static System.Resources.ResourceManager ResourceManager
        {
            get
            {
                if (resourceManager == null)
                {
                    System.Resources.ResourceManager manager = new System.Resources.ResourceManager("System.Activities.SR", typeof(System.Activities.SR).Assembly);
                    resourceManager = manager;
                }
                return resourceManager;
            }
        }

        internal static CultureInfo Culture
        {
            get => 
                resourceCulture;
            set => 
                resourceCulture = value;
        }

        internal static string ActivityInstanceFixupFailed =>
            ResourceManager.GetString("ActivityInstanceFixupFailed", Culture);

        internal static string ActivityMapIsCorrupt =>
            ResourceManager.GetString("ActivityMapIsCorrupt", Culture);

        internal static string AECDisposed =>
            ResourceManager.GetString("AECDisposed", Culture);

        internal static string HandleInitializationContextDisposed =>
            ResourceManager.GetString("HandleInitializationContextDisposed", Culture);

        internal static string CannotGetValueOfOutArgument =>
            ResourceManager.GetString("CannotGetValueOfOutArgument", Culture);

        internal static string OverloadOnlyCallableFromWorkflowThread =>
            ResourceManager.GetString("OverloadOnlyCallableFromWorkflowThread", Culture);

        internal static string SameUserStateUsedForMultipleInvokes =>
            ResourceManager.GetString("SameUserStateUsedForMultipleInvokes", Culture);

        internal static string SendNotSupported =>
            ResourceManager.GetString("SendNotSupported", Culture);

        internal static string InitializationIncomplete =>
            ResourceManager.GetString("InitializationIncomplete", Culture);

        internal static string CannotSetValueOfInArgument =>
            ResourceManager.GetString("CannotSetValueOfInArgument", Culture);

        internal static string CanOnlyCancelDirectChildren =>
            ResourceManager.GetString("CanOnlyCancelDirectChildren", Culture);

        internal static string DictionaryIsReadOnly =>
            ResourceManager.GetString("DictionaryIsReadOnly", Culture);

        internal static string EnvironmentDisposed =>
            ResourceManager.GetString("EnvironmentDisposed", Culture);

        internal static string ResultCannotBeSetOnArgumentExpressions =>
            ResourceManager.GetString("ResultCannotBeSetOnArgumentExpressions", Culture);

        internal static string OutOfInternalBookmarks =>
            ResourceManager.GetString("OutOfInternalBookmarks", Culture);

        internal static string ConstVariableCannotBeSet =>
            ResourceManager.GetString("ConstVariableCannotBeSet", Culture);

        internal static string InstanceStoreRequiredToPersist =>
            ResourceManager.GetString("InstanceStoreRequiredToPersist", Culture);

        internal static string ControllerInvalidBeforeInitialize =>
            ResourceManager.GetString("ControllerInvalidBeforeInitialize", Culture);

        internal static string OperationAlreadyCompleted =>
            ResourceManager.GetString("OperationAlreadyCompleted", Culture);

        internal static string OnlyOneOperationPerActivity =>
            ResourceManager.GetString("OnlyOneOperationPerActivity", Culture);

        internal static string TrackingRelatedWorkflowAbort =>
            ResourceManager.GetString("TrackingRelatedWorkflowAbort", Culture);

        internal static string CannotUnregisterDefaultBookmarkScope =>
            ResourceManager.GetString("CannotUnregisterDefaultBookmarkScope", Culture);

        internal static string DefaultAbortReason =>
            ResourceManager.GetString("DefaultAbortReason", Culture);

        internal static string InstanceMustBePaused =>
            ResourceManager.GetString("InstanceMustBePaused", Culture);

        internal static string InstanceMustNotBePaused =>
            ResourceManager.GetString("InstanceMustNotBePaused", Culture);

        internal static string CannotSerializeVariableExpression =>
            ResourceManager.GetString("CannotSerializeVariableExpression", Culture);

        internal static string RuntimeOperationInProgress =>
            ResourceManager.GetString("RuntimeOperationInProgress", Culture);

        internal static string RuntimeRunning =>
            ResourceManager.GetString("RuntimeRunning", Culture);

        internal static string BookmarksOnlyResumableWhileIdle =>
            ResourceManager.GetString("BookmarksOnlyResumableWhileIdle", Culture);

        internal static string CannotCompleteRuntimeOwnedTransaction =>
            ResourceManager.GetString("CannotCompleteRuntimeOwnedTransaction", Culture);

        internal static string OnlySingleCastDelegatesAllowed =>
            ResourceManager.GetString("OnlySingleCastDelegatesAllowed", Culture);

        internal static string CannotPerformOperationFromHandlerThread =>
            ResourceManager.GetString("CannotPerformOperationFromHandlerThread", Culture);

        internal static string InvalidIdleAction =>
            ResourceManager.GetString("InvalidIdleAction", Culture);

        internal static string InvalidUnhandledExceptionAction =>
            ResourceManager.GetString("InvalidUnhandledExceptionAction", Culture);

        internal static string MultiDimensionalArraysNotSupported =>
            ResourceManager.GetString("MultiDimensionalArraysNotSupported", Culture);

        internal static string WrongCacheMetadataForNativeActivity =>
            ResourceManager.GetString("WrongCacheMetadataForNativeActivity", Culture);

        internal static string WrongOnCreateDynamicUpdateMapForNativeActivity =>
            ResourceManager.GetString("WrongOnCreateDynamicUpdateMapForNativeActivity", Culture);

        internal static string WrongCacheMetadataForCodeActivity =>
            ResourceManager.GetString("WrongCacheMetadataForCodeActivity", Culture);

        internal static string AsyncMethodsMustAllBeStaticOrInstance =>
            ResourceManager.GetString("AsyncMethodsMustAllBeStaticOrInstance", Culture);

        internal static string AsyncMethodsMustFromSameType =>
            ResourceManager.GetString("AsyncMethodsMustFromSameType", Culture);

        internal static string InvalidStateForAsyncCallback =>
            ResourceManager.GetString("InvalidStateForAsyncCallback", Culture);

        internal static string EnumeratorNotStarted =>
            ResourceManager.GetString("EnumeratorNotStarted", Culture);

        internal static string CannotInvokeOpenedActivity =>
            ResourceManager.GetString("CannotInvokeOpenedActivity", Culture);

        internal static string CannotPersistWhileDetached =>
            ResourceManager.GetString("CannotPersistWhileDetached", Culture);

        internal static string DirectLambdaParameterReference =>
            ResourceManager.GetString("DirectLambdaParameterReference", Culture);

        internal static string ActivityFailedToOpenBefore =>
            ResourceManager.GetString("ActivityFailedToOpenBefore", Culture);

        internal static string CannotAddHandlesUpdateError =>
            ResourceManager.GetString("CannotAddHandlesUpdateError", Culture);

        internal static string CopyToIndexOutOfRange =>
            ResourceManager.GetString("CopyToIndexOutOfRange", Culture);

        internal static string CopyToRankMustBeOne =>
            ResourceManager.GetString("CopyToRankMustBeOne", Culture);

        internal static string CopyToNotEnoughSpaceInArray =>
            ResourceManager.GetString("CopyToNotEnoughSpaceInArray", Culture);

        internal static string ArgumentNameRequired =>
            ResourceManager.GetString("ArgumentNameRequired", Culture);

        internal static string ProvidedStateInitializedForExecution =>
            ResourceManager.GetString("ProvidedStateInitializedForExecution", Culture);

        internal static string OutOfIdSpaceIds =>
            ResourceManager.GetString("OutOfIdSpaceIds", Culture);

        internal static string InvalidActivityIdFormat =>
            ResourceManager.GetString("InvalidActivityIdFormat", Culture);

        internal static string InvalidLocationExpression =>
            ResourceManager.GetString("InvalidLocationExpression", Culture);

        internal static string InvalidTypeConverterUsage =>
            ResourceManager.GetString("InvalidTypeConverterUsage", Culture);

        internal static string TooManyViolationsForExceptionMessage =>
            ResourceManager.GetString("TooManyViolationsForExceptionMessage", Culture);

        internal static string DefaultInvalidWorkflowExceptionMessage =>
            ResourceManager.GetString("DefaultInvalidWorkflowExceptionMessage", Culture);

        internal static string WrongNumberOfArgumentsForActivityDelegate =>
            ResourceManager.GetString("WrongNumberOfArgumentsForActivityDelegate", Culture);

        internal static string AECForPropertiesHasBeenDisposed =>
            ResourceManager.GetString("AECForPropertiesHasBeenDisposed", Culture);

        internal static string CannotAddOrRemoveWithChildren =>
            ResourceManager.GetString("CannotAddOrRemoveWithChildren", Culture);

        internal static string SetupOrCleanupWorkflowThreadThrew =>
            ResourceManager.GetString("SetupOrCleanupWorkflowThreadThrew", Culture);

        internal static string WorkItemAbortedInstance =>
            ResourceManager.GetString("WorkItemAbortedInstance", Culture);

        internal static string ValueMustBeAssignableToType =>
            ResourceManager.GetString("ValueMustBeAssignableToType", Culture);

        internal static string ExternalLocationsGetOnly =>
            ResourceManager.GetString("ExternalLocationsGetOnly", Culture);

        internal static string ResultArgumentMustBeBoundToResultProperty =>
            ResourceManager.GetString("ResultArgumentMustBeBoundToResultProperty", Culture);

        internal static string RootArgumentViolationsFoundNoInputs =>
            ResourceManager.GetString("RootArgumentViolationsFoundNoInputs", Culture);

        internal static string RootArgumentViolationsFound =>
            ResourceManager.GetString("RootArgumentViolationsFound", Culture);

        internal static string DefaultCancelationRequiresCancelHasBeenRequested =>
            ResourceManager.GetString("DefaultCancelationRequiresCancelHasBeenRequested", Culture);

        internal static string AlreadySetupNoPersist =>
            ResourceManager.GetString("AlreadySetupNoPersist", Culture);

        internal static string HasExecutingChildrenNoPersist =>
            ResourceManager.GetString("HasExecutingChildrenNoPersist", Culture);

        internal static string OutOfInstanceIds =>
            ResourceManager.GetString("OutOfInstanceIds", Culture);

        internal static string DelegateArgumentMustBeSet =>
            ResourceManager.GetString("DelegateArgumentMustBeSet", Culture);

        internal static string VariableMustBeSet =>
            ResourceManager.GetString("VariableMustBeSet", Culture);

        internal static string CannotEnlistMultipleTransactions =>
            ResourceManager.GetString("CannotEnlistMultipleTransactions", Culture);

        internal static string CannotPersistInsideIsolation =>
            ResourceManager.GetString("CannotPersistInsideIsolation", Culture);

        internal static string CannotPersistInsideNoPersist =>
            ResourceManager.GetString("CannotPersistInsideNoPersist", Culture);

        internal static string CannotScheduleChildrenWhileEnteringIsolation =>
            ResourceManager.GetString("CannotScheduleChildrenWhileEnteringIsolation", Culture);

        internal static string CannotSetupIsolationInsideIsolation =>
            ResourceManager.GetString("CannotSetupIsolationInsideIsolation", Culture);

        internal static string CannotSetupIsolationInsideNoPersist =>
            ResourceManager.GetString("CannotSetupIsolationInsideNoPersist", Culture);

        internal static string CannotSetupIsolationWithChildren =>
            ResourceManager.GetString("CannotSetupIsolationWithChildren", Culture);

        internal static string EnlistedTransactionPropertiesRequireIsolationBlocks =>
            ResourceManager.GetString("EnlistedTransactionPropertiesRequireIsolationBlocks", Culture);

        internal static string PrepareForSerializationRequiresPersistability =>
            ResourceManager.GetString("PrepareForSerializationRequiresPersistability", Culture);

        internal static string PauseWhenPersistableInvalidIfPersistable =>
            ResourceManager.GetString("PauseWhenPersistableInvalidIfPersistable", Culture);

        internal static string CannotResetPropertyInDataContext =>
            ResourceManager.GetString("CannotResetPropertyInDataContext", Culture);

        internal static string CompilerError =>
            ResourceManager.GetString("CompilerError", Culture);

        internal static string CannotModifyCatchAfterOpen =>
            ResourceManager.GetString("CannotModifyCatchAfterOpen", Culture);

        internal static string BookmarkNotFoundGeneric =>
            ResourceManager.GetString("BookmarkNotFoundGeneric", Culture);

        internal static string BookmarkScopeAlreadyInitialized =>
            ResourceManager.GetString("BookmarkScopeAlreadyInitialized", Culture);

        internal static string ExclusiveHandleRegisterBookmarkScopeFailed =>
            ResourceManager.GetString("ExclusiveHandleRegisterBookmarkScopeFailed", Culture);

        internal static string ExclusiveHandleReinitializeFailed =>
            ResourceManager.GetString("ExclusiveHandleReinitializeFailed", Culture);

        internal static string CreateBookmarkScopeFailed =>
            ResourceManager.GetString("CreateBookmarkScopeFailed", Culture);

        internal static string CannotUnregisterNullBookmarkScope =>
            ResourceManager.GetString("CannotUnregisterNullBookmarkScope", Culture);

        internal static string RegisteredBookmarkScopeRequired =>
            ResourceManager.GetString("RegisteredBookmarkScopeRequired", Culture);

        internal static string BookmarkScopesRequireKeys =>
            ResourceManager.GetString("BookmarkScopesRequireKeys", Culture);

        internal static string DebugInfoNotSkipArgumentResolution =>
            ResourceManager.GetString("DebugInfoNotSkipArgumentResolution", Culture);

        internal static string DebugInfoTryGetValueFailed =>
            ResourceManager.GetString("DebugInfoTryGetValueFailed", Culture);

        internal static string RuntimeTransactionAlreadyExists =>
            ResourceManager.GetString("RuntimeTransactionAlreadyExists", Culture);

        internal static string RuntimeTransactionIsSuppressed =>
            ResourceManager.GetString("RuntimeTransactionIsSuppressed", Culture);

        internal static string NoRuntimeTransactionExists =>
            ResourceManager.GetString("NoRuntimeTransactionExists", Culture);

        internal static string CannotSuppressAlreadyRegisteredHandle =>
            ResourceManager.GetString("CannotSuppressAlreadyRegisteredHandle", Culture);

        internal static string CannotSetRuntimeTransactionInNoPersist =>
            ResourceManager.GetString("CannotSetRuntimeTransactionInNoPersist", Culture);

        internal static string OnlyOneRequireTransactionContextAllowed =>
            ResourceManager.GetString("OnlyOneRequireTransactionContextAllowed", Culture);

        internal static string ExtensionsCannotBeModified =>
            ResourceManager.GetString("ExtensionsCannotBeModified", Culture);

        internal static string CannotWaitForIdleSynchronously =>
            ResourceManager.GetString("CannotWaitForIdleSynchronously", Culture);

        internal static string BookmarkScopeHasBookmarks =>
            ResourceManager.GetString("BookmarkScopeHasBookmarks", Culture);

        internal static string BookmarkScopeNotRegisteredForInitialize =>
            ResourceManager.GetString("BookmarkScopeNotRegisteredForInitialize", Culture);

        internal static string BookmarkScopeNotRegisteredForUnregister =>
            ResourceManager.GetString("BookmarkScopeNotRegisteredForUnregister", Culture);

        internal static string MarkCanceledOnlyCallableIfCancelRequested =>
            ResourceManager.GetString("MarkCanceledOnlyCallableIfCancelRequested", Culture);

        internal static string OnlyBookmarkOwnerCanRemove =>
            ResourceManager.GetString("OnlyBookmarkOwnerCanRemove", Culture);

        internal static string CanOnlyAbortDirectChildren =>
            ResourceManager.GetString("CanOnlyAbortDirectChildren", Culture);

        internal static string DefaultWorkflowApplicationExceptionMessage =>
            ResourceManager.GetString("DefaultWorkflowApplicationExceptionMessage", Culture);

        internal static string BeginExecuteMustUseProvidedStateAsAsyncResultState =>
            ResourceManager.GetString("BeginExecuteMustUseProvidedStateAsAsyncResultState", Culture);

        internal static string BeginExecuteMustNotReturnANullAsyncResult =>
            ResourceManager.GetString("BeginExecuteMustNotReturnANullAsyncResult", Culture);

        internal static string CompensableActivityAlreadyConfirmedOrCompensated =>
            ResourceManager.GetString("CompensableActivityAlreadyConfirmedOrCompensated", Culture);

        internal static string CannotCallAbortInstanceFromWorkflowThread =>
            ResourceManager.GetString("CannotCallAbortInstanceFromWorkflowThread", Culture);

        internal static string BadCopyToArray =>
            ResourceManager.GetString("BadCopyToArray", Culture);

        internal static string ReadonlyNameScopeCannotBeUpdated =>
            ResourceManager.GetString("ReadonlyNameScopeCannotBeUpdated", Culture);

        internal static string SymbolResolverMustBeSingleton =>
            ResourceManager.GetString("SymbolResolverMustBeSingleton", Culture);

        internal static string SymbolResolverAlreadyExists =>
            ResourceManager.GetString("SymbolResolverAlreadyExists", Culture);

        internal static string CanNotFindSymbolResolverInWorkflowInstanceExtensions =>
            ResourceManager.GetString("CanNotFindSymbolResolverInWorkflowInstanceExtensions", Culture);

        internal static string UnmatchedNoPersistExit =>
            ResourceManager.GetString("UnmatchedNoPersistExit", Culture);

        internal static string HandleNotInitialized =>
            ResourceManager.GetString("HandleNotInitialized", Culture);

        internal static string TransactionHandleAlreadyHasTransaction =>
            ResourceManager.GetString("TransactionHandleAlreadyHasTransaction", Culture);

        internal static string CannotPerformOperationOnHandle =>
            ResourceManager.GetString("CannotPerformOperationOnHandle", Culture);

        internal static string SavingActivityToXamlNotSupported =>
            ResourceManager.GetString("SavingActivityToXamlNotSupported", Culture);

        internal static string NoOverloadGroupsAreConfigured =>
            ResourceManager.GetString("NoOverloadGroupsAreConfigured", Culture);

        internal static string ErrorsEncounteredWhileProcessingTree =>
            ResourceManager.GetString("ErrorsEncounteredWhileProcessingTree", Culture);

        internal static string RuntimeDelegateArgumentTypeIncorrect =>
            ResourceManager.GetString("RuntimeDelegateArgumentTypeIncorrect", Culture);

        internal static string RuntimeDelegateArgumentDirectionIncorrect =>
            ResourceManager.GetString("RuntimeDelegateArgumentDirectionIncorrect", Culture);

        internal static string NoCAInSecondaryRoot =>
            ResourceManager.GetString("NoCAInSecondaryRoot", Culture);

        internal static string CompensateWithNoTargetConstraint =>
            ResourceManager.GetString("CompensateWithNoTargetConstraint", Culture);

        internal static string ConfirmWithNoTargetConstraint =>
            ResourceManager.GetString("ConfirmWithNoTargetConstraint", Culture);

        internal static string UnInitializedRuntimeTransactionHandle =>
            ResourceManager.GetString("UnInitializedRuntimeTransactionHandle", Culture);

        internal static string ArgumentTypeCannotBeNull =>
            ResourceManager.GetString("ArgumentTypeCannotBeNull", Culture);

        internal static string AbortingDueToInstanceTimeout =>
            ResourceManager.GetString("AbortingDueToInstanceTimeout", Culture);

        internal static string InvalidLValueExpression =>
            ResourceManager.GetString("InvalidLValueExpression", Culture);

        internal static string CantFindTimerExtension =>
            ResourceManager.GetString("CantFindTimerExtension", Culture);

        internal static string InstanceMethodCallRequiresTargetObject =>
            ResourceManager.GetString("InstanceMethodCallRequiresTargetObject", Culture);

        internal static string NewArrayBoundsRequiresIntegralArguments =>
            ResourceManager.GetString("NewArrayBoundsRequiresIntegralArguments", Culture);

        internal static string NewArrayRequiresArrayTypeAsResultType =>
            ResourceManager.GetString("NewArrayRequiresArrayTypeAsResultType", Culture);

        internal static string ExpressionRequiredForConversion =>
            ResourceManager.GetString("ExpressionRequiredForConversion", Culture);

        internal static string OverloadingMethodMustBeStatic =>
            ResourceManager.GetString("OverloadingMethodMustBeStatic", Culture);

        internal static string IsolationLevelValidation =>
            ResourceManager.GetString("IsolationLevelValidation", Culture);

        internal static string AbortInstanceOnTransactionFailureDoesNotMatch =>
            ResourceManager.GetString("AbortInstanceOnTransactionFailureDoesNotMatch", Culture);

        internal static string CannotChangeAbortInstanceFlagAfterPropertyRegistration =>
            ResourceManager.GetString("CannotChangeAbortInstanceFlagAfterPropertyRegistration", Culture);

        internal static string CompensableActivityInsideTransactionScopeActivity =>
            ResourceManager.GetString("CompensableActivityInsideTransactionScopeActivity", Culture);

        internal static string WorkflowTerminatedExceptionDefaultMessage =>
            ResourceManager.GetString("WorkflowTerminatedExceptionDefaultMessage", Culture);

        internal static string XamlElementExpected =>
            ResourceManager.GetString("XamlElementExpected", Culture);

        internal static string InvalidRuntimeState =>
            ResourceManager.GetString("InvalidRuntimeState", Culture);

        internal static string InstanceStoreFailed =>
            ResourceManager.GetString("InstanceStoreFailed", Culture);

        internal static string LoadingWorkflowApplicationRequiresInstanceStore =>
            ResourceManager.GetString("LoadingWorkflowApplicationRequiresInstanceStore", Culture);

        internal static string WorkflowApplicationAlreadyHasId =>
            ResourceManager.GetString("WorkflowApplicationAlreadyHasId", Culture);

        internal static string CannotUseInputsWithLoad =>
            ResourceManager.GetString("CannotUseInputsWithLoad", Culture);

        internal static string ArgumentMustbePropertyofWorkflowElement =>
            ResourceManager.GetString("ArgumentMustbePropertyofWorkflowElement", Culture);

        internal static string TimerExtensionAlreadyAttached =>
            ResourceManager.GetString("TimerExtensionAlreadyAttached", Culture);

        internal static string TimerExtensionRequiresWorkflowInstance =>
            ResourceManager.GetString("TimerExtensionRequiresWorkflowInstance", Culture);

        internal static string RuntimeArgumentNotCreated =>
            ResourceManager.GetString("RuntimeArgumentNotCreated", Culture);

        internal static string InvalidEvaluationOrderValue =>
            ResourceManager.GetString("InvalidEvaluationOrderValue", Culture);

        internal static string LambdaNotXamlSerializable =>
            ResourceManager.GetString("LambdaNotXamlSerializable", Culture);

        internal static string InvalidVisualBasicSettingsValue =>
            ResourceManager.GetString("InvalidVisualBasicSettingsValue", Culture);

        internal static string EmptyGuidOnDeserializedInstance =>
            ResourceManager.GetString("EmptyGuidOnDeserializedInstance", Culture);

        internal static string NoRunnableInstances =>
            ResourceManager.GetString("NoRunnableInstances", Culture);

        internal static string AbortingDueToLoadFailure =>
            ResourceManager.GetString("AbortingDueToLoadFailure", Culture);

        internal static string TryLoadRequiresOwner =>
            ResourceManager.GetString("TryLoadRequiresOwner", Culture);

        internal static string GetRunnableRequiresOwner =>
            ResourceManager.GetString("GetRunnableRequiresOwner", Culture);

        internal static string MustMatchReferenceExpressionReturnType =>
            ResourceManager.GetString("MustMatchReferenceExpressionReturnType", Culture);

        internal static string PublicEnvironmentAccessToNonGenericActivity =>
            ResourceManager.GetString("PublicEnvironmentAccessToNonGenericActivity", Culture);

        internal static string SavingFuncToXamlNotSupported =>
            ResourceManager.GetString("SavingFuncToXamlNotSupported", Culture);

        internal static string CSharpExpressionsMustBeCompiled =>
            ResourceManager.GetString("CSharpExpressionsMustBeCompiled", Culture);

        internal static string ActivityNotICompiledExpressionRoot =>
            ResourceManager.GetString("ActivityNotICompiledExpressionRoot", Culture);

        internal static string BadWorkflowIdentityFormat =>
            ResourceManager.GetString("BadWorkflowIdentityFormat", Culture);

        internal static string IdentityNameSemicolon =>
            ResourceManager.GetString("IdentityNameSemicolon", Culture);

        internal static string IdentityControlCharacter =>
            ResourceManager.GetString("IdentityControlCharacter", Culture);

        internal static string IdentityWhitespace =>
            ResourceManager.GetString("IdentityWhitespace", Culture);

        internal static string CompiledExpressionsIgnoringUnnamedVariable =>
            ResourceManager.GetString("CompiledExpressionsIgnoringUnnamedVariable", Culture);

        internal static string PublicChildrenChangeBlockDU =>
            ResourceManager.GetString("PublicChildrenChangeBlockDU", Culture);

        internal static string CannotSaveOriginalValueForActivity =>
            ResourceManager.GetString("CannotSaveOriginalValueForActivity", Culture);

        internal static string DelegateArgumentChangeBlockDU =>
            ResourceManager.GetString("DelegateArgumentChangeBlockDU", Culture);

        internal static string BlockedUpdateInsideActivityUpdateError =>
            ResourceManager.GetString("BlockedUpdateInsideActivityUpdateError", Culture);

        internal static string CannotUpdateEnvironmentInTheMiddleOfResolvingVariables =>
            ResourceManager.GetString("CannotUpdateEnvironmentInTheMiddleOfResolvingVariables", Culture);

        internal static string InstanceStoreDoesntMatchWorkflowApplication =>
            ResourceManager.GetString("InstanceStoreDoesntMatchWorkflowApplication", Culture);

        internal static string WorkflowApplicationInstanceLoaded =>
            ResourceManager.GetString("WorkflowApplicationInstanceLoaded", Culture);

        internal static string WorkflowApplicationInstanceAbandoned =>
            ResourceManager.GetString("WorkflowApplicationInstanceAbandoned", Culture);

        internal static string MustCallPrepareBeforeFinalize =>
            ResourceManager.GetString("MustCallPrepareBeforeFinalize", Culture);

        internal static string ActivityIsUncached =>
            ResourceManager.GetString("ActivityIsUncached", Culture);

        internal static string ActivityIsNotRoot =>
            ResourceManager.GetString("ActivityIsNotRoot", Culture);

        internal static string QueryActivityIsNotInDefinition =>
            ResourceManager.GetString("QueryActivityIsNotInDefinition", Culture);

        internal static string QueryVariableIsNotInDefinition =>
            ResourceManager.GetString("QueryVariableIsNotInDefinition", Culture);

        internal static string QueryVariableIsNotPublic =>
            ResourceManager.GetString("QueryVariableIsNotPublic", Culture);

        internal static string UpdateSymbolsMustMatch =>
            ResourceManager.GetString("UpdateSymbolsMustMatch", Culture);

        internal static string AssemblyReferenceIsImmutable =>
            ResourceManager.GetString("AssemblyReferenceIsImmutable", Culture);

        internal static string TextExpressionCompilerActivityNameRequired =>
            ResourceManager.GetString("TextExpressionCompilerActivityNameRequired", Culture);

        internal static string TextExpressionCompilerActivityNamespaceRequired =>
            ResourceManager.GetString("TextExpressionCompilerActivityNamespaceRequired", Culture);

        internal static string TextExpressionCompilerActivityRequired =>
            ResourceManager.GetString("TextExpressionCompilerActivityRequired", Culture);

        internal static string TextExpressionCompilerAddGeneratedFileRequired =>
            ResourceManager.GetString("TextExpressionCompilerAddGeneratedFileRequired", Culture);

        internal static string TextExpressionCompilerLanguageRequired =>
            ResourceManager.GetString("TextExpressionCompilerLanguageRequired", Culture);

        internal static string TextExpressionCompilerOutputPathRequired =>
            ResourceManager.GetString("TextExpressionCompilerOutputPathRequired", Culture);

        internal static string ITextExpressionParameterMustBeActivity =>
            ResourceManager.GetString("ITextExpressionParameterMustBeActivity", Culture);

        internal static string BlockedUpdateInsideActivityUpdateByUserError =>
            ResourceManager.GetString("BlockedUpdateInsideActivityUpdateByUserError", Culture);

        internal static string CannotUpdateEnvironmentInTheMiddleOfResolvingArguments =>
            ResourceManager.GetString("CannotUpdateEnvironmentInTheMiddleOfResolvingArguments", Culture);

        internal static string InvalidImplementationAsWorkflowRoot =>
            ResourceManager.GetString("InvalidImplementationAsWorkflowRoot", Culture);

        internal static string InvalidOriginalWorkflowDefinitionForImplementationMapCreation =>
            ResourceManager.GetString("InvalidOriginalWorkflowDefinitionForImplementationMapCreation", Culture);

        internal static string InvalidUpdatedWorkflowDefinitionForImplementationMapCreation =>
            ResourceManager.GetString("InvalidUpdatedWorkflowDefinitionForImplementationMapCreation", Culture);

        internal static string NoDynamicArgumentsInActivityDefinitionChange =>
            ResourceManager.GetString("NoDynamicArgumentsInActivityDefinitionChange", Culture);

        internal static string NoDynamicArgumentsInActivityDefinitionChangeRuntime =>
            ResourceManager.GetString("NoDynamicArgumentsInActivityDefinitionChangeRuntime", Culture);

        internal static string InvalidImplementationMapRuntime =>
            ResourceManager.GetString("InvalidImplementationMapRuntime", Culture);

        internal static string InvalidImplementationAsWorkflowRootForRuntimeState =>
            ResourceManager.GetString("InvalidImplementationAsWorkflowRootForRuntimeState", Culture);

        internal static string InvalidImplementationAsWorkflowRootForRuntimeStateBecauseArgumentsChanged =>
            ResourceManager.GetString("InvalidImplementationAsWorkflowRootForRuntimeStateBecauseArgumentsChanged", Culture);

        internal static string PrivateMembersHaveChanged =>
            ResourceManager.GetString("PrivateMembersHaveChanged", Culture);

        internal static string BeforeInitializeComponentXBTExtensionResourceNotFound =>
            ResourceManager.GetString("BeforeInitializeComponentXBTExtensionResourceNotFound", Culture);

        internal static string ActivityXamlServiceLineString =>
            ResourceManager.GetString("ActivityXamlServiceLineString", Culture);

        internal static string NAUCDisposed =>
            ResourceManager.GetString("NAUCDisposed", Culture);

        internal static string WDCDisposed =>
            ResourceManager.GetString("WDCDisposed", Culture);

        internal static string AddedIdleExpressionBlockDU =>
            ResourceManager.GetString("AddedIdleExpressionBlockDU", Culture);

        internal static string AbortingDueToDynamicUpdateFailure =>
            ResourceManager.GetString("AbortingDueToDynamicUpdateFailure", Culture);

        internal static string AbortingDueToVersionMismatch =>
            ResourceManager.GetString("AbortingDueToVersionMismatch", Culture);

        internal static string CompiledLocationReferenceGetLocation =>
            ResourceManager.GetString("CompiledLocationReferenceGetLocation", Culture);

        internal static string InvalidMergeMapArgumentsChanged =>
            ResourceManager.GetString("InvalidMergeMapArgumentsChanged", Culture);

        internal static string MultipleFlowNodesSharingSameChildBlockDU =>
            ResourceManager.GetString("MultipleFlowNodesSharingSameChildBlockDU", Culture);

        internal static string DUActivityTypeMismatchRuntime =>
            ResourceManager.GetString("DUActivityTypeMismatchRuntime", Culture);

        internal static string InstanceStoreHasDefaultOwner =>
            ResourceManager.GetString("InstanceStoreHasDefaultOwner", Culture);

        internal static string CannotCreateOwnerWithoutIdentity =>
            ResourceManager.GetString("CannotCreateOwnerWithoutIdentity", Culture);

        internal static string CannotSaveOriginalValuesForReferencedChildren =>
            ResourceManager.GetString("CannotSaveOriginalValuesForReferencedChildren", Culture);

        internal static string ReferencedChildInIsNewlyAdded =>
            ResourceManager.GetString("ReferencedChildInIsNewlyAdded", Culture);

        internal static string CannotChangeMatchesInImplementation =>
            ResourceManager.GetString("CannotChangeMatchesInImplementation", Culture);

        internal static string GeneratedAndProvidedMapConflict =>
            ResourceManager.GetString("GeneratedAndProvidedMapConflict", Culture);

        internal static string GeneratedAndProvidedMapConflictRuntime =>
            ResourceManager.GetString("GeneratedAndProvidedMapConflictRuntime", Culture);

        internal static string SequenceDuplicateReferences =>
            ResourceManager.GetString("SequenceDuplicateReferences", Culture);

        internal static string FlowchartContainsReferences =>
            ResourceManager.GetString("FlowchartContainsReferences", Culture);

        internal static string CannotMoveChildAcrossDifferentFlowNodeTypes =>
            ResourceManager.GetString("CannotMoveChildAcrossDifferentFlowNodeTypes", Culture);

        internal static string PickBranchTriggerActionSwapped =>
            ResourceManager.GetString("PickBranchTriggerActionSwapped", Culture);

        internal static string NoChangesMapQueryNotSupported =>
            ResourceManager.GetString("NoChangesMapQueryNotSupported", Culture);

        internal static string LambdaExpressionReturnTypeInvalid =>
            ResourceManager.GetString("LambdaExpressionReturnTypeInvalid", Culture);

        internal static string LambdaExpressionTypeRequired =>
            ResourceManager.GetString("LambdaExpressionTypeRequired", Culture);

        internal static string UnsupportedLocationReferenceValue =>
            ResourceManager.GetString("UnsupportedLocationReferenceValue", Culture);

        internal static string VariableOrArgumentAdditionToReferencedEnvironmentNoDUSupported =>
            ResourceManager.GetString("VariableOrArgumentAdditionToReferencedEnvironmentNoDUSupported", Culture);

        internal static string InvalidPrepareForRuntimeValidationSettings =>
            ResourceManager.GetString("InvalidPrepareForRuntimeValidationSettings", Culture);

        internal static string DebugSymbolChecksumValueInvalid =>
            ResourceManager.GetString("DebugSymbolChecksumValueInvalid", Culture);

        internal static string ChangeConditionalTransitionToUnconditionalBlockDU =>
            ResourceManager.GetString("ChangeConditionalTransitionToUnconditionalBlockDU", Culture);

        internal static string ChangeTransitionTypeDuringTransitioningBlockDU =>
            ResourceManager.GetString("ChangeTransitionTypeDuringTransitioningBlockDU", Culture);

        internal static string ChangingTriggerOrUseOriginalConditionActionBlockDU =>
            ResourceManager.GetString("ChangingTriggerOrUseOriginalConditionActionBlockDU", Culture);

        internal static string DUDisallowIfCannotFindingMatchingCondition =>
            ResourceManager.GetString("DUDisallowIfCannotFindingMatchingCondition", Culture);

        internal static string DUTriggerOrConditionChangedDuringTransitioning =>
            ResourceManager.GetString("DUTriggerOrConditionChangedDuringTransitioning", Culture);

        internal static string RemovingTransitionsBlockDU =>
            ResourceManager.GetString("RemovingTransitionsBlockDU", Culture);

        internal static string TriggerOrConditionChangedDuringTransitioning =>
            ResourceManager.GetString("TriggerOrConditionChangedDuringTransitioning", Culture);

        internal static string TriggerOrConditionIsReferenced =>
            ResourceManager.GetString("TriggerOrConditionIsReferenced", Culture);

        internal static string MovingActivitiesInStateBlockDU =>
            ResourceManager.GetString("MovingActivitiesInStateBlockDU", Culture);
    }
}

