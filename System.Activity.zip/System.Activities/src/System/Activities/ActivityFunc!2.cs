﻿namespace System.Activities
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Runtime.CompilerServices;

    public sealed class ActivityFunc<T, TResult> : ActivityDelegate
    {
        protected internal override DelegateOutArgument GetResultArgument() => 
            this.Result;

        internal override IList<RuntimeDelegateArgument> InternalGetRuntimeDelegateArguments() => 
            new List<RuntimeDelegateArgument>(2) { 
                new RuntimeDelegateArgument(ActivityDelegate.ArgumentName, typeof(T), ArgumentDirection.In, this.Argument),
                new RuntimeDelegateArgument(ActivityDelegate.ResultArgumentName, typeof(TResult), ArgumentDirection.Out, this.Result)
            };

        [DefaultValue((string) null)]
        public DelegateInArgument<T> Argument { get; set; }

        [DefaultValue((string) null)]
        public DelegateOutArgument<TResult> Result { get; set; }
    }
}

