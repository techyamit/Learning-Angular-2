﻿namespace System.Activities
{
    using System;
    using System.Activities.Validation;
    using System.Collections;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Runtime.CompilerServices;

    public static class WorkflowInspectionServices
    {
        public static void CacheMetadata(Activity rootActivity)
        {
            CacheMetadata(rootActivity, null);
        }

        public static void CacheMetadata(Activity rootActivity, LocationReferenceEnvironment hostEnvironment)
        {
            if (rootActivity == null)
            {
                throw FxTrace.Exception.ArgumentNull("rootActivity");
            }
            if (rootActivity.HasBeenAssociatedWithAnInstance)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.RootActivityAlreadyAssociatedWithInstance(rootActivity.DisplayName)));
            }
            IList<ValidationError> validationErrors = null;
            if (hostEnvironment == null)
            {
                hostEnvironment = new ActivityLocationReferenceEnvironment();
            }
            ActivityUtilities.CacheRootMetadata(rootActivity, hostEnvironment, ProcessActivityTreeOptions.FullCachingOptions, null, ref validationErrors);
            ActivityValidationServices.ThrowIfViolationsExist(validationErrors, ActivityValidationServices.ExceptionReason.InvalidTree);
        }

        public static bool CanInduceIdle(Activity activity)
        {
            if (activity == null)
            {
                throw FxTrace.Exception.ArgumentNull("activity");
            }
            if (!activity.IsMetadataCached)
            {
                IList<ValidationError> validationErrors = null;
                ActivityUtilities.CacheRootMetadata(activity, new ActivityLocationReferenceEnvironment(), ProcessActivityTreeOptions.FullCachingOptions, null, ref validationErrors);
                ActivityValidationServices.ThrowIfViolationsExist(validationErrors, ActivityValidationServices.ExceptionReason.InvalidTree);
            }
            return activity.InternalCanInduceIdle;
        }

        [IteratorStateMachine(typeof(<GetActivities>d__3))]
        public static IEnumerable<Activity> GetActivities(Activity activity)
        {
            int <i>5__1;
            int num2;
            if (activity == null)
            {
                throw FxTrace.Exception.ArgumentNull("activity");
            }
            if (!activity.IsMetadataCached)
            {
                IList<ValidationError> validationErrors = null;
                ActivityUtilities.CacheRootMetadata(activity, new ActivityLocationReferenceEnvironment(), ProcessActivityTreeOptions.FullCachingOptions, null, ref validationErrors);
                ActivityValidationServices.ThrowIfViolationsExist(validationErrors, ActivityValidationServices.ExceptionReason.InvalidTree);
            }
            for (<i>5__1 = 0; <i>5__1 < activity.RuntimeArguments.Count; <i>5__1 = num2 + 1)
            {
                RuntimeArgument argument = activity.RuntimeArguments[<i>5__1];
                if ((argument.BoundArgument != null) && (argument.BoundArgument.Expression != null))
                {
                    yield return argument.BoundArgument.Expression;
                }
                num2 = <i>5__1;
            }
            for (<i>5__1 = 0; <i>5__1 < activity.RuntimeVariables.Count; <i>5__1 = num2 + 1)
            {
                Variable variable = activity.RuntimeVariables[<i>5__1];
                if (variable.Default != null)
                {
                    yield return variable.Default;
                }
                num2 = <i>5__1;
            }
            for (<i>5__1 = 0; <i>5__1 < activity.ImplementationVariables.Count; <i>5__1 = num2 + 1)
            {
                Variable variable2 = activity.ImplementationVariables[<i>5__1];
                if (variable2.Default != null)
                {
                    yield return variable2.Default;
                }
                num2 = <i>5__1;
            }
            for (<i>5__1 = 0; <i>5__1 < activity.Children.Count; <i>5__1 = num2 + 1)
            {
                yield return activity.Children[<i>5__1];
                num2 = <i>5__1;
            }
            for (<i>5__1 = 0; <i>5__1 < activity.ImportedChildren.Count; <i>5__1 = num2 + 1)
            {
                yield return activity.ImportedChildren[<i>5__1];
                num2 = <i>5__1;
            }
            for (<i>5__1 = 0; <i>5__1 < activity.ImplementationChildren.Count; <i>5__1 = num2 + 1)
            {
                yield return activity.ImplementationChildren[<i>5__1];
                num2 = <i>5__1;
            }
            for (<i>5__1 = 0; <i>5__1 < activity.Delegates.Count; <i>5__1 = num2 + 1)
            {
                ActivityDelegate delegate2 = activity.Delegates[<i>5__1];
                if (delegate2.Handler != null)
                {
                    yield return delegate2.Handler;
                }
                num2 = <i>5__1;
            }
            for (<i>5__1 = 0; <i>5__1 < activity.ImportedDelegates.Count; <i>5__1 = num2 + 1)
            {
                ActivityDelegate delegate3 = activity.ImportedDelegates[<i>5__1];
                if (delegate3.Handler != null)
                {
                    yield return delegate3.Handler;
                }
                num2 = <i>5__1;
            }
            for (<i>5__1 = 0; <i>5__1 < activity.ImplementationDelegates.Count; <i>5__1 = num2 + 1)
            {
                ActivityDelegate delegate4 = activity.ImplementationDelegates[<i>5__1];
                if (delegate4.Handler != null)
                {
                    yield return delegate4.Handler;
                }
                num2 = <i>5__1;
            }
        }

        public static Version GetImplementationVersion(Activity activity)
        {
            if (activity == null)
            {
                throw FxTrace.Exception.ArgumentNull("activity");
            }
            return activity.ImplementationVersion;
        }

        public static Activity Resolve(Activity root, string id)
        {
            if (root == null)
            {
                throw FxTrace.Exception.ArgumentNull("root");
            }
            if (string.IsNullOrEmpty(id))
            {
                throw FxTrace.Exception.ArgumentNullOrEmpty("id");
            }
            if (!root.IsMetadataCached)
            {
                IList<ValidationError> validationErrors = null;
                ActivityUtilities.CacheRootMetadata(root, new ActivityLocationReferenceEnvironment(), ProcessActivityTreeOptions.FullCachingOptions, null, ref validationErrors);
                ActivityValidationServices.ThrowIfViolationsExist(validationErrors, ActivityValidationServices.ExceptionReason.InvalidTree);
            }
            QualifiedId id2 = QualifiedId.Parse(id);
            if (!QualifiedId.TryGetElementFromRoot(root, id2, out Activity activity))
            {
                throw FxTrace.Exception.Argument("id", System.Activities.SR.IdNotFoundInWorkflow(id));
            }
            return activity;
        }

    }
}

