﻿namespace System.Activities
{
    using System;
    using System.Runtime.CompilerServices;

    internal static class WorkflowIdentityFilterExtensions
    {
        public static bool IsValid(this WorkflowIdentityFilter value) => 
            (value >= WorkflowIdentityFilter.Exact) && (value <= WorkflowIdentityFilter.AnyRevision);
    }
}

