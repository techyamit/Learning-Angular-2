﻿namespace System.Activities
{
    using System;
    using System.Activities.XamlIntegration;
    using System.ComponentModel;
    using System.Globalization;
    using System.Runtime.InteropServices;
    using System.Runtime.Serialization;
    using System.Text;
    using System.Text.RegularExpressions;

    [Serializable, DataContract, TypeConverter(typeof(WorkflowIdentityConverter))]
    public class WorkflowIdentity : IEquatable<WorkflowIdentity>
    {
        private static Regex identityString = new Regex("^(?<name>[^;]*)\r\n               (; (\\s* Version \\s* = \\s* (?<version>[^;]*))? )?\r\n               (; (\\s* Package \\s* = \\s* (?<package>.*))? )?\r\n              $", RegexOptions.IgnorePatternWhitespace);
        private const string versionString = "; Version=";
        private const string packageString = "; Package=";
        private string name;
        private System.Version version;
        private string package;

        public WorkflowIdentity()
        {
            this.name = string.Empty;
        }

        public WorkflowIdentity(string name, System.Version version, string package)
        {
            this.name = ValidateName(name, "name");
            this.version = version;
            this.package = ValidatePackage(package, "package");
        }

        public bool Equals(WorkflowIdentity other) => 
            (((other != null) && (this.name == other.name)) && (this.version == other.version)) && (this.package == other.package);

        public override bool Equals(object obj) => 
            this.Equals(obj as WorkflowIdentity);

        public override int GetHashCode()
        {
            int hashCode = this.name.GetHashCode();
            if (this.version != null)
            {
                hashCode ^= this.version.GetHashCode();
            }
            if (this.package != null)
            {
                hashCode ^= this.package.GetHashCode();
            }
            return hashCode;
        }

        private static bool HasControlCharacter(string value)
        {
            for (int i = 0; i < value.Length; i++)
            {
                if (char.IsControl(value, i))
                {
                    return true;
                }
            }
            return false;
        }

        private static bool HasLeadingOrTrailingWhitespace(string value)
        {
            if (value.Length <= 0)
            {
                return false;
            }
            if (!char.IsWhiteSpace(value[0]))
            {
                return char.IsWhiteSpace(value[value.Length - 1]);
            }
            return true;
        }

        private static string Normalize(string value, string paramName, bool throwOnError = true)
        {
            try
            {
                string s = value.Normalize(NormalizationForm.FormC);
                for (int i = s.Length - 1; i >= 0; i--)
                {
                    if (char.GetUnicodeCategory(s, i) == UnicodeCategory.Format)
                    {
                        s = s.Remove(i, 1);
                    }
                }
                return s;
            }
            catch (ArgumentException exception)
            {
                if (throwOnError)
                {
                    throw System.Activities.FxTrace.Exception.AsError(new ArgumentException(exception.Message, paramName, exception));
                }
                return null;
            }
        }

        public static WorkflowIdentity Parse(string identity)
        {
            if (identity == null)
            {
                throw System.Activities.FxTrace.Exception.ArgumentNull("identity");
            }
            return IdentityParser.Parse(identity, true);
        }

        public override string ToString()
        {
            StringBuilder builder = new StringBuilder(this.name);
            if (this.version != null)
            {
                builder.Append("; Version=");
                builder.Append(this.version.ToString());
            }
            if (this.package != null)
            {
                builder.Append("; Package=");
                builder.Append(this.package);
            }
            return builder.ToString();
        }

        public static bool TryParse(string identity, out WorkflowIdentity result)
        {
            if (identity == null)
            {
                result = null;
                return false;
            }
            result = IdentityParser.Parse(identity, false);
            return (result > null);
        }

        private static string ValidateName(string name, string paramName)
        {
            if (name == null)
            {
                throw System.Activities.FxTrace.Exception.ArgumentNull(paramName);
            }
            if (name.Contains(";"))
            {
                throw System.Activities.FxTrace.Exception.Argument(paramName, System.Activities.SR.IdentityNameSemicolon);
            }
            if (HasControlCharacter(name))
            {
                throw System.Activities.FxTrace.Exception.Argument(paramName, System.Activities.SR.IdentityControlCharacter);
            }
            if (HasLeadingOrTrailingWhitespace(name))
            {
                throw System.Activities.FxTrace.Exception.Argument(paramName, System.Activities.SR.IdentityWhitespace);
            }
            return Normalize(name, paramName, true);
        }

        private static string ValidatePackage(string package, string paramName)
        {
            if (package == null)
            {
                return null;
            }
            if (HasControlCharacter(package))
            {
                throw System.Activities.FxTrace.Exception.Argument(paramName, System.Activities.SR.IdentityControlCharacter);
            }
            if (HasLeadingOrTrailingWhitespace(package))
            {
                throw System.Activities.FxTrace.Exception.Argument(paramName, System.Activities.SR.IdentityWhitespace);
            }
            return Normalize(package, paramName, true);
        }

        private static void WrapInSerializationException(Exception exception)
        {
            throw System.Activities.FxTrace.Exception.AsError(new SerializationException(exception.Message, exception));
        }

        public string Name
        {
            get => 
                this.name;
            set => 
                this.name = ValidateName(value, "value");
        }

        public System.Version Version
        {
            get => 
                this.version;
            set => 
                this.version = value;
        }

        public string Package
        {
            get => 
                this.package;
            set => 
                this.package = ValidatePackage(value, "value");
        }

        [DataMember(EmitDefaultValue=false, Name="name")]
        internal string SerializedName
        {
            get => 
                this.name;
            set => 
                this.name = value;
        }

        [DataMember(EmitDefaultValue=false, Name="version")]
        internal string SerializedVersion
        {
            get
            {
                if (this.version != null)
                {
                    return this.version.ToString();
                }
                return null;
            }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    this.version = null;
                }
                else
                {
                    try
                    {
                        this.version = System.Version.Parse(value);
                    }
                    catch (ArgumentException exception)
                    {
                        WrapInSerializationException(exception);
                    }
                    catch (FormatException exception2)
                    {
                        WrapInSerializationException(exception2);
                    }
                    catch (OverflowException exception3)
                    {
                        WrapInSerializationException(exception3);
                    }
                }
            }
        }

        [DataMember(EmitDefaultValue=false, Name="package")]
        internal string SerializedPackage
        {
            get => 
                this.package;
            set => 
                this.package = value;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct IdentityParser
        {
            private const string paramName = "identity";
            private bool throwOnError;
            private Match match;
            private string name;
            private Version version;
            private string package;
            public static WorkflowIdentity Parse(string identity, bool throwOnError)
            {
                if (WorkflowIdentity.HasControlCharacter(identity))
                {
                    if (throwOnError)
                    {
                        throw System.Activities.FxTrace.Exception.Argument("identity", System.Activities.SR.IdentityControlCharacter);
                    }
                    return null;
                }
                WorkflowIdentity.IdentityParser parser = new WorkflowIdentity.IdentityParser {
                    throwOnError = throwOnError,
                    match = WorkflowIdentity.identityString.Match(identity.Trim())
                };
                if (parser.match.Success)
                {
                    return parser.Parse();
                }
                if (throwOnError)
                {
                    throw System.Activities.FxTrace.Exception.Argument("identity", System.Activities.SR.BadWorkflowIdentityFormat);
                }
                return null;
            }

            private WorkflowIdentity Parse()
            {
                if (!this.ExtractName())
                {
                    return null;
                }
                if (!this.ExtractVersion())
                {
                    return null;
                }
                if (!this.ExtractPackage())
                {
                    return null;
                }
                return new WorkflowIdentity { 
                    name = this.name,
                    version = this.version,
                    package = this.package
                };
            }

            private bool ExtractName()
            {
                Group group = this.match.Groups["name"];
                this.name = WorkflowIdentity.Normalize(group.Value.TrimEnd(new char[0]), "identity", this.throwOnError);
                return (this.name > null);
            }

            private bool ExtractVersion()
            {
                Group group = this.match.Groups["version"];
                if (group.Success)
                {
                    string input = group.Value;
                    if (!this.throwOnError)
                    {
                        return Version.TryParse(input, out this.version);
                    }
                    this.version = Version.Parse(input);
                }
                return true;
            }

            private bool ExtractPackage()
            {
                Group group = this.match.Groups["package"];
                if (group.Success)
                {
                    this.package = WorkflowIdentity.Normalize(group.Value, "identity", this.throwOnError);
                    return (this.package > null);
                }
                return true;
            }
        }
    }
}

