﻿namespace System.Activities
{
    using System;
    using System.Activities.DurableInstancing;
    using System.Activities.DynamicUpdate;
    using System.Activities.Hosting;
    using System.Activities.Runtime;
    using System.Activities.Tracking;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Linq;
    using System.Runtime;
    using System.Runtime.CompilerServices;
    using System.Runtime.DurableInstancing;
    using System.Runtime.InteropServices;
    using System.Threading;
    using System.Transactions;
    using System.Xml.Linq;

    public sealed class WorkflowApplication : WorkflowInstance
    {
        private static AsyncCallback eventFrameCallback;
        private static IdleEventHandler idleHandler;
        private static CompletedEventHandler completedHandler;
        private static UnhandledExceptionEventHandler unhandledExceptionHandler;
        private static Action<object, TimeoutException> waitAsyncCompleteCallback;
        private static readonly WorkflowIdentity unknownIdentity = new WorkflowIdentity();
        private Action<WorkflowApplicationAbortedEventArgs> onAborted;
        private Action<WorkflowApplicationEventArgs> onUnloaded;
        private Action<WorkflowApplicationCompletedEventArgs> onCompleted;
        private Func<WorkflowApplicationUnhandledExceptionEventArgs, UnhandledExceptionAction> onUnhandledException;
        private Func<WorkflowApplicationIdleEventArgs, PersistableIdleAction> onPersistableIdle;
        private Action<WorkflowApplicationIdleEventArgs> onIdle;
        private WorkflowEventData eventData;
        private WorkflowInstanceExtensionManager extensions;
        private PersistencePipeline persistencePipelineInUse;
        private System.Runtime.DurableInstancing.InstanceStore instanceStore;
        private PersistenceManager persistenceManager;
        private WorkflowApplicationState state;
        private int handlerThreadId;
        private bool isInHandler;
        private Action invokeCompletedCallback;
        private Guid instanceId;
        private bool instanceIdSet;
        private bool hasCalledAbort;
        private bool hasCalledRun;
        private bool hasRaisedCompleted;
        private Quack<InstanceOperation> pendingOperations;
        private bool isBusy;
        private bool hasExecutionOccurredSinceLastIdle;
        private int pendingUnenqueued;
        private int actionCount;
        private IDictionary<string, object> initialWorkflowArguments;
        private IList<Handle> rootExecutionProperties;
        private IDictionary<XName, InstanceValue> instanceMetadata;

        public WorkflowApplication(Activity workflowDefinition) : this(workflowDefinition, (WorkflowIdentity) null)
        {
        }

        public WorkflowApplication(Activity workflowDefinition, WorkflowIdentity definitionIdentity) : base(workflowDefinition, definitionIdentity)
        {
            this.pendingOperations = new Quack<InstanceOperation>();
        }

        public WorkflowApplication(Activity workflowDefinition, IDictionary<string, object> inputs) : this(workflowDefinition, inputs, (WorkflowIdentity) null)
        {
        }

        public WorkflowApplication(Activity workflowDefinition, IDictionary<string, object> inputs, WorkflowIdentity definitionIdentity) : this(workflowDefinition, definitionIdentity)
        {
            if (inputs == null)
            {
                throw FxTrace.Exception.ArgumentNull("inputs");
            }
            this.initialWorkflowArguments = inputs;
        }

        private WorkflowApplication(Activity workflowDefinition, IDictionary<string, object> inputs, IList<Handle> executionProperties) : this(workflowDefinition)
        {
            this.initialWorkflowArguments = inputs;
            this.rootExecutionProperties = executionProperties;
        }

        public void Abort()
        {
            this.Abort(System.Activities.SR.DefaultAbortReason);
        }

        public void Abort(string reason)
        {
            this.Abort(reason, null);
        }

        private void Abort(string reason, Exception innerException)
        {
            if (this.state != WorkflowApplicationState.Aborted)
            {
                this.AbortInstance(new WorkflowApplicationAbortedException(reason, innerException), false);
            }
        }

        private void AbortDueToException(Exception e)
        {
            if (e is InstanceUpdateException)
            {
                this.Abort(System.Activities.SR.AbortingDueToDynamicUpdateFailure, e);
            }
            else if (e is VersionMismatchException)
            {
                this.Abort(System.Activities.SR.AbortingDueToVersionMismatch, e);
            }
            else
            {
                this.Abort(System.Activities.SR.AbortingDueToLoadFailure);
            }
        }

        private void AbortInstance(Exception reason, bool isWorkflowThread)
        {
            this.state = WorkflowApplicationState.Aborted;
            Thread.MemoryBarrier();
            this.AbortPersistence();
            if (isWorkflowThread)
            {
                if (!this.hasCalledAbort)
                {
                    this.hasCalledAbort = true;
                    base.Controller.Abort(reason);
                    this.ScheduleTrackAndRaiseAborted(reason);
                }
            }
            else
            {
                bool flag = true;
                InstanceOperation operation = null;
                try
                {
                    operation = new InstanceOperation();
                    flag = this.WaitForTurnAsync(operation, true, ActivityDefaults.AcquireLockTimeout, new Action<object, TimeoutException>(this.OnAbortWaitComplete), reason);
                    if (flag && !this.hasCalledAbort)
                    {
                        this.hasCalledAbort = true;
                        base.Controller.Abort(reason);
                        this.ScheduleTrackAndRaiseAborted(reason);
                    }
                }
                finally
                {
                    if (flag)
                    {
                        this.NotifyOperationComplete(operation);
                    }
                }
            }
        }

        private void AbortPersistence()
        {
            if (this.persistenceManager != null)
            {
                this.persistenceManager.Abort();
            }
            PersistencePipeline persistencePipelineInUse = this.persistencePipelineInUse;
            if (persistencePipelineInUse != null)
            {
                persistencePipelineInUse.Abort();
            }
        }

        public void AddInitialInstanceValues(IDictionary<XName, object> writeOnlyValues)
        {
            base.ThrowIfReadOnly();
            if (writeOnlyValues != null)
            {
                if (this.instanceMetadata == null)
                {
                    this.instanceMetadata = new Dictionary<XName, InstanceValue>(writeOnlyValues.Count);
                }
                foreach (KeyValuePair<XName, object> pair in writeOnlyValues)
                {
                    this.instanceMetadata[pair.Key] = new InstanceValue(pair.Value, InstanceValueOptions.WriteOnly | InstanceValueOptions.Optional);
                }
            }
        }

        private void AddToPending(InstanceOperation operation, bool push)
        {
            if (base.IsReadOnly)
            {
                operation.RequiresInitialized = false;
            }
            if (push)
            {
                this.pendingOperations.PushFront(operation);
            }
            else
            {
                this.pendingOperations.Enqueue(operation);
            }
            operation.OnEnqueued();
        }

        private bool AreBookmarksInvalid(out BookmarkResumptionResult result)
        {
            if (this.hasRaisedCompleted)
            {
                result = BookmarkResumptionResult.NotFound;
                return true;
            }
            if ((this.state == WorkflowApplicationState.Unloaded) || (this.state == WorkflowApplicationState.Aborted))
            {
                result = BookmarkResumptionResult.NotReady;
                return true;
            }
            result = BookmarkResumptionResult.Success;
            return false;
        }

        public IAsyncResult BeginCancel(AsyncCallback callback, object state) => 
            this.BeginCancel(ActivityDefaults.AcquireLockTimeout, callback, state);

        public IAsyncResult BeginCancel(TimeSpan timeout, AsyncCallback callback, object state)
        {
            this.ThrowIfHandlerThread();
            System.Runtime.TimeoutHelper.ThrowIfNegativeArgument(timeout);
            return CancelAsyncResult.Create(this, timeout, callback, state);
        }

        public static IAsyncResult BeginCreateDefaultInstanceOwner(System.Runtime.DurableInstancing.InstanceStore instanceStore, WorkflowIdentity definitionIdentity, WorkflowIdentityFilter identityFilter, AsyncCallback callback, object state) => 
            BeginCreateDefaultInstanceOwner(instanceStore, definitionIdentity, identityFilter, ActivityDefaults.OpenTimeout, callback, state);

        public static IAsyncResult BeginCreateDefaultInstanceOwner(System.Runtime.DurableInstancing.InstanceStore instanceStore, WorkflowIdentity definitionIdentity, WorkflowIdentityFilter identityFilter, TimeSpan timeout, AsyncCallback callback, object state)
        {
            if (instanceStore == null)
            {
                throw FxTrace.Exception.ArgumentNull("instanceStore");
            }
            if (instanceStore.DefaultInstanceOwner != null)
            {
                throw FxTrace.Exception.Argument("instanceStore", System.Activities.SR.InstanceStoreHasDefaultOwner);
            }
            return new InstanceCommandWithTemporaryHandleAsyncResult(instanceStore, GetCreateOwnerCommand(definitionIdentity, identityFilter), timeout, callback, state);
        }

        public static IAsyncResult BeginDeleteDefaultInstanceOwner(System.Runtime.DurableInstancing.InstanceStore instanceStore, AsyncCallback callback, object state) => 
            BeginDeleteDefaultInstanceOwner(instanceStore, ActivityDefaults.CloseTimeout, callback, state);

        public static IAsyncResult BeginDeleteDefaultInstanceOwner(System.Runtime.DurableInstancing.InstanceStore instanceStore, TimeSpan timeout, AsyncCallback callback, object state)
        {
            if (instanceStore == null)
            {
                throw FxTrace.Exception.ArgumentNull("instanceStore");
            }
            if (instanceStore.DefaultInstanceOwner == null)
            {
                return new CompletedAsyncResult(callback, state);
            }
            return new InstanceCommandWithTemporaryHandleAsyncResult(instanceStore, new DeleteWorkflowOwnerCommand(), timeout, callback, state);
        }

        internal static IAsyncResult BeginDiscardInstance(PersistenceManagerBase persistanceManager, TimeSpan timeout, AsyncCallback callback, object state)
        {
            PersistenceManager persistenceManager = (PersistenceManager) persistanceManager;
            return new UnlockInstanceAsyncResult(persistenceManager, new System.Runtime.TimeoutHelper(timeout), callback, state);
        }

        public static IAsyncResult BeginGetInstance(Guid instanceId, System.Runtime.DurableInstancing.InstanceStore instanceStore, AsyncCallback callback, object state) => 
            BeginGetInstance(instanceId, instanceStore, ActivityDefaults.LoadTimeout, callback, state);

        public static IAsyncResult BeginGetInstance(Guid instanceId, System.Runtime.DurableInstancing.InstanceStore instanceStore, TimeSpan timeout, AsyncCallback callback, object state)
        {
            if (instanceId == Guid.Empty)
            {
                throw FxTrace.Exception.ArgumentNullOrEmpty("instanceId");
            }
            if (instanceStore == null)
            {
                throw FxTrace.Exception.ArgumentNull("instanceStore");
            }
            System.Runtime.TimeoutHelper.ThrowIfNegativeArgument(timeout);
            return new LoadAsyncResult(null, new PersistenceManager(instanceStore, null, instanceId), false, timeout, callback, state);
        }

        public static IAsyncResult BeginGetRunnableInstance(System.Runtime.DurableInstancing.InstanceStore instanceStore, AsyncCallback callback, object state) => 
            BeginGetRunnableInstance(instanceStore, ActivityDefaults.LoadTimeout, callback, state);

        public static IAsyncResult BeginGetRunnableInstance(System.Runtime.DurableInstancing.InstanceStore instanceStore, TimeSpan timeout, AsyncCallback callback, object state)
        {
            if (instanceStore == null)
            {
                throw FxTrace.Exception.ArgumentNull("instanceStore");
            }
            System.Runtime.TimeoutHelper.ThrowIfNegativeArgument(timeout);
            if (instanceStore.DefaultInstanceOwner == null)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.GetRunnableRequiresOwner));
            }
            return new LoadAsyncResult(null, new PersistenceManager(instanceStore, null), true, timeout, callback, state);
        }

        private IAsyncResult BeginInternalPersist(PersistenceOperation operation, TimeSpan timeout, bool isInternalPersist, AsyncCallback callback, object state) => 
            new UnloadOrPersistAsyncResult(this, timeout, operation, true, isInternalPersist, callback, state);

        private IAsyncResult BeginInternalRun(TimeSpan timeout, bool isUserRun, AsyncCallback callback, object state)
        {
            this.ThrowIfHandlerThread();
            System.Runtime.TimeoutHelper.ThrowIfNegativeArgument(timeout);
            return RunAsyncResult.Create(this, isUserRun, timeout, callback, state);
        }

        internal static IAsyncResult BeginInvoke(Activity activity, IDictionary<string, object> inputs, WorkflowInstanceExtensionManager extensions, TimeSpan timeout, SynchronizationContext syncContext, AsyncInvokeContext invokeContext, AsyncCallback callback, object state) => 
            new InvokeAsyncResult(activity, inputs, extensions, timeout, syncContext, invokeContext, callback, state);

        public IAsyncResult BeginLoad(WorkflowApplicationInstance instance, AsyncCallback callback, object state) => 
            this.BeginLoad(instance, null, ActivityDefaults.LoadTimeout, callback, state);

        public IAsyncResult BeginLoad(Guid instanceId, AsyncCallback callback, object state) => 
            this.BeginLoad(instanceId, ActivityDefaults.LoadTimeout, callback, state);

        public IAsyncResult BeginLoad(WorkflowApplicationInstance instance, DynamicUpdateMap updateMap, AsyncCallback callback, object state) => 
            this.BeginLoad(instance, updateMap, ActivityDefaults.LoadTimeout, callback, state);

        public IAsyncResult BeginLoad(WorkflowApplicationInstance instance, TimeSpan timeout, AsyncCallback callback, object state) => 
            this.BeginLoad(instance, null, timeout, callback, state);

        public IAsyncResult BeginLoad(Guid instanceId, TimeSpan timeout, AsyncCallback callback, object state)
        {
            this.ThrowIfAborted();
            base.ThrowIfReadOnly();
            if (instanceId == Guid.Empty)
            {
                throw FxTrace.Exception.ArgumentNullOrEmpty("instanceId");
            }
            System.Runtime.TimeoutHelper.ThrowIfNegativeArgument(timeout);
            if (this.InstanceStore == null)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.LoadingWorkflowApplicationRequiresInstanceStore));
            }
            if (this.instanceIdSet)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.WorkflowApplicationAlreadyHasId));
            }
            if (this.initialWorkflowArguments != null)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.CannotUseInputsWithLoad));
            }
            return new LoadAsyncResult(this, new PersistenceManager(this.InstanceStore, this.GetInstanceMetadata(), instanceId), false, timeout, callback, state);
        }

        public IAsyncResult BeginLoad(WorkflowApplicationInstance instance, DynamicUpdateMap updateMap, TimeSpan timeout, AsyncCallback callback, object state)
        {
            this.ThrowIfAborted();
            base.ThrowIfReadOnly();
            if (instance == null)
            {
                throw FxTrace.Exception.ArgumentNull("instance");
            }
            System.Runtime.TimeoutHelper.ThrowIfNegativeArgument(timeout);
            if (this.instanceIdSet)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.WorkflowApplicationAlreadyHasId));
            }
            if (this.initialWorkflowArguments != null)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.CannotUseInputsWithLoad));
            }
            if ((this.InstanceStore != null) && (this.InstanceStore != instance.InstanceStore))
            {
                throw FxTrace.Exception.Argument("instance", System.Activities.SR.InstanceStoreDoesntMatchWorkflowApplication);
            }
            instance.MarkAsLoaded();
            PersistenceManager persistenceManager = (PersistenceManager) instance.PersistenceManager;
            persistenceManager.SetInstanceMetadata(this.GetInstanceMetadata());
            return new LoadAsyncResult(this, persistenceManager, instance.Values, updateMap, timeout, callback, state);
        }

        public IAsyncResult BeginLoadRunnableInstance(AsyncCallback callback, object state) => 
            this.BeginLoadRunnableInstance(ActivityDefaults.LoadTimeout, callback, state);

        public IAsyncResult BeginLoadRunnableInstance(TimeSpan timeout, AsyncCallback callback, object state)
        {
            base.ThrowIfReadOnly();
            System.Runtime.TimeoutHelper.ThrowIfNegativeArgument(timeout);
            if (this.InstanceStore == null)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.LoadingWorkflowApplicationRequiresInstanceStore));
            }
            if (this.instanceIdSet)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.WorkflowApplicationAlreadyHasId));
            }
            if (this.initialWorkflowArguments != null)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.CannotUseInputsWithLoad));
            }
            if (this.persistenceManager != null)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.TryLoadRequiresOwner));
            }
            PersistenceManager persistenceManager = new PersistenceManager(this.InstanceStore, this.GetInstanceMetadata());
            if (!persistenceManager.IsInitialized)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.TryLoadRequiresOwner));
            }
            return new LoadAsyncResult(this, persistenceManager, true, timeout, callback, state);
        }

        public IAsyncResult BeginPersist(AsyncCallback callback, object state) => 
            this.BeginPersist(ActivityDefaults.SaveTimeout, callback, state);

        public IAsyncResult BeginPersist(TimeSpan timeout, AsyncCallback callback, object state)
        {
            this.ThrowIfHandlerThread();
            System.Runtime.TimeoutHelper.ThrowIfNegativeArgument(timeout);
            return new UnloadOrPersistAsyncResult(this, timeout, PersistenceOperation.Save, false, false, callback, state);
        }

        public IAsyncResult BeginResumeBookmark(Bookmark bookmark, object value, AsyncCallback callback, object state) => 
            this.BeginResumeBookmark(bookmark, value, ActivityDefaults.ResumeBookmarkTimeout, callback, state);

        public IAsyncResult BeginResumeBookmark(string bookmarkName, object value, AsyncCallback callback, object state)
        {
            if (string.IsNullOrEmpty(bookmarkName))
            {
                throw FxTrace.Exception.ArgumentNullOrEmpty("bookmarkName");
            }
            return this.BeginResumeBookmark(new Bookmark(bookmarkName), value, callback, state);
        }

        public IAsyncResult BeginResumeBookmark(Bookmark bookmark, object value, TimeSpan timeout, AsyncCallback callback, object state)
        {
            System.Runtime.TimeoutHelper.ThrowIfNegativeArgument(timeout);
            this.ThrowIfHandlerThread();
            return new ResumeBookmarkAsyncResult(this, bookmark, value, timeout, callback, state);
        }

        public IAsyncResult BeginResumeBookmark(string bookmarkName, object value, TimeSpan timeout, AsyncCallback callback, object state)
        {
            if (string.IsNullOrEmpty(bookmarkName))
            {
                throw FxTrace.Exception.ArgumentNullOrEmpty("bookmarkName");
            }
            return this.BeginResumeBookmark(new Bookmark(bookmarkName), value, timeout, callback, state);
        }

        public IAsyncResult BeginRun(AsyncCallback callback, object state) => 
            this.BeginRun(ActivityDefaults.AcquireLockTimeout, callback, state);

        public IAsyncResult BeginRun(TimeSpan timeout, AsyncCallback callback, object state) => 
            this.BeginInternalRun(timeout, true, callback, state);

        public IAsyncResult BeginTerminate(Exception reason, AsyncCallback callback, object state) => 
            this.BeginTerminate(reason, ActivityDefaults.AcquireLockTimeout, callback, state);

        public IAsyncResult BeginTerminate(string reason, AsyncCallback callback, object state) => 
            this.BeginTerminate(reason, ActivityDefaults.AcquireLockTimeout, callback, state);

        public IAsyncResult BeginTerminate(Exception reason, TimeSpan timeout, AsyncCallback callback, object state)
        {
            if (reason == null)
            {
                throw FxTrace.Exception.ArgumentNull("reason");
            }
            this.ThrowIfHandlerThread();
            System.Runtime.TimeoutHelper.ThrowIfNegativeArgument(timeout);
            return TerminateAsyncResult.Create(this, reason, timeout, callback, state);
        }

        public IAsyncResult BeginTerminate(string reason, TimeSpan timeout, AsyncCallback callback, object state)
        {
            if (string.IsNullOrEmpty(reason))
            {
                throw FxTrace.Exception.ArgumentNullOrEmpty("reason");
            }
            return this.BeginTerminate(new WorkflowApplicationTerminatedException(reason, this.Id), timeout, callback, state);
        }

        public IAsyncResult BeginUnload(AsyncCallback callback, object state) => 
            this.BeginUnload(ActivityDefaults.SaveTimeout, callback, state);

        public IAsyncResult BeginUnload(TimeSpan timeout, AsyncCallback callback, object state)
        {
            this.ThrowIfHandlerThread();
            System.Runtime.TimeoutHelper.ThrowIfNegativeArgument(timeout);
            return new UnloadOrPersistAsyncResult(this, timeout, PersistenceOperation.Unload, false, false, callback, state);
        }

        public void Cancel()
        {
            this.Cancel(ActivityDefaults.AcquireLockTimeout);
        }

        public void Cancel(TimeSpan timeout)
        {
            this.ThrowIfHandlerThread();
            System.Runtime.TimeoutHelper.ThrowIfNegativeArgument(timeout);
            System.Runtime.TimeoutHelper helper = new System.Runtime.TimeoutHelper(timeout);
            InstanceOperation operation = null;
            try
            {
                operation = new InstanceOperation();
                this.WaitForTurn(operation, helper.RemainingTime());
                this.ValidateStateForCancel();
                this.CancelCore();
                base.Controller.FlushTrackingRecords(helper.RemainingTime());
            }
            finally
            {
                this.NotifyOperationComplete(operation);
            }
        }

        private void CancelCore()
        {
            if (!this.hasRaisedCompleted && (this.state != WorkflowApplicationState.Unloaded))
            {
                base.Controller.ScheduleCancel();
                if (!this.hasCalledRun && !this.hasRaisedCompleted)
                {
                    this.RunCore();
                }
            }
        }

        private static void CompletePersistenceContext(WorkflowPersistenceContext context, TransactionScope scope, bool success)
        {
            TransactionHelper.CompleteTransactionScope(ref scope);
            if (context != null)
            {
                if (success)
                {
                    context.Complete();
                }
                else
                {
                    context.Abort();
                }
            }
        }

        public static void CreateDefaultInstanceOwner(System.Runtime.DurableInstancing.InstanceStore instanceStore, WorkflowIdentity definitionIdentity, WorkflowIdentityFilter identityFilter)
        {
            CreateDefaultInstanceOwner(instanceStore, definitionIdentity, identityFilter, ActivityDefaults.OpenTimeout);
        }

        public static void CreateDefaultInstanceOwner(System.Runtime.DurableInstancing.InstanceStore instanceStore, WorkflowIdentity definitionIdentity, WorkflowIdentityFilter identityFilter, TimeSpan timeout)
        {
            if (instanceStore == null)
            {
                throw FxTrace.Exception.ArgumentNull("instanceStore");
            }
            if (instanceStore.DefaultInstanceOwner != null)
            {
                throw FxTrace.Exception.Argument("instanceStore", System.Activities.SR.InstanceStoreHasDefaultOwner);
            }
            CreateWorkflowOwnerWithIdentityCommand createOwnerCommand = GetCreateOwnerCommand(definitionIdentity, identityFilter);
            InstanceView view = ExecuteInstanceCommandWithTemporaryHandle(instanceStore, createOwnerCommand, timeout);
            instanceStore.DefaultInstanceOwner = view.InstanceOwner;
        }

        private static System.Activities.WorkflowApplication CreateInstance(Activity activity, IDictionary<string, object> inputs, WorkflowInstanceExtensionManager extensions, SynchronizationContext syncContext, Action invokeCompletedCallback)
        {
            Transaction current = Transaction.Current;
            List<Handle> executionProperties = null;
            if (current != null)
            {
                executionProperties = new List<Handle>(1) {
                    new RuntimeTransactionHandle(current)
                };
            }
            System.Activities.WorkflowApplication application = new System.Activities.WorkflowApplication(activity, inputs, executionProperties) {
                SynchronizationContext = syncContext
            };
            bool flag = false;
            try
            {
                application.isBusy = true;
                if (extensions != null)
                {
                    application.extensions = extensions;
                }
                application.invokeCompletedCallback = invokeCompletedCallback;
                flag = true;
            }
            finally
            {
                if (!flag)
                {
                    application.isBusy = false;
                }
            }
            return application;
        }

        private void CreatePersistenceManager()
        {
            PersistenceManager newManager = new PersistenceManager(this.InstanceStore, this.GetInstanceMetadata(), this.instanceId);
            this.SetPersistenceManager(newManager);
        }

        private void DecrementPendingUnenqueud()
        {
            Quack<InstanceOperation> pendingOperations = this.pendingOperations;
            lock (pendingOperations)
            {
                this.pendingUnenqueued--;
            }
        }

        public static void DeleteDefaultInstanceOwner(System.Runtime.DurableInstancing.InstanceStore instanceStore)
        {
            DeleteDefaultInstanceOwner(instanceStore, ActivityDefaults.CloseTimeout);
        }

        public static void DeleteDefaultInstanceOwner(System.Runtime.DurableInstancing.InstanceStore instanceStore, TimeSpan timeout)
        {
            if (instanceStore == null)
            {
                throw FxTrace.Exception.ArgumentNull("instanceStore");
            }
            if (instanceStore.DefaultInstanceOwner != null)
            {
                DeleteWorkflowOwnerCommand command = new DeleteWorkflowOwnerCommand();
                ExecuteInstanceCommandWithTemporaryHandle(instanceStore, command, timeout);
                instanceStore.DefaultInstanceOwner = null;
            }
        }

        internal static void DiscardInstance(PersistenceManagerBase persistanceManager, TimeSpan timeout)
        {
            PersistenceManager persistenceManager = (PersistenceManager) persistanceManager;
            System.Runtime.TimeoutHelper timeoutHelper = new System.Runtime.TimeoutHelper(timeout);
            UnlockInstance(persistenceManager, timeoutHelper);
        }

        public void EndCancel(IAsyncResult result)
        {
            CancelAsyncResult.End(result);
        }

        public static void EndCreateDefaultInstanceOwner(IAsyncResult asyncResult)
        {
            InstanceCommandWithTemporaryHandleAsyncResult.End(asyncResult, out System.Runtime.DurableInstancing.InstanceStore store, out InstanceView view);
            store.DefaultInstanceOwner = view.InstanceOwner;
        }

        public static void EndDeleteDefaultInstanceOwner(IAsyncResult asyncResult)
        {
            if (asyncResult is CompletedAsyncResult)
            {
                CompletedAsyncResult.End(asyncResult);
            }
            else
            {
                InstanceCommandWithTemporaryHandleAsyncResult.End(asyncResult, out System.Runtime.DurableInstancing.InstanceStore store, out _);
                store.DefaultInstanceOwner = null;
            }
        }

        internal static void EndDiscardInstance(IAsyncResult asyncResult)
        {
            UnlockInstanceAsyncResult.End(asyncResult);
        }

        public static WorkflowApplicationInstance EndGetInstance(IAsyncResult asyncResult) => 
            LoadAsyncResult.EndAndCreateInstance(asyncResult);

        public static WorkflowApplicationInstance EndGetRunnableInstance(IAsyncResult asyncResult) => 
            LoadAsyncResult.EndAndCreateInstance(asyncResult);

        private void EndInternalPersist(IAsyncResult result)
        {
            UnloadOrPersistAsyncResult.End(result);
        }

        internal static IDictionary<string, object> EndInvoke(IAsyncResult result) => 
            InvokeAsyncResult.End(result);

        public void EndLoad(IAsyncResult result)
        {
            LoadAsyncResult.End(result);
        }

        public void EndLoadRunnableInstance(IAsyncResult result)
        {
            LoadAsyncResult.End(result);
        }

        public void EndPersist(IAsyncResult result)
        {
            UnloadOrPersistAsyncResult.End(result);
        }

        public BookmarkResumptionResult EndResumeBookmark(IAsyncResult result) => 
            ResumeBookmarkAsyncResult.End(result);

        public void EndRun(IAsyncResult result)
        {
            RunAsyncResult.End(result);
        }

        public void EndTerminate(IAsyncResult result)
        {
            TerminateAsyncResult.End(result);
        }

        public void EndUnload(IAsyncResult result)
        {
            UnloadOrPersistAsyncResult.End(result);
        }

        private void Enqueue(InstanceOperation operation)
        {
            this.Enqueue(operation, false);
        }

        private void Enqueue(InstanceOperation operation, bool push)
        {
            Quack<InstanceOperation> pendingOperations = this.pendingOperations;
            lock (pendingOperations)
            {
                operation.ActionId = this.actionCount;
                if (this.isBusy)
                {
                    if (operation.InterruptsScheduler && base.IsReadOnly)
                    {
                        base.Controller.RequestPause();
                    }
                    this.AddToPending(operation, push);
                }
                else
                {
                    if (operation.RequiresInitialized)
                    {
                        this.EnsureInitialized();
                    }
                    if (!operation.CanRun(this) && !this.IsInTerminalState)
                    {
                        this.AddToPending(operation, push);
                    }
                    else
                    {
                        this.actionCount++;
                        try
                        {
                        }
                        finally
                        {
                            operation.Notified = true;
                            this.isBusy = true;
                        }
                    }
                }
            }
        }

        private void EnsureInitialized()
        {
            if (!base.IsReadOnly)
            {
                base.RegisterExtensionManager(this.extensions);
                base.Initialize(this.initialWorkflowArguments, this.rootExecutionProperties);
                if ((this.persistenceManager == null) && (this.instanceStore != null))
                {
                    this.persistenceManager = new PersistenceManager(this.instanceStore, this.GetInstanceMetadata(), this.Id);
                }
            }
        }

        private static void EventFrame(IAsyncResult result)
        {
            if (!result.CompletedSynchronously)
            {
                WorkflowEventData asyncState = (WorkflowEventData) result.AsyncState;
                System.Activities.WorkflowApplication instance = asyncState.Instance;
                bool flag = true;
                try
                {
                    Exception reason = null;
                    try
                    {
                        flag = asyncState.NextCallback(result, instance, false);
                    }
                    catch (Exception exception2)
                    {
                        if (Fx.IsFatal(exception2))
                        {
                            throw;
                        }
                        reason = exception2;
                    }
                    if (reason != null)
                    {
                        instance.AbortInstance(reason, true);
                    }
                }
                finally
                {
                    if (flag)
                    {
                        instance.OnNotifyPaused();
                    }
                }
            }
        }

        private static InstanceView ExecuteInstanceCommandWithTemporaryHandle(System.Runtime.DurableInstancing.InstanceStore instanceStore, InstancePersistenceCommand command, TimeSpan timeout)
        {
            InstanceHandle handle = null;
            InstanceView view;
            try
            {
                handle = instanceStore.CreateInstanceHandle();
                view = instanceStore.Execute(handle, command, timeout);
            }
            finally
            {
                if (handle != null)
                {
                    handle.Free();
                }
            }
            return view;
        }

        private static ActivityExecutor ExtractRuntimeState(IDictionary<XName, InstanceValue> values, Guid instanceId)
        {
            if (values.TryGetValue(WorkflowNamespace.Workflow, out InstanceValue value2))
            {
                ActivityExecutor executor = value2.Value as ActivityExecutor;
                if (executor != null)
                {
                    return executor;
                }
            }
            throw FxTrace.Exception.AsError(new InstancePersistenceException(System.Activities.SR.WorkflowInstanceNotFoundInStore(instanceId)));
        }

        private InstanceOperation FindOperation()
        {
            if (this.pendingOperations.Count > 0)
            {
                InstanceOperation operation = this.pendingOperations[0];
                if (operation.RequiresInitialized)
                {
                    this.EnsureInitialized();
                }
                if (operation.CanRun(this) || this.IsInTerminalState)
                {
                    this.actionCount++;
                    operation.Notified = true;
                    this.pendingOperations.Dequeue();
                    return operation;
                }
                for (int i = 0; i < this.pendingOperations.Count; i++)
                {
                    operation = this.pendingOperations[i];
                    if (operation.RequiresInitialized)
                    {
                        this.EnsureInitialized();
                    }
                    if (operation.CanRun(this))
                    {
                        this.actionCount++;
                        operation.Notified = true;
                        this.pendingOperations.Remove(i);
                        return operation;
                    }
                }
            }
            return null;
        }

        private void ForceNotifyOperationComplete()
        {
            this.OnNotifyPaused();
        }

        internal static IList<ActivityBlockingUpdate> GetActivitiesBlockingUpdate(WorkflowApplicationInstance instance, DynamicUpdateMap updateMap) => 
            GetActivitiesBlockingUpdate(ExtractRuntimeState(instance.Values, instance.InstanceId), updateMap);

        public ReadOnlyCollection<BookmarkInfo> GetBookmarks() => 
            this.GetBookmarks(ActivityDefaults.ResumeBookmarkTimeout);

        public ReadOnlyCollection<BookmarkInfo> GetBookmarks(TimeSpan timeout)
        {
            ReadOnlyCollection<BookmarkInfo> bookmarks;
            this.ThrowIfHandlerThread();
            System.Runtime.TimeoutHelper.ThrowIfNegativeArgument(timeout);
            InstanceOperation operation = new InstanceOperation();
            try
            {
                this.WaitForTurn(operation, timeout);
                this.ValidateStateForGetAllBookmarks();
                bookmarks = base.Controller.GetBookmarks();
            }
            finally
            {
                this.NotifyOperationComplete(operation);
            }
            return bookmarks;
        }

        internal ReadOnlyCollection<BookmarkInfo> GetBookmarksForIdle() => 
            base.Controller.GetBookmarks();

        internal void GetCompletionStatus(out Exception terminationException, out bool cancelled)
        {
            ActivityInstanceState completionState = base.Controller.GetCompletionState(out _, out terminationException);
            cancelled = completionState == ActivityInstanceState.Canceled;
        }

        private static CreateWorkflowOwnerWithIdentityCommand GetCreateOwnerCommand(WorkflowIdentity definitionIdentity, WorkflowIdentityFilter identityFilter)
        {
            if (!identityFilter.IsValid())
            {
                throw FxTrace.Exception.AsError(new ArgumentOutOfRangeException("identityFilter"));
            }
            if ((definitionIdentity == null) && (identityFilter != WorkflowIdentityFilter.Any))
            {
                throw FxTrace.Exception.Argument("definitionIdentity", System.Activities.SR.CannotCreateOwnerWithoutIdentity);
            }
            CreateWorkflowOwnerWithIdentityCommand command1 = new CreateWorkflowOwnerWithIdentityCommand {
                InstanceOwnerMetadata = { { 
                    WorkflowNamespace.WorkflowHostType,
                    new InstanceValue(Workflow45Namespace.WorkflowApplication)
                } }
            };
            Collection<WorkflowIdentity> collection1 = new Collection<WorkflowIdentity> {
                definitionIdentity
            };
            command1.InstanceOwnerMetadata.Add(Workflow45Namespace.DefinitionIdentities, new InstanceValue(collection1));
            command1.InstanceOwnerMetadata.Add(Workflow45Namespace.DefinitionIdentityFilter, new InstanceValue(identityFilter));
            return command1;
        }

        public static WorkflowApplicationInstance GetInstance(Guid instanceId, System.Runtime.DurableInstancing.InstanceStore instanceStore) => 
            GetInstance(instanceId, instanceStore, ActivityDefaults.LoadTimeout);

        public static WorkflowApplicationInstance GetInstance(Guid instanceId, System.Runtime.DurableInstancing.InstanceStore instanceStore, TimeSpan timeout)
        {
            if (instanceId == Guid.Empty)
            {
                throw FxTrace.Exception.ArgumentNullOrEmpty("instanceId");
            }
            if (instanceStore == null)
            {
                throw FxTrace.Exception.ArgumentNull("instanceStore");
            }
            System.Runtime.TimeoutHelper.ThrowIfNegativeArgument(timeout);
            PersistenceManager persistenceManager = new PersistenceManager(instanceStore, null, instanceId);
            return LoadCore(timeout, false, persistenceManager);
        }

        private IDictionary<XName, InstanceValue> GetInstanceMetadata()
        {
            if (base.DefinitionIdentity != null)
            {
                if (this.instanceMetadata == null)
                {
                    this.instanceMetadata = new Dictionary<XName, InstanceValue>(2);
                }
                if (!this.instanceMetadata.ContainsKey(WorkflowNamespace.WorkflowHostType))
                {
                    this.instanceMetadata.Add(WorkflowNamespace.WorkflowHostType, new InstanceValue(Workflow45Namespace.WorkflowApplication));
                }
                this.instanceMetadata[Workflow45Namespace.DefinitionIdentity] = new InstanceValue(base.DefinitionIdentity, InstanceValueOptions.Optional);
            }
            return this.instanceMetadata;
        }

        public static WorkflowApplicationInstance GetRunnableInstance(System.Runtime.DurableInstancing.InstanceStore instanceStore) => 
            GetRunnableInstance(instanceStore, ActivityDefaults.LoadTimeout);

        public static WorkflowApplicationInstance GetRunnableInstance(System.Runtime.DurableInstancing.InstanceStore instanceStore, TimeSpan timeout)
        {
            if (instanceStore == null)
            {
                throw FxTrace.Exception.ArgumentNull("instanceStore");
            }
            System.Runtime.TimeoutHelper.ThrowIfNegativeArgument(timeout);
            if (instanceStore.DefaultInstanceOwner == null)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.GetRunnableRequiresOwner));
            }
            PersistenceManager persistenceManager = new PersistenceManager(instanceStore, null);
            return LoadCore(timeout, true, persistenceManager);
        }

        private void IncrementPendingUnenqueud()
        {
            Quack<InstanceOperation> pendingOperations = this.pendingOperations;
            lock (pendingOperations)
            {
                this.pendingUnenqueued++;
            }
        }

        private static void InitializePersistenceContext(bool isTransactionRequired, System.Runtime.TimeoutHelper timeoutHelper, out WorkflowPersistenceContext context, out TransactionScope scope)
        {
            context = new WorkflowPersistenceContext(isTransactionRequired, timeoutHelper.OriginalTimeout);
            scope = TransactionHelper.CreateTransactionScope(context.PublicTransaction);
        }

        internal IEnumerable<T> InternalGetExtensions<T>() where T: class => 
            base.GetExtensions<T>();

        private void InternalRun(TimeSpan timeout, bool isUserRun)
        {
            this.ThrowIfHandlerThread();
            System.Runtime.TimeoutHelper.ThrowIfNegativeArgument(timeout);
            System.Runtime.TimeoutHelper helper = new System.Runtime.TimeoutHelper(timeout);
            InstanceOperation operation = null;
            try
            {
                operation = new InstanceOperation();
                this.WaitForTurn(operation, helper.RemainingTime());
                this.ValidateStateForRun();
                if (isUserRun)
                {
                    this.hasExecutionOccurredSinceLastIdle = true;
                }
                this.RunCore();
                base.Controller.FlushTrackingRecords(helper.RemainingTime());
            }
            finally
            {
                this.NotifyOperationComplete(operation);
            }
        }

        internal static IDictionary<string, object> Invoke(Activity activity, IDictionary<string, object> inputs, WorkflowInstanceExtensionManager extensions, TimeSpan timeout)
        {
            PumpBasedSynchronizationContext syncContext = new PumpBasedSynchronizationContext(timeout);
            System.Activities.WorkflowApplication instance = CreateInstance(activity, inputs, extensions, syncContext, new Action(syncContext.OnInvokeCompleted));
            try
            {
                RunInstance(instance);
                syncContext.DoPump();
            }
            catch (TimeoutException)
            {
                instance.Abort(System.Activities.SR.AbortingDueToInstanceTimeout);
                throw;
            }
            Exception terminationException = null;
            IDictionary<string, object> outputs = null;
            if (instance.Controller.State == WorkflowInstanceState.Aborted)
            {
                terminationException = new WorkflowApplicationAbortedException(System.Activities.SR.DefaultAbortReason, instance.Controller.GetAbortReason());
            }
            else
            {
                instance.Controller.GetCompletionState(out outputs, out terminationException);
            }
            if (terminationException != null)
            {
                throw FxTrace.Exception.AsError(terminationException);
            }
            return outputs;
        }

        private bool IsLoadTransactionRequired() => 
            base.GetExtensions<IPersistencePipelineModule>().Any<IPersistencePipelineModule>(module => module.IsLoadTransactionRequired);

        public void Load(WorkflowApplicationInstance instance)
        {
            this.Load(instance, ActivityDefaults.LoadTimeout);
        }

        public void Load(Guid instanceId)
        {
            this.Load(instanceId, ActivityDefaults.LoadTimeout);
        }

        public void Load(WorkflowApplicationInstance instance, DynamicUpdateMap updateMap)
        {
            this.Load(instance, updateMap, ActivityDefaults.LoadTimeout);
        }

        public void Load(WorkflowApplicationInstance instance, TimeSpan timeout)
        {
            this.Load(instance, null, timeout);
        }

        public void Load(Guid instanceId, TimeSpan timeout)
        {
            this.ThrowIfAborted();
            base.ThrowIfReadOnly();
            if (instanceId == Guid.Empty)
            {
                throw FxTrace.Exception.ArgumentNullOrEmpty("instanceId");
            }
            System.Runtime.TimeoutHelper.ThrowIfNegativeArgument(timeout);
            if (this.InstanceStore == null)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.LoadingWorkflowApplicationRequiresInstanceStore));
            }
            if (this.instanceIdSet)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.WorkflowApplicationAlreadyHasId));
            }
            if (this.initialWorkflowArguments != null)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.CannotUseInputsWithLoad));
            }
            InstanceOperation operation = new InstanceOperation {
                RequiresInitialized = false
            };
            try
            {
                System.Runtime.TimeoutHelper timeoutHelper = new System.Runtime.TimeoutHelper(timeout);
                this.WaitForTurn(operation, timeoutHelper.RemainingTime());
                this.ValidateStateForLoad();
                this.instanceId = instanceId;
                this.instanceIdSet = true;
                this.CreatePersistenceManager();
                this.LoadCore(null, timeoutHelper, false, null);
            }
            finally
            {
                this.NotifyOperationComplete(operation);
            }
        }

        public void Load(WorkflowApplicationInstance instance, DynamicUpdateMap updateMap, TimeSpan timeout)
        {
            this.ThrowIfAborted();
            base.ThrowIfReadOnly();
            if (instance == null)
            {
                throw FxTrace.Exception.ArgumentNull("instance");
            }
            System.Runtime.TimeoutHelper.ThrowIfNegativeArgument(timeout);
            if (this.instanceIdSet)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.WorkflowApplicationAlreadyHasId));
            }
            if (this.initialWorkflowArguments != null)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.CannotUseInputsWithLoad));
            }
            if ((this.InstanceStore != null) && (this.InstanceStore != instance.InstanceStore))
            {
                throw FxTrace.Exception.Argument("instance", System.Activities.SR.InstanceStoreDoesntMatchWorkflowApplication);
            }
            instance.MarkAsLoaded();
            InstanceOperation operation = new InstanceOperation {
                RequiresInitialized = false
            };
            try
            {
                System.Runtime.TimeoutHelper timeoutHelper = new System.Runtime.TimeoutHelper(timeout);
                this.WaitForTurn(operation, timeoutHelper.RemainingTime());
                this.ValidateStateForLoad();
                this.instanceId = instance.InstanceId;
                this.instanceIdSet = true;
                if (this.instanceStore == null)
                {
                    this.instanceStore = instance.InstanceStore;
                }
                PersistenceManager persistenceManager = (PersistenceManager) instance.PersistenceManager;
                persistenceManager.SetInstanceMetadata(this.GetInstanceMetadata());
                this.SetPersistenceManager(persistenceManager);
                this.LoadCore(updateMap, timeoutHelper, false, instance.Values);
            }
            finally
            {
                this.NotifyOperationComplete(operation);
            }
        }

        private static WorkflowApplicationInstance LoadCore(TimeSpan timeout, bool loadAny, PersistenceManager persistenceManager)
        {
            System.Runtime.TimeoutHelper timeoutHelper = new System.Runtime.TimeoutHelper(timeout);
            if (!persistenceManager.IsInitialized)
            {
                persistenceManager.Initialize(unknownIdentity, timeoutHelper.RemainingTime());
            }
            WorkflowPersistenceContext context = null;
            TransactionScope scope = null;
            WorkflowApplicationInstance instance = null;
            try
            {
                InitializePersistenceContext(false, timeoutHelper, out context, out scope);
                IDictionary<XName, InstanceValue> values = LoadValues(persistenceManager, timeoutHelper, loadAny);
                ActivityExecutor executor = ExtractRuntimeState(values, persistenceManager.InstanceId);
                instance = new WorkflowApplicationInstance(persistenceManager, values, executor.WorkflowIdentity);
            }
            finally
            {
                bool success = instance > null;
                CompletePersistenceContext(context, scope, success);
                if (!success)
                {
                    persistenceManager.Abort();
                }
            }
            return instance;
        }

        private void LoadCore(DynamicUpdateMap updateMap, System.Runtime.TimeoutHelper timeoutHelper, bool loadAny, IDictionary<XName, InstanceValue> values = null)
        {
            if ((values == null) && !this.persistenceManager.IsInitialized)
            {
                this.persistenceManager.Initialize(base.DefinitionIdentity, timeoutHelper.RemainingTime());
            }
            PersistencePipeline pipeline = null;
            WorkflowPersistenceContext context = null;
            TransactionScope scope = null;
            bool success = false;
            Exception e = null;
            try
            {
                InitializePersistenceContext(this.IsLoadTransactionRequired(), timeoutHelper, out context, out scope);
                if (values == null)
                {
                    values = LoadValues(this.persistenceManager, timeoutHelper, loadAny);
                    if (loadAny)
                    {
                        if (this.instanceIdSet)
                        {
                            throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.WorkflowApplicationAlreadyHasId));
                        }
                        this.instanceId = this.persistenceManager.InstanceId;
                        this.instanceIdSet = true;
                    }
                }
                pipeline = this.ProcessInstanceValues(values, out object obj2);
                if (pipeline != null)
                {
                    try
                    {
                        this.persistencePipelineInUse = pipeline;
                        Thread.MemoryBarrier();
                        if (this.state == WorkflowApplicationState.Aborted)
                        {
                            throw FxTrace.Exception.AsError(new OperationCanceledException(System.Activities.SR.DefaultAbortReason));
                        }
                        pipeline.EndLoad(pipeline.BeginLoad(timeoutHelper.RemainingTime(), null, null));
                    }
                    finally
                    {
                        this.persistencePipelineInUse = null;
                    }
                }
                try
                {
                    base.Initialize(obj2, updateMap);
                    if (updateMap != null)
                    {
                        this.UpdateInstanceMetadata();
                    }
                }
                catch (InstanceUpdateException exception2)
                {
                    e = exception2;
                    throw;
                }
                catch (VersionMismatchException exception3)
                {
                    e = exception3;
                    throw;
                }
                success = true;
            }
            finally
            {
                CompletePersistenceContext(context, scope, success);
                if (!success)
                {
                    this.AbortDueToException(e);
                }
            }
            if (pipeline != null)
            {
                pipeline.Publish();
            }
        }

        public void LoadRunnableInstance()
        {
            this.LoadRunnableInstance(ActivityDefaults.LoadTimeout);
        }

        public void LoadRunnableInstance(TimeSpan timeout)
        {
            base.ThrowIfReadOnly();
            System.Runtime.TimeoutHelper.ThrowIfNegativeArgument(timeout);
            if (this.InstanceStore == null)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.LoadingWorkflowApplicationRequiresInstanceStore));
            }
            if (this.instanceIdSet)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.WorkflowApplicationAlreadyHasId));
            }
            if (this.initialWorkflowArguments != null)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.CannotUseInputsWithLoad));
            }
            if (this.persistenceManager != null)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.TryLoadRequiresOwner));
            }
            InstanceOperation operation = new InstanceOperation {
                RequiresInitialized = false
            };
            try
            {
                System.Runtime.TimeoutHelper timeoutHelper = new System.Runtime.TimeoutHelper(timeout);
                this.WaitForTurn(operation, timeoutHelper.RemainingTime());
                this.ValidateStateForLoad();
                base.RegisterExtensionManager(this.extensions);
                this.persistenceManager = new PersistenceManager(this.InstanceStore, this.GetInstanceMetadata());
                if (!this.persistenceManager.IsInitialized)
                {
                    throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.TryLoadRequiresOwner));
                }
                this.LoadCore(null, timeoutHelper, true, null);
            }
            finally
            {
                this.NotifyOperationComplete(operation);
            }
        }

        private static IDictionary<XName, InstanceValue> LoadValues(PersistenceManager persistenceManager, System.Runtime.TimeoutHelper timeoutHelper, bool loadAny)
        {
            if (loadAny)
            {
                if (!persistenceManager.TryLoad(timeoutHelper.RemainingTime(), out IDictionary<XName, InstanceValue> dictionary))
                {
                    throw FxTrace.Exception.AsError(new InstanceNotReadyException(System.Activities.SR.NoRunnableInstances));
                }
                return dictionary;
            }
            return persistenceManager.Load(timeoutHelper.RemainingTime());
        }

        private void MarkUnloaded()
        {
            this.state = WorkflowApplicationState.Unloaded;
            if (base.Controller.State != WorkflowInstanceState.Complete)
            {
                base.Controller.Abort();
            }
            else
            {
                base.DisposeExtensions();
            }
            Exception reason = null;
            try
            {
                Action<WorkflowApplicationEventArgs> unloaded = this.Unloaded;
                if (unloaded != null)
                {
                    this.handlerThreadId = Thread.CurrentThread.ManagedThreadId;
                    this.isInHandler = true;
                    unloaded(new WorkflowApplicationEventArgs(this));
                }
            }
            catch (Exception exception2)
            {
                if (Fx.IsFatal(exception2))
                {
                    throw;
                }
                reason = exception2;
            }
            finally
            {
                this.isInHandler = false;
            }
            if (reason != null)
            {
                this.AbortInstance(reason, true);
            }
        }

        private void NotifyOperationComplete(InstanceOperation operation)
        {
            if ((operation != null) && operation.Notified)
            {
                this.OnNotifyPaused();
            }
        }

        private void OnAbortTrackingComplete(IAsyncResult result)
        {
            if (!result.CompletedSynchronously)
            {
                Exception asyncState = (Exception) result.AsyncState;
                try
                {
                    base.Controller.EndFlushTrackingRecords(result);
                }
                catch (Exception exception2)
                {
                    if (Fx.IsFatal(exception2))
                    {
                        throw;
                    }
                }
                this.RaiseAborted(asyncState);
            }
        }

        private void OnAbortWaitComplete(object state, TimeoutException exception)
        {
            if (exception == null)
            {
                bool flag = false;
                Exception reason = (Exception) state;
                try
                {
                    if (!this.hasCalledAbort)
                    {
                        flag = true;
                        this.hasCalledAbort = true;
                        base.Controller.Abort(reason);
                    }
                }
                finally
                {
                    this.ForceNotifyOperationComplete();
                }
                if (flag)
                {
                    this.TrackAndRaiseAborted(reason);
                }
            }
        }

        protected internal override IAsyncResult OnBeginAssociateKeys(ICollection<InstanceKey> keys, AsyncCallback callback, object state)
        {
            throw Fx.AssertAndThrow("WorkflowApplication is sealed with CanUseKeys as false, so WorkflowInstance should not call OnBeginAssociateKeys.");
        }

        protected internal override IAsyncResult OnBeginPersist(AsyncCallback callback, object state) => 
            this.BeginInternalPersist(PersistenceOperation.Save, ActivityDefaults.InternalSaveTimeout, true, callback, state);

        protected internal override IAsyncResult OnBeginResumeBookmark(Bookmark bookmark, object value, TimeSpan timeout, AsyncCallback callback, object state)
        {
            this.ThrowIfHandlerThread();
            return new ResumeBookmarkAsyncResult(this, bookmark, value, true, timeout, callback, state);
        }

        protected internal override void OnDisassociateKeys(ICollection<InstanceKey> keys)
        {
            throw Fx.AssertAndThrow("WorkflowApplication is sealed with CanUseKeys as false, so WorkflowInstance should not call OnDisassociateKeys.");
        }

        protected internal override void OnEndAssociateKeys(IAsyncResult result)
        {
            throw Fx.AssertAndThrow("WorkflowApplication is sealed with CanUseKeys as false, so WorkflowInstance should not call OnEndAssociateKeys.");
        }

        protected internal override void OnEndPersist(IAsyncResult result)
        {
            this.EndInternalPersist(result);
        }

        protected internal override BookmarkResumptionResult OnEndResumeBookmark(IAsyncResult result) => 
            ResumeBookmarkAsyncResult.End(result);

        protected override void OnNotifyPaused()
        {
            WorkflowInstanceState? nullable = null;
            if (base.IsReadOnly)
            {
                nullable = new WorkflowInstanceState?(base.Controller.State);
            }
            WorkflowApplicationState state = this.state;
            bool flag = true;
            while (flag)
            {
                if (nullable.HasValue && this.ShouldRaiseComplete(nullable.Value))
                {
                    Exception reason = null;
                    try
                    {
                        this.hasRaisedCompleted = true;
                        if (completedHandler == null)
                        {
                            completedHandler = new CompletedEventHandler();
                        }
                        flag = completedHandler.Run(this);
                    }
                    catch (Exception exception2)
                    {
                        if (Fx.IsFatal(exception2))
                        {
                            throw;
                        }
                        reason = exception2;
                    }
                    if (reason != null)
                    {
                        this.AbortInstance(reason, true);
                    }
                }
                else
                {
                    bool flag2;
                    bool flag3;
                    InstanceOperation operation = null;
                    Quack<InstanceOperation> pendingOperations = this.pendingOperations;
                    lock (pendingOperations)
                    {
                        WorkflowInstanceState? nullable2;
                        WorkflowInstanceState runnable;
                        operation = this.FindOperation();
                        if (nullable.HasValue)
                        {
                            nullable2 = nullable;
                            runnable = WorkflowInstanceState.Runnable;
                        }
                        flag2 = ((((WorkflowInstanceState) nullable2.GetValueOrDefault()) == runnable) ? nullable2.HasValue : false) && (state == WorkflowApplicationState.Runnable);
                        if (this.hasExecutionOccurredSinceLastIdle && nullable.HasValue)
                        {
                            nullable2 = nullable;
                            runnable = WorkflowInstanceState.Idle;
                        }
                        flag3 = (((((WorkflowInstanceState) nullable2.GetValueOrDefault()) == runnable) ? nullable2.HasValue : false) && !this.hasRaisedCompleted) && (this.pendingUnenqueued == 0);
                        if (((operation == null) && !flag2) && !flag3)
                        {
                            this.isBusy = false;
                            flag = false;
                        }
                    }
                    if (operation != null)
                    {
                        operation.NotifyTurn();
                        flag = false;
                        continue;
                    }
                    if (flag3)
                    {
                        this.hasExecutionOccurredSinceLastIdle = false;
                        Exception reason = null;
                        try
                        {
                            if (idleHandler == null)
                            {
                                idleHandler = new IdleEventHandler();
                            }
                            flag = idleHandler.Run(this);
                        }
                        catch (Exception exception4)
                        {
                            if (Fx.IsFatal(exception4))
                            {
                                throw;
                            }
                            reason = exception4;
                        }
                        if (reason != null)
                        {
                            this.AbortInstance(reason, true);
                        }
                        continue;
                    }
                    if (flag2)
                    {
                        this.hasExecutionOccurredSinceLastIdle = true;
                        this.actionCount++;
                        base.Controller.Run();
                        flag = false;
                    }
                }
            }
        }

        protected override void OnNotifyUnhandledException(Exception exception, Activity exceptionSource, string exceptionSourceInstanceId)
        {
            bool flag = true;
            try
            {
                Exception reason = null;
                try
                {
                    if (unhandledExceptionHandler == null)
                    {
                        unhandledExceptionHandler = new UnhandledExceptionEventHandler();
                    }
                    flag = unhandledExceptionHandler.Run(this, exception, exceptionSource, exceptionSourceInstanceId);
                }
                catch (Exception exception3)
                {
                    if (Fx.IsFatal(exception3))
                    {
                        throw;
                    }
                    reason = exception3;
                }
                if (reason != null)
                {
                    this.AbortInstance(reason, true);
                }
            }
            finally
            {
                if (flag)
                {
                    this.OnNotifyPaused();
                }
            }
        }

        protected internal override void OnRequestAbort(Exception reason)
        {
            this.AbortInstance(reason, false);
        }

        private static void OnWaitAsyncComplete(object state, TimeoutException exception)
        {
            WaitForTurnData data = (WaitForTurnData) state;
            if (!data.Instance.Remove(data.Operation))
            {
                exception = null;
            }
            data.Callback(data.State, exception);
        }

        public void Persist()
        {
            this.Persist(ActivityDefaults.SaveTimeout);
        }

        public void Persist(TimeSpan timeout)
        {
            this.ThrowIfHandlerThread();
            System.Runtime.TimeoutHelper.ThrowIfNegativeArgument(timeout);
            System.Runtime.TimeoutHelper timeoutHelper = new System.Runtime.TimeoutHelper(timeout);
            RequiresPersistenceOperation operation = new RequiresPersistenceOperation();
            try
            {
                this.WaitForTurn(operation, timeoutHelper.RemainingTime());
                this.ValidateStateForPersist();
                this.PersistCore(ref timeoutHelper, PersistenceOperation.Save);
            }
            finally
            {
                this.NotifyOperationComplete(operation);
            }
        }

        private void PersistCore(ref System.Runtime.TimeoutHelper timeoutHelper, PersistenceOperation operation)
        {
            if (this.HasPersistenceProvider)
            {
                if (!this.persistenceManager.IsInitialized)
                {
                    this.persistenceManager.Initialize(base.DefinitionIdentity, timeoutHelper.RemainingTime());
                }
                if (!this.persistenceManager.IsLocked && (Transaction.Current != null))
                {
                    this.persistenceManager.EnsureReadyness(timeoutHelper.RemainingTime());
                }
                this.TrackPersistence(operation);
                base.Controller.FlushTrackingRecords(timeoutHelper.RemainingTime());
            }
            bool success = false;
            WorkflowPersistenceContext context = null;
            TransactionScope scope = null;
            try
            {
                IDictionary<XName, InstanceValue> instance = null;
                PersistencePipeline pipeline = null;
                if (base.HasPersistenceModule)
                {
                    pipeline = new PersistencePipeline(base.GetExtensions<IPersistencePipelineModule>(), PersistenceManager.GenerateInitialData(this));
                    pipeline.Collect();
                    pipeline.Map();
                    instance = pipeline.Values;
                }
                if (this.HasPersistenceProvider)
                {
                    if (instance == null)
                    {
                        instance = PersistenceManager.GenerateInitialData(this);
                    }
                    if (context == null)
                    {
                        InitializePersistenceContext((pipeline != null) && pipeline.IsSaveTransactionRequired, timeoutHelper, out context, out scope);
                    }
                    this.persistenceManager.Save(instance, operation, timeoutHelper.RemainingTime());
                }
                if (pipeline != null)
                {
                    if (context == null)
                    {
                        InitializePersistenceContext(pipeline.IsSaveTransactionRequired, timeoutHelper, out context, out scope);
                    }
                    try
                    {
                        this.persistencePipelineInUse = pipeline;
                        Thread.MemoryBarrier();
                        if (this.state == WorkflowApplicationState.Aborted)
                        {
                            throw FxTrace.Exception.AsError(new OperationCanceledException(System.Activities.SR.DefaultAbortReason));
                        }
                        pipeline.EndSave(pipeline.BeginSave(timeoutHelper.RemainingTime(), null, null));
                    }
                    finally
                    {
                        this.persistencePipelineInUse = null;
                    }
                }
                success = true;
            }
            finally
            {
                CompletePersistenceContext(context, scope, success);
                if (success)
                {
                    if (operation != PersistenceOperation.Save)
                    {
                        this.state = WorkflowApplicationState.Paused;
                        if (TD.WorkflowApplicationUnloadedIsEnabled())
                        {
                            TD.WorkflowApplicationUnloaded(this.Id.ToString());
                        }
                    }
                    else if (TD.WorkflowApplicationPersistedIsEnabled())
                    {
                        TD.WorkflowApplicationPersisted(this.Id.ToString());
                    }
                    if ((operation == PersistenceOperation.Complete) || (operation == PersistenceOperation.Unload))
                    {
                        if (this.HasPersistenceProvider && this.persistenceManager.OwnerWasCreated)
                        {
                            this.persistenceManager.DeleteOwner(timeoutHelper.RemainingTime());
                        }
                        this.MarkUnloaded();
                    }
                }
            }
        }

        private PersistencePipeline ProcessInstanceValues(IDictionary<XName, InstanceValue> values, out object deserializedRuntimeState)
        {
            PersistencePipeline pipeline = null;
            deserializedRuntimeState = ExtractRuntimeState(values, this.persistenceManager.InstanceId);
            if (base.HasPersistenceModule)
            {
                pipeline = new PersistencePipeline(base.GetExtensions<IPersistencePipelineModule>());
                pipeline.SetLoadedValues(values);
            }
            return pipeline;
        }

        private void RaiseAborted(Exception reason)
        {
            if (this.invokeCompletedCallback == null)
            {
                Action<WorkflowApplicationAbortedEventArgs> aborted = this.Aborted;
                if (aborted != null)
                {
                    try
                    {
                        this.handlerThreadId = Thread.CurrentThread.ManagedThreadId;
                        this.isInHandler = true;
                        aborted(new WorkflowApplicationAbortedEventArgs(this, reason));
                    }
                    finally
                    {
                        this.isInHandler = false;
                    }
                }
            }
            else
            {
                this.invokeCompletedCallback();
            }
            if (TD.WorkflowInstanceAbortedIsEnabled())
            {
                TD.WorkflowInstanceAborted(this.Id.ToString(), reason);
            }
        }

        private bool RaiseIdleEvent()
        {
            if (TD.WorkflowApplicationIdledIsEnabled())
            {
                TD.WorkflowApplicationIdled(this.Id.ToString());
            }
            Exception reason = null;
            try
            {
                Action<WorkflowApplicationIdleEventArgs> idle = this.Idle;
                if (idle != null)
                {
                    this.handlerThreadId = Thread.CurrentThread.ManagedThreadId;
                    this.isInHandler = true;
                    idle(new WorkflowApplicationIdleEventArgs(this));
                }
            }
            catch (Exception exception2)
            {
                if (Fx.IsFatal(exception2))
                {
                    throw;
                }
                reason = exception2;
            }
            finally
            {
                this.isInHandler = false;
            }
            if (reason != null)
            {
                this.AbortInstance(reason, true);
                return false;
            }
            return true;
        }

        private bool Remove(InstanceOperation operation)
        {
            Quack<InstanceOperation> pendingOperations = this.pendingOperations;
            lock (pendingOperations)
            {
                return this.pendingOperations.Remove(operation);
            }
        }

        public BookmarkResumptionResult ResumeBookmark(Bookmark bookmark, object value) => 
            this.ResumeBookmark(bookmark, value, ActivityDefaults.ResumeBookmarkTimeout);

        public BookmarkResumptionResult ResumeBookmark(string bookmarkName, object value)
        {
            if (string.IsNullOrEmpty(bookmarkName))
            {
                throw FxTrace.Exception.ArgumentNullOrEmpty("bookmarkName");
            }
            return this.ResumeBookmark(new Bookmark(bookmarkName), value);
        }

        public BookmarkResumptionResult ResumeBookmark(Bookmark bookmark, object value, TimeSpan timeout)
        {
            BookmarkResumptionResult result2;
            System.Runtime.TimeoutHelper.ThrowIfNegativeArgument(timeout);
            this.ThrowIfHandlerThread();
            System.Runtime.TimeoutHelper helper = new System.Runtime.TimeoutHelper(timeout);
            InstanceOperation operation = new RequiresIdleOperation();
            bool flag = false;
            try
            {
                InstanceOperation operation2;
                if (!this.hasCalledRun)
                {
                    flag = true;
                    this.IncrementPendingUnenqueud();
                    this.InternalRun(helper.RemainingTime(), false);
                }
            Label_003A:
                operation2 = null;
                try
                {
                    this.WaitForTurn(operation, helper.RemainingTime());
                    if (flag)
                    {
                        this.DecrementPendingUnenqueud();
                        flag = false;
                    }
                    if (this.AreBookmarksInvalid(out BookmarkResumptionResult result))
                    {
                        return result;
                    }
                    result = this.ResumeBookmarkCore(bookmark, value);
                    switch (result)
                    {
                        case BookmarkResumptionResult.Success:
                            base.Controller.FlushTrackingRecords(helper.RemainingTime());
                            goto Label_009F;

                        case BookmarkResumptionResult.NotReady:
                            operation2 = new DeferredRequiresIdleOperation();
                            break;
                    }
                }
                finally
                {
                    this.NotifyOperationComplete(operation);
                }
            Label_009F:
                operation = operation2;
                if (operation != null)
                {
                    goto Label_003A;
                }
                result2 = result;
            }
            finally
            {
                if (flag)
                {
                    this.DecrementPendingUnenqueud();
                }
            }
            return result2;
        }

        public BookmarkResumptionResult ResumeBookmark(string bookmarkName, object value, TimeSpan timeout)
        {
            if (string.IsNullOrEmpty(bookmarkName))
            {
                throw FxTrace.Exception.ArgumentNullOrEmpty("bookmarkName");
            }
            return this.ResumeBookmark(new Bookmark(bookmarkName), value, timeout);
        }

        private BookmarkResumptionResult ResumeBookmarkCore(Bookmark bookmark, object value)
        {
            BookmarkResumptionResult result = base.Controller.ScheduleBookmarkResumption(bookmark, value);
            if (result == BookmarkResumptionResult.Success)
            {
                this.RunCore();
            }
            return result;
        }

        public void Run()
        {
            this.Run(ActivityDefaults.AcquireLockTimeout);
        }

        public void Run(TimeSpan timeout)
        {
            this.InternalRun(timeout, true);
        }

        private void RunCore()
        {
            if (!this.hasCalledRun)
            {
                this.hasCalledRun = true;
            }
            this.state = WorkflowApplicationState.Runnable;
        }

        private static void RunInstance(System.Activities.WorkflowApplication instance)
        {
            instance.EnsureInitialized();
            instance.RunCore();
            instance.hasExecutionOccurredSinceLastIdle = true;
            instance.Controller.Run();
        }

        private void ScheduleTrackAndRaiseAborted(Exception reason)
        {
            if (base.Controller.HasPendingTrackingRecords || (this.Aborted != null))
            {
                ActionItem.Schedule(new Action<object>(this.TrackAndRaiseAborted), reason);
            }
        }

        private void SetPersistenceManager(PersistenceManager newManager)
        {
            base.RegisterExtensionManager(this.extensions);
            this.persistenceManager = newManager;
        }

        private bool ShouldRaiseComplete(WorkflowInstanceState state) => 
            (state == WorkflowInstanceState.Complete) && !this.hasRaisedCompleted;

        private static System.Activities.WorkflowApplication StartInvoke(Activity activity, IDictionary<string, object> inputs, WorkflowInstanceExtensionManager extensions, SynchronizationContext syncContext, Action invokeCompletedCallback, AsyncInvokeContext invokeContext)
        {
            System.Activities.WorkflowApplication instance = CreateInstance(activity, inputs, extensions, syncContext, invokeCompletedCallback);
            if (invokeContext != null)
            {
                invokeContext.WorkflowApplication = instance;
            }
            RunInstance(instance);
            return instance;
        }

        public void Terminate(Exception reason)
        {
            this.Terminate(reason, ActivityDefaults.AcquireLockTimeout);
        }

        public void Terminate(string reason)
        {
            this.Terminate(reason, ActivityDefaults.AcquireLockTimeout);
        }

        public void Terminate(Exception reason, TimeSpan timeout)
        {
            if (reason == null)
            {
                throw FxTrace.Exception.ArgumentNull("reason");
            }
            this.ThrowIfHandlerThread();
            System.Runtime.TimeoutHelper.ThrowIfNegativeArgument(timeout);
            System.Runtime.TimeoutHelper helper = new System.Runtime.TimeoutHelper(timeout);
            InstanceOperation operation = null;
            try
            {
                operation = new InstanceOperation();
                this.WaitForTurn(operation, helper.RemainingTime());
                this.ValidateStateForTerminate();
                this.TerminateCore(reason);
                base.Controller.FlushTrackingRecords(helper.RemainingTime());
            }
            finally
            {
                this.NotifyOperationComplete(operation);
            }
        }

        public void Terminate(string reason, TimeSpan timeout)
        {
            if (string.IsNullOrEmpty(reason))
            {
                throw FxTrace.Exception.ArgumentNullOrEmpty("reason");
            }
            this.Terminate(new WorkflowApplicationTerminatedException(reason, this.Id), timeout);
        }

        private void TerminateCore(Exception reason)
        {
            base.Controller.Terminate(reason);
        }

        private void ThrowIfAborted()
        {
            if (this.state == WorkflowApplicationState.Aborted)
            {
                throw FxTrace.Exception.AsError(new WorkflowApplicationAbortedException(System.Activities.SR.WorkflowApplicationAborted(this.Id), this.Id));
            }
        }

        private void ThrowIfHandlerThread()
        {
            if (this.IsHandlerThread)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.CannotPerformOperationFromHandlerThread));
            }
        }

        private void ThrowIfMulticast(Delegate value)
        {
            if ((value != null) && (value.GetInvocationList().Length > 1))
            {
                throw FxTrace.Exception.Argument("value", System.Activities.SR.OnlySingleCastDelegatesAllowed);
            }
        }

        private void ThrowIfNoInstanceStore()
        {
            if (!this.HasPersistenceProvider)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.InstanceStoreRequiredToPersist));
            }
        }

        private void ThrowIfTerminatedOrCompleted()
        {
            if (this.hasRaisedCompleted)
            {
                base.Controller.GetCompletionState(out Exception exception);
                if (exception != null)
                {
                    throw FxTrace.Exception.AsError(new WorkflowApplicationTerminatedException(System.Activities.SR.WorkflowApplicationTerminated(this.Id), this.Id, exception));
                }
                throw FxTrace.Exception.AsError(new WorkflowApplicationCompletedException(System.Activities.SR.WorkflowApplicationCompleted(this.Id), this.Id));
            }
        }

        private void ThrowIfUnloaded()
        {
            if (this.state == WorkflowApplicationState.Unloaded)
            {
                throw FxTrace.Exception.AsError(new WorkflowApplicationUnloadedException(System.Activities.SR.WorkflowApplicationUnloaded(this.Id), this.Id));
            }
        }

        private void TrackAndRaiseAborted(object state)
        {
            Exception exception = (Exception) state;
            if (base.Controller.HasPendingTrackingRecords)
            {
                try
                {
                    IAsyncResult result = base.Controller.BeginFlushTrackingRecords(ActivityDefaults.TrackingTimeout, Fx.ThunkCallback(new AsyncCallback(this.OnAbortTrackingComplete)), exception);
                    if (result.CompletedSynchronously)
                    {
                        base.Controller.EndFlushTrackingRecords(result);
                    }
                    else
                    {
                        return;
                    }
                }
                catch (Exception exception2)
                {
                    if (Fx.IsFatal(exception2))
                    {
                        throw;
                    }
                }
            }
            this.RaiseAborted(exception);
        }

        private void TrackPersistence(PersistenceOperation operation)
        {
            if (base.Controller.TrackingEnabled)
            {
                if (operation == PersistenceOperation.Complete)
                {
                    base.Controller.Track(new WorkflowInstanceRecord(this.Id, base.WorkflowDefinition.DisplayName, "Deleted", base.DefinitionIdentity));
                }
                else if (operation == PersistenceOperation.Unload)
                {
                    base.Controller.Track(new WorkflowInstanceRecord(this.Id, base.WorkflowDefinition.DisplayName, "Unloaded", base.DefinitionIdentity));
                }
                else
                {
                    base.Controller.Track(new WorkflowInstanceRecord(this.Id, base.WorkflowDefinition.DisplayName, "Persisted", base.DefinitionIdentity));
                }
            }
        }

        public void Unload()
        {
            this.Unload(ActivityDefaults.SaveTimeout);
        }

        public void Unload(TimeSpan timeout)
        {
            this.ThrowIfHandlerThread();
            System.Runtime.TimeoutHelper.ThrowIfNegativeArgument(timeout);
            System.Runtime.TimeoutHelper timeoutHelper = new System.Runtime.TimeoutHelper(timeout);
            RequiresPersistenceOperation operation = new RequiresPersistenceOperation();
            try
            {
                this.WaitForTurn(operation, timeoutHelper.RemainingTime());
                this.ValidateStateForUnload();
                if (this.state != WorkflowApplicationState.Unloaded)
                {
                    PersistenceOperation complete;
                    if (base.Controller.State == WorkflowInstanceState.Complete)
                    {
                        complete = PersistenceOperation.Complete;
                    }
                    else
                    {
                        complete = PersistenceOperation.Unload;
                    }
                    this.PersistCore(ref timeoutHelper, complete);
                }
            }
            finally
            {
                this.NotifyOperationComplete(operation);
            }
        }

        private static void UnlockInstance(PersistenceManager persistenceManager, System.Runtime.TimeoutHelper timeoutHelper)
        {
            try
            {
                if (persistenceManager.OwnerWasCreated)
                {
                    persistenceManager.DeleteOwner(timeoutHelper.RemainingTime());
                }
                else
                {
                    persistenceManager.Unlock(timeoutHelper.RemainingTime());
                }
            }
            finally
            {
                persistenceManager.Abort();
            }
        }

        private void UpdateInstanceMetadata()
        {
            Dictionary<XName, InstanceValue> metadata = new Dictionary<XName, InstanceValue> {
                { 
                    Workflow45Namespace.DefinitionIdentity,
                    new InstanceValue(base.DefinitionIdentity, InstanceValueOptions.Optional)
                }
            };
            this.persistenceManager.SetMutablemetadata(metadata);
        }

        private void ValidateStateForCancel()
        {
            this.ThrowIfAborted();
        }

        private void ValidateStateForGetAllBookmarks()
        {
            this.ThrowIfAborted();
            this.ThrowIfTerminatedOrCompleted();
            this.ThrowIfUnloaded();
        }

        private void ValidateStateForLoad()
        {
            this.ThrowIfAborted();
            base.ThrowIfReadOnly();
            if (this.instanceIdSet)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.WorkflowApplicationAlreadyHasId));
            }
        }

        private void ValidateStateForPersist()
        {
            this.ThrowIfAborted();
            this.ThrowIfTerminatedOrCompleted();
            this.ThrowIfUnloaded();
            this.ThrowIfNoInstanceStore();
        }

        private void ValidateStateForRun()
        {
            this.ThrowIfAborted();
            this.ThrowIfTerminatedOrCompleted();
            this.ThrowIfUnloaded();
        }

        private void ValidateStateForTerminate()
        {
            this.ThrowIfAborted();
            this.ThrowIfTerminatedOrCompleted();
            this.ThrowIfUnloaded();
        }

        private void ValidateStateForUnload()
        {
            this.ThrowIfAborted();
            if (base.Controller.State != WorkflowInstanceState.Complete)
            {
                this.ThrowIfNoInstanceStore();
            }
        }

        private bool WaitForTurn(InstanceOperation operation, TimeSpan timeout)
        {
            this.Enqueue(operation);
            return this.WaitForTurnNoEnqueue(operation, timeout);
        }

        private bool WaitForTurnAsync(InstanceOperation operation, TimeSpan timeout, Action<object, TimeoutException> callback, object state) => 
            this.WaitForTurnAsync(operation, false, timeout, callback, state);

        private bool WaitForTurnAsync(InstanceOperation operation, bool push, TimeSpan timeout, Action<object, TimeoutException> callback, object state)
        {
            this.Enqueue(operation, push);
            return this.WaitForTurnNoEnqueueAsync(operation, timeout, callback, state);
        }

        private bool WaitForTurnNoEnqueue(InstanceOperation operation, TimeSpan timeout)
        {
            if (!operation.WaitForTurn(timeout) && this.Remove(operation))
            {
                throw FxTrace.Exception.AsError(new TimeoutException(System.Activities.SR.TimeoutOnOperation(timeout)));
            }
            return true;
        }

        private bool WaitForTurnNoEnqueueAsync(InstanceOperation operation, TimeSpan timeout, Action<object, TimeoutException> callback, object state)
        {
            if (waitAsyncCompleteCallback == null)
            {
                waitAsyncCompleteCallback = new Action<object, TimeoutException>(System.Activities.WorkflowApplication.OnWaitAsyncComplete);
            }
            return operation.WaitForTurnAsync(timeout, waitAsyncCompleteCallback, new WaitForTurnData(callback, state, operation, this));
        }

        public System.Runtime.DurableInstancing.InstanceStore InstanceStore
        {
            get => 
                this.instanceStore;
            set
            {
                base.ThrowIfReadOnly();
                this.instanceStore = value;
            }
        }

        public WorkflowInstanceExtensionManager Extensions
        {
            get
            {
                if (this.extensions == null)
                {
                    this.extensions = new WorkflowInstanceExtensionManager();
                    if (base.IsReadOnly)
                    {
                        this.extensions.MakeReadOnly();
                    }
                }
                return this.extensions;
            }
        }

        public Action<WorkflowApplicationAbortedEventArgs> Aborted
        {
            get => 
                this.onAborted;
            set
            {
                this.ThrowIfMulticast(value);
                this.onAborted = value;
            }
        }

        public Action<WorkflowApplicationEventArgs> Unloaded
        {
            get => 
                this.onUnloaded;
            set
            {
                this.ThrowIfMulticast(value);
                this.onUnloaded = value;
            }
        }

        public Action<WorkflowApplicationCompletedEventArgs> Completed
        {
            get => 
                this.onCompleted;
            set
            {
                this.ThrowIfMulticast(value);
                this.onCompleted = value;
            }
        }

        public Func<WorkflowApplicationUnhandledExceptionEventArgs, UnhandledExceptionAction> OnUnhandledException
        {
            get => 
                this.onUnhandledException;
            set
            {
                this.ThrowIfMulticast(value);
                this.onUnhandledException = value;
            }
        }

        public Action<WorkflowApplicationIdleEventArgs> Idle
        {
            get => 
                this.onIdle;
            set
            {
                this.ThrowIfMulticast(value);
                this.onIdle = value;
            }
        }

        public Func<WorkflowApplicationIdleEventArgs, PersistableIdleAction> PersistableIdle
        {
            get => 
                this.onPersistableIdle;
            set
            {
                this.ThrowIfMulticast(value);
                this.onPersistableIdle = value;
            }
        }

        public override Guid Id
        {
            get
            {
                if (!this.instanceIdSet)
                {
                    Quack<InstanceOperation> pendingOperations = this.pendingOperations;
                    lock (pendingOperations)
                    {
                        if (!this.instanceIdSet)
                        {
                            this.instanceId = Guid.NewGuid();
                            this.instanceIdSet = true;
                        }
                    }
                }
                return this.instanceId;
            }
        }

        protected internal override bool SupportsInstanceKeys =>
            false;

        private static AsyncCallback EventFrameCallback
        {
            get
            {
                if (eventFrameCallback == null)
                {
                    eventFrameCallback = Fx.ThunkCallback(new AsyncCallback(System.Activities.WorkflowApplication.EventFrame));
                }
                return eventFrameCallback;
            }
        }

        private WorkflowEventData EventData
        {
            get
            {
                if (this.eventData == null)
                {
                    this.eventData = new WorkflowEventData(this);
                }
                return this.eventData;
            }
        }

        private bool HasPersistenceProvider =>
            this.persistenceManager > null;

        private bool IsHandlerThread =>
            this.isInHandler && (this.handlerThreadId == Thread.CurrentThread.ManagedThreadId);

        private bool IsInTerminalState
        {
            get
            {
                if (this.state != WorkflowApplicationState.Unloaded)
                {
                    return (this.state == WorkflowApplicationState.Aborted);
                }
                return true;
            }
        }

        [Serializable, CompilerGenerated]
        private sealed class <>c
        {
            public static readonly System.Activities.WorkflowApplication.<>c <>9 = new System.Activities.WorkflowApplication.<>c();
            public static Func<IPersistencePipelineModule, bool> <>9__139_0;

            internal bool <IsLoadTransactionRequired>b__139_0(IPersistencePipelineModule module) => 
                module.IsLoadTransactionRequired;
        }

        private class CancelAsyncResult : System.Activities.WorkflowApplication.SimpleOperationAsyncResult
        {
            private CancelAsyncResult(System.Activities.WorkflowApplication instance, AsyncCallback callback, object state) : base(instance, callback, state)
            {
            }

            public static System.Activities.WorkflowApplication.CancelAsyncResult Create(System.Activities.WorkflowApplication instance, TimeSpan timeout, AsyncCallback callback, object state)
            {
                System.Activities.WorkflowApplication.CancelAsyncResult result = new System.Activities.WorkflowApplication.CancelAsyncResult(instance, callback, state);
                result.Run(timeout);
                return result;
            }

            public static void End(IAsyncResult result)
            {
                AsyncResult.End<System.Activities.WorkflowApplication.CancelAsyncResult>(result);
            }

            protected override void PerformOperation()
            {
                base.Instance.CancelCore();
            }

            protected override void ValidateState()
            {
                base.Instance.ValidateStateForCancel();
            }
        }

        private class CompletedEventHandler
        {
            private Func<IAsyncResult, System.Activities.WorkflowApplication, bool, bool> stage1Callback;
            private Func<IAsyncResult, System.Activities.WorkflowApplication, bool, bool> stage2Callback;

            private bool OnStage1Complete(IAsyncResult lastResult, System.Activities.WorkflowApplication instance, bool isStillSync)
            {
                if (lastResult != null)
                {
                    instance.Controller.EndFlushTrackingRecords(lastResult);
                }
                ActivityInstanceState completionState = instance.Controller.GetCompletionState(out IDictionary<string, object> dictionary, out Exception exception);
                if (instance.invokeCompletedCallback == null)
                {
                    Action<WorkflowApplicationCompletedEventArgs> completed = instance.Completed;
                    if (completed != null)
                    {
                        instance.handlerThreadId = Thread.CurrentThread.ManagedThreadId;
                        try
                        {
                            instance.isInHandler = true;
                            completed(new WorkflowApplicationCompletedEventArgs(instance, exception, completionState, dictionary));
                        }
                        finally
                        {
                            instance.isInHandler = false;
                        }
                    }
                }
                switch (completionState)
                {
                    case ActivityInstanceState.Closed:
                        if (TD.WorkflowApplicationCompletedIsEnabled())
                        {
                            TD.WorkflowApplicationCompleted(instance.Id.ToString());
                        }
                        break;

                    case ActivityInstanceState.Canceled:
                        if (TD.WorkflowInstanceCanceledIsEnabled())
                        {
                            TD.WorkflowInstanceCanceled(instance.Id.ToString());
                        }
                        break;

                    case ActivityInstanceState.Faulted:
                        if (TD.WorkflowApplicationTerminatedIsEnabled())
                        {
                            TD.WorkflowApplicationTerminated(instance.Id.ToString(), exception);
                        }
                        break;
                }
                IAsyncResult result = null;
                if ((instance.persistenceManager != null) || instance.HasPersistenceModule)
                {
                    instance.EventData.NextCallback = this.Stage2Callback;
                    result = instance.BeginInternalPersist(System.Activities.WorkflowApplication.PersistenceOperation.Unload, ActivityDefaults.InternalSaveTimeout, true, System.Activities.WorkflowApplication.EventFrameCallback, instance.EventData);
                    if (!result.CompletedSynchronously)
                    {
                        return false;
                    }
                }
                else
                {
                    instance.MarkUnloaded();
                }
                return this.OnStage2Complete(result, instance, isStillSync);
            }

            private bool OnStage2Complete(IAsyncResult lastResult, System.Activities.WorkflowApplication instance, bool isStillSync)
            {
                if (lastResult != null)
                {
                    instance.EndInternalPersist(lastResult);
                }
                if (instance.invokeCompletedCallback != null)
                {
                    instance.invokeCompletedCallback();
                }
                return true;
            }

            public bool Run(System.Activities.WorkflowApplication instance)
            {
                IAsyncResult lastResult = null;
                if (instance.Controller.HasPendingTrackingRecords)
                {
                    instance.EventData.NextCallback = this.Stage1Callback;
                    lastResult = instance.Controller.BeginFlushTrackingRecords(ActivityDefaults.TrackingTimeout, System.Activities.WorkflowApplication.EventFrameCallback, instance.EventData);
                    if (!lastResult.CompletedSynchronously)
                    {
                        return false;
                    }
                }
                return this.OnStage1Complete(lastResult, instance, true);
            }

            private Func<IAsyncResult, System.Activities.WorkflowApplication, bool, bool> Stage1Callback
            {
                get
                {
                    if (this.stage1Callback == null)
                    {
                        this.stage1Callback = new Func<IAsyncResult, System.Activities.WorkflowApplication, bool, bool>(this.OnStage1Complete);
                    }
                    return this.stage1Callback;
                }
            }

            private Func<IAsyncResult, System.Activities.WorkflowApplication, bool, bool> Stage2Callback
            {
                get
                {
                    if (this.stage2Callback == null)
                    {
                        this.stage2Callback = new Func<IAsyncResult, System.Activities.WorkflowApplication, bool, bool>(this.OnStage2Complete);
                    }
                    return this.stage2Callback;
                }
            }
        }

        private class DeferredRequiresIdleOperation : System.Activities.WorkflowApplication.InstanceOperation
        {
            public DeferredRequiresIdleOperation()
            {
                base.InterruptsScheduler = false;
            }

            public override bool CanRun(System.Activities.WorkflowApplication instance) => 
                ((base.ActionId != instance.actionCount) && (instance.Controller.State == WorkflowInstanceState.Idle)) || (instance.Controller.State == WorkflowInstanceState.Complete);
        }

        private class IdleEventHandler
        {
            private Func<IAsyncResult, System.Activities.WorkflowApplication, bool, bool> stage1Callback;
            private Func<IAsyncResult, System.Activities.WorkflowApplication, bool, bool> stage2Callback;

            private bool OnStage1Complete(IAsyncResult lastResult, System.Activities.WorkflowApplication application, bool isStillSync)
            {
                if (lastResult != null)
                {
                    application.Controller.EndFlushTrackingRecords(lastResult);
                }
                IAsyncResult result = null;
                if ((application.RaiseIdleEvent() && application.Controller.IsPersistable) && (application.persistenceManager != null))
                {
                    Func<WorkflowApplicationIdleEventArgs, PersistableIdleAction> persistableIdle = application.PersistableIdle;
                    if (persistableIdle != null)
                    {
                        PersistableIdleAction none = PersistableIdleAction.None;
                        application.handlerThreadId = Thread.CurrentThread.ManagedThreadId;
                        try
                        {
                            application.isInHandler = true;
                            none = persistableIdle(new WorkflowApplicationIdleEventArgs(application));
                        }
                        finally
                        {
                            application.isInHandler = false;
                        }
                        if (TD.WorkflowApplicationPersistableIdleIsEnabled())
                        {
                            TD.WorkflowApplicationPersistableIdle(application.Id.ToString(), none.ToString());
                        }
                        if (none != PersistableIdleAction.None)
                        {
                            System.Activities.WorkflowApplication.PersistenceOperation unload = System.Activities.WorkflowApplication.PersistenceOperation.Unload;
                            if (none == PersistableIdleAction.Persist)
                            {
                                unload = System.Activities.WorkflowApplication.PersistenceOperation.Save;
                            }
                            else if (none != PersistableIdleAction.Unload)
                            {
                                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.InvalidIdleAction));
                            }
                            application.EventData.NextCallback = this.Stage2Callback;
                            result = application.BeginInternalPersist(unload, ActivityDefaults.InternalSaveTimeout, true, System.Activities.WorkflowApplication.EventFrameCallback, application.EventData);
                            if (!result.CompletedSynchronously)
                            {
                                return false;
                            }
                        }
                    }
                    else if (TD.WorkflowApplicationPersistableIdleIsEnabled())
                    {
                        TD.WorkflowApplicationPersistableIdle(application.Id.ToString(), PersistableIdleAction.None.ToString());
                    }
                }
                return this.OnStage2Complete(result, application, isStillSync);
            }

            private bool OnStage2Complete(IAsyncResult lastResult, System.Activities.WorkflowApplication instance, bool isStillSync)
            {
                if (lastResult != null)
                {
                    instance.EndInternalPersist(lastResult);
                }
                return true;
            }

            public bool Run(System.Activities.WorkflowApplication instance)
            {
                IAsyncResult lastResult = null;
                if (instance.Controller.TrackingEnabled)
                {
                    instance.Controller.Track(new WorkflowInstanceRecord(instance.Id, instance.WorkflowDefinition.DisplayName, "Idle", instance.DefinitionIdentity));
                    instance.EventData.NextCallback = this.Stage1Callback;
                    lastResult = instance.Controller.BeginFlushTrackingRecords(ActivityDefaults.TrackingTimeout, System.Activities.WorkflowApplication.EventFrameCallback, instance.EventData);
                    if (!lastResult.CompletedSynchronously)
                    {
                        return false;
                    }
                }
                return this.OnStage1Complete(lastResult, instance, true);
            }

            private Func<IAsyncResult, System.Activities.WorkflowApplication, bool, bool> Stage1Callback
            {
                get
                {
                    if (this.stage1Callback == null)
                    {
                        this.stage1Callback = new Func<IAsyncResult, System.Activities.WorkflowApplication, bool, bool>(this.OnStage1Complete);
                    }
                    return this.stage1Callback;
                }
            }

            private Func<IAsyncResult, System.Activities.WorkflowApplication, bool, bool> Stage2Callback
            {
                get
                {
                    if (this.stage2Callback == null)
                    {
                        this.stage2Callback = new Func<IAsyncResult, System.Activities.WorkflowApplication, bool, bool>(this.OnStage2Complete);
                    }
                    return this.stage2Callback;
                }
            }
        }

        private class InstanceCommandWithTemporaryHandleAsyncResult : TransactedAsyncResult
        {
            private static AsyncResult.AsyncCompletion commandCompletedCallback = new AsyncResult.AsyncCompletion(System.Activities.WorkflowApplication.InstanceCommandWithTemporaryHandleAsyncResult.OnCommandCompleted);
            private static Action<AsyncResult, Exception> completeCallback = new Action<AsyncResult, Exception>(System.Activities.WorkflowApplication.InstanceCommandWithTemporaryHandleAsyncResult.OnComplete);
            private InstancePersistenceCommand command;
            private DependentTransaction dependentTransaction;
            private InstanceStore instanceStore;
            private InstanceHandle temporaryHandle;
            private InstanceView commandResult;

            public InstanceCommandWithTemporaryHandleAsyncResult(InstanceStore instanceStore, InstancePersistenceCommand command, TimeSpan timeout, AsyncCallback callback, object state) : base(callback, state)
            {
                IAsyncResult result;
                this.instanceStore = instanceStore;
                this.command = command;
                this.temporaryHandle = instanceStore.CreateInstanceHandle();
                Transaction current = Transaction.Current;
                if (current != null)
                {
                    this.dependentTransaction = current.DependentClone(DependentCloneOption.BlockCommitUntilComplete);
                }
                base.OnCompleting = completeCallback;
                using (base.PrepareTransactionalCall(this.dependentTransaction))
                {
                    result = instanceStore.BeginExecute(this.temporaryHandle, command, timeout, base.PrepareAsyncCompletion(commandCompletedCallback), this);
                }
                if (base.SyncContinue(result))
                {
                    base.Complete(true);
                }
            }

            public static void End(IAsyncResult result, out InstanceStore instanceStore, out InstanceView commandResult)
            {
                System.Activities.WorkflowApplication.InstanceCommandWithTemporaryHandleAsyncResult result2 = End<System.Activities.WorkflowApplication.InstanceCommandWithTemporaryHandleAsyncResult>(result);
                instanceStore = result2.instanceStore;
                commandResult = result2.commandResult;
            }

            private static bool OnCommandCompleted(IAsyncResult result)
            {
                System.Activities.WorkflowApplication.InstanceCommandWithTemporaryHandleAsyncResult asyncState = (System.Activities.WorkflowApplication.InstanceCommandWithTemporaryHandleAsyncResult) result.AsyncState;
                asyncState.commandResult = asyncState.instanceStore.EndExecute(result);
                return true;
            }

            private static void OnComplete(AsyncResult result, Exception exception)
            {
                System.Activities.WorkflowApplication.InstanceCommandWithTemporaryHandleAsyncResult result2 = (System.Activities.WorkflowApplication.InstanceCommandWithTemporaryHandleAsyncResult) result;
                if (result2.dependentTransaction != null)
                {
                    result2.dependentTransaction.Complete();
                }
                result2.temporaryHandle.Free();
            }
        }

        private class InstanceOperation
        {
            private AsyncWaitHandle waitHandle;

            public InstanceOperation()
            {
                this.InterruptsScheduler = true;
                this.RequiresInitialized = true;
            }

            public virtual bool CanRun(System.Activities.WorkflowApplication instance) => 
                true;

            public void NotifyTurn()
            {
                this.waitHandle.Set();
            }

            public void OnEnqueued()
            {
                this.waitHandle = new AsyncWaitHandle();
            }

            public bool WaitForTurn(TimeSpan timeout)
            {
                if (this.waitHandle != null)
                {
                    return this.waitHandle.Wait(timeout);
                }
                return true;
            }

            public bool WaitForTurnAsync(TimeSpan timeout, Action<object, TimeoutException> callback, object state)
            {
                if (this.waitHandle != null)
                {
                    return this.waitHandle.WaitAsync(callback, state, timeout);
                }
                return true;
            }

            public bool Notified { get; set; }

            public int ActionId { get; set; }

            public bool InterruptsScheduler { get; protected set; }

            public bool RequiresInitialized { get; set; }
        }

        private class InvokeAsyncResult : AsyncResult
        {
            private static Action<object, TimeoutException> waitCompleteCallback;
            private System.Activities.WorkflowApplication instance;
            private AsyncWaitHandle completionWaiter;
            private IDictionary<string, object> outputs;
            private Exception completionException;

            public InvokeAsyncResult(Activity activity, IDictionary<string, object> inputs, WorkflowInstanceExtensionManager extensions, TimeSpan timeout, SynchronizationContext syncContext, AsyncInvokeContext invokeContext, AsyncCallback callback, object state) : base(callback, state)
            {
                this.completionWaiter = new AsyncWaitHandle();
                syncContext = syncContext ?? System.Activities.WorkflowApplication.SynchronousSynchronizationContext.Value;
                this.instance = System.Activities.WorkflowApplication.StartInvoke(activity, inputs, extensions, syncContext, new Action(this.OnInvokeComplete), invokeContext);
                if (this.completionWaiter.WaitAsync(WaitCompleteCallback, this, timeout) && this.OnWorkflowCompletion())
                {
                    if (this.completionException != null)
                    {
                        throw FxTrace.Exception.AsError(this.completionException);
                    }
                    base.Complete(true);
                }
            }

            public static IDictionary<string, object> End(IAsyncResult result) => 
                AsyncResult.End<System.Activities.WorkflowApplication.InvokeAsyncResult>(result).outputs;

            private void OnInvokeComplete()
            {
                this.completionWaiter.Set();
            }

            private static void OnWaitComplete(object state, TimeoutException asyncException)
            {
                System.Activities.WorkflowApplication.InvokeAsyncResult result = (System.Activities.WorkflowApplication.InvokeAsyncResult) state;
                if (asyncException != null)
                {
                    result.instance.Abort(System.Activities.SR.AbortingDueToInstanceTimeout);
                    result.Complete(false, asyncException);
                }
                else
                {
                    bool flag = true;
                    try
                    {
                        flag = result.OnWorkflowCompletion();
                    }
                    catch (Exception exception)
                    {
                        if (Fx.IsFatal(exception))
                        {
                            throw;
                        }
                        result.completionException = exception;
                    }
                    if (flag)
                    {
                        result.Complete(false, result.completionException);
                    }
                }
            }

            private bool OnWorkflowCompletion()
            {
                if (this.instance.Controller.State == WorkflowInstanceState.Aborted)
                {
                    this.completionException = new WorkflowApplicationAbortedException(System.Activities.SR.DefaultAbortReason, this.instance.Controller.GetAbortReason());
                }
                else
                {
                    this.instance.Controller.GetCompletionState(out this.outputs, out this.completionException);
                }
                return true;
            }

            private static Action<object, TimeoutException> WaitCompleteCallback
            {
                get
                {
                    if (waitCompleteCallback == null)
                    {
                        waitCompleteCallback = new Action<object, TimeoutException>(System.Activities.WorkflowApplication.InvokeAsyncResult.OnWaitComplete);
                    }
                    return waitCompleteCallback;
                }
            }
        }

        private class LoadAsyncResult : TransactedAsyncResult
        {
            private static Action<object, TimeoutException> waitCompleteCallback = new Action<object, TimeoutException>(System.Activities.WorkflowApplication.LoadAsyncResult.OnWaitComplete);
            private static AsyncResult.AsyncCompletion providerRegisteredCallback = new AsyncResult.AsyncCompletion(System.Activities.WorkflowApplication.LoadAsyncResult.OnProviderRegistered);
            private static AsyncResult.AsyncCompletion loadCompleteCallback = new AsyncResult.AsyncCompletion(System.Activities.WorkflowApplication.LoadAsyncResult.OnLoadComplete);
            private static AsyncResult.AsyncCompletion loadPipelineCallback = new AsyncResult.AsyncCompletion(System.Activities.WorkflowApplication.LoadAsyncResult.OnLoadPipeline);
            private static AsyncResult.AsyncCompletion completeContextCallback = new AsyncResult.AsyncCompletion(System.Activities.WorkflowApplication.LoadAsyncResult.OnCompleteContext);
            private static Action<AsyncResult, Exception> completeCallback = new Action<AsyncResult, Exception>(System.Activities.WorkflowApplication.LoadAsyncResult.OnComplete);
            private readonly System.Activities.WorkflowApplication application;
            private readonly System.Activities.WorkflowApplication.PersistenceManager persistenceManager;
            private readonly System.Runtime.TimeoutHelper timeoutHelper;
            private readonly bool loadAny;
            private object deserializedRuntimeState;
            private PersistencePipeline pipeline;
            private WorkflowPersistenceContext context;
            private DependentTransaction dependentTransaction;
            private IDictionary<XName, InstanceValue> values;
            private DynamicUpdateMap updateMap;
            private System.Activities.WorkflowApplication.InstanceOperation instanceOperation;

            public LoadAsyncResult(System.Activities.WorkflowApplication application, System.Activities.WorkflowApplication.PersistenceManager persistenceManager, bool loadAny, TimeSpan timeout, AsyncCallback callback, object state) : base(callback, state)
            {
                this.application = application;
                this.persistenceManager = persistenceManager;
                this.loadAny = loadAny;
                this.timeoutHelper = new System.Runtime.TimeoutHelper(timeout);
                this.Initialize();
            }

            public LoadAsyncResult(System.Activities.WorkflowApplication application, System.Activities.WorkflowApplication.PersistenceManager persistenceManager, IDictionary<XName, InstanceValue> values, DynamicUpdateMap updateMap, TimeSpan timeout, AsyncCallback callback, object state) : base(callback, state)
            {
                this.application = application;
                this.persistenceManager = persistenceManager;
                this.values = values;
                this.timeoutHelper = new System.Runtime.TimeoutHelper(timeout);
                this.updateMap = updateMap;
                this.Initialize();
            }

            private static void Abort(System.Activities.WorkflowApplication.LoadAsyncResult thisPtr, Exception exception)
            {
                if (thisPtr.application == null)
                {
                    thisPtr.persistenceManager.Abort();
                }
                else
                {
                    thisPtr.application.AbortDueToException(exception);
                }
            }

            private bool CompleteContext()
            {
                if (this.application != null)
                {
                    this.application.Initialize(this.deserializedRuntimeState, this.updateMap);
                    if (this.updateMap != null)
                    {
                        this.application.UpdateInstanceMetadata();
                    }
                }
                if (this.context.TryBeginComplete(base.PrepareAsyncCompletion(completeContextCallback), this, out IAsyncResult result))
                {
                    return base.SyncContinue(result);
                }
                return this.Finish();
            }

            public static void End(IAsyncResult result)
            {
                AsyncResult.End<System.Activities.WorkflowApplication.LoadAsyncResult>(result);
            }

            public static WorkflowApplicationInstance EndAndCreateInstance(IAsyncResult result)
            {
                System.Activities.WorkflowApplication.LoadAsyncResult result2 = AsyncResult.End<System.Activities.WorkflowApplication.LoadAsyncResult>(result);
                Fx.AssertAndThrow(result2.application == null, "Should not create a WorkflowApplicationInstance if we already have a WorkflowApplication");
                ActivityExecutor executor = System.Activities.WorkflowApplication.ExtractRuntimeState(result2.values, result2.persistenceManager.InstanceId);
                return new WorkflowApplicationInstance(result2.persistenceManager, result2.values, executor.WorkflowIdentity);
            }

            private bool Finish()
            {
                if (this.pipeline != null)
                {
                    this.pipeline.Publish();
                }
                return true;
            }

            private void Initialize()
            {
                bool flag;
                base.OnCompleting = completeCallback;
                Transaction current = Transaction.Current;
                if (current != null)
                {
                    this.dependentTransaction = current.DependentClone(DependentCloneOption.BlockCommitUntilComplete);
                }
                bool flag2 = false;
                Exception exception = null;
                try
                {
                    if (this.application == null)
                    {
                        flag = this.RegisterProvider();
                    }
                    else
                    {
                        flag = this.WaitForTurn();
                    }
                    flag2 = true;
                }
                catch (InstanceUpdateException exception2)
                {
                    exception = exception2;
                    throw;
                }
                catch (VersionMismatchException exception3)
                {
                    exception = exception3;
                    throw;
                }
                finally
                {
                    if (!flag2)
                    {
                        if (this.dependentTransaction != null)
                        {
                            this.dependentTransaction.Complete();
                        }
                        Abort(this, exception);
                    }
                }
                if (flag)
                {
                    base.Complete(true);
                }
            }

            private bool Load()
            {
                bool flag = false;
                IAsyncResult result = null;
                try
                {
                    bool transactionRequired = (this.application != null) ? this.application.IsLoadTransactionRequired() : false;
                    this.context = new WorkflowPersistenceContext(transactionRequired, this.dependentTransaction, this.timeoutHelper.OriginalTimeout);
                    if (this.values == null)
                    {
                        using (base.PrepareTransactionalCall(this.context.PublicTransaction))
                        {
                            if (this.loadAny)
                            {
                                result = this.persistenceManager.BeginTryLoad(this.timeoutHelper.RemainingTime(), base.PrepareAsyncCompletion(loadCompleteCallback), this);
                            }
                            else
                            {
                                result = this.persistenceManager.BeginLoad(this.timeoutHelper.RemainingTime(), base.PrepareAsyncCompletion(loadCompleteCallback), this);
                            }
                        }
                    }
                    flag = true;
                }
                finally
                {
                    if (!flag && (this.context != null))
                    {
                        this.context.Abort();
                    }
                }
                if (result == null)
                {
                    return this.LoadValues(null);
                }
                return base.SyncContinue(result);
            }

            private bool LoadValues(IAsyncResult result)
            {
                IAsyncResult result2 = null;
                bool flag = false;
                try
                {
                    if (result != null)
                    {
                        if (this.loadAny)
                        {
                            if (!this.persistenceManager.EndTryLoad(result, out this.values))
                            {
                                throw FxTrace.Exception.AsError(new InstanceNotReadyException(System.Activities.SR.NoRunnableInstances));
                            }
                            if (this.application != null)
                            {
                                if (this.application.instanceIdSet)
                                {
                                    throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.WorkflowApplicationAlreadyHasId));
                                }
                                this.application.instanceId = this.persistenceManager.InstanceId;
                                this.application.instanceIdSet = true;
                            }
                        }
                        else
                        {
                            this.values = this.persistenceManager.EndLoad(result);
                        }
                    }
                    if (this.application != null)
                    {
                        this.pipeline = this.application.ProcessInstanceValues(this.values, out this.deserializedRuntimeState);
                        if (this.pipeline != null)
                        {
                            this.pipeline.SetLoadedValues(this.values);
                            this.application.persistencePipelineInUse = this.pipeline;
                            Thread.MemoryBarrier();
                            if (this.application.state == System.Activities.WorkflowApplication.WorkflowApplicationState.Aborted)
                            {
                                throw FxTrace.Exception.AsError(new OperationCanceledException(System.Activities.SR.DefaultAbortReason));
                            }
                            using (base.PrepareTransactionalCall(this.context.PublicTransaction))
                            {
                                result2 = this.pipeline.BeginLoad(this.timeoutHelper.RemainingTime(), base.PrepareAsyncCompletion(loadPipelineCallback), this);
                            }
                        }
                    }
                    flag = true;
                }
                finally
                {
                    if (!flag)
                    {
                        this.context.Abort();
                    }
                }
                if (this.pipeline != null)
                {
                    return base.SyncContinue(result2);
                }
                return this.CompleteContext();
            }

            private void NotifyOperationComplete()
            {
                if (this.application != null)
                {
                    System.Activities.WorkflowApplication.InstanceOperation instanceOperation = this.instanceOperation;
                    this.instanceOperation = null;
                    this.application.NotifyOperationComplete(instanceOperation);
                }
            }

            private static void OnComplete(AsyncResult result, Exception exception)
            {
                System.Activities.WorkflowApplication.LoadAsyncResult thisPtr = (System.Activities.WorkflowApplication.LoadAsyncResult) result;
                try
                {
                    if (thisPtr.dependentTransaction != null)
                    {
                        thisPtr.dependentTransaction.Complete();
                    }
                    if (exception != null)
                    {
                        Abort(thisPtr, exception);
                    }
                }
                finally
                {
                    thisPtr.NotifyOperationComplete();
                }
            }

            private static bool OnCompleteContext(IAsyncResult result)
            {
                System.Activities.WorkflowApplication.LoadAsyncResult asyncState = (System.Activities.WorkflowApplication.LoadAsyncResult) result.AsyncState;
                asyncState.context.EndComplete(result);
                return asyncState.Finish();
            }

            private static bool OnLoadComplete(IAsyncResult result)
            {
                System.Activities.WorkflowApplication.LoadAsyncResult asyncState = (System.Activities.WorkflowApplication.LoadAsyncResult) result.AsyncState;
                return asyncState.LoadValues(result);
            }

            private static bool OnLoadPipeline(IAsyncResult result)
            {
                System.Activities.WorkflowApplication.LoadAsyncResult asyncState = (System.Activities.WorkflowApplication.LoadAsyncResult) result.AsyncState;
                bool flag = false;
                try
                {
                    asyncState.pipeline.EndLoad(result);
                    flag = true;
                }
                finally
                {
                    if (!flag)
                    {
                        asyncState.context.Abort();
                    }
                }
                return asyncState.CompleteContext();
            }

            private static bool OnProviderRegistered(IAsyncResult result)
            {
                System.Activities.WorkflowApplication.LoadAsyncResult asyncState = (System.Activities.WorkflowApplication.LoadAsyncResult) result.AsyncState;
                asyncState.persistenceManager.EndInitialize(result);
                return asyncState.Load();
            }

            private static void OnWaitComplete(object state, TimeoutException asyncException)
            {
                System.Activities.WorkflowApplication.LoadAsyncResult result = (System.Activities.WorkflowApplication.LoadAsyncResult) state;
                if (asyncException != null)
                {
                    result.Complete(false, asyncException);
                }
                else
                {
                    bool flag;
                    Exception exception = null;
                    try
                    {
                        flag = result.ValidateState();
                    }
                    catch (Exception exception2)
                    {
                        if (Fx.IsFatal(exception2))
                        {
                            throw;
                        }
                        exception = exception2;
                        flag = true;
                    }
                    if (flag)
                    {
                        result.Complete(false, exception);
                    }
                }
            }

            private bool RegisterProvider()
            {
                if (!this.persistenceManager.IsInitialized)
                {
                    WorkflowIdentity definitionIdentity = (this.application != null) ? this.application.DefinitionIdentity : System.Activities.WorkflowApplication.unknownIdentity;
                    IAsyncResult result = this.persistenceManager.BeginInitialize(definitionIdentity, this.timeoutHelper.RemainingTime(), base.PrepareAsyncCompletion(providerRegisteredCallback), this);
                    return base.SyncContinue(result);
                }
                return this.Load();
            }

            private bool ValidateState()
            {
                this.application.ValidateStateForLoad();
                this.application.SetPersistenceManager(this.persistenceManager);
                if (!this.loadAny)
                {
                    this.application.instanceId = this.persistenceManager.InstanceId;
                    this.application.instanceIdSet = true;
                }
                if (this.application.InstanceStore == null)
                {
                    this.application.InstanceStore = this.persistenceManager.InstanceStore;
                }
                return this.RegisterProvider();
            }

            private bool WaitForTurn()
            {
                bool flag;
                bool flag2 = false;
                System.Activities.WorkflowApplication.InstanceOperation operation1 = new System.Activities.WorkflowApplication.InstanceOperation {
                    RequiresInitialized = false
                };
                this.instanceOperation = operation1;
                try
                {
                    if (this.application.WaitForTurnAsync(this.instanceOperation, this.timeoutHelper.RemainingTime(), waitCompleteCallback, this))
                    {
                        flag = this.ValidateState();
                    }
                    else
                    {
                        flag = false;
                    }
                    flag2 = true;
                }
                finally
                {
                    if (!flag2)
                    {
                        this.NotifyOperationComplete();
                    }
                }
                return flag;
            }
        }

        private class PersistenceManager : System.Activities.WorkflowApplication.PersistenceManagerBase
        {
            private InstanceHandle handle;
            private InstanceHandle temporaryHandle;
            private InstanceOwner owner;
            private bool ownerWasCreated;
            private bool isLocked;
            private bool aborted;
            private bool isTryLoad;
            private Guid instanceId;
            private System.Runtime.DurableInstancing.InstanceStore store;
            private IDictionary<XName, InstanceValue> instanceMetadata;
            private IDictionary<XName, InstanceValue> mutableMetadata;

            public PersistenceManager(System.Runtime.DurableInstancing.InstanceStore store, IDictionary<XName, InstanceValue> instanceMetadata)
            {
                this.isTryLoad = true;
                this.instanceMetadata = instanceMetadata;
                this.InitializeInstanceMetadata();
                this.owner = store.DefaultInstanceOwner;
                if (this.owner != null)
                {
                    this.handle = store.CreateInstanceHandle(this.owner);
                }
                this.store = store;
            }

            public PersistenceManager(System.Runtime.DurableInstancing.InstanceStore store, IDictionary<XName, InstanceValue> instanceMetadata, Guid instanceId)
            {
                this.instanceId = instanceId;
                this.instanceMetadata = instanceMetadata;
                this.InitializeInstanceMetadata();
                this.owner = store.DefaultInstanceOwner;
                if (this.owner != null)
                {
                    this.handle = store.CreateInstanceHandle(this.owner, instanceId);
                }
                this.store = store;
            }

            public void Abort()
            {
                this.aborted = true;
                Thread.MemoryBarrier();
                InstanceHandle handle = this.handle;
                if (handle != null)
                {
                    handle.Free();
                }
                this.FreeTemporaryHandle();
            }

            public IAsyncResult BeginDeleteOwner(TimeSpan timeout, AsyncCallback callback, object state)
            {
                IAsyncResult result = null;
                try
                {
                    this.CreateTemporaryHandle(this.owner);
                    result = this.store.BeginExecute(this.temporaryHandle, new DeleteWorkflowOwnerCommand(), timeout, callback, state);
                }
                catch (InstancePersistenceCommandException)
                {
                }
                catch (InstanceOwnerException)
                {
                }
                catch (OperationCanceledException)
                {
                }
                finally
                {
                    if (result == null)
                    {
                        this.FreeTemporaryHandle();
                    }
                }
                return result;
            }

            public IAsyncResult BeginEnsureReadyness(TimeSpan timeout, AsyncCallback callback, object state)
            {
                using (new TransactionScope(TransactionScopeOption.Suppress))
                {
                    return this.store.BeginExecute(this.handle, CreateSaveCommand(null, this.instanceMetadata, System.Activities.WorkflowApplication.PersistenceOperation.Save), timeout, callback, state);
                }
            }

            public IAsyncResult BeginInitialize(WorkflowIdentity definitionIdentity, TimeSpan timeout, AsyncCallback callback, object state)
            {
                using (new TransactionScope(TransactionScopeOption.Suppress))
                {
                    IAsyncResult result = null;
                    try
                    {
                        this.CreateTemporaryHandle(null);
                        result = this.store.BeginExecute(this.temporaryHandle, GetCreateOwnerCommand(definitionIdentity), timeout, callback, state);
                    }
                    finally
                    {
                        if (result == null)
                        {
                            this.FreeTemporaryHandle();
                        }
                    }
                    return result;
                }
            }

            public IAsyncResult BeginLoad(TimeSpan timeout, AsyncCallback callback, object state) => 
                this.store.BeginExecute(this.handle, new LoadWorkflowCommand(), timeout, callback, state);

            public IAsyncResult BeginSave(IDictionary<XName, InstanceValue> instance, System.Activities.WorkflowApplication.PersistenceOperation operation, TimeSpan timeout, AsyncCallback callback, object state) => 
                this.store.BeginExecute(this.handle, CreateSaveCommand(instance, this.isLocked ? this.mutableMetadata : this.instanceMetadata, operation), timeout, callback, state);

            public IAsyncResult BeginTryLoad(TimeSpan timeout, AsyncCallback callback, object state) => 
                this.store.BeginExecute(this.handle, new TryLoadRunnableWorkflowCommand(), timeout, callback, state);

            public IAsyncResult BeginUnlock(TimeSpan timeout, AsyncCallback callback, object state)
            {
                SaveWorkflowCommand command = new SaveWorkflowCommand {
                    UnlockInstance = true
                };
                return this.store.BeginExecute(this.handle, command, timeout, callback, state);
            }

            private static SaveWorkflowCommand CreateSaveCommand(IDictionary<XName, InstanceValue> instance, IDictionary<XName, InstanceValue> instanceMetadata, System.Activities.WorkflowApplication.PersistenceOperation operation)
            {
                SaveWorkflowCommand command = new SaveWorkflowCommand {
                    CompleteInstance = operation == System.Activities.WorkflowApplication.PersistenceOperation.Complete,
                    UnlockInstance = operation != System.Activities.WorkflowApplication.PersistenceOperation.Save
                };
                if (instance != null)
                {
                    foreach (KeyValuePair<XName, InstanceValue> pair in instance)
                    {
                        command.InstanceData.Add(pair);
                    }
                }
                if (instanceMetadata != null)
                {
                    foreach (KeyValuePair<XName, InstanceValue> pair2 in instanceMetadata)
                    {
                        command.InstanceMetadataChanges.Add(pair2);
                    }
                }
                return command;
            }

            private void CreateTemporaryHandle(InstanceOwner owner)
            {
                this.temporaryHandle = this.store.CreateInstanceHandle(owner);
                Thread.MemoryBarrier();
                if (this.aborted)
                {
                    this.FreeTemporaryHandle();
                }
            }

            public void DeleteOwner(TimeSpan timeout)
            {
                try
                {
                    this.CreateTemporaryHandle(this.owner);
                    this.store.Execute(this.temporaryHandle, new DeleteWorkflowOwnerCommand(), timeout);
                }
                catch (InstancePersistenceCommandException)
                {
                }
                catch (InstanceOwnerException)
                {
                }
                catch (OperationCanceledException)
                {
                }
                finally
                {
                    this.FreeTemporaryHandle();
                }
            }

            public void EndDeleteOwner(IAsyncResult result)
            {
                try
                {
                    this.store.EndExecute(result);
                }
                catch (InstancePersistenceCommandException)
                {
                }
                catch (InstanceOwnerException)
                {
                }
                catch (OperationCanceledException)
                {
                }
                finally
                {
                    this.FreeTemporaryHandle();
                }
            }

            public void EndEnsureReadyness(IAsyncResult result)
            {
                this.store.EndExecute(result);
                this.isLocked = true;
            }

            public void EndInitialize(IAsyncResult result)
            {
                try
                {
                    this.owner = this.store.EndExecute(result).InstanceOwner;
                    this.ownerWasCreated = true;
                }
                finally
                {
                    this.FreeTemporaryHandle();
                }
                this.handle = this.isTryLoad ? this.store.CreateInstanceHandle(this.owner) : this.store.CreateInstanceHandle(this.owner, this.InstanceId);
                Thread.MemoryBarrier();
                if (this.aborted)
                {
                    this.handle.Free();
                }
            }

            public IDictionary<XName, InstanceValue> EndLoad(IAsyncResult result)
            {
                InstanceView view = this.store.EndExecute(result);
                this.isLocked = true;
                if (!this.handle.IsValid)
                {
                    throw FxTrace.Exception.AsError(new OperationCanceledException(System.Activities.SR.WorkflowInstanceAborted(this.InstanceId)));
                }
                return view.InstanceData;
            }

            public void EndSave(IAsyncResult result)
            {
                this.store.EndExecute(result);
                this.isLocked = true;
            }

            public bool EndTryLoad(IAsyncResult result, out IDictionary<XName, InstanceValue> data)
            {
                InstanceView view = this.store.EndExecute(result);
                return this.TryLoadHelper(view, out data);
            }

            public void EndUnlock(IAsyncResult result)
            {
                this.store.EndExecute(result);
            }

            public void EnsureReadyness(TimeSpan timeout)
            {
                using (new TransactionScope(TransactionScopeOption.Suppress))
                {
                    this.store.Execute(this.handle, CreateSaveCommand(null, this.instanceMetadata, System.Activities.WorkflowApplication.PersistenceOperation.Save), timeout);
                    this.isLocked = true;
                }
            }

            private void FreeTemporaryHandle()
            {
                InstanceHandle temporaryHandle = this.temporaryHandle;
                if (temporaryHandle != null)
                {
                    temporaryHandle.Free();
                }
            }

            public static Dictionary<XName, InstanceValue> GenerateInitialData(System.Activities.WorkflowApplication instance)
            {
                Dictionary<XName, InstanceValue> dictionary = new Dictionary<XName, InstanceValue>(10) {
                    [WorkflowNamespace.Bookmarks] = new InstanceValue(instance.Controller.GetBookmarks(), InstanceValueOptions.WriteOnly | InstanceValueOptions.Optional),
                    [WorkflowNamespace.LastUpdate] = new InstanceValue(DateTime.UtcNow, InstanceValueOptions.WriteOnly | InstanceValueOptions.Optional)
                };
                foreach (KeyValuePair<string, LocationInfo> pair in instance.Controller.GetMappedVariables())
                {
                    XName name = WorkflowNamespace.VariablesPath.GetName(pair.Key);
                    dictionary[name] = new InstanceValue(pair.Value, InstanceValueOptions.WriteOnly | InstanceValueOptions.Optional);
                }
                Fx.AssertAndThrow(instance.Controller.State != WorkflowInstanceState.Aborted, "Cannot generate data for an aborted instance.");
                if (instance.Controller.State != WorkflowInstanceState.Complete)
                {
                    dictionary[WorkflowNamespace.Workflow] = new InstanceValue(instance.Controller.PrepareForSerialization());
                    dictionary[WorkflowNamespace.Status] = new InstanceValue((instance.Controller.State == WorkflowInstanceState.Idle) ? "Idle" : "Executing", InstanceValueOptions.WriteOnly);
                    return dictionary;
                }
                dictionary[WorkflowNamespace.Workflow] = new InstanceValue(instance.Controller.PrepareForSerialization(), InstanceValueOptions.Optional);
                ActivityInstanceState completionState = instance.Controller.GetCompletionState(out IDictionary<string, object> dictionary2, out Exception exception);
                switch (completionState)
                {
                    case ActivityInstanceState.Faulted:
                        dictionary[WorkflowNamespace.Status] = new InstanceValue("Faulted", InstanceValueOptions.WriteOnly);
                        dictionary[WorkflowNamespace.Exception] = new InstanceValue(exception, InstanceValueOptions.WriteOnly | InstanceValueOptions.Optional);
                        return dictionary;

                    case ActivityInstanceState.Closed:
                        dictionary[WorkflowNamespace.Status] = new InstanceValue("Closed", InstanceValueOptions.WriteOnly);
                        if (dictionary2 != null)
                        {
                            foreach (KeyValuePair<string, object> pair2 in dictionary2)
                            {
                                XName name = WorkflowNamespace.OutputPath.GetName(pair2.Key);
                                dictionary[name] = new InstanceValue(pair2.Value, InstanceValueOptions.WriteOnly | InstanceValueOptions.Optional);
                            }
                        }
                        return dictionary;
                }
                Fx.AssertAndThrow(completionState == ActivityInstanceState.Canceled, "Cannot be executing when WorkflowState was completed.");
                dictionary[WorkflowNamespace.Status] = new InstanceValue("Canceled", InstanceValueOptions.WriteOnly);
                return dictionary;
            }

            private static InstancePersistenceCommand GetCreateOwnerCommand(WorkflowIdentity definitionIdentity)
            {
                if (definitionIdentity == null)
                {
                    return new CreateWorkflowOwnerCommand();
                }
                CreateWorkflowOwnerWithIdentityCommand command = new CreateWorkflowOwnerWithIdentityCommand();
                if (definitionIdentity != System.Activities.WorkflowApplication.unknownIdentity)
                {
                    Collection<WorkflowIdentity> collection1 = new Collection<WorkflowIdentity> {
                        definitionIdentity
                    };
                    command.InstanceOwnerMetadata.Add(Workflow45Namespace.DefinitionIdentities, new InstanceValue(collection1));
                }
                return command;
            }

            public void Initialize(WorkflowIdentity definitionIdentity, TimeSpan timeout)
            {
                using (new TransactionScope(TransactionScopeOption.Suppress))
                {
                    try
                    {
                        this.CreateTemporaryHandle(null);
                        this.owner = this.store.Execute(this.temporaryHandle, GetCreateOwnerCommand(definitionIdentity), timeout).InstanceOwner;
                        this.ownerWasCreated = true;
                    }
                    finally
                    {
                        this.FreeTemporaryHandle();
                    }
                    this.handle = this.isTryLoad ? this.store.CreateInstanceHandle(this.owner) : this.store.CreateInstanceHandle(this.owner, this.InstanceId);
                    Thread.MemoryBarrier();
                    if (this.aborted)
                    {
                        this.handle.Free();
                    }
                }
            }

            private void InitializeInstanceMetadata()
            {
                if (this.instanceMetadata == null)
                {
                    this.instanceMetadata = new Dictionary<XName, InstanceValue>(1);
                }
                this.instanceMetadata[PersistenceMetadataNamespace.InstanceType] = new InstanceValue(WorkflowNamespace.WorkflowHostType, InstanceValueOptions.WriteOnly);
            }

            public IDictionary<XName, InstanceValue> Load(TimeSpan timeout)
            {
                InstanceView view = this.store.Execute(this.handle, new LoadWorkflowCommand(), timeout);
                this.isLocked = true;
                if (!this.handle.IsValid)
                {
                    throw FxTrace.Exception.AsError(new OperationCanceledException(System.Activities.SR.WorkflowInstanceAborted(this.InstanceId)));
                }
                return view.InstanceData;
            }

            public void Save(IDictionary<XName, InstanceValue> instance, System.Activities.WorkflowApplication.PersistenceOperation operation, TimeSpan timeout)
            {
                this.store.Execute(this.handle, CreateSaveCommand(instance, this.isLocked ? this.mutableMetadata : this.instanceMetadata, operation), timeout);
                this.isLocked = true;
            }

            public void SetInstanceMetadata(IDictionary<XName, InstanceValue> metadata)
            {
                if (metadata != null)
                {
                    this.instanceMetadata = metadata;
                    this.InitializeInstanceMetadata();
                }
            }

            public void SetMutablemetadata(IDictionary<XName, InstanceValue> metadata)
            {
                this.mutableMetadata = metadata;
            }

            public bool TryLoad(TimeSpan timeout, out IDictionary<XName, InstanceValue> data)
            {
                InstanceView view = this.store.Execute(this.handle, new TryLoadRunnableWorkflowCommand(), timeout);
                return this.TryLoadHelper(view, out data);
            }

            private bool TryLoadHelper(InstanceView view, out IDictionary<XName, InstanceValue> data)
            {
                if (!view.IsBoundToLock)
                {
                    data = null;
                    return false;
                }
                this.instanceId = view.InstanceId;
                this.isLocked = true;
                if (!this.handle.IsValid)
                {
                    throw FxTrace.Exception.AsError(new OperationCanceledException(System.Activities.SR.WorkflowInstanceAborted(this.InstanceId)));
                }
                data = view.InstanceData;
                return true;
            }

            public void Unlock(TimeSpan timeout)
            {
                SaveWorkflowCommand command = new SaveWorkflowCommand {
                    UnlockInstance = true
                };
                this.store.Execute(this.handle, command, timeout);
            }

            public sealed override Guid InstanceId =>
                this.instanceId;

            public sealed override System.Runtime.DurableInstancing.InstanceStore InstanceStore =>
                this.store;

            public bool IsInitialized =>
                this.handle > null;

            public bool IsLocked =>
                this.isLocked;

            public bool OwnerWasCreated =>
                this.ownerWasCreated;
        }

        internal abstract class PersistenceManagerBase
        {
            protected PersistenceManagerBase()
            {
            }

            public abstract System.Runtime.DurableInstancing.InstanceStore InstanceStore { get; }

            public abstract Guid InstanceId { get; }
        }

        private enum PersistenceOperation : byte
        {
            Complete = 0,
            Save = 1,
            Unload = 2
        }

        private class PumpBasedSynchronizationContext : SynchronizationContext
        {
            [ThreadStatic]
            private static AutoResetEvent waitObject;
            private AutoResetEvent queueWaiter;
            private WorkItem currentWorkItem;
            private object thisLock;
            private System.Runtime.TimeoutHelper timeoutHelper;

            public PumpBasedSynchronizationContext(TimeSpan timeout)
            {
                this.timeoutHelper = new System.Runtime.TimeoutHelper(timeout);
                this.thisLock = new object();
            }

            public void DoPump()
            {
                WorkItem currentWorkItem;
                object thisLock = this.thisLock;
                lock (thisLock)
                {
                    if (waitObject == null)
                    {
                        waitObject = new AutoResetEvent(false);
                    }
                    this.queueWaiter = waitObject;
                    currentWorkItem = this.currentWorkItem;
                    this.currentWorkItem = null;
                    currentWorkItem.Invoke();
                    goto Label_0062;
                }
            Label_004E:
                currentWorkItem = this.currentWorkItem;
                this.currentWorkItem = null;
                currentWorkItem.Invoke();
            Label_0062:
                if (this.WaitForNextItem())
                {
                    goto Label_004E;
                }
            }

            public void OnInvokeCompleted()
            {
                Fx.AssertAndFailFast(this.currentWorkItem == null, "There can be no pending work items when complete");
                this.IsInvokeCompleted = true;
                object thisLock = this.thisLock;
                lock (thisLock)
                {
                    if (this.queueWaiter != null)
                    {
                        this.queueWaiter.Set();
                    }
                }
            }

            public override void Post(SendOrPostCallback d, object state)
            {
                this.ScheduleWorkItem(new WorkItem(d, state));
            }

            private void ScheduleWorkItem(WorkItem item)
            {
                object thisLock = this.thisLock;
                lock (thisLock)
                {
                    Fx.AssertAndFailFast(this.currentWorkItem == null, "There cannot be more than 1 work item at a given time");
                    this.currentWorkItem = item;
                    if (this.queueWaiter != null)
                    {
                        this.queueWaiter.Set();
                    }
                }
            }

            public override void Send(SendOrPostCallback d, object state)
            {
                throw FxTrace.Exception.AsError(new NotSupportedException(System.Activities.SR.SendNotSupported));
            }

            private bool WaitForNextItem()
            {
                if (!this.WaitOne(this.queueWaiter, this.timeoutHelper.RemainingTime()))
                {
                    throw FxTrace.Exception.AsError(new TimeoutException(System.Activities.SR.TimeoutOnOperation(this.timeoutHelper.OriginalTimeout)));
                }
                if (this.IsInvokeCompleted)
                {
                    return false;
                }
                return true;
            }

            private bool WaitOne(AutoResetEvent waiter, TimeSpan timeout)
            {
                bool flag3;
                bool flag = false;
                try
                {
                    bool flag2 = System.Runtime.TimeoutHelper.WaitOne(waiter, timeout);
                    flag = flag2;
                    flag3 = flag2;
                }
                finally
                {
                    if (!flag)
                    {
                        waitObject = null;
                    }
                }
                return flag3;
            }

            private bool IsInvokeCompleted { get; set; }

            private class WorkItem
            {
                private SendOrPostCallback callback;
                private object state;

                public WorkItem(SendOrPostCallback callback, object state)
                {
                    this.callback = callback;
                    this.state = state;
                }

                public void Invoke()
                {
                    this.callback(this.state);
                }
            }
        }

        private class RequiresIdleOperation : System.Activities.WorkflowApplication.InstanceOperation
        {
            private bool requiresRunnableInstance;

            public RequiresIdleOperation() : this(false)
            {
            }

            public RequiresIdleOperation(bool requiresRunnableInstance)
            {
                base.InterruptsScheduler = false;
                this.requiresRunnableInstance = requiresRunnableInstance;
            }

            public override bool CanRun(System.Activities.WorkflowApplication instance)
            {
                if (this.requiresRunnableInstance && (instance.state != System.Activities.WorkflowApplication.WorkflowApplicationState.Runnable))
                {
                    return false;
                }
                if (instance.Controller.State != WorkflowInstanceState.Idle)
                {
                    return (instance.Controller.State == WorkflowInstanceState.Complete);
                }
                return true;
            }
        }

        private class RequiresPersistenceOperation : System.Activities.WorkflowApplication.InstanceOperation
        {
            public override bool CanRun(System.Activities.WorkflowApplication instance)
            {
                if (!instance.Controller.IsPersistable && (instance.Controller.State != WorkflowInstanceState.Complete))
                {
                    instance.Controller.PauseWhenPersistable();
                    return false;
                }
                return true;
            }
        }

        private class ResumeBookmarkAsyncResult : AsyncResult
        {
            private static AsyncResult.AsyncCompletion resumedCallback = new AsyncResult.AsyncCompletion(System.Activities.WorkflowApplication.ResumeBookmarkAsyncResult.OnResumed);
            private static Action<object, TimeoutException> waitCompleteCallback = new Action<object, TimeoutException>(System.Activities.WorkflowApplication.ResumeBookmarkAsyncResult.OnWaitComplete);
            private static AsyncResult.AsyncCompletion trackingCompleteCallback = new AsyncResult.AsyncCompletion(System.Activities.WorkflowApplication.ResumeBookmarkAsyncResult.OnTrackingComplete);
            private System.Activities.WorkflowApplication instance;
            private Bookmark bookmark;
            private object value;
            private BookmarkResumptionResult resumptionResult;
            private System.Runtime.TimeoutHelper timeoutHelper;
            private bool isFromExtension;
            private bool pendedUnenqueued;
            private System.Activities.WorkflowApplication.InstanceOperation currentOperation;

            public ResumeBookmarkAsyncResult(System.Activities.WorkflowApplication instance, Bookmark bookmark, object value, TimeSpan timeout, AsyncCallback callback, object state) : this(instance, bookmark, value, false, timeout, callback, state)
            {
            }

            public ResumeBookmarkAsyncResult(System.Activities.WorkflowApplication instance, Bookmark bookmark, object value, bool isFromExtension, TimeSpan timeout, AsyncCallback callback, object state) : base(callback, state)
            {
                this.instance = instance;
                this.bookmark = bookmark;
                this.value = value;
                this.isFromExtension = isFromExtension;
                this.timeoutHelper = new System.Runtime.TimeoutHelper(timeout);
                bool flag = false;
                bool flag2 = false;
                base.OnCompleting = new Action<AsyncResult, Exception>(this.Finally);
                try
                {
                    if (!this.instance.hasCalledRun && !this.isFromExtension)
                    {
                        this.pendedUnenqueued = true;
                        this.instance.IncrementPendingUnenqueud();
                        IAsyncResult result = this.instance.BeginInternalRun(this.timeoutHelper.RemainingTime(), false, base.PrepareAsyncCompletion(resumedCallback), this);
                        if (result.CompletedSynchronously)
                        {
                            flag = OnResumed(result);
                        }
                    }
                    else
                    {
                        flag = this.StartResumptionLoop();
                    }
                    flag2 = true;
                }
                finally
                {
                    if (!flag2)
                    {
                        this.Finally(null, null);
                    }
                }
                if (flag)
                {
                    base.Complete(true);
                }
            }

            private bool CheckIfBookmarksAreInvalid() => 
                this.instance.AreBookmarksInvalid(out this.resumptionResult);

            private void ClearPendedUnenqueued()
            {
                if (this.pendedUnenqueued)
                {
                    this.pendedUnenqueued = false;
                    this.instance.DecrementPendingUnenqueud();
                }
            }

            public static BookmarkResumptionResult End(IAsyncResult result) => 
                AsyncResult.End<System.Activities.WorkflowApplication.ResumeBookmarkAsyncResult>(result).resumptionResult;

            private void Finally(AsyncResult result, Exception completionException)
            {
                this.ClearPendedUnenqueued();
                this.NotifyOperationComplete();
            }

            private void NotifyOperationComplete()
            {
                System.Activities.WorkflowApplication.InstanceOperation currentOperation = this.currentOperation;
                this.currentOperation = null;
                this.instance.NotifyOperationComplete(currentOperation);
            }

            private static bool OnResumed(IAsyncResult result)
            {
                System.Activities.WorkflowApplication.ResumeBookmarkAsyncResult asyncState = (System.Activities.WorkflowApplication.ResumeBookmarkAsyncResult) result.AsyncState;
                asyncState.instance.EndRun(result);
                return asyncState.StartResumptionLoop();
            }

            private static bool OnTrackingComplete(IAsyncResult result)
            {
                System.Activities.WorkflowApplication.ResumeBookmarkAsyncResult asyncState = (System.Activities.WorkflowApplication.ResumeBookmarkAsyncResult) result.AsyncState;
                asyncState.instance.Controller.EndFlushTrackingRecords(result);
                return true;
            }

            private static void OnWaitComplete(object state, TimeoutException asyncException)
            {
                System.Activities.WorkflowApplication.ResumeBookmarkAsyncResult result = (System.Activities.WorkflowApplication.ResumeBookmarkAsyncResult) state;
                if (asyncException != null)
                {
                    result.Complete(false, asyncException);
                }
                else
                {
                    Exception exception = null;
                    bool flag = false;
                    try
                    {
                        result.ClearPendedUnenqueued();
                        if (result.CheckIfBookmarksAreInvalid())
                        {
                            flag = true;
                        }
                        else
                        {
                            flag = result.ProcessResumption();
                            if (result.resumptionResult == BookmarkResumptionResult.NotReady)
                            {
                                flag = result.WaitOnCurrentOperation();
                            }
                        }
                    }
                    catch (Exception exception2)
                    {
                        if (Fx.IsFatal(exception2))
                        {
                            throw;
                        }
                        flag = true;
                        exception = exception2;
                    }
                    if (flag)
                    {
                        result.Complete(false, exception);
                    }
                }
            }

            private bool ProcessResumption()
            {
                bool flag = true;
                this.resumptionResult = this.instance.ResumeBookmarkCore(this.bookmark, this.value);
                if (this.resumptionResult == BookmarkResumptionResult.Success)
                {
                    if (!this.instance.Controller.HasPendingTrackingRecords)
                    {
                        return flag;
                    }
                    IAsyncResult result = this.instance.Controller.BeginFlushTrackingRecords(this.timeoutHelper.RemainingTime(), base.PrepareAsyncCompletion(trackingCompleteCallback), this);
                    return (result.CompletedSynchronously && OnTrackingComplete(result));
                }
                if (this.resumptionResult == BookmarkResumptionResult.NotReady)
                {
                    this.NotifyOperationComplete();
                    this.currentOperation = new System.Activities.WorkflowApplication.DeferredRequiresIdleOperation();
                }
                return flag;
            }

            private bool StartResumptionLoop()
            {
                this.currentOperation = new System.Activities.WorkflowApplication.RequiresIdleOperation(this.isFromExtension);
                return this.WaitOnCurrentOperation();
            }

            private bool WaitOnCurrentOperation()
            {
                bool flag = true;
                bool flag2 = true;
                while (flag2)
                {
                    flag2 = false;
                    if (this.instance.WaitForTurnAsync(this.currentOperation, this.timeoutHelper.RemainingTime(), waitCompleteCallback, this))
                    {
                        this.ClearPendedUnenqueued();
                        if (this.CheckIfBookmarksAreInvalid())
                        {
                            flag = true;
                        }
                        else
                        {
                            flag = this.ProcessResumption();
                            flag2 = this.resumptionResult == BookmarkResumptionResult.NotReady;
                        }
                    }
                    else
                    {
                        flag = false;
                    }
                }
                return flag;
            }
        }

        private class RunAsyncResult : System.Activities.WorkflowApplication.SimpleOperationAsyncResult
        {
            private bool isUserRun;

            private RunAsyncResult(System.Activities.WorkflowApplication instance, bool isUserRun, AsyncCallback callback, object state) : base(instance, callback, state)
            {
                this.isUserRun = isUserRun;
            }

            public static System.Activities.WorkflowApplication.RunAsyncResult Create(System.Activities.WorkflowApplication instance, bool isUserRun, TimeSpan timeout, AsyncCallback callback, object state)
            {
                System.Activities.WorkflowApplication.RunAsyncResult result = new System.Activities.WorkflowApplication.RunAsyncResult(instance, isUserRun, callback, state);
                result.Run(timeout);
                return result;
            }

            public static void End(IAsyncResult result)
            {
                AsyncResult.End<System.Activities.WorkflowApplication.RunAsyncResult>(result);
            }

            protected override void PerformOperation()
            {
                if (this.isUserRun)
                {
                    base.Instance.hasExecutionOccurredSinceLastIdle = true;
                }
                base.Instance.RunCore();
            }

            protected override void ValidateState()
            {
                base.Instance.ValidateStateForRun();
            }
        }

        private abstract class SimpleOperationAsyncResult : AsyncResult
        {
            private static Action<object, TimeoutException> waitCompleteCallback = new Action<object, TimeoutException>(System.Activities.WorkflowApplication.SimpleOperationAsyncResult.OnWaitComplete);
            private static AsyncCallback trackingCompleteCallback = Fx.ThunkCallback(new AsyncCallback(System.Activities.WorkflowApplication.SimpleOperationAsyncResult.OnTrackingComplete));
            private System.Activities.WorkflowApplication instance;
            private System.Runtime.TimeoutHelper timeoutHelper;

            protected SimpleOperationAsyncResult(System.Activities.WorkflowApplication instance, AsyncCallback callback, object state) : base(callback, state)
            {
                this.instance = instance;
            }

            private static void OnTrackingComplete(IAsyncResult result)
            {
                if (!result.CompletedSynchronously)
                {
                    System.Activities.WorkflowApplication.SimpleOperationAsyncResult asyncState = (System.Activities.WorkflowApplication.SimpleOperationAsyncResult) result.AsyncState;
                    Exception exception = null;
                    try
                    {
                        asyncState.instance.Controller.EndFlushTrackingRecords(result);
                    }
                    catch (Exception exception2)
                    {
                        if (Fx.IsFatal(exception2))
                        {
                            throw;
                        }
                        exception = exception2;
                    }
                    finally
                    {
                        asyncState.instance.ForceNotifyOperationComplete();
                    }
                    asyncState.Complete(false, exception);
                }
            }

            private static void OnWaitComplete(object state, TimeoutException asyncException)
            {
                System.Activities.WorkflowApplication.SimpleOperationAsyncResult result = (System.Activities.WorkflowApplication.SimpleOperationAsyncResult) state;
                if (asyncException != null)
                {
                    result.Complete(false, asyncException);
                }
                else
                {
                    Exception exception = null;
                    bool flag = true;
                    try
                    {
                        result.ValidateState();
                        flag = result.PerformOperationAndTrack();
                    }
                    catch (Exception exception2)
                    {
                        if (Fx.IsFatal(exception2))
                        {
                            throw;
                        }
                        exception = exception2;
                    }
                    finally
                    {
                        if (flag)
                        {
                            result.instance.ForceNotifyOperationComplete();
                        }
                    }
                    if (flag)
                    {
                        result.Complete(false, exception);
                    }
                }
            }

            protected abstract void PerformOperation();
            private bool PerformOperationAndTrack()
            {
                this.PerformOperation();
                bool flag = true;
                if (!this.instance.Controller.HasPendingTrackingRecords)
                {
                    return flag;
                }
                IAsyncResult result = this.instance.Controller.BeginFlushTrackingRecords(this.timeoutHelper.RemainingTime(), trackingCompleteCallback, this);
                if (result.CompletedSynchronously)
                {
                    this.instance.Controller.EndFlushTrackingRecords(result);
                    return flag;
                }
                return false;
            }

            protected void Run(TimeSpan timeout)
            {
                this.timeoutHelper = new System.Runtime.TimeoutHelper(timeout);
                System.Activities.WorkflowApplication.InstanceOperation operation = new System.Activities.WorkflowApplication.InstanceOperation();
                bool flag = true;
                try
                {
                    flag = this.instance.WaitForTurnAsync(operation, this.timeoutHelper.RemainingTime(), waitCompleteCallback, this);
                    if (flag)
                    {
                        this.ValidateState();
                        flag = this.PerformOperationAndTrack();
                    }
                }
                finally
                {
                    if (flag)
                    {
                        this.instance.NotifyOperationComplete(operation);
                    }
                }
                if (flag)
                {
                    base.Complete(true);
                }
            }

            protected abstract void ValidateState();

            protected System.Activities.WorkflowApplication Instance =>
                this.instance;
        }

        internal class SynchronousSynchronizationContext : SynchronizationContext
        {
            private static System.Activities.WorkflowApplication.SynchronousSynchronizationContext value;

            private SynchronousSynchronizationContext()
            {
            }

            public override void Post(SendOrPostCallback d, object state)
            {
                d(state);
            }

            public override void Send(SendOrPostCallback d, object state)
            {
                d(state);
            }

            public static System.Activities.WorkflowApplication.SynchronousSynchronizationContext Value
            {
                get
                {
                    if (value == null)
                    {
                        value = new System.Activities.WorkflowApplication.SynchronousSynchronizationContext();
                    }
                    return value;
                }
            }
        }

        private class TerminateAsyncResult : System.Activities.WorkflowApplication.SimpleOperationAsyncResult
        {
            private Exception reason;

            private TerminateAsyncResult(System.Activities.WorkflowApplication instance, Exception reason, AsyncCallback callback, object state) : base(instance, callback, state)
            {
                this.reason = reason;
            }

            public static System.Activities.WorkflowApplication.TerminateAsyncResult Create(System.Activities.WorkflowApplication instance, Exception reason, TimeSpan timeout, AsyncCallback callback, object state)
            {
                System.Activities.WorkflowApplication.TerminateAsyncResult result = new System.Activities.WorkflowApplication.TerminateAsyncResult(instance, reason, callback, state);
                result.Run(timeout);
                return result;
            }

            public static void End(IAsyncResult result)
            {
                AsyncResult.End<System.Activities.WorkflowApplication.TerminateAsyncResult>(result);
            }

            protected override void PerformOperation()
            {
                base.Instance.TerminateCore(this.reason);
            }

            protected override void ValidateState()
            {
                base.Instance.ValidateStateForTerminate();
            }
        }

        private class UnhandledExceptionEventHandler
        {
            private Func<IAsyncResult, System.Activities.WorkflowApplication, bool, bool> stage1Callback;

            private bool OnStage1Complete(IAsyncResult lastResult, System.Activities.WorkflowApplication instance, bool isStillSync) => 
                this.OnStage1Complete(lastResult, instance, instance.EventData.UnhandledException, instance.EventData.UnhandledExceptionSource, instance.EventData.UnhandledExceptionSourceInstance);

            private bool OnStage1Complete(IAsyncResult lastResult, System.Activities.WorkflowApplication instance, Exception exception, Activity source, string sourceInstanceId)
            {
                if (lastResult != null)
                {
                    instance.Controller.EndFlushTrackingRecords(lastResult);
                }
                Func<WorkflowApplicationUnhandledExceptionEventArgs, UnhandledExceptionAction> onUnhandledException = instance.OnUnhandledException;
                UnhandledExceptionAction terminate = UnhandledExceptionAction.Terminate;
                if (onUnhandledException != null)
                {
                    try
                    {
                        instance.isInHandler = true;
                        instance.handlerThreadId = Thread.CurrentThread.ManagedThreadId;
                        terminate = onUnhandledException(new WorkflowApplicationUnhandledExceptionEventArgs(instance, exception, source, sourceInstanceId));
                    }
                    finally
                    {
                        instance.isInHandler = false;
                    }
                }
                if (instance.invokeCompletedCallback != null)
                {
                    terminate = UnhandledExceptionAction.Terminate;
                }
                if (TD.WorkflowApplicationUnhandledExceptionIsEnabled())
                {
                    TD.WorkflowApplicationUnhandledException(instance.Id.ToString(), source.GetType().ToString(), source.DisplayName, terminate.ToString(), exception);
                }
                switch (terminate)
                {
                    case UnhandledExceptionAction.Abort:
                        instance.AbortInstance(exception, true);
                        break;

                    case UnhandledExceptionAction.Cancel:
                        instance.Controller.ScheduleCancel();
                        break;

                    case UnhandledExceptionAction.Terminate:
                        instance.TerminateCore(exception);
                        break;

                    default:
                        throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.InvalidUnhandledExceptionAction));
                }
                return true;
            }

            public bool Run(System.Activities.WorkflowApplication instance, Exception exception, Activity exceptionSource, string exceptionSourceInstanceId)
            {
                IAsyncResult lastResult = null;
                if (instance.Controller.HasPendingTrackingRecords)
                {
                    instance.EventData.NextCallback = this.Stage1Callback;
                    instance.EventData.UnhandledException = exception;
                    instance.EventData.UnhandledExceptionSource = exceptionSource;
                    instance.EventData.UnhandledExceptionSourceInstance = exceptionSourceInstanceId;
                    lastResult = instance.Controller.BeginFlushTrackingRecords(ActivityDefaults.TrackingTimeout, System.Activities.WorkflowApplication.EventFrameCallback, instance.EventData);
                    if (!lastResult.CompletedSynchronously)
                    {
                        return false;
                    }
                }
                return this.OnStage1Complete(lastResult, instance, exception, exceptionSource, exceptionSourceInstanceId);
            }

            private Func<IAsyncResult, System.Activities.WorkflowApplication, bool, bool> Stage1Callback
            {
                get
                {
                    if (this.stage1Callback == null)
                    {
                        this.stage1Callback = new Func<IAsyncResult, System.Activities.WorkflowApplication, bool, bool>(this.OnStage1Complete);
                    }
                    return this.stage1Callback;
                }
            }
        }

        private class UnloadOrPersistAsyncResult : TransactedAsyncResult
        {
            private static Action<object, TimeoutException> waitCompleteCallback = new Action<object, TimeoutException>(System.Activities.WorkflowApplication.UnloadOrPersistAsyncResult.OnWaitComplete);
            private static AsyncResult.AsyncCompletion savedCallback = new AsyncResult.AsyncCompletion(System.Activities.WorkflowApplication.UnloadOrPersistAsyncResult.OnSaved);
            private static AsyncResult.AsyncCompletion persistedCallback = new AsyncResult.AsyncCompletion(System.Activities.WorkflowApplication.UnloadOrPersistAsyncResult.OnPersisted);
            private static AsyncResult.AsyncCompletion initializedCallback = new AsyncResult.AsyncCompletion(System.Activities.WorkflowApplication.UnloadOrPersistAsyncResult.OnProviderInitialized);
            private static AsyncResult.AsyncCompletion readynessEnsuredCallback = new AsyncResult.AsyncCompletion(System.Activities.WorkflowApplication.UnloadOrPersistAsyncResult.OnProviderReadynessEnsured);
            private static AsyncResult.AsyncCompletion trackingCompleteCallback = new AsyncResult.AsyncCompletion(System.Activities.WorkflowApplication.UnloadOrPersistAsyncResult.OnTrackingComplete);
            private static AsyncResult.AsyncCompletion deleteOwnerCompleteCallback = new AsyncResult.AsyncCompletion(System.Activities.WorkflowApplication.UnloadOrPersistAsyncResult.OnOwnerDeleted);
            private static AsyncResult.AsyncCompletion completeContextCallback = new AsyncResult.AsyncCompletion(System.Activities.WorkflowApplication.UnloadOrPersistAsyncResult.OnCompleteContext);
            private static Action<AsyncResult, Exception> completeCallback = new Action<AsyncResult, Exception>(System.Activities.WorkflowApplication.UnloadOrPersistAsyncResult.OnComplete);
            private DependentTransaction dependentTransaction;
            private System.Activities.WorkflowApplication instance;
            private bool isUnloaded;
            private System.Runtime.TimeoutHelper timeoutHelper;
            private System.Activities.WorkflowApplication.PersistenceOperation operation;
            private System.Activities.WorkflowApplication.RequiresPersistenceOperation instanceOperation;
            private WorkflowPersistenceContext context;
            private IDictionary<XName, InstanceValue> data;
            private PersistencePipeline pipeline;
            private bool isInternalPersist;

            public UnloadOrPersistAsyncResult(System.Activities.WorkflowApplication instance, TimeSpan timeout, System.Activities.WorkflowApplication.PersistenceOperation operation, bool isWorkflowThread, bool isInternalPersist, AsyncCallback callback, object state) : base(callback, state)
            {
                bool flag;
                this.instance = instance;
                this.timeoutHelper = new System.Runtime.TimeoutHelper(timeout);
                this.operation = operation;
                this.isInternalPersist = isInternalPersist;
                this.isUnloaded = (operation == System.Activities.WorkflowApplication.PersistenceOperation.Unload) || (operation == System.Activities.WorkflowApplication.PersistenceOperation.Complete);
                base.OnCompleting = completeCallback;
                bool flag2 = false;
                Transaction current = Transaction.Current;
                if (current != null)
                {
                    this.dependentTransaction = current.DependentClone(DependentCloneOption.BlockCommitUntilComplete);
                }
                try
                {
                    if (isWorkflowThread)
                    {
                        flag = this.InitializeProvider();
                        flag2 = true;
                    }
                    else
                    {
                        this.instanceOperation = new System.Activities.WorkflowApplication.RequiresPersistenceOperation();
                        try
                        {
                            if (this.instance.WaitForTurnAsync(this.instanceOperation, this.timeoutHelper.RemainingTime(), waitCompleteCallback, this))
                            {
                                flag = this.ValidateState();
                            }
                            else
                            {
                                flag = false;
                            }
                            flag2 = true;
                        }
                        finally
                        {
                            if (!flag2)
                            {
                                this.NotifyOperationComplete();
                            }
                        }
                    }
                }
                finally
                {
                    if (!flag2 && (this.dependentTransaction != null))
                    {
                        this.dependentTransaction.Complete();
                    }
                }
                if (flag)
                {
                    base.Complete(true);
                }
            }

            private bool CloseInstance()
            {
                if (this.operation != System.Activities.WorkflowApplication.PersistenceOperation.Save)
                {
                    this.instance.state = System.Activities.WorkflowApplication.WorkflowApplicationState.Paused;
                }
                if (this.isUnloaded)
                {
                    this.instance.MarkUnloaded();
                }
                return true;
            }

            private bool CollectAndMap()
            {
                bool flag = false;
                try
                {
                    if (this.instance.HasPersistenceModule)
                    {
                        IEnumerable<IPersistencePipelineModule> extensions = this.instance.GetExtensions<IPersistencePipelineModule>();
                        this.pipeline = new PersistencePipeline(extensions, System.Activities.WorkflowApplication.PersistenceManager.GenerateInitialData(this.instance));
                        this.pipeline.Collect();
                        this.pipeline.Map();
                        this.data = this.pipeline.Values;
                    }
                    flag = true;
                }
                finally
                {
                    if (!flag && (this.context != null))
                    {
                        this.context.Abort();
                    }
                }
                if (this.instance.HasPersistenceProvider)
                {
                    return this.Persist();
                }
                return this.Save();
            }

            private bool CompleteContext()
            {
                bool flag = false;
                IAsyncResult result = null;
                if (this.context != null)
                {
                    flag = this.context.TryBeginComplete(base.PrepareAsyncCompletion(completeContextCallback), this, out result);
                }
                if (flag)
                {
                    return base.SyncContinue(result);
                }
                return this.DeleteOwner();
            }

            private bool DeleteOwner()
            {
                if ((!this.instance.HasPersistenceProvider || !this.instance.persistenceManager.OwnerWasCreated) || ((this.operation != System.Activities.WorkflowApplication.PersistenceOperation.Unload) && (this.operation != System.Activities.WorkflowApplication.PersistenceOperation.Complete)))
                {
                    return this.CloseInstance();
                }
                IAsyncResult result = null;
                using (base.PrepareTransactionalCall(this.dependentTransaction))
                {
                    result = this.instance.persistenceManager.BeginDeleteOwner(this.timeoutHelper.RemainingTime(), base.PrepareAsyncCompletion(deleteOwnerCompleteCallback), this);
                }
                return base.SyncContinue(result);
            }

            public static void End(IAsyncResult result)
            {
                AsyncResult.End<System.Activities.WorkflowApplication.UnloadOrPersistAsyncResult>(result);
            }

            private bool EnsureProviderReadyness()
            {
                if ((this.instance.HasPersistenceProvider && !this.instance.persistenceManager.IsLocked) && (this.dependentTransaction != null))
                {
                    IAsyncResult result = this.instance.persistenceManager.BeginEnsureReadyness(this.timeoutHelper.RemainingTime(), base.PrepareAsyncCompletion(readynessEnsuredCallback), this);
                    return base.SyncContinue(result);
                }
                return this.Track();
            }

            private bool InitializeProvider()
            {
                if ((this.operation == System.Activities.WorkflowApplication.PersistenceOperation.Unload) && (this.instance.Controller.State == WorkflowInstanceState.Complete))
                {
                    this.operation = System.Activities.WorkflowApplication.PersistenceOperation.Complete;
                }
                if (this.instance.HasPersistenceProvider && !this.instance.persistenceManager.IsInitialized)
                {
                    IAsyncResult result = this.instance.persistenceManager.BeginInitialize(this.instance.DefinitionIdentity, this.timeoutHelper.RemainingTime(), base.PrepareAsyncCompletion(initializedCallback), this);
                    return base.SyncContinue(result);
                }
                return this.EnsureProviderReadyness();
            }

            private void NotifyOperationComplete()
            {
                System.Activities.WorkflowApplication.RequiresPersistenceOperation instanceOperation = this.instanceOperation;
                this.instanceOperation = null;
                this.instance.NotifyOperationComplete(instanceOperation);
            }

            private static void OnComplete(AsyncResult result, Exception exception)
            {
                System.Activities.WorkflowApplication.UnloadOrPersistAsyncResult result2 = (System.Activities.WorkflowApplication.UnloadOrPersistAsyncResult) result;
                try
                {
                    result2.NotifyOperationComplete();
                }
                finally
                {
                    if (result2.dependentTransaction != null)
                    {
                        result2.dependentTransaction.Complete();
                    }
                }
            }

            private static bool OnCompleteContext(IAsyncResult result)
            {
                System.Activities.WorkflowApplication.UnloadOrPersistAsyncResult asyncState = (System.Activities.WorkflowApplication.UnloadOrPersistAsyncResult) result.AsyncState;
                asyncState.context.EndComplete(result);
                return asyncState.DeleteOwner();
            }

            private static bool OnOwnerDeleted(IAsyncResult result)
            {
                System.Activities.WorkflowApplication.UnloadOrPersistAsyncResult asyncState = (System.Activities.WorkflowApplication.UnloadOrPersistAsyncResult) result.AsyncState;
                asyncState.instance.persistenceManager.EndDeleteOwner(result);
                return asyncState.CloseInstance();
            }

            private static bool OnPersisted(IAsyncResult result)
            {
                System.Activities.WorkflowApplication.UnloadOrPersistAsyncResult asyncState = (System.Activities.WorkflowApplication.UnloadOrPersistAsyncResult) result.AsyncState;
                bool flag = false;
                try
                {
                    asyncState.instance.persistenceManager.EndSave(result);
                    flag = true;
                }
                finally
                {
                    if (!flag)
                    {
                        asyncState.context.Abort();
                    }
                }
                return asyncState.Save();
            }

            private static bool OnProviderInitialized(IAsyncResult result)
            {
                System.Activities.WorkflowApplication.UnloadOrPersistAsyncResult asyncState = (System.Activities.WorkflowApplication.UnloadOrPersistAsyncResult) result.AsyncState;
                asyncState.instance.persistenceManager.EndInitialize(result);
                return asyncState.EnsureProviderReadyness();
            }

            private static bool OnProviderReadynessEnsured(IAsyncResult result)
            {
                System.Activities.WorkflowApplication.UnloadOrPersistAsyncResult asyncState = (System.Activities.WorkflowApplication.UnloadOrPersistAsyncResult) result.AsyncState;
                asyncState.instance.persistenceManager.EndEnsureReadyness(result);
                return asyncState.Track();
            }

            private static bool OnSaved(IAsyncResult result)
            {
                System.Activities.WorkflowApplication.UnloadOrPersistAsyncResult asyncState = (System.Activities.WorkflowApplication.UnloadOrPersistAsyncResult) result.AsyncState;
                bool flag = false;
                try
                {
                    asyncState.pipeline.EndSave(result);
                    flag = true;
                }
                finally
                {
                    asyncState.instance.persistencePipelineInUse = null;
                    if (!flag)
                    {
                        asyncState.context.Abort();
                    }
                }
                return asyncState.CompleteContext();
            }

            private static bool OnTrackingComplete(IAsyncResult result)
            {
                System.Activities.WorkflowApplication.UnloadOrPersistAsyncResult asyncState = (System.Activities.WorkflowApplication.UnloadOrPersistAsyncResult) result.AsyncState;
                asyncState.instance.Controller.EndFlushTrackingRecords(result);
                return asyncState.CollectAndMap();
            }

            private static void OnWaitComplete(object state, TimeoutException asyncException)
            {
                System.Activities.WorkflowApplication.UnloadOrPersistAsyncResult result = (System.Activities.WorkflowApplication.UnloadOrPersistAsyncResult) state;
                if (asyncException != null)
                {
                    result.Complete(false, asyncException);
                }
                else
                {
                    bool flag;
                    Exception exception = null;
                    try
                    {
                        flag = result.ValidateState();
                    }
                    catch (Exception exception2)
                    {
                        if (Fx.IsFatal(exception2))
                        {
                            throw;
                        }
                        exception = exception2;
                        flag = true;
                    }
                    if (flag)
                    {
                        result.Complete(false, exception);
                    }
                }
            }

            private bool Persist()
            {
                IAsyncResult result = null;
                try
                {
                    if (this.data == null)
                    {
                        this.data = System.Activities.WorkflowApplication.PersistenceManager.GenerateInitialData(this.instance);
                    }
                    if (this.context == null)
                    {
                        this.context = new WorkflowPersistenceContext((this.pipeline != null) && this.pipeline.IsSaveTransactionRequired, this.dependentTransaction, this.timeoutHelper.OriginalTimeout);
                    }
                    using (base.PrepareTransactionalCall(this.context.PublicTransaction))
                    {
                        result = this.instance.persistenceManager.BeginSave(this.data, this.operation, this.timeoutHelper.RemainingTime(), base.PrepareAsyncCompletion(persistedCallback), this);
                    }
                }
                finally
                {
                    if ((result == null) && (this.context != null))
                    {
                        this.context.Abort();
                    }
                }
                return base.SyncContinue(result);
            }

            private bool Save()
            {
                if (this.pipeline == null)
                {
                    return this.CompleteContext();
                }
                IAsyncResult result = null;
                try
                {
                    if (this.context == null)
                    {
                        this.context = new WorkflowPersistenceContext(this.pipeline.IsSaveTransactionRequired, this.dependentTransaction, this.timeoutHelper.RemainingTime());
                    }
                    this.instance.persistencePipelineInUse = this.pipeline;
                    Thread.MemoryBarrier();
                    if (this.instance.state == System.Activities.WorkflowApplication.WorkflowApplicationState.Aborted)
                    {
                        throw FxTrace.Exception.AsError(new OperationCanceledException(System.Activities.SR.DefaultAbortReason));
                    }
                    using (base.PrepareTransactionalCall(this.context.PublicTransaction))
                    {
                        result = this.pipeline.BeginSave(this.timeoutHelper.RemainingTime(), base.PrepareAsyncCompletion(savedCallback), this);
                    }
                }
                finally
                {
                    if (result == null)
                    {
                        this.instance.persistencePipelineInUse = null;
                        if (this.context != null)
                        {
                            this.context.Abort();
                        }
                    }
                }
                return base.SyncContinue(result);
            }

            private bool Track()
            {
                TimeSpan trackingTimeout;
                if (this.instance.HasPersistenceProvider)
                {
                    this.instance.TrackPersistence(this.operation);
                }
                if (!this.instance.Controller.HasPendingTrackingRecords)
                {
                    return this.CollectAndMap();
                }
                if (this.isInternalPersist)
                {
                    trackingTimeout = ActivityDefaults.TrackingTimeout;
                }
                else
                {
                    trackingTimeout = this.timeoutHelper.RemainingTime();
                }
                IAsyncResult result = this.instance.Controller.BeginFlushTrackingRecords(trackingTimeout, base.PrepareAsyncCompletion(trackingCompleteCallback), this);
                return base.SyncContinue(result);
            }

            private bool ValidateState()
            {
                bool flag = false;
                if (this.operation == System.Activities.WorkflowApplication.PersistenceOperation.Unload)
                {
                    this.instance.ValidateStateForUnload();
                    flag = this.instance.state == System.Activities.WorkflowApplication.WorkflowApplicationState.Unloaded;
                }
                else
                {
                    this.instance.ValidateStateForPersist();
                }
                return (flag || this.InitializeProvider());
            }
        }

        private class UnlockInstanceAsyncResult : TransactedAsyncResult
        {
            private static AsyncResult.AsyncCompletion instanceUnlockedCallback = new AsyncResult.AsyncCompletion(System.Activities.WorkflowApplication.UnlockInstanceAsyncResult.OnInstanceUnlocked);
            private static AsyncResult.AsyncCompletion ownerDeletedCallback = new AsyncResult.AsyncCompletion(System.Activities.WorkflowApplication.UnlockInstanceAsyncResult.OnOwnerDeleted);
            private static Action<AsyncResult, Exception> completeCallback = new Action<AsyncResult, Exception>(System.Activities.WorkflowApplication.UnlockInstanceAsyncResult.OnComplete);
            private readonly System.Activities.WorkflowApplication.PersistenceManager persistenceManager;
            private readonly System.Runtime.TimeoutHelper timeoutHelper;
            private DependentTransaction dependentTransaction;

            public UnlockInstanceAsyncResult(System.Activities.WorkflowApplication.PersistenceManager persistenceManager, System.Runtime.TimeoutHelper timeoutHelper, AsyncCallback callback, object state) : base(callback, state)
            {
                this.persistenceManager = persistenceManager;
                this.timeoutHelper = timeoutHelper;
                Transaction current = Transaction.Current;
                if (current != null)
                {
                    this.dependentTransaction = current.DependentClone(DependentCloneOption.BlockCommitUntilComplete);
                }
                base.OnCompleting = completeCallback;
                bool flag = false;
                try
                {
                    IAsyncResult result;
                    using (base.PrepareTransactionalCall(this.dependentTransaction))
                    {
                        if (this.persistenceManager.OwnerWasCreated)
                        {
                            result = this.persistenceManager.BeginDeleteOwner(this.timeoutHelper.RemainingTime(), base.PrepareAsyncCompletion(ownerDeletedCallback), this);
                        }
                        else
                        {
                            result = this.persistenceManager.BeginUnlock(this.timeoutHelper.RemainingTime(), base.PrepareAsyncCompletion(instanceUnlockedCallback), this);
                        }
                    }
                    if (base.SyncContinue(result))
                    {
                        base.Complete(true);
                    }
                    flag = true;
                }
                finally
                {
                    if (!flag)
                    {
                        this.persistenceManager.Abort();
                    }
                }
            }

            public static void End(IAsyncResult result)
            {
                AsyncResult.End<System.Activities.WorkflowApplication.UnlockInstanceAsyncResult>(result);
            }

            private static void OnComplete(AsyncResult result, Exception exception)
            {
                System.Activities.WorkflowApplication.UnlockInstanceAsyncResult result2 = (System.Activities.WorkflowApplication.UnlockInstanceAsyncResult) result;
                if (result2.dependentTransaction != null)
                {
                    result2.dependentTransaction.Complete();
                }
                result2.persistenceManager.Abort();
            }

            private static bool OnInstanceUnlocked(IAsyncResult result)
            {
                System.Activities.WorkflowApplication.UnlockInstanceAsyncResult asyncState = (System.Activities.WorkflowApplication.UnlockInstanceAsyncResult) result.AsyncState;
                asyncState.persistenceManager.EndUnlock(result);
                return true;
            }

            private static bool OnOwnerDeleted(IAsyncResult result)
            {
                System.Activities.WorkflowApplication.UnlockInstanceAsyncResult asyncState = (System.Activities.WorkflowApplication.UnlockInstanceAsyncResult) result.AsyncState;
                asyncState.persistenceManager.EndDeleteOwner(result);
                return true;
            }
        }

        private class WaitForTurnData
        {
            public WaitForTurnData(Action<object, TimeoutException> callback, object state, System.Activities.WorkflowApplication.InstanceOperation operation, System.Activities.WorkflowApplication instance)
            {
                this.Callback = callback;
                this.State = state;
                this.Operation = operation;
                this.Instance = instance;
            }

            public Action<object, TimeoutException> Callback { get; private set; }

            public object State { get; private set; }

            public System.Activities.WorkflowApplication.InstanceOperation Operation { get; private set; }

            public System.Activities.WorkflowApplication Instance { get; private set; }
        }

        private enum WorkflowApplicationState : byte
        {
            Paused = 0,
            Runnable = 1,
            Unloaded = 2,
            Aborted = 3
        }

        private class WorkflowEventData
        {
            public WorkflowEventData(System.Activities.WorkflowApplication instance)
            {
                this.Instance = instance;
            }

            public System.Activities.WorkflowApplication Instance { get; private set; }

            public Func<IAsyncResult, System.Activities.WorkflowApplication, bool, bool> NextCallback { get; set; }

            public Exception UnhandledException { get; set; }

            public Activity UnhandledExceptionSource { get; set; }

            public string UnhandledExceptionSourceInstance { get; set; }
        }
    }
}

