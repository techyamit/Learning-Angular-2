﻿namespace System.Activities
{
    using System;
    using System.Activities.Runtime;
    using System.Activities.XamlIntegration;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.Windows.Markup;

    [ContentProperty("Implementation")]
    public sealed class DynamicActivity : Activity, ICustomTypeDescriptor, IDynamicActivity
    {
        private Activity runtimeImplementation;
        private DynamicActivityTypeDescriptor typeDescriptor;
        private Collection<Attribute> attributes;

        public DynamicActivity()
        {
            this.typeDescriptor = new DynamicActivityTypeDescriptor(this);
        }

        internal override void InternalExecute(System.Activities.ActivityInstance instance, ActivityExecutor executor, BookmarkManager bookmarkManager)
        {
            if (this.runtimeImplementation != null)
            {
                executor.ScheduleActivity(this.runtimeImplementation, instance, null, null, null);
            }
        }

        internal sealed override void OnInternalCacheMetadata(bool createEmptyBindings)
        {
            Activity activity = null;
            if (this.Implementation != null)
            {
                activity = this.Implementation();
            }
            if (activity != null)
            {
                Collection<Activity> implementationChildren = new Collection<Activity> {
                    activity
                };
                base.SetImplementationChildrenCollection(implementationChildren);
            }
            this.runtimeImplementation = activity;
            Activity.ReflectedInformation information = new Activity.ReflectedInformation(this);
            base.SetImportedChildrenCollection(information.GetChildren());
            base.SetVariablesCollection(information.GetVariables());
            base.SetImportedDelegatesCollection(information.GetDelegates());
            base.SetArgumentsCollection(information.GetArguments(), createEmptyBindings);
        }

        AttributeCollection ICustomTypeDescriptor.GetAttributes() => 
            this.typeDescriptor.GetAttributes();

        string ICustomTypeDescriptor.GetClassName() => 
            this.typeDescriptor.GetClassName();

        string ICustomTypeDescriptor.GetComponentName() => 
            this.typeDescriptor.GetComponentName();

        TypeConverter ICustomTypeDescriptor.GetConverter() => 
            this.typeDescriptor.GetConverter();

        EventDescriptor ICustomTypeDescriptor.GetDefaultEvent() => 
            this.typeDescriptor.GetDefaultEvent();

        PropertyDescriptor ICustomTypeDescriptor.GetDefaultProperty() => 
            this.typeDescriptor.GetDefaultProperty();

        object ICustomTypeDescriptor.GetEditor(Type editorBaseType) => 
            this.typeDescriptor.GetEditor(editorBaseType);

        EventDescriptorCollection ICustomTypeDescriptor.GetEvents() => 
            this.typeDescriptor.GetEvents();

        EventDescriptorCollection ICustomTypeDescriptor.GetEvents(Attribute[] attributes) => 
            this.typeDescriptor.GetEvents(attributes);

        PropertyDescriptorCollection ICustomTypeDescriptor.GetProperties() => 
            this.typeDescriptor.GetProperties();

        PropertyDescriptorCollection ICustomTypeDescriptor.GetProperties(Attribute[] attributes) => 
            this.typeDescriptor.GetProperties(attributes);

        object ICustomTypeDescriptor.GetPropertyOwner(PropertyDescriptor pd) => 
            this.typeDescriptor.GetPropertyOwner(pd);

        public string Name
        {
            get => 
                this.typeDescriptor.Name;
            set => 
                this.typeDescriptor.Name = value;
        }

        [DependsOn("Name")]
        public Collection<Attribute> Attributes
        {
            get
            {
                if (this.attributes == null)
                {
                    this.attributes = new Collection<Attribute>();
                }
                return this.attributes;
            }
        }

        [Browsable(false), DependsOn("Attributes")]
        public KeyedCollection<string, DynamicActivityProperty> Properties =>
            this.typeDescriptor.Properties;

        [DependsOn("Properties")]
        public Collection<Constraint> Constraints =>
            base.Constraints;

        [TypeConverter(typeof(ImplementationVersionConverter)), DefaultValue((string) null)]
        public Version ImplementationVersion
        {
            get => 
                base.ImplementationVersion;
            set => 
                base.ImplementationVersion = value;
        }

        [XamlDeferLoad(typeof(FuncDeferringLoader), typeof(Activity)), DefaultValue((string) null), Browsable(false), Ambient]
        public Func<Activity> Implementation
        {
            get => 
                base.Implementation;
            set => 
                base.Implementation = value;
        }

        KeyedCollection<string, DynamicActivityProperty> IDynamicActivity.Properties =>
            this.Properties;
    }
}

