﻿namespace System.Activities.Expressions
{
    using System;
    using System.Activities;
    using System.Runtime;
    using System.Runtime.CompilerServices;

    public sealed class VariableValue<T> : EnvironmentLocationValue<T>
    {
        public VariableValue()
        {
        }

        public VariableValue(System.Activities.Variable variable)
        {
            this.Variable = variable;
        }

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (this.Variable == null)
            {
                metadata.AddValidationError(System.Activities.SR.VariableMustBeSet);
            }
            else
            {
                if (!(this.Variable is Variable<T>) && !TypeHelper.AreTypesCompatible(this.Variable.Type, typeof(T)))
                {
                    metadata.AddValidationError(System.Activities.SR.VariableTypeInvalid(this.Variable, typeof(T), this.Variable.Type));
                }
                if (!this.Variable.IsInTree)
                {
                    metadata.AddValidationError(System.Activities.SR.VariableShouldBeOpen(this.Variable.Name));
                }
                if (!metadata.Environment.IsVisible(this.Variable))
                {
                    metadata.AddValidationError(System.Activities.SR.VariableNotVisible(this.Variable.Name));
                }
            }
        }

        public override string ToString()
        {
            if ((this.Variable != null) && !string.IsNullOrEmpty(this.Variable.Name))
            {
                return this.Variable.Name;
            }
            return base.ToString();
        }

        public System.Activities.Variable Variable { get; set; }

        public override System.Activities.LocationReference LocationReference =>
            this.Variable;
    }
}

