﻿namespace System.Activities.Expressions
{
    using System;
    using System.Activities;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Reflection;
    using System.Runtime.InteropServices;
    using System.Xaml;

    public static class TextExpression
    {
        private static readonly AttachableMemberIdentifier namespacesProperty = new AttachableMemberIdentifier(typeof(TextExpression), "Namespaces");
        private static readonly AttachableMemberIdentifier namespacesForImplementationProperty = new AttachableMemberIdentifier(typeof(TextExpression), "NamespacesForImplementation");
        private static readonly AttachableMemberIdentifier referencesProperty = new AttachableMemberIdentifier(typeof(TextExpression), "References");
        private static readonly AttachableMemberIdentifier referencesForImplementationProperty = new AttachableMemberIdentifier(typeof(TextExpression), "ReferencesForImplementation");
        private static readonly ReadOnlyCollection<string> defaultNamespaces;
        private static readonly ReadOnlyCollection<AssemblyReference> defaultReferences;

        static TextExpression()
        {
            string[] list = new string[] { "System", "System.Collections", "System.Collections.Generic", "System.Activities", "System.Activities.Expressions", "System.Activities.Statements" };
            defaultNamespaces = new ReadOnlyCollection<string>(list);
            AssemblyReference[] referenceArray1 = new AssemblyReference[] { new AssemblyName("mscorlib"), new AssemblyName("System"), new AssemblyName("System.Activities"), new AssemblyName("System.Core") };
            defaultReferences = new ReadOnlyCollection<AssemblyReference>(referenceArray1);
        }

        private static IList<T> GetCollection<T>(object target, AttachableMemberIdentifier property)
        {
            if (!AttachablePropertyServices.TryGetProperty<IList<T>>(target, property, out IList<T> list))
            {
                list = new Collection<T>();
                AttachablePropertyServices.SetProperty(target, property, list);
            }
            return list;
        }

        public static IList<string> GetNamespaces(object target) => 
            GetCollection<string>(target, namespacesProperty);

        public static IList<string> GetNamespacesForImplementation(object target) => 
            GetCollection<string>(target, namespacesForImplementationProperty);

        public static IList<string> GetNamespacesInScope(Activity activity)
        {
            Activity root = GetRoot(activity, out bool flag);
            IList<string> namespacesForImplementation = flag ? GetNamespacesForImplementation(root) : GetNamespaces(root);
            if (((namespacesForImplementation.Count == 0) && !flag) && (GetReferences(root).Count == 0))
            {
                namespacesForImplementation = GetNamespacesForImplementation(root);
            }
            return namespacesForImplementation;
        }

        public static IList<AssemblyReference> GetReferences(object target) => 
            GetCollection<AssemblyReference>(target, referencesProperty);

        public static IList<AssemblyReference> GetReferencesForImplementation(object target) => 
            GetCollection<AssemblyReference>(target, referencesForImplementationProperty);

        public static IList<AssemblyReference> GetReferencesInScope(Activity activity)
        {
            Activity root = GetRoot(activity, out bool flag);
            IList<AssemblyReference> referencesForImplementation = flag ? GetReferencesForImplementation(root) : GetReferences(root);
            if (((referencesForImplementation.Count == 0) && !flag) && (GetNamespaces(root).Count == 0))
            {
                referencesForImplementation = GetReferencesForImplementation(root);
            }
            return referencesForImplementation;
        }

        private static Activity GetRoot(Activity activity, out bool isImplementation)
        {
            isImplementation = false;
            Activity activity2 = null;
            if (activity == null)
            {
                return activity2;
            }
            if (activity.MemberOf == null)
            {
                throw FxTrace.Exception.Argument("activity", System.Activities.SR.ActivityIsUncached);
            }
            LocationReferenceEnvironment parentEnvironment = activity.GetParentEnvironment();
            isImplementation = activity.MemberOf != activity.RootActivity.MemberOf;
            return parentEnvironment.Root;
        }

        internal static bool LanguagesAreEqual(string left, string right) => 
            string.Equals(left, right, StringComparison.OrdinalIgnoreCase);

        private static void SetCollection<T>(object target, AttachableMemberIdentifier property, IList<T> collection)
        {
            if (collection == null)
            {
                AttachablePropertyServices.RemoveProperty(target, property);
            }
            else
            {
                if (collection is Array)
                {
                    collection = new Collection<T>(collection);
                }
                AttachablePropertyServices.SetProperty(target, property, collection);
            }
        }

        public static void SetNamespaces(object target, IList<string> namespaces)
        {
            SetCollection<string>(target, namespacesProperty, namespaces);
        }

        public static void SetNamespaces(object target, params string[] namespaces)
        {
            SetCollection<string>(target, namespacesProperty, namespaces);
        }

        public static void SetNamespacesForImplementation(object target, IList<string> namespaces)
        {
            SetCollection<string>(target, namespacesForImplementationProperty, namespaces);
        }

        public static void SetNamespacesForImplementation(object target, params string[] namespaces)
        {
            SetCollection<string>(target, namespacesForImplementationProperty, namespaces);
        }

        public static void SetReferences(object target, IList<AssemblyReference> references)
        {
            SetCollection<AssemblyReference>(target, referencesProperty, references);
        }

        public static void SetReferences(object target, params AssemblyReference[] references)
        {
            SetCollection<AssemblyReference>(target, referencesProperty, references);
        }

        public static void SetReferencesForImplementation(object target, IList<AssemblyReference> references)
        {
            SetCollection<AssemblyReference>(target, referencesForImplementationProperty, references);
        }

        public static void SetReferencesForImplementation(object target, params AssemblyReference[] references)
        {
            SetCollection<AssemblyReference>(target, referencesForImplementationProperty, references);
        }

        private static bool ShouldSerializeCollection<T>(object target, AttachableMemberIdentifier property) => 
            AttachablePropertyServices.TryGetProperty<IList<T>>(target, property, out IList<T> list) && (list.Count > 0);

        public static bool ShouldSerializeNamespaces(object target) => 
            ShouldSerializeCollection<string>(target, namespacesProperty);

        public static bool ShouldSerializeNamespacesForImplementation(object target) => 
            !(target is Activity) && ShouldSerializeCollection<string>(target, namespacesForImplementationProperty);

        public static bool ShouldSerializeReferences(object target) => 
            ShouldSerializeCollection<AssemblyReference>(target, referencesProperty);

        public static bool ShouldSerializeReferencesForImplementation(object target) => 
            !(target is Activity) && ShouldSerializeCollection<AssemblyReference>(target, referencesForImplementationProperty);

        public static IList<string> DefaultNamespaces =>
            defaultNamespaces;

        public static IList<AssemblyReference> DefaultReferences =>
            defaultReferences;
    }
}

