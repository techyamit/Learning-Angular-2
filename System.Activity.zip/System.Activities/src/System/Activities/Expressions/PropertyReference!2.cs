﻿namespace System.Activities.Expressions
{
    using System;
    using System.Activities;
    using System.ComponentModel;
    using System.Reflection;
    using System.Runtime;
    using System.Runtime.CompilerServices;
    using System.Runtime.Serialization;
    using System.Threading;

    public sealed class PropertyReference<TOperand, TResult> : CodeActivity<Location<TResult>>
    {
        private PropertyInfo propertyInfo;
        private Func<object, object[], object> getFunc;
        private Func<object, object[], object> setFunc;
        private MethodInfo getMethod;
        private MethodInfo setMethod;
        private static MruCache<MethodInfo, Func<object, object[], object>> funcCache;
        private static ReaderWriterLockSlim locker;

        static PropertyReference()
        {
            PropertyReference<TOperand, TResult>.funcCache = new MruCache<MethodInfo, Func<object, object[], object>>(500);
            PropertyReference<TOperand, TResult>.locker = new ReaderWriterLockSlim();
        }

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            MethodInfo getMethod = this.getMethod;
            MethodInfo setMethod = this.setMethod;
            bool isRequired = false;
            if (typeof(TOperand).IsEnum)
            {
                metadata.AddValidationError(System.Activities.SR.TargetTypeCannotBeEnum(base.GetType().Name, base.DisplayName));
            }
            else if (typeof(TOperand).IsValueType)
            {
                metadata.AddValidationError(System.Activities.SR.TargetTypeIsValueType(base.GetType().Name, base.DisplayName));
            }
            if (string.IsNullOrEmpty(this.PropertyName))
            {
                metadata.AddValidationError(System.Activities.SR.ActivityPropertyMustBeSet("PropertyName", base.DisplayName));
            }
            else
            {
                this.propertyInfo = typeof(TOperand).GetProperty(this.PropertyName);
                if (this.propertyInfo == null)
                {
                    metadata.AddValidationError(System.Activities.SR.MemberNotFound(this.PropertyName, typeof(TOperand).Name));
                }
                else
                {
                    this.getMethod = this.propertyInfo.GetGetMethod();
                    this.setMethod = this.propertyInfo.GetSetMethod();
                    if ((this.setMethod == null) && !TypeHelper.AreTypesCompatible(this.propertyInfo.DeclaringType, typeof(System.Activities.Location)))
                    {
                        metadata.AddValidationError(System.Activities.SR.ReadonlyPropertyCannotBeSet(this.propertyInfo.DeclaringType, this.propertyInfo.Name));
                    }
                    if (((this.getMethod != null) && !this.getMethod.IsStatic) || ((this.setMethod != null) && !this.setMethod.IsStatic))
                    {
                        isRequired = true;
                    }
                }
            }
            MemberExpressionHelper.AddOperandArgument<TOperand>(metadata, this.Operand, isRequired);
            if (this.propertyInfo != null)
            {
                if (MethodCallExpressionHelper.NeedRetrieve(this.getMethod, getMethod, this.getFunc))
                {
                    this.getFunc = MethodCallExpressionHelper.GetFunc(metadata, this.getMethod, PropertyReference<TOperand, TResult>.funcCache, PropertyReference<TOperand, TResult>.locker, false);
                }
                if (MethodCallExpressionHelper.NeedRetrieve(this.setMethod, setMethod, this.setFunc))
                {
                    this.setFunc = MethodCallExpressionHelper.GetFunc(metadata, this.setMethod, PropertyReference<TOperand, TResult>.funcCache, PropertyReference<TOperand, TResult>.locker, false);
                }
            }
        }

        protected override Location<TResult> Execute(CodeActivityContext context) => 
            new PropertyLocation<TOperand, TResult, TResult>(this.propertyInfo, this.getFunc, this.setFunc, this.Operand.Get(context));

        [DefaultValue((string) null)]
        public string PropertyName { get; set; }

        public InArgument<TOperand> Operand { get; set; }

        [DataContract]
        internal class PropertyLocation<T> : Location<T>
        {
            private object owner;
            private PropertyInfo propertyInfo;
            private Func<object, object[], object> getFunc;
            private Func<object, object[], object> setFunc;

            public PropertyLocation(PropertyInfo propertyInfo, Func<object, object[], object> getFunc, Func<object, object[], object> setFunc, object owner)
            {
                this.propertyInfo = propertyInfo;
                this.owner = owner;
                this.getFunc = getFunc;
                this.setFunc = setFunc;
            }

            public override T Value
            {
                get
                {
                    if (this.getFunc != null)
                    {
                        if (!this.propertyInfo.GetGetMethod().IsStatic && (this.owner == null))
                        {
                            throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.NullReferencedMemberAccess(this.propertyInfo.DeclaringType.Name, this.propertyInfo.Name)));
                        }
                        return this.getFunc(this.owner, new object[0]);
                    }
                    if ((this.propertyInfo.GetGetMethod() == null) && !TypeHelper.AreTypesCompatible(this.propertyInfo.DeclaringType, typeof(System.Activities.Location)))
                    {
                        throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.WriteonlyPropertyCannotBeRead(this.propertyInfo.DeclaringType, this.propertyInfo.Name)));
                    }
                    return (T) this.propertyInfo.GetValue(this.owner, null);
                }
                set
                {
                    if (this.setFunc != null)
                    {
                        if (!this.propertyInfo.GetSetMethod().IsStatic && (this.owner == null))
                        {
                            throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.NullReferencedMemberAccess(this.propertyInfo.DeclaringType.Name, this.propertyInfo.Name)));
                        }
                        object[] objArray1 = new object[] { value };
                        this.setFunc(this.owner, objArray1);
                    }
                    else
                    {
                        this.propertyInfo.SetValue(this.owner, value, null);
                    }
                }
            }

            [DataMember(EmitDefaultValue=false, Name="owner")]
            internal object SerializedOwner
            {
                get => 
                    this.owner;
                set => 
                    this.owner = value;
            }

            [DataMember(Name="propertyInfo")]
            internal PropertyInfo SerializedPropertyInfo
            {
                get => 
                    this.propertyInfo;
                set => 
                    this.propertyInfo = value;
            }
        }
    }
}

