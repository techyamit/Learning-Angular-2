﻿namespace System.Activities.Expressions
{
    using System;
    using System.Linq.Expressions;
    using System.Reflection;
    using System.Security.Permissions;

    internal static class OperatorPermissionHelper
    {
        internal static Expression InjectReflectionPermissionIfNecessary(MethodInfo method, Expression expression)
        {
            if (method == null)
            {
                return expression;
            }
            if (method.IsPublic)
            {
                return expression;
            }
            ReflectionPermission permission = new ReflectionPermission(ReflectionPermissionFlag.MemberAccess);
            Expression expression2 = Expression.Call((Expression) Expression.Constant(permission), "Demand", (Type[]) null, (Expression[]) null);
            Expression[] expressions = new Expression[] { expression2, expression };
            return Expression.Block(expression.Type, expressions);
        }
    }
}

