﻿namespace System.Activities.Expressions
{
    using System;
    using System.Activities;
    using System.Activities.DynamicUpdate;
    using System.Activities.Statements;
    using System.ComponentModel;
    using System.Linq.Expressions;
    using System.Reflection;
    using System.Runtime.CompilerServices;

    public sealed class OrElse : Activity<bool>
    {
        public OrElse()
        {
            this.Implementation = delegate {
                if ((this.Left != null) && (this.Right != null))
                {
                    ParameterExpression expression;
                    If @if = new If {
                        Condition = this.Left
                    };
                    Assign<bool> assign = new Assign<bool>();
                    Expression[] arguments = new Expression[] { expression = Expression.Parameter(typeof(ActivityContext), "context") };
                    ParameterExpression[] parameters = new ParameterExpression[] { expression };
                    assign.To = new OutArgument<bool>(Expression.Lambda<Func<ActivityContext, bool>>(Expression.Call(Expression.Property(Expression.Constant(this, typeof(OrElse)), (MethodInfo) methodof(Activity<bool>.get_Result, Activity<bool>)), (MethodInfo) methodof(OutArgument<bool>.Get, OutArgument<bool>), arguments), parameters));
                    assign.Value = 1;
                    @if.Then = assign;
                    assign = new Assign<bool>();
                    Expression[] expressionArray3 = new Expression[] { expression = Expression.Parameter(typeof(ActivityContext), "context") };
                    ParameterExpression[] expressionArray4 = new ParameterExpression[] { expression };
                    assign.To = new OutArgument<bool>(Expression.Lambda<Func<ActivityContext, bool>>(Expression.Call(Expression.Property(Expression.Constant(this, typeof(OrElse)), (MethodInfo) methodof(Activity<bool>.get_Result, Activity<bool>)), (MethodInfo) methodof(OutArgument<bool>.Get, OutArgument<bool>), expressionArray3), expressionArray4));
                    assign.Value = new InArgument<bool>(this.Right);
                    @if.Else = assign;
                    return @if;
                }
                return null;
            };
        }

        protected override void CacheMetadata(ActivityMetadata metadata)
        {
            metadata.AddImportedChild(this.Left);
            metadata.AddImportedChild(this.Right);
            if (this.Left == null)
            {
                metadata.AddValidationError(System.Activities.SR.BinaryExpressionActivityRequiresArgument("Left", "OrElse", base.DisplayName));
            }
            if (this.Right == null)
            {
                metadata.AddValidationError(System.Activities.SR.BinaryExpressionActivityRequiresArgument("Right", "OrElse", base.DisplayName));
            }
        }

        protected override void OnCreateDynamicUpdateMap(UpdateMapMetadata metadata, Activity originalActivity)
        {
            metadata.AllowUpdateInsideThisActivity();
        }

        [DefaultValue((string) null)]
        public Activity<bool> Left { get; set; }

        [DefaultValue((string) null)]
        public Activity<bool> Right { get; set; }
    }
}

