﻿namespace System.Activities.Expressions
{
    using System;
    using System.Activities;
    using System.Activities.XamlIntegration;
    using System.Collections;
    using System.ComponentModel;
    using System.Globalization;
    using System.IO;
    using System.Reflection;
    using System.Runtime.CompilerServices;

    [TypeConverter(typeof(AssemblyReferenceConverter))]
    public class AssemblyReference
    {
        private const int AssemblyToAssemblyNameCacheInitSize = 100;
        private const int AssemblyCacheInitialSize = 100;
        private static object assemblyToAssemblyNameCacheLock = new object();
        private static volatile Hashtable assemblyToAssemblyNameCache;
        private static volatile Hashtable assemblyCache;
        private static object assemblyCacheLock = new object();
        private System.Reflection.Assembly assembly;
        private System.Reflection.AssemblyName assemblyName;
        private bool isImmutable;

        public AssemblyReference()
        {
        }

        internal AssemblyReference(System.Reflection.Assembly assembly, System.Reflection.AssemblyName assemblyName)
        {
            this.assembly = assembly;
            this.assemblyName = assemblyName;
            this.isImmutable = true;
        }

        internal static bool AssemblySatisfiesReference(System.Reflection.AssemblyName assemblyName, System.Reflection.AssemblyName reference)
        {
            if (reference.Name != assemblyName.Name)
            {
                return false;
            }
            if ((reference.Version != null) && !reference.Version.Equals(assemblyName.Version))
            {
                return false;
            }
            if ((reference.CultureInfo != null) && !reference.CultureInfo.Equals(assemblyName.CultureInfo))
            {
                return false;
            }
            byte[] publicKeyToken = reference.GetPublicKeyToken();
            if (publicKeyToken != null)
            {
                byte[] curKeyToken = assemblyName.GetPublicKeyToken();
                if (!AssemblyNameEqualityComparer.IsSameKeyToken(publicKeyToken, curKeyToken))
                {
                    return false;
                }
            }
            return true;
        }

        internal static System.Reflection.Assembly GetAssembly(System.Reflection.AssemblyName assemblyName)
        {
            if (assemblyCache == null)
            {
                object assemblyCacheLock = AssemblyReference.assemblyCacheLock;
                lock (assemblyCacheLock)
                {
                    if (assemblyCache == null)
                    {
                        assemblyCache = new Hashtable(100, new AssemblyNameEqualityComparer());
                    }
                }
            }
            System.Reflection.Assembly assembly = assemblyCache[assemblyName] as System.Reflection.Assembly;
            if (assembly == null)
            {
                System.Reflection.Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
                for (int i = assemblies.Length - 1; i >= 0; i--)
                {
                    System.Reflection.Assembly assembly2 = assemblies[i];
                    if (!assembly2.IsDynamic)
                    {
                        System.Reflection.AssemblyName fastAssemblyName = GetFastAssemblyName(assembly2);
                        Version version = fastAssemblyName.Version;
                        CultureInfo cultureInfo = fastAssemblyName.CultureInfo;
                        byte[] publicKeyToken = fastAssemblyName.GetPublicKeyToken();
                        Version version2 = assemblyName.Version;
                        CultureInfo info2 = assemblyName.CultureInfo;
                        byte[] reqKeyToken = assemblyName.GetPublicKeyToken();
                        if ((((string.Compare(fastAssemblyName.Name, assemblyName.Name, StringComparison.OrdinalIgnoreCase) == 0) && ((version2 == null) || version2.Equals(version))) && ((info2 == null) || info2.Equals(cultureInfo))) && ((reqKeyToken == null) || AssemblyNameEqualityComparer.IsSameKeyToken(reqKeyToken, publicKeyToken)))
                        {
                            object obj3 = AssemblyReference.assemblyCacheLock;
                            lock (obj3)
                            {
                                assemblyCache[assemblyName] = assembly2;
                                return assembly2;
                            }
                        }
                    }
                }
                assembly = LoadAssembly(assemblyName);
                if (assembly == null)
                {
                    return assembly;
                }
                object assemblyCacheLock = AssemblyReference.assemblyCacheLock;
                lock (assemblyCacheLock)
                {
                    assemblyCache[assemblyName] = assembly;
                }
            }
            return assembly;
        }

        internal static System.Reflection.AssemblyName GetFastAssemblyName(System.Reflection.Assembly assembly)
        {
            if (assembly.IsDynamic)
            {
                return new System.Reflection.AssemblyName(assembly.FullName);
            }
            if (assemblyToAssemblyNameCache == null)
            {
                object assemblyToAssemblyNameCacheLock = AssemblyReference.assemblyToAssemblyNameCacheLock;
                lock (assemblyToAssemblyNameCacheLock)
                {
                    if (assemblyToAssemblyNameCache == null)
                    {
                        assemblyToAssemblyNameCache = new Hashtable(100);
                    }
                }
            }
            System.Reflection.AssemblyName name = assemblyToAssemblyNameCache[assembly] as System.Reflection.AssemblyName;
            if (name == null)
            {
                name = new System.Reflection.AssemblyName(assembly.FullName);
                object assemblyToAssemblyNameCacheLock = AssemblyReference.assemblyToAssemblyNameCacheLock;
                lock (assemblyToAssemblyNameCacheLock)
                {
                    assemblyToAssemblyNameCache[assembly] = name;
                }
            }
            return name;
        }

        public void LoadAssembly()
        {
            if ((this.AssemblyName != null) && ((this.assembly == null) || !this.isImmutable))
            {
                this.assembly = GetAssembly(this.AssemblyName);
            }
        }

        private static System.Reflection.Assembly LoadAssembly(System.Reflection.AssemblyName assemblyName)
        {
            System.Reflection.Assembly assembly = null;
            byte[] publicKeyToken = assemblyName.GetPublicKeyToken();
            if (((assemblyName.Version != null) || (assemblyName.CultureInfo != null)) || (publicKeyToken != null))
            {
                try
                {
                    assembly = System.Reflection.Assembly.Load(assemblyName.FullName);
                }
                catch (Exception exception)
                {
                    if ((!(exception is FileNotFoundException) && !(exception is FileLoadException)) && (!(exception is TargetInvocationException) || (!(((TargetInvocationException) exception).InnerException is FileNotFoundException) && !(((TargetInvocationException) exception).InnerException is FileNotFoundException))))
                    {
                        throw;
                    }
                    assembly = null;
                    FxTrace.Exception.AsWarning(exception);
                    return assembly;
                }
                return assembly;
            }
            return System.Reflection.Assembly.LoadWithPartialName(assemblyName.FullName);
        }

        public static implicit operator AssemblyReference(System.Reflection.Assembly assembly) => 
            new AssemblyReference { Assembly = assembly };

        public static implicit operator AssemblyReference(System.Reflection.AssemblyName assemblyName) => 
            new AssemblyReference { AssemblyName = assemblyName };

        private void ThrowIfImmutable()
        {
            if (this.isImmutable)
            {
                throw FxTrace.Exception.AsError(new NotSupportedException(System.Activities.SR.AssemblyReferenceIsImmutable));
            }
        }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public System.Reflection.Assembly Assembly
        {
            get => 
                this.assembly;
            set
            {
                this.ThrowIfImmutable();
                this.assembly = value;
            }
        }

        public System.Reflection.AssemblyName AssemblyName
        {
            get => 
                this.assemblyName;
            set
            {
                this.ThrowIfImmutable();
                this.assemblyName = value;
            }
        }
    }
}

