﻿namespace System.Activities.Expressions
{
    using System.Activities;

    internal interface ILocationReferenceWrapper
    {
        System.Activities.LocationReference LocationReference { get; }
    }
}

