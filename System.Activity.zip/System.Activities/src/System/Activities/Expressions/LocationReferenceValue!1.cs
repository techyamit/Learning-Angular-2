﻿namespace System.Activities.Expressions
{
    using System;
    using System.Activities;

    internal sealed class LocationReferenceValue<T> : CodeActivity<T>, IExpressionContainer, ILocationReferenceWrapper, ILocationReferenceExpression
    {
        private LocationReference locationReference;

        internal LocationReferenceValue(LocationReference locationReference)
        {
            base.UseOldFastPath = true;
            this.locationReference = locationReference;
        }

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
        }

        protected override T Execute(CodeActivityContext context)
        {
            T local;
            try
            {
                context.AllowChainedEnvironmentAccess = true;
                local = context.GetValue<T>(this.locationReference);
            }
            finally
            {
                context.AllowChainedEnvironmentAccess = false;
            }
            return local;
        }

        ActivityWithResult ILocationReferenceExpression.CreateNewInstance(LocationReference locationReference) => 
            new LocationReferenceValue<T>(locationReference);

        LocationReference ILocationReferenceWrapper.LocationReference =>
            this.locationReference;
    }
}

