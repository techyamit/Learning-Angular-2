﻿namespace System.Activities.Expressions
{
    using System;
    using System.Activities;

    public class EnvironmentLocationValue<T> : CodeActivity<T>, IExpressionContainer, ILocationReferenceExpression
    {
        private System.Activities.LocationReference locationReference;

        internal EnvironmentLocationValue()
        {
            base.UseOldFastPath = true;
        }

        internal EnvironmentLocationValue(System.Activities.LocationReference locationReference) : this()
        {
            this.locationReference = locationReference;
        }

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
        }

        protected override T Execute(CodeActivityContext context)
        {
            T local;
            try
            {
                context.AllowChainedEnvironmentAccess = true;
                local = context.GetValue<T>(this.LocationReference);
            }
            finally
            {
                context.AllowChainedEnvironmentAccess = false;
            }
            return local;
        }

        ActivityWithResult ILocationReferenceExpression.CreateNewInstance(System.Activities.LocationReference locationReference) => 
            new EnvironmentLocationValue<T>(locationReference);

        public virtual System.Activities.LocationReference LocationReference =>
            this.locationReference;
    }
}

