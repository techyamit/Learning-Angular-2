﻿namespace System.Activities.Expressions
{
    using System;
    using System.Activities;
    using System.Collections.ObjectModel;
    using System.Reflection;
    using System.Runtime;
    using System.Runtime.Collections;
    using System.Runtime.CompilerServices;
    using System.Threading;
    using System.Windows.Markup;

    [ContentProperty("Arguments")]
    public sealed class New<TResult> : CodeActivity<TResult>
    {
        private Collection<Argument> arguments;
        private Func<object[], TResult> function;
        private ConstructorInfo constructorInfo;
        private static MruCache<ConstructorInfo, Func<object[], TResult>> funcCache;
        private static ReaderWriterLockSlim locker;

        static New()
        {
            New<TResult>.funcCache = new MruCache<ConstructorInfo, Func<object[], TResult>>(500);
            New<TResult>.locker = new ReaderWriterLockSlim();
        }

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            bool flag = false;
            ConstructorInfo constructorInfo = this.constructorInfo;
            Type[] types = new Type[this.Arguments.Count];
            for (int i = 0; i < this.Arguments.Count; i++)
            {
                Argument argument = this.Arguments[i];
                if ((argument == null) || (argument.Expression == null))
                {
                    metadata.AddValidationError(System.Activities.SR.ArgumentRequired("Arguments", typeof(New<TResult>)));
                    flag = true;
                }
                else
                {
                    RuntimeArgument argument2 = new RuntimeArgument("Argument" + i, this.arguments[i].ArgumentType, this.arguments[i].Direction, true);
                    metadata.Bind(this.arguments[i], argument2);
                    metadata.AddArgument(argument2);
                    types[i] = (this.Arguments[i].Direction == ArgumentDirection.In) ? this.Arguments[i].ArgumentType : this.Arguments[i].ArgumentType.MakeByRefType();
                }
            }
            if (!flag)
            {
                this.constructorInfo = typeof(TResult).GetConstructor(types);
                if ((this.constructorInfo == null) && (!typeof(TResult).IsValueType || (types.Length != 0)))
                {
                    metadata.AddValidationError(System.Activities.SR.ConstructorInfoNotFound(typeof(TResult).Name));
                }
                else if ((this.constructorInfo != constructorInfo) || (this.function == null))
                {
                    this.function = MethodCallExpressionHelper.GetFunc<TResult>(metadata, this.constructorInfo, New<TResult>.funcCache, New<TResult>.locker);
                }
            }
        }

        protected override TResult Execute(CodeActivityContext context)
        {
            object[] arg = new object[this.Arguments.Count];
            for (int i = 0; i < this.Arguments.Count; i++)
            {
                arg[i] = this.Arguments[i].Get(context);
            }
            TResult local = this.function(arg);
            for (int j = 0; j < this.Arguments.Count; j++)
            {
                Argument argument = this.Arguments[j];
                if ((argument.Direction == ArgumentDirection.InOut) || (argument.Direction == ArgumentDirection.Out))
                {
                    argument.Set(context, arg[j]);
                }
            }
            return local;
        }

        public Collection<Argument> Arguments
        {
            get
            {
                if (this.arguments == null)
                {
                    ValidatingCollection<Argument> collection1 = new ValidatingCollection<Argument> {
                        OnAddValidationCallback = delegate (Argument item) {
                            if (item == null)
                            {
                                throw FxTrace.Exception.ArgumentNull("item");
                            }
                        }
                    };
                    this.arguments = collection1;
                }
                return this.arguments;
            }
        }

        [Serializable, CompilerGenerated]
        private sealed class <>c
        {
            public static readonly New<TResult>.<>c <>9;
            public static Action<Argument> <>9__6_0;

            static <>c()
            {
                New<TResult>.<>c.<>9 = new New<TResult>.<>c();
            }

            internal void <get_Arguments>b__6_0(Argument item)
            {
                if (item == null)
                {
                    throw FxTrace.Exception.ArgumentNull("item");
                }
            }
        }
    }
}

