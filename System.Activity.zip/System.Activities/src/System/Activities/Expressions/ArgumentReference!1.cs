﻿namespace System.Activities.Expressions
{
    using System;
    using System.Activities;
    using System.Runtime.CompilerServices;

    public sealed class ArgumentReference<T> : EnvironmentLocationReference<T>
    {
        private RuntimeArgument targetArgument;

        public ArgumentReference()
        {
        }

        public ArgumentReference(string argumentName)
        {
            this.ArgumentName = argumentName;
        }

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            this.targetArgument = null;
            if (string.IsNullOrEmpty(this.ArgumentName))
            {
                metadata.AddValidationError(System.Activities.SR.ArgumentNameRequired);
            }
            else
            {
                this.targetArgument = ActivityUtilities.FindArgument(this.ArgumentName, this);
                if (this.targetArgument == null)
                {
                    metadata.AddValidationError(System.Activities.SR.ArgumentNotFound(this.ArgumentName));
                }
                else if (this.targetArgument.Type != typeof(T))
                {
                    metadata.AddValidationError(System.Activities.SR.ArgumentTypeMustBeCompatible(this.ArgumentName, this.targetArgument.Type, typeof(T)));
                }
            }
        }

        public override string ToString()
        {
            if (!string.IsNullOrEmpty(this.ArgumentName))
            {
                return this.ArgumentName;
            }
            return base.ToString();
        }

        public string ArgumentName { get; set; }

        public override System.Activities.LocationReference LocationReference =>
            this.targetArgument;
    }
}

