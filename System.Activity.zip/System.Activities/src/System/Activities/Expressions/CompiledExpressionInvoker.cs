﻿namespace System.Activities.Expressions
{
    using System;
    using System.Activities;
    using System.Activities.XamlIntegration;
    using System.Collections.Generic;
    using System.Linq.Expressions;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Xaml;

    public class CompiledExpressionInvoker
    {
        private static readonly AttachableMemberIdentifier compiledExpressionRootProperty = new AttachableMemberIdentifier(typeof(CompiledExpressionInvoker), "CompiledExpressionRoot");
        private static readonly AttachableMemberIdentifier compiledExpressionRootForImplementationProperty = new AttachableMemberIdentifier(typeof(CompiledExpressionInvoker), "CompiledExpressionRootForImplementation");
        private int expressionId;
        private Activity expressionActivity;
        private bool isReference;
        private ITextExpression textExpression;
        private Activity metadataRoot;
        private ICompiledExpressionRoot compiledRoot;
        private IList<LocationReference> locationReferences;
        private CodeActivityMetadata metadata;
        private CodeActivityPublicEnvironmentAccessor accessor;

        public CompiledExpressionInvoker(ITextExpression expression, bool isReference, CodeActivityMetadata metadata)
        {
            if (expression == null)
            {
                throw FxTrace.Exception.ArgumentNull("expression");
            }
            this.expressionId = -1;
            this.textExpression = expression;
            this.expressionActivity = expression as Activity;
            this.isReference = isReference;
            this.locationReferences = new List<LocationReference>();
            this.metadata = metadata;
            this.accessor = CodeActivityPublicEnvironmentAccessor.Create(this.metadata);
            if (this.expressionActivity == null)
            {
                throw FxTrace.Exception.Argument("expression", System.Activities.SR.ITextExpressionParameterMustBeActivity);
            }
            ActivityWithResult expressionActivity = this.expressionActivity as ActivityWithResult;
            this.metadataRoot = metadata.Environment.Root;
            this.ProcessLocationReferences();
        }

        private bool CanExecuteExpression(ICompiledExpressionRoot compiledExpressionRoot, out int expressionId) => 
            compiledExpressionRoot.CanExecuteExpression(this.textExpression.ExpressionText, this.isReference, this.locationReferences, out expressionId);

        private void CreateRequiredArguments(IList<string> requiredLocationNames)
        {
            if ((requiredLocationNames != null) && (requiredLocationNames.Count > 0))
            {
                foreach (string str in requiredLocationNames)
                {
                    LocationReference sourceReference = this.FindLocationReference(str);
                    if (sourceReference != null)
                    {
                        if (this.isReference)
                        {
                            this.accessor.CreateLocationArgument(sourceReference, true);
                        }
                        else
                        {
                            this.accessor.CreateArgument(sourceReference, ArgumentDirection.In, true);
                        }
                    }
                }
            }
        }

        private bool FindCompiledExpressionRoot(out int exprId, out ICompiledExpressionRoot compiledExpressionRoot)
        {
            for (Activity activity = this.metadata.CurrentActivity.Parent; activity != null; activity = activity.Parent)
            {
                ICompiledExpressionRoot root = null;
                if (TryGetCompiledExpressionRoot(this.metadata.CurrentActivity, activity, out root) && this.CanExecuteExpression(root, out exprId))
                {
                    compiledExpressionRoot = root;
                    return true;
                }
            }
            exprId = -1;
            compiledExpressionRoot = null;
            return false;
        }

        private LocationReference FindLocationReference(string name)
        {
            LocationReference result = null;
            for (LocationReferenceEnvironment environment = this.accessor.ActivityMetadata.Environment; environment != null; environment = environment.Parent)
            {
                if (environment.TryGetLocationReference(name, out result))
                {
                    return result;
                }
            }
            return result;
        }

        public static object GetCompiledExpressionRoot(object target)
        {
            object obj2 = null;
            AttachablePropertyServices.TryGetProperty(target, compiledExpressionRootProperty, out obj2);
            return obj2;
        }

        public static object GetCompiledExpressionRootForImplementation(object target)
        {
            object obj2 = null;
            AttachablePropertyServices.TryGetProperty(target, compiledExpressionRootForImplementationProperty, out obj2);
            return obj2;
        }

        internal Expression GetExpressionTree()
        {
            if (((this.compiledRoot == null) || (this.expressionId < 0)) && !this.TryGetCompiledExpressionRootAtDesignTime(this.expressionActivity, this.metadataRoot, out this.compiledRoot, out this.expressionId))
            {
                return null;
            }
            return this.compiledRoot.GetExpressionTreeForExpression(this.expressionId, this.locationReferences);
        }

        public object InvokeExpression(ActivityContext activityContext)
        {
            if (activityContext == null)
            {
                throw FxTrace.Exception.ArgumentNull("activityContext");
            }
            if ((((this.compiledRoot == null) || (this.expressionId < 0)) && (!TryGetCompiledExpressionRoot(this.expressionActivity, this.metadataRoot, out this.compiledRoot) || !this.CanExecuteExpression(this.compiledRoot, out this.expressionId))) && !this.TryGetCurrentCompiledExpressionRoot(activityContext, out this.compiledRoot, out this.expressionId))
            {
                throw FxTrace.Exception.AsError(new NotSupportedException(System.Activities.SR.TextExpressionMetadataRequiresCompilation(this.expressionActivity.GetType().Name)));
            }
            return this.compiledRoot.InvokeExpression(this.expressionId, this.locationReferences, activityContext);
        }

        private void ProcessLocationReferences()
        {
            Stack<LocationReferenceEnvironment> stack = new Stack<LocationReferenceEnvironment>();
            for (LocationReferenceEnvironment environment = this.accessor.ActivityMetadata.Environment; environment != null; environment = environment.Parent)
            {
                stack.Push(environment);
            }
            foreach (LocationReferenceEnvironment environment2 in stack)
            {
                foreach (LocationReference reference in environment2.GetLocationReferences())
                {
                    if (this.textExpression.RequiresCompilation)
                    {
                        this.accessor.CreateLocationArgument(reference, false);
                    }
                    this.locationReferences.Add(new InlinedLocationReference(reference, this.metadata.CurrentActivity));
                }
            }
            if (this.TryGetCompiledExpressionRootAtDesignTime(this.expressionActivity, this.metadataRoot, out this.compiledRoot, out this.expressionId))
            {
                this.IsStaticallyCompiled = true;
                if (!this.textExpression.RequiresCompilation)
                {
                    IList<string> requiredLocations = this.compiledRoot.GetRequiredLocations(this.expressionId);
                    this.CreateRequiredArguments(requiredLocations);
                }
            }
        }

        public static void SetCompiledExpressionRoot(object target, ICompiledExpressionRoot compiledExpressionRoot)
        {
            if (compiledExpressionRoot == null)
            {
                AttachablePropertyServices.RemoveProperty(target, compiledExpressionRootProperty);
            }
            else
            {
                AttachablePropertyServices.SetProperty(target, compiledExpressionRootProperty, compiledExpressionRoot);
            }
        }

        public static void SetCompiledExpressionRootForImplementation(object target, ICompiledExpressionRoot compiledExpressionRoot)
        {
            if (compiledExpressionRoot == null)
            {
                AttachablePropertyServices.RemoveProperty(target, compiledExpressionRootForImplementationProperty);
            }
            else
            {
                AttachablePropertyServices.SetProperty(target, compiledExpressionRootForImplementationProperty, compiledExpressionRoot);
            }
        }

        internal static bool TryGetCompiledExpressionRoot(Activity expression, Activity target, out ICompiledExpressionRoot compiledExpressionRoot)
        {
            bool forImplementation = expression.MemberOf != expression.RootActivity.MemberOf;
            return TryGetCompiledExpressionRoot(target, forImplementation, out compiledExpressionRoot);
        }

        internal static bool TryGetCompiledExpressionRoot(Activity target, bool forImplementation, out ICompiledExpressionRoot compiledExpressionRoot)
        {
            if (!forImplementation)
            {
                compiledExpressionRoot = GetCompiledExpressionRoot(target) as ICompiledExpressionRoot;
                if (compiledExpressionRoot != null)
                {
                    return true;
                }
            }
            if (target is ICompiledExpressionRoot)
            {
                compiledExpressionRoot = (ICompiledExpressionRoot) target;
                return true;
            }
            compiledExpressionRoot = GetCompiledExpressionRootForImplementation(target) as ICompiledExpressionRoot;
            if (compiledExpressionRoot != null)
            {
                return true;
            }
            compiledExpressionRoot = null;
            return false;
        }

        private bool TryGetCompiledExpressionRootAtDesignTime(Activity expression, Activity target, out ICompiledExpressionRoot compiledExpressionRoot, out int exprId)
        {
            exprId = -1;
            compiledExpressionRoot = null;
            return ((TryGetCompiledExpressionRoot(expression, target, out compiledExpressionRoot) && this.CanExecuteExpression(compiledExpressionRoot, out exprId)) || this.FindCompiledExpressionRoot(out exprId, out compiledExpressionRoot));
        }

        private bool TryGetCurrentCompiledExpressionRoot(ActivityContext activityContext, out ICompiledExpressionRoot compiledExpressionRoot, out int expressionId)
        {
            for (System.Activities.ActivityInstance instance = activityContext.CurrentInstance; (instance != null) && (instance.Activity != this.metadataRoot); instance = instance.Parent)
            {
                ICompiledExpressionRoot root = null;
                if (TryGetCompiledExpressionRoot(instance.Activity, true, out root) && this.CanExecuteExpression(root, out expressionId))
                {
                    compiledExpressionRoot = root;
                    return true;
                }
            }
            compiledExpressionRoot = null;
            expressionId = -1;
            return false;
        }

        public bool IsStaticallyCompiled { get; private set; }
    }
}

