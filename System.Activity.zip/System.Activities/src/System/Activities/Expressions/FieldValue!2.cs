﻿namespace System.Activities.Expressions
{
    using System;
    using System.Activities;
    using System.Activities.Validation;
    using System.ComponentModel;
    using System.Reflection;
    using System.Runtime.CompilerServices;

    public sealed class FieldValue<TOperand, TResult> : CodeActivity<TResult>
    {
        private Func<TOperand, TResult> operationFunction;
        private bool isOperationFunctionStatic;

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            bool isRequired = false;
            if (typeof(TOperand).IsEnum)
            {
                metadata.AddValidationError(System.Activities.SR.TargetTypeCannotBeEnum(base.GetType().Name, base.DisplayName));
            }
            if (string.IsNullOrEmpty(this.FieldName))
            {
                metadata.AddValidationError(System.Activities.SR.ActivityPropertyMustBeSet("FieldName", base.DisplayName));
            }
            else
            {
                FieldInfo field = null;
                field = typeof(TOperand).GetField(this.FieldName);
                if (field == null)
                {
                    metadata.AddValidationError(System.Activities.SR.MemberNotFound(this.FieldName, typeof(TOperand).Name));
                }
                else
                {
                    this.isOperationFunctionStatic = field.IsStatic;
                    isRequired = !this.isOperationFunctionStatic;
                    if (!MemberExpressionHelper.TryGenerateLinqDelegate<TOperand, TResult>(this.FieldName, true, this.isOperationFunctionStatic, out this.operationFunction, out ValidationError error))
                    {
                        metadata.AddValidationError(error);
                    }
                }
            }
            MemberExpressionHelper.AddOperandArgument<TOperand>(metadata, this.Operand, isRequired);
        }

        protected override TResult Execute(CodeActivityContext context)
        {
            TOperand arg = this.Operand.Get(context);
            if (!this.isOperationFunctionStatic && (arg == null))
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.MemberCannotBeNull("Operand", base.GetType().Name, base.DisplayName)));
            }
            return this.operationFunction(arg);
        }

        [DefaultValue((string) null)]
        public string FieldName { get; set; }

        [DefaultValue((string) null)]
        public InArgument<TOperand> Operand { get; set; }
    }
}

