﻿namespace System.Activities.Expressions
{
    using System;
    using System.Activities;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Linq.Expressions;
    using System.Reflection;
    using System.Runtime;
    using System.Runtime.InteropServices;
    using System.Threading;

    internal static class MethodCallExpressionHelper
    {
        public const int FuncCacheCapacity = 500;

        private static Expression ComposeBlockExpression(Collection<ParameterExpression> variables, Collection<Expression> assignVariables, Expression callExpression, Collection<Expression> assignVariablesBack, Type returnType, bool isConstructor, bool valueTypeReference)
        {
            Collection<Expression> collection = new Collection<Expression>();
            foreach (Expression expression3 in assignVariables)
            {
                collection.Add(expression3);
            }
            ParameterExpression item = Expression.Parameter(isConstructor ? returnType : typeof(object), "result");
            variables.Add(item);
            if (returnType != typeof(void))
            {
                Expression expression4 = null;
                if (!isConstructor && returnType.IsValueType)
                {
                    expression4 = Expression.Assign(item, Expression.Convert(callExpression, typeof(object)));
                }
                else
                {
                    expression4 = Expression.Assign(item, callExpression);
                }
                collection.Add(expression4);
            }
            else
            {
                collection.Add(callExpression);
            }
            foreach (Expression expression5 in assignVariablesBack)
            {
                collection.Add(expression5);
            }
            if (!valueTypeReference)
            {
                collection.Add(item);
            }
            return Expression.Block((IEnumerable<ParameterExpression>) variables, (IEnumerable<Expression>) collection);
        }

        private static Expression ComposeLinqExpression<TResult>(ConstructorInfo constructorInfo, ParameterExpression objectArray)
        {
            NewExpression expression;
            Collection<Expression> assignVariablesExpressions = new Collection<Expression>();
            Collection<Expression> assignVariablesBackExpressions = new Collection<Expression>();
            Collection<ParameterExpression> variables = new Collection<ParameterExpression>();
            PrepareForVariables(constructorInfo, objectArray, variables, assignVariablesExpressions, assignVariablesBackExpressions);
            if (constructorInfo != null)
            {
                expression = Expression.New(constructorInfo, (IEnumerable<Expression>) variables);
            }
            else
            {
                expression = Expression.New(typeof(TResult));
            }
            return ComposeBlockExpression(variables, assignVariablesExpressions, expression, assignVariablesBackExpressions, typeof(TResult), true, false);
        }

        private static Expression ComposeLinqExpression(MethodInfo methodInfo, ParameterExpression targetInstance, ParameterExpression objectArray, Type returnType, bool valueTypeReference)
        {
            Expression expression3;
            Collection<Expression> assignVariablesExpressions = new Collection<Expression>();
            Collection<Expression> assignVariablesBackExpressions = new Collection<Expression>();
            Collection<ParameterExpression> variables = new Collection<ParameterExpression>();
            PrepareForVariables(methodInfo, objectArray, variables, assignVariablesExpressions, assignVariablesBackExpressions);
            ParameterExpression tempInstance = null;
            Expression assignTempInstanceExpression = null;
            if ((!methodInfo.IsStatic && methodInfo.DeclaringType.IsValueType) & valueTypeReference)
            {
                expression3 = PrepareForCallExpression(methodInfo, targetInstance, variables, out tempInstance, out assignTempInstanceExpression);
                variables.Add(tempInstance);
                assignVariablesExpressions.Add(assignTempInstanceExpression);
                assignVariablesBackExpressions.Add(Expression.Assign(targetInstance, Expression.Convert(tempInstance, typeof(object))));
                return ComposeBlockExpression(variables, assignVariablesExpressions, expression3, assignVariablesBackExpressions, returnType, false, true);
            }
            expression3 = PrepareForCallExpression(methodInfo, targetInstance, variables);
            return ComposeBlockExpression(variables, assignVariablesExpressions, expression3, assignVariablesBackExpressions, returnType, false, false);
        }

        private static Func<object[], TResult> GetFunc<TResult>(CodeActivityMetadata metadata, ConstructorInfo constructorInfo)
        {
            try
            {
                ParameterExpression expression;
                ParameterExpression[] parameters = new ParameterExpression[] { expression };
                return Expression.Lambda<Func<object[], TResult>>(ComposeLinqExpression<TResult>(constructorInfo, expression = Expression.Parameter(typeof(object[]), "arguments")), parameters).Compile();
            }
            catch (Exception exception)
            {
                if (Fx.IsFatal(exception))
                {
                    throw;
                }
                metadata.AddValidationError(exception.Message);
                return null;
            }
        }

        private static Func<object, object[], object> GetFunc(CodeActivityMetadata metadata, MethodInfo methodInfo, bool valueTypeReference = false)
        {
            try
            {
                ParameterExpression expression;
                ParameterExpression expression2;
                ParameterExpression[] parameters = new ParameterExpression[] { expression, expression2 };
                return Expression.Lambda<Func<object, object[], object>>(ComposeLinqExpression(methodInfo, expression = Expression.Parameter(typeof(object), "targetInstance"), expression2 = Expression.Parameter(typeof(object[]), "arguments"), methodInfo.ReturnType, valueTypeReference), parameters).Compile();
            }
            catch (Exception exception)
            {
                if (Fx.IsFatal(exception))
                {
                    throw;
                }
                metadata.AddValidationError(exception.Message);
                return null;
            }
        }

        internal static Func<object[], TResult> GetFunc<TResult>(CodeActivityMetadata metadata, ConstructorInfo constructorInfo, MruCache<ConstructorInfo, Func<object[], TResult>> cache, ReaderWriterLockSlim locker)
        {
            Func<object[], TResult> func = null;
            if (constructorInfo != null)
            {
                locker.EnterWriteLock();
                try
                {
                    cache.TryGetValue(constructorInfo, out func);
                }
                finally
                {
                    locker.ExitWriteLock();
                }
            }
            if (func == null)
            {
                func = GetFunc<TResult>(metadata, constructorInfo);
                if (constructorInfo == null)
                {
                    return func;
                }
                locker.EnterWriteLock();
                try
                {
                    Func<object[], TResult> func2 = null;
                    if (!cache.TryGetValue(constructorInfo, out func2))
                    {
                        cache.Add(constructorInfo, func);
                        return func;
                    }
                    func = func2;
                }
                finally
                {
                    locker.ExitWriteLock();
                }
            }
            return func;
        }

        internal static Func<object, object[], object> GetFunc(CodeActivityMetadata metadata, MethodInfo methodInfo, MruCache<MethodInfo, Func<object, object[], object>> cache, ReaderWriterLockSlim locker, bool valueTypeReference = false)
        {
            Func<object, object[], object> func = null;
            locker.EnterWriteLock();
            try
            {
                cache.TryGetValue(methodInfo, out func);
            }
            finally
            {
                locker.ExitWriteLock();
            }
            if (func == null)
            {
                func = GetFunc(metadata, methodInfo, valueTypeReference);
                locker.EnterWriteLock();
                try
                {
                    Func<object, object[], object> func2 = null;
                    if (!cache.TryGetValue(methodInfo, out func2))
                    {
                        cache.Add(methodInfo, func);
                        return func;
                    }
                    func = func2;
                }
                finally
                {
                    locker.ExitWriteLock();
                }
            }
            return func;
        }

        internal static bool NeedRetrieve(MethodBase newMethod, MethodBase oldMethod, Delegate func)
        {
            if (newMethod == null)
            {
                return false;
            }
            if ((newMethod == oldMethod) && (func != null))
            {
                return false;
            }
            return true;
        }

        private static MethodCallExpression PrepareForCallExpression(MethodInfo methodInfo, ParameterExpression targetInstance, Collection<ParameterExpression> variables)
        {
            if (!methodInfo.IsStatic)
            {
                return Expression.Call(Expression.Convert(targetInstance, methodInfo.DeclaringType), methodInfo, (IEnumerable<Expression>) variables);
            }
            return Expression.Call(methodInfo, (IEnumerable<Expression>) variables);
        }

        private static MethodCallExpression PrepareForCallExpression(MethodInfo methodInfo, ParameterExpression targetInstance, Collection<ParameterExpression> variables, out ParameterExpression tempInstance, out Expression assignTempInstanceExpression)
        {
            tempInstance = null;
            assignTempInstanceExpression = null;
            if (!methodInfo.IsStatic)
            {
                if (methodInfo.DeclaringType.IsValueType)
                {
                    tempInstance = Expression.Parameter(methodInfo.DeclaringType, "tempInstance");
                    assignTempInstanceExpression = Expression.Assign(tempInstance, Expression.Convert(targetInstance, methodInfo.DeclaringType));
                    return Expression.Call(tempInstance, methodInfo, (IEnumerable<Expression>) variables);
                }
                return Expression.Call(Expression.Convert(targetInstance, methodInfo.DeclaringType), methodInfo, (IEnumerable<Expression>) variables);
            }
            return Expression.Call(methodInfo, (IEnumerable<Expression>) variables);
        }

        private static void PrepareForVariables(MethodBase methodInfo, ParameterExpression objectArray, Collection<ParameterExpression> variables, Collection<Expression> assignVariablesExpressions, Collection<Expression> assignVariablesBackExpressions)
        {
            if (methodInfo != null)
            {
                ParameterInfo[] parameters = methodInfo.GetParameters();
                for (int i = 0; i < parameters.Length; i++)
                {
                    Type parameterType = parameters[i].ParameterType;
                    ParameterExpression left = Expression.Parameter(parameterType.IsByRef ? parameterType.GetElementType() : parameterType, "arg" + i);
                    if (left.Type.IsValueType && (Nullable.GetUnderlyingType(left.Type) == null))
                    {
                        Type[] types = new Type[] { typeof(object), typeof(Type) };
                        assignVariablesExpressions.Add(Expression.Assign(left, Expression.Convert(Expression.Call(typeof(Convert).GetMethod("ChangeType", types), Expression.ArrayIndex(objectArray, Expression.Constant(i)), Expression.Constant(left.Type, typeof(Type))), left.Type)));
                    }
                    else
                    {
                        assignVariablesExpressions.Add(Expression.Assign(left, Expression.Convert(Expression.ArrayIndex(objectArray, Expression.Constant(i)), left.Type)));
                    }
                    if (parameterType.IsByRef)
                    {
                        if (left.Type.IsValueType)
                        {
                            Expression[] indexes = new Expression[] { Expression.Constant(i) };
                            assignVariablesBackExpressions.Add(Expression.Assign(Expression.ArrayAccess(objectArray, indexes), Expression.Convert(left, typeof(object))));
                        }
                        else
                        {
                            Expression[] indexes = new Expression[] { Expression.Constant(i) };
                            assignVariablesBackExpressions.Add(Expression.Assign(Expression.ArrayAccess(objectArray, indexes), left));
                        }
                    }
                    variables.Add(left);
                }
            }
        }
    }
}

