﻿namespace System.Activities.Expressions
{
    using System;
    using System.Linq.Expressions;

    public interface ITextExpression
    {
        Expression GetExpressionTree();

        string ExpressionText { get; }

        string Language { get; }

        bool RequiresCompilation { get; }
    }
}

