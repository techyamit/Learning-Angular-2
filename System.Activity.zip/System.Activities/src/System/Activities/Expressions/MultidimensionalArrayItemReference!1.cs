﻿namespace System.Activities.Expressions
{
    using System;
    using System.Activities;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.Runtime;
    using System.Runtime.Collections;
    using System.Runtime.CompilerServices;
    using System.Runtime.Serialization;
    using System.Windows.Markup;

    [ContentProperty("Indices")]
    public sealed class MultidimensionalArrayItemReference<TItem> : CodeActivity<Location<TItem>>
    {
        private Collection<InArgument<int>> indices;

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (this.Indices.Count == 0)
            {
                metadata.AddValidationError(System.Activities.SR.IndicesAreNeeded(base.GetType().Name, base.DisplayName));
            }
            RuntimeArgument argument = new RuntimeArgument("Array", typeof(System.Array), ArgumentDirection.In, true);
            metadata.Bind(this.Array, argument);
            metadata.AddArgument(argument);
            for (int i = 0; i < this.Indices.Count; i++)
            {
                RuntimeArgument argument3 = new RuntimeArgument("Index_" + i, typeof(int), ArgumentDirection.In, true);
                metadata.Bind(this.Indices[i], argument3);
                metadata.AddArgument(argument3);
            }
            RuntimeArgument argument2 = new RuntimeArgument("Result", typeof(Location<TItem>), ArgumentDirection.Out);
            metadata.Bind(base.Result, argument2);
            metadata.AddArgument(argument2);
        }

        protected override Location<TItem> Execute(CodeActivityContext context)
        {
            System.Array array = this.Array.Get(context);
            if (array == null)
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.MemberCannotBeNull("Array", base.GetType().Name, base.DisplayName)));
            }
            Type elementType = array.GetType().GetElementType();
            if (!TypeHelper.AreTypesCompatible(typeof(TItem), elementType))
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidCastException(System.Activities.SR.IncompatibleTypeForMultidimensionalArrayItemReference(typeof(TItem).Name, elementType.Name)));
            }
            int[] indices = new int[this.Indices.Count];
            for (int i = 0; i < this.Indices.Count; i++)
            {
                indices[i] = this.Indices[i].Get(context);
            }
            return new MultidimensionArrayLocation<TItem>(array, indices);
        }

        [RequiredArgument, DefaultValue((string) null)]
        public InArgument<System.Array> Array { get; set; }

        [DefaultValue((string) null)]
        public Collection<InArgument<int>> Indices
        {
            get
            {
                if (this.indices == null)
                {
                    ValidatingCollection<InArgument<int>> collection1 = new ValidatingCollection<InArgument<int>> {
                        OnAddValidationCallback = delegate (InArgument<int> item) {
                            if (item == null)
                            {
                                throw System.Activities.FxTrace.Exception.ArgumentNull("item");
                            }
                        }
                    };
                    this.indices = collection1;
                }
                return this.indices;
            }
        }

        [Serializable, CompilerGenerated]
        private sealed class <>c
        {
            public static readonly MultidimensionalArrayItemReference<TItem>.<>c <>9;
            public static Action<InArgument<int>> <>9__6_0;

            static <>c()
            {
                MultidimensionalArrayItemReference<TItem>.<>c.<>9 = new MultidimensionalArrayItemReference<TItem>.<>c();
            }

            internal void <get_Indices>b__6_0(InArgument<int> item)
            {
                if (item == null)
                {
                    throw System.Activities.FxTrace.Exception.ArgumentNull("item");
                }
            }
        }

        [DataContract]
        internal class MultidimensionArrayLocation : Location<TItem>
        {
            private Array array;
            private int[] indices;

            public MultidimensionArrayLocation(Array array, int[] indices)
            {
                this.array = array;
                this.indices = indices;
            }

            public override TItem Value
            {
                get => 
                    (TItem) this.array.GetValue(this.indices);
                set => 
                    this.array.SetValue(value, this.indices);
            }

            [DataMember(Name="array")]
            internal Array Serializedarray
            {
                get => 
                    this.array;
                set => 
                    this.array = value;
            }

            [DataMember(EmitDefaultValue=false, Name="indices")]
            internal int[] SerializedIndices
            {
                get => 
                    this.indices;
                set => 
                    this.indices = value;
            }
        }
    }
}

