﻿namespace System.Activities.Expressions
{
    using System;
    using System.Activities;
    using System.Activities.XamlIntegration;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Runtime;
    using System.Runtime.CompilerServices;
    using System.Text.RegularExpressions;
    using System.Windows.Markup;

    [DebuggerStepThrough, ContentProperty("Value")]
    public sealed class Literal<T> : CodeActivity<T>, IExpressionContainer, IValueSerializableExpression
    {
        private static Regex ExpressionEscapeRegex;

        static Literal()
        {
            Literal<T>.ExpressionEscapeRegex = new Regex(@"^(%*\[)");
        }

        public Literal()
        {
            base.UseOldFastPath = true;
        }

        public Literal(T value) : this()
        {
            this.Value = value;
        }

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            Type type = typeof(T);
            if (!type.IsValueType && (type != TypeHelper.StringType))
            {
                metadata.AddValidationError(System.Activities.SR.LiteralsMustBeValueTypesOrImmutableTypes(TypeHelper.StringType, type));
            }
        }

        public bool CanConvertToString(IValueSerializerContext context)
        {
            if (this.Value != null)
            {
                Type type = typeof(T);
                Type type2 = this.Value.GetType();
                if (type2 == TypeHelper.StringType)
                {
                    string str = this.Value as string;
                    if (string.IsNullOrEmpty(str))
                    {
                        return false;
                    }
                }
                TypeConverter converter = TypeDescriptor.GetConverter(type);
                if ((!(type == type2) || (converter == null)) || (!converter.CanConvertTo(TypeHelper.StringType) || !converter.CanConvertFrom(TypeHelper.StringType)))
                {
                    return false;
                }
                if (type2 == typeof(DateTime))
                {
                    DateTime literalValue = (DateTime) this.Value;
                    return Literal<T>.IsShortTimeFormattingSafe(literalValue);
                }
                if (type2 == typeof(DateTimeOffset))
                {
                    DateTimeOffset literalValue = (DateTimeOffset) this.Value;
                    return Literal<T>.IsShortTimeFormattingSafe(literalValue);
                }
            }
            return true;
        }

        public string ConvertToString(IValueSerializerContext context)
        {
            if (this.Value == null)
            {
                return "[Nothing]";
            }
            Type type = typeof(T);
            Type type2 = this.Value.GetType();
            TypeConverter converter = TypeDescriptor.GetConverter(type);
            if (type == TypeHelper.StringType)
            {
                string input = Convert.ToString(this.Value);
                if (input.EndsWith("]", StringComparison.Ordinal) && Literal<T>.ExpressionEscapeRegex.IsMatch(input))
                {
                    return ("%" + input);
                }
            }
            return converter.ConvertToString(context, this.Value);
        }

        protected override T Execute(CodeActivityContext context) => 
            this.Value;

        private static bool IsShortTimeFormattingSafe(DateTime literalValue)
        {
            if (((literalValue.Second == 0) && (literalValue.Millisecond == 0)) && (literalValue.Kind == DateTimeKind.Unspecified))
            {
                DateTime time = new DateTime(literalValue.Year, literalValue.Month, literalValue.Day, literalValue.Hour, literalValue.Minute, literalValue.Second, literalValue.Millisecond, literalValue.Kind);
                if (literalValue.Ticks == time.Ticks)
                {
                    return true;
                }
            }
            return false;
        }

        private static bool IsShortTimeFormattingSafe(DateTimeOffset literalValue) => 
            Literal<T>.IsShortTimeFormattingSafe(literalValue.DateTime);

        [EditorBrowsable(EditorBrowsableState.Never)]
        public bool ShouldSerializeValue() => 
            !Equals(this.Value, default(T));

        public override string ToString()
        {
            if (this.Value != null)
            {
                return this.Value.ToString();
            }
            return "null";
        }

        public T Value { get; set; }
    }
}

