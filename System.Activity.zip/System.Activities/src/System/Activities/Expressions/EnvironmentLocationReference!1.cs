﻿namespace System.Activities.Expressions
{
    using System;
    using System.Activities;

    public class EnvironmentLocationReference<T> : CodeActivity<Location<T>>, IExpressionContainer, ILocationReferenceExpression
    {
        private System.Activities.LocationReference locationReference;

        internal EnvironmentLocationReference()
        {
            base.UseOldFastPath = true;
        }

        internal EnvironmentLocationReference(System.Activities.LocationReference locationReference) : this()
        {
            this.locationReference = locationReference;
        }

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
        }

        protected sealed override Location<T> Execute(CodeActivityContext context)
        {
            Location<T> location;
            try
            {
                context.AllowChainedEnvironmentAccess = true;
                location = context.GetLocation<T>(this.LocationReference);
            }
            finally
            {
                context.AllowChainedEnvironmentAccess = false;
            }
            return location;
        }

        ActivityWithResult ILocationReferenceExpression.CreateNewInstance(System.Activities.LocationReference locationReference) => 
            new EnvironmentLocationReference<T>(locationReference);

        public virtual System.Activities.LocationReference LocationReference =>
            this.locationReference;
    }
}

