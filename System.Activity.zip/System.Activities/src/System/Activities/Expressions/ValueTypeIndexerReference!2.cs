﻿namespace System.Activities.Expressions
{
    using System;
    using System.Activities;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.Reflection;
    using System.Runtime;
    using System.Runtime.Collections;
    using System.Runtime.CompilerServices;
    using System.Runtime.Serialization;
    using System.Threading;
    using System.Windows.Markup;

    [ContentProperty("Indices")]
    public sealed class ValueTypeIndexerReference<TOperand, TItem> : CodeActivity<Location<TItem>>
    {
        private Collection<InArgument> indices;
        private MethodInfo getMethod;
        private MethodInfo setMethod;
        private Func<object, object[], object> getFunc;
        private Func<object, object[], object> setFunc;
        private static MruCache<MethodInfo, Func<object, object[], object>> funcCache;
        private static ReaderWriterLockSlim locker;

        static ValueTypeIndexerReference()
        {
            ValueTypeIndexerReference<TOperand, TItem>.funcCache = new MruCache<MethodInfo, Func<object, object[], object>>(500);
            ValueTypeIndexerReference<TOperand, TItem>.locker = new ReaderWriterLockSlim();
        }

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            MethodInfo getMethod = this.getMethod;
            MethodInfo setMethod = this.setMethod;
            if (!typeof(TOperand).IsValueType)
            {
                metadata.AddValidationError(System.Activities.SR.TypeMustbeValueType(typeof(TOperand).Name));
            }
            if (this.Indices.Count == 0)
            {
                metadata.AddValidationError(System.Activities.SR.IndicesAreNeeded(base.GetType().Name, base.DisplayName));
            }
            else
            {
                IndexerHelper.CacheMethod<TOperand, TItem>(this.Indices, ref this.getMethod, ref this.setMethod);
                if (this.setMethod == null)
                {
                    metadata.AddValidationError(System.Activities.SR.SpecialMethodNotFound("set_Item", typeof(TOperand).Name));
                }
            }
            RuntimeArgument argument = new RuntimeArgument("OperandLocation", typeof(TOperand), ArgumentDirection.InOut, true);
            metadata.Bind(this.OperandLocation, argument);
            metadata.AddArgument(argument);
            IndexerHelper.OnGetArguments<TItem>(this.Indices, base.Result, metadata);
            if (MethodCallExpressionHelper.NeedRetrieve(this.getMethod, getMethod, this.getFunc))
            {
                this.getFunc = MethodCallExpressionHelper.GetFunc(metadata, this.getMethod, ValueTypeIndexerReference<TOperand, TItem>.funcCache, ValueTypeIndexerReference<TOperand, TItem>.locker, false);
            }
            if (MethodCallExpressionHelper.NeedRetrieve(this.setMethod, setMethod, this.setFunc))
            {
                this.setFunc = MethodCallExpressionHelper.GetFunc(metadata, this.setMethod, ValueTypeIndexerReference<TOperand, TItem>.funcCache, ValueTypeIndexerReference<TOperand, TItem>.locker, true);
            }
        }

        protected override Location<TItem> Execute(CodeActivityContext context)
        {
            object[] indices = new object[this.Indices.Count];
            for (int i = 0; i < this.Indices.Count; i++)
            {
                indices[i] = this.Indices[i].Get(context);
            }
            return new IndexerLocation<TOperand, TItem>(this.OperandLocation.GetLocation(context), indices, this.getMethod, this.setMethod, this.getFunc, this.setFunc);
        }

        [RequiredArgument, DefaultValue((string) null)]
        public InOutArgument<TOperand> OperandLocation { get; set; }

        [RequiredArgument, DefaultValue((string) null)]
        public Collection<InArgument> Indices
        {
            get
            {
                if (this.indices == null)
                {
                    ValidatingCollection<InArgument> collection1 = new ValidatingCollection<InArgument> {
                        OnAddValidationCallback = delegate (InArgument item) {
                            if (item == null)
                            {
                                throw System.Activities.FxTrace.Exception.ArgumentNull("item");
                            }
                        }
                    };
                    this.indices = collection1;
                }
                return this.indices;
            }
        }

        [Serializable, CompilerGenerated]
        private sealed class <>c
        {
            public static readonly ValueTypeIndexerReference<TOperand, TItem>.<>c <>9;
            public static Action<InArgument> <>9__12_0;

            static <>c()
            {
                ValueTypeIndexerReference<TOperand, TItem>.<>c.<>9 = new ValueTypeIndexerReference<TOperand, TItem>.<>c();
            }

            internal void <get_Indices>b__12_0(InArgument item)
            {
                if (item == null)
                {
                    throw System.Activities.FxTrace.Exception.ArgumentNull("item");
                }
            }
        }

        [DataContract]
        internal class IndexerLocation : Location<TItem>
        {
            private Location<TOperand> operandLocation;
            private object[] indices;
            private object[] parameters;
            private MethodInfo getMethod;
            private MethodInfo setMethod;
            private Func<object, object[], object> getFunc;
            private Func<object, object[], object> setFunc;

            public IndexerLocation(Location<TOperand> operandLocation, object[] indices, MethodInfo getMethod, MethodInfo setMethod, Func<object, object[], object> getFunc, Func<object, object[], object> setFunc)
            {
                this.operandLocation = operandLocation;
                this.indices = indices;
                this.getMethod = getMethod;
                this.setMethod = setMethod;
                this.setFunc = setFunc;
                this.getFunc = getFunc;
            }

            public override TItem Value
            {
                get
                {
                    if (this.getFunc != null)
                    {
                        return (TItem) this.getFunc(this.operandLocation.Value, this.indices);
                    }
                    if (this.getMethod == null)
                    {
                        throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.SpecialMethodNotFound("get_Item", typeof(TOperand).Name)));
                    }
                    return (TItem) this.getMethod.Invoke(this.operandLocation.Value, this.indices);
                }
                set
                {
                    if (this.parameters == null)
                    {
                        this.parameters = new object[this.indices.Length + 1];
                        for (int i = 0; i < this.indices.Length; i++)
                        {
                            this.parameters[i] = this.indices[i];
                        }
                        this.parameters[this.parameters.Length - 1] = value;
                    }
                    object obj2 = this.operandLocation.Value;
                    if (this.setFunc != null)
                    {
                        obj2 = this.setFunc(obj2, this.parameters);
                    }
                    else
                    {
                        this.setMethod.Invoke(obj2, this.parameters);
                    }
                    if (obj2 != null)
                    {
                        this.operandLocation.Value = (TOperand) obj2;
                    }
                }
            }

            [DataMember(EmitDefaultValue=false, Name="operandLocation")]
            internal Location<TOperand> SerializedOperandLocation
            {
                get => 
                    this.operandLocation;
                set => 
                    this.operandLocation = value;
            }

            [DataMember(EmitDefaultValue=false, Name="indices")]
            internal object[] SerializedIndices
            {
                get => 
                    this.indices;
                set => 
                    this.indices = value;
            }

            [DataMember(EmitDefaultValue=false, Name="parameters")]
            internal object[] SerializedParameters
            {
                get => 
                    this.parameters;
                set => 
                    this.parameters = value;
            }

            [DataMember(EmitDefaultValue=false, Name="getMethod")]
            internal MethodInfo SerializedGetMethod
            {
                get => 
                    this.getMethod;
                set => 
                    this.getMethod = value;
            }

            [DataMember(EmitDefaultValue=false, Name="setMethod")]
            internal MethodInfo SerializedSetMethod
            {
                get => 
                    this.setMethod;
                set => 
                    this.setMethod = value;
            }
        }
    }
}

