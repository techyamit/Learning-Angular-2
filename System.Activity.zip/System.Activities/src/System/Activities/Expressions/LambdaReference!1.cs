﻿namespace System.Activities.Expressions
{
    using System;
    using System.Activities;
    using System.Activities.XamlIntegration;
    using System.Diagnostics;
    using System.Linq.Expressions;
    using System.Windows.Markup;

    [DebuggerStepThrough]
    public sealed class LambdaReference<T> : CodeActivity<Location<T>>, IExpressionContainer, IValueSerializableExpression
    {
        private Expression<Func<ActivityContext, T>> locationExpression;
        private Expression<Func<ActivityContext, T>> rewrittenTree;
        private LocationFactory<T> locationFactory;

        public LambdaReference(Expression<Func<ActivityContext, T>> locationExpression)
        {
            if (locationExpression == null)
            {
                throw FxTrace.Exception.ArgumentNull("locationExpression");
            }
            this.locationExpression = locationExpression;
            base.UseOldFastPath = true;
        }

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            CodeActivityPublicEnvironmentAccessor publicAccessor = CodeActivityPublicEnvironmentAccessor.Create(metadata);
            if (ExpressionUtilities.TryRewriteLambdaExpression(this.locationExpression, out Expression expression, publicAccessor, true))
            {
                this.rewrittenTree = (Expression<Func<ActivityContext, T>>) expression;
            }
            else
            {
                this.rewrittenTree = this.locationExpression;
            }
            string extraErrorMessage = null;
            if (!ExpressionUtilities.IsLocation(this.rewrittenTree, typeof(T), out extraErrorMessage))
            {
                string invalidLValueExpression = System.Activities.SR.InvalidLValueExpression;
                if (extraErrorMessage != null)
                {
                    invalidLValueExpression = invalidLValueExpression + ":" + extraErrorMessage;
                }
                metadata.AddValidationError(invalidLValueExpression);
            }
        }

        public bool CanConvertToString(IValueSerializerContext context) => 
            true;

        public string ConvertToString(IValueSerializerContext context)
        {
            throw FxTrace.Exception.AsError(new LambdaSerializationException());
        }

        protected override Location<T> Execute(CodeActivityContext context)
        {
            if (this.locationFactory == null)
            {
                this.locationFactory = ExpressionUtilities.CreateLocationFactory<T>(this.rewrittenTree);
            }
            return this.locationFactory.CreateLocation(context);
        }

        internal Expression LambdaExpression =>
            this.locationExpression;
    }
}

