﻿namespace System.Activities
{
    using System;
    using System.Runtime.CompilerServices;
    using System.Runtime.Serialization;

    public abstract class ActivityWithResult : Activity
    {
        internal ActivityWithResult()
        {
        }

        internal abstract object InternalExecuteInResolutionContextUntyped(CodeActivityContext resolutionContext);

        public Type ResultType =>
            this.InternalResultType;

        [IgnoreDataMember]
        public OutArgument Result
        {
            get => 
                this.ResultCore;
            set => 
                this.ResultCore = value;
        }

        internal abstract Type InternalResultType { get; }

        internal abstract OutArgument ResultCore { get; set; }

        internal RuntimeArgument ResultRuntimeArgument { get; set; }

        internal override bool IsActivityWithResult =>
            true;
    }
}

