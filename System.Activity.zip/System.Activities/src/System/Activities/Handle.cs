﻿namespace System.Activities
{
    using System;
    using System.Runtime.CompilerServices;
    using System.Runtime.Serialization;

    [DataContract]
    public abstract class Handle
    {
        private System.Activities.ActivityInstance owner;
        private bool isUninitialized = true;

        protected Handle()
        {
        }

        internal static string GetPropertyName(Type handleType) => 
            handleType.FullName;

        internal void Initialize(HandleInitializationContext context)
        {
            this.owner = context.OwningActivityInstance;
            this.isUninitialized = false;
            this.OnInitialize(context);
        }

        protected virtual void OnInitialize(HandleInitializationContext context)
        {
        }

        protected virtual void OnUninitialize(HandleInitializationContext context)
        {
        }

        internal void Reinitialize(System.Activities.ActivityInstance owner)
        {
            this.owner = owner;
        }

        protected void ThrowIfUninitialized()
        {
            if (this.isUninitialized)
            {
                throw System.Activities.FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.HandleNotInitialized));
            }
        }

        internal void Uninitialize(HandleInitializationContext context)
        {
            this.OnUninitialize(context);
            this.isUninitialized = true;
        }

        public System.Activities.ActivityInstance Owner =>
            this.owner;

        public string ExecutionPropertyName =>
            base.GetType().FullName;

        [DataMember(EmitDefaultValue=false, Name="owner")]
        internal System.Activities.ActivityInstance SerializedOwner
        {
            get => 
                this.owner;
            set => 
                this.owner = value;
        }

        [DataMember(EmitDefaultValue=false, Name="isUninitialized")]
        internal bool SerializedIsUninitialized
        {
            get => 
                this.isUninitialized;
            set => 
                this.isUninitialized = value;
        }

        [DataMember(EmitDefaultValue=false)]
        internal bool CanBeRemovedWithExecutingChildren { get; set; }

        internal bool IsInitialized =>
            !this.isUninitialized;
    }
}

