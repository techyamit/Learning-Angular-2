﻿namespace System.Activities
{
    using System;
    using System.Runtime.CompilerServices;

    public class ActivityPropertyReference
    {
        public string SourceProperty { get; set; }

        public string TargetProperty { get; set; }
    }
}

