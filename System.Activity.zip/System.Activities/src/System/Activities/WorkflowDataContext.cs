﻿namespace System.Activities
{
    using System;
    using System.Activities.Runtime;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Runtime.CompilerServices;
    using System.Threading;

    public sealed class WorkflowDataContext : CustomTypeDescriptor, INotifyPropertyChanged, IDisposable
    {
        private ActivityExecutor executor;
        private System.Activities.ActivityInstance activityInstance;
        private IDictionary<Location, PropertyDescriptorImpl> locationMapping;
        private System.ComponentModel.PropertyChangedEventHandler propertyChangedEventHandler;
        private PropertyDescriptorCollection properties;
        private ActivityContext cachedResolutionContext;

        [field: CompilerGenerated]
        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        internal WorkflowDataContext(ActivityExecutor executor, System.Activities.ActivityInstance activityInstance, bool includeLocalVariables)
        {
            this.executor = executor;
            this.activityInstance = activityInstance;
            this.IncludesLocalVariables = includeLocalVariables;
            this.properties = this.CreateProperties();
        }

        private void AddNotifyHandler(PropertyDescriptorImpl property)
        {
            using (ActivityContext context = this.ResolutionContext)
            {
                Location key = property.LocationReference.GetLocation(context);
                INotifyPropertyChanged changed = key as INotifyPropertyChanged;
                if (changed != null)
                {
                    changed.PropertyChanged += this.PropertyChangedEventHandler;
                    if (this.locationMapping == null)
                    {
                        this.locationMapping = new Dictionary<Location, PropertyDescriptorImpl>();
                    }
                    this.locationMapping.Add(key, property);
                }
            }
        }

        private void AddProperty(LocationReference reference, Dictionary<string, object> names, List<PropertyDescriptorImpl> propertyList)
        {
            if (!string.IsNullOrEmpty(reference.Name) && !names.ContainsKey(reference.Name))
            {
                names.Add(reference.Name, reference);
                PropertyDescriptorImpl item = new PropertyDescriptorImpl(reference);
                propertyList.Add(item);
                this.AddNotifyHandler(item);
            }
        }

        private PropertyDescriptorCollection CreateProperties()
        {
            Dictionary<string, object> names = new Dictionary<string, object>();
            List<PropertyDescriptorImpl> propertyList = new List<PropertyDescriptorImpl>();
            LocationReferenceEnvironment publicEnvironment = this.activityInstance.Activity.PublicEnvironment;
            for (bool flag = true; publicEnvironment != null; flag = false)
            {
                foreach (LocationReference reference in publicEnvironment.GetLocationReferences())
                {
                    if ((this.IncludesLocalVariables || !flag) || !(reference is Variable))
                    {
                        this.AddProperty(reference, names, propertyList);
                    }
                }
                publicEnvironment = publicEnvironment.Parent;
            }
            return new PropertyDescriptorCollection(propertyList.ToArray(), true);
        }

        public void Dispose()
        {
            if (this.locationMapping != null)
            {
                foreach (KeyValuePair<Location, PropertyDescriptorImpl> pair in this.locationMapping)
                {
                    INotifyPropertyChanged key = pair.Key as INotifyPropertyChanged;
                    if (key != null)
                    {
                        key.PropertyChanged -= this.PropertyChangedEventHandler;
                    }
                }
            }
        }

        internal void DisposeEnvironment()
        {
            this.activityInstance = null;
        }

        public override PropertyDescriptorCollection GetProperties() => 
            this.properties;

        private void OnLocationChanged(object sender, PropertyChangedEventArgs e)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if (propertyChanged != null)
            {
                Location key = (Location) sender;
                if (this.locationMapping.TryGetValue(key, out PropertyDescriptorImpl impl))
                {
                    if (e.PropertyName == "Value")
                    {
                        propertyChanged(this, new PropertyChangedEventArgs(impl.Name));
                    }
                    else
                    {
                        propertyChanged(this, new PropertyChangedEventArgs(impl.Name + "." + e.PropertyName));
                    }
                }
            }
        }

        private void ThrowIfEnvironmentDisposed()
        {
            if (this.activityInstance == null)
            {
                throw FxTrace.Exception.AsError(new ObjectDisposedException(base.GetType().FullName, System.Activities.SR.WDCDisposed));
            }
        }

        internal bool IncludesLocalVariables { get; set; }

        private ActivityContext ResolutionContext
        {
            get
            {
                this.ThrowIfEnvironmentDisposed();
                if (this.cachedResolutionContext == null)
                {
                    this.cachedResolutionContext = new ActivityContext(this.activityInstance, this.executor);
                    this.cachedResolutionContext.AllowChainedEnvironmentAccess = true;
                }
                else
                {
                    this.cachedResolutionContext.Reinitialize(this.activityInstance, this.executor);
                }
                return this.cachedResolutionContext;
            }
        }

        private System.ComponentModel.PropertyChangedEventHandler PropertyChangedEventHandler
        {
            get
            {
                if (this.propertyChangedEventHandler == null)
                {
                    this.propertyChangedEventHandler = new System.ComponentModel.PropertyChangedEventHandler(this.OnLocationChanged);
                }
                return this.propertyChangedEventHandler;
            }
        }

        private class PropertyDescriptorImpl : PropertyDescriptor
        {
            private System.Activities.LocationReference reference;

            public PropertyDescriptorImpl(System.Activities.LocationReference reference) : base(reference.Name, new Attribute[0])
            {
                this.reference = reference;
            }

            public override bool CanResetValue(object component) => 
                false;

            public override object GetValue(object component)
            {
                WorkflowDataContext context = (WorkflowDataContext) component;
                using (ActivityContext context2 = context.ResolutionContext)
                {
                    return this.reference.GetLocation(context2).Value;
                }
            }

            public override void ResetValue(object component)
            {
                throw FxTrace.Exception.AsError(new NotSupportedException(System.Activities.SR.CannotResetPropertyInDataContext));
            }

            public override void SetValue(object component, object value)
            {
                if (this.IsReadOnly)
                {
                    throw FxTrace.Exception.AsError(new NotSupportedException(System.Activities.SR.PropertyReadOnlyInWorkflowDataContext(this.Name)));
                }
                WorkflowDataContext context = (WorkflowDataContext) component;
                using (ActivityContext context2 = context.ResolutionContext)
                {
                    this.reference.GetLocation(context2).Value = value;
                }
            }

            public override bool ShouldSerializeValue(object component) => 
                true;

            public override Type ComponentType =>
                typeof(WorkflowDataContext);

            public override bool IsReadOnly =>
                false;

            public override Type PropertyType =>
                this.reference.Type;

            public System.Activities.LocationReference LocationReference =>
                this.reference;
        }
    }
}

