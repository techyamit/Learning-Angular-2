﻿namespace Microsoft.CSharp.Activities
{
    using System;
    using System.Activities;
    using System.Activities.Expressions;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Linq.Expressions;
    using System.Runtime.CompilerServices;
    using System.Windows.Markup;

    [DebuggerStepThrough, ContentProperty("ExpressionText")]
    public class CSharpValue<TResult> : CodeActivity<TResult>, ITextExpression
    {
        private CompiledExpressionInvoker invoker;

        public CSharpValue()
        {
            base.UseOldFastPath = true;
        }

        public CSharpValue(string expressionText) : this()
        {
            this.ExpressionText = expressionText;
        }

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            this.invoker = new CompiledExpressionInvoker(this, false, metadata);
        }

        protected override TResult Execute(CodeActivityContext context) => 
            (TResult) this.invoker.InvokeExpression(context);

        public Expression GetExpressionTree()
        {
            if (!base.IsMetadataCached)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.ActivityIsUncached));
            }
            return this.invoker.GetExpressionTree();
        }

        public string ExpressionText { get; set; }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Language =>
            "C#";

        public bool RequiresCompilation =>
            true;
    }
}

