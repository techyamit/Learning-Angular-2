﻿namespace Microsoft.VisualBasic.Activities.XamlIntegration
{
    using Microsoft.VisualBasic.Activities;
    using System;
    using System.Activities.Expressions;
    using System.Collections;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Reflection;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Security;
    using System.Text.RegularExpressions;
    using System.Threading;
    using System.Windows.Markup;
    using System.Xaml;
    using System.Xml.Linq;

    internal static class VisualBasicExpressionConverter
    {
        private static readonly Regex assemblyQualifiedNamespaceRegex = new Regex("clr-namespace:(?<namespace>[^;]*);assembly=(?<assembly>.*)", RegexOptions.Compiled | RegexOptions.IgnoreCase);

        public static VisualBasicSettings CollectXmlNamespacesAndAssemblies(ITypeDescriptorContext context)
        {
            IList<Assembly> referenceAssemblies = null;
            IXamlSchemaContextProvider service = context.GetService(typeof(IXamlSchemaContextProvider)) as IXamlSchemaContextProvider;
            if ((service != null) && (service.SchemaContext != null))
            {
                referenceAssemblies = service.SchemaContext.ReferenceAssemblies;
                if ((referenceAssemblies != null) && (referenceAssemblies.Count == 0))
                {
                    referenceAssemblies = null;
                }
            }
            VisualBasicSettings settings = null;
            IXamlNamespaceResolver resolver = (IXamlNamespaceResolver) context.GetService(typeof(IXamlNamespaceResolver));
            if (resolver == null)
            {
                return null;
            }
            object xmlnsMappingsLockObject = AssemblyCache.XmlnsMappingsLockObject;
            lock (xmlnsMappingsLockObject)
            {
                foreach (System.Xaml.NamespaceDeclaration declaration in resolver.GetNamespacePrefixes())
                {
                    WrapCachedMapping(declaration, out ReadOnlyXmlnsMapping mapping);
                    if (!mapping.IsEmpty)
                    {
                        if (settings == null)
                        {
                            settings = new VisualBasicSettings();
                        }
                        if (!mapping.IsEmpty)
                        {
                            foreach (ReadOnlyVisualBasicImportReference reference in mapping.ImportReferences)
                            {
                                if (referenceAssemblies != null)
                                {
                                    VisualBasicImportReference reference2;
                                    if (reference.EarlyBoundAssembly != null)
                                    {
                                        if (referenceAssemblies.Contains(reference.EarlyBoundAssembly))
                                        {
                                            reference2 = reference.Clone();
                                            reference2.EarlyBoundAssembly = reference.EarlyBoundAssembly;
                                            settings.ImportReferences.Add(reference2);
                                        }
                                    }
                                    else
                                    {
                                        for (int i = 0; i < referenceAssemblies.Count; i++)
                                        {
                                            AssemblyName fastAssemblyName = VisualBasicHelper.GetFastAssemblyName(referenceAssemblies[i]);
                                            if (reference.AssemblySatisfiesReference(fastAssemblyName))
                                            {
                                                reference2 = reference.Clone();
                                                reference2.EarlyBoundAssembly = referenceAssemblies[i];
                                                settings.ImportReferences.Add(reference2);
                                                break;
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    VisualBasicImportReference item = reference.Clone();
                                    if (reference.EarlyBoundAssembly != null)
                                    {
                                        item.EarlyBoundAssembly = reference.EarlyBoundAssembly;
                                    }
                                    settings.ImportReferences.Add(item);
                                }
                            }
                        }
                    }
                }
            }
            return settings;
        }

        [SecuritySafeCritical]
        private static void WrapCachedMapping(System.Xaml.NamespaceDeclaration prefix, out ReadOnlyXmlnsMapping readOnlyMapping)
        {
            XmlnsMapping mapping = new XmlnsMapping();
            XNamespace key = XNamespace.Get(prefix.Namespace);
            if (!AssemblyCache.XmlnsMappings.TryGetValue(key, out mapping))
            {
                Match match = assemblyQualifiedNamespaceRegex.Match(prefix.Namespace);
                if (match.Success)
                {
                    mapping.ImportReferences = new System.Collections.Generic.HashSet<VisualBasicImportReference>();
                    VisualBasicImportReference item = new VisualBasicImportReference {
                        Assembly = match.Groups["assembly"].Value,
                        Import = match.Groups["namespace"].Value,
                        Xmlns = key
                    };
                    mapping.ImportReferences.Add(item);
                }
                else
                {
                    mapping.ImportReferences = new System.Collections.Generic.HashSet<VisualBasicImportReference>();
                }
                AssemblyCache.XmlnsMappings[key] = mapping;
            }
            readOnlyMapping = new ReadOnlyXmlnsMapping(mapping);
        }

        private static class AssemblyCache
        {
            private static bool initialized = false;
            public static object XmlnsMappingsLockObject = new object();
            [SecurityCritical]
            private static Dictionary<XNamespace, VisualBasicExpressionConverter.XmlnsMapping> xmlnsMappings;

            [SecurityCritical]
            private static void CacheLoadedAssembly(Assembly assembly)
            {
                XmlnsDefinitionAttribute[] customAttributes = (XmlnsDefinitionAttribute[]) assembly.GetCustomAttributes(typeof(XmlnsDefinitionAttribute), false);
                string fullName = assembly.FullName;
                object xmlnsMappingsLockObject = XmlnsMappingsLockObject;
                lock (xmlnsMappingsLockObject)
                {
                    for (int i = 0; i < customAttributes.Length; i++)
                    {
                        XNamespace key = XNamespace.Get(customAttributes[i].XmlNamespace);
                        if (!xmlnsMappings.TryGetValue(key, out VisualBasicExpressionConverter.XmlnsMapping mapping))
                        {
                            mapping.ImportReferences = new System.Collections.Generic.HashSet<VisualBasicImportReference>();
                            xmlnsMappings[key] = mapping;
                        }
                        VisualBasicImportReference item = new VisualBasicImportReference {
                            Assembly = fullName,
                            Import = customAttributes[i].ClrNamespace,
                            Xmlns = key
                        };
                        item.EarlyBoundAssembly = assembly;
                        mapping.ImportReferences.Add(item);
                    }
                }
            }

            [SecurityCritical]
            private static void EnsureInitialized()
            {
                if (!initialized)
                {
                    if (xmlnsMappings == null)
                    {
                        Interlocked.CompareExchange<Dictionary<XNamespace, VisualBasicExpressionConverter.XmlnsMapping>>(ref xmlnsMappings, new Dictionary<XNamespace, VisualBasicExpressionConverter.XmlnsMapping>(new XNamespaceEqualityComparer()), null);
                    }
                    object xmlnsMappingsLockObject = XmlnsMappingsLockObject;
                    lock (xmlnsMappingsLockObject)
                    {
                        if (!initialized)
                        {
                            AppDomain.CurrentDomain.AssemblyLoad += new AssemblyLoadEventHandler(VisualBasicExpressionConverter.AssemblyCache.OnAssemblyLoaded);
                            foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
                            {
                                if (assembly.IsDefined(typeof(XmlnsDefinitionAttribute), false) && !assembly.IsDynamic)
                                {
                                    CacheLoadedAssembly(assembly);
                                }
                            }
                            initialized = true;
                        }
                    }
                }
            }

            [SecurityCritical]
            private static void OnAssemblyLoaded(object sender, AssemblyLoadEventArgs args)
            {
                Assembly loadedAssembly = args.LoadedAssembly;
                if (loadedAssembly.IsDefined(typeof(XmlnsDefinitionAttribute), false) && !loadedAssembly.IsDynamic)
                {
                    CacheLoadedAssembly(loadedAssembly);
                }
            }

            public static Dictionary<XNamespace, VisualBasicExpressionConverter.XmlnsMapping> XmlnsMappings
            {
                [SecurityCritical]
                get
                {
                    EnsureInitialized();
                    return xmlnsMappings;
                }
            }

            private class XNamespaceEqualityComparer : IEqualityComparer<XNamespace>
            {
                bool IEqualityComparer<XNamespace>.Equals(XNamespace x, XNamespace y) => 
                    x == y;

                int IEqualityComparer<XNamespace>.GetHashCode(XNamespace x) => 
                    x.GetHashCode();
            }
        }

        [StructLayout(LayoutKind.Sequential), SecuritySafeCritical]
        private struct ReadOnlyVisualBasicImportReference
        {
            private readonly VisualBasicImportReference wrappedReference;
            internal ReadOnlyVisualBasicImportReference(VisualBasicImportReference referenceToWrap)
            {
                this.wrappedReference = referenceToWrap;
            }

            internal Assembly EarlyBoundAssembly =>
                this.wrappedReference.EarlyBoundAssembly;
            internal VisualBasicImportReference Clone() => 
                this.wrappedReference.Clone();

            internal bool AssemblySatisfiesReference(AssemblyName assemblyName)
            {
                if (this.wrappedReference.AssemblyName.Name != assemblyName.Name)
                {
                    return false;
                }
                if ((this.wrappedReference.AssemblyName.Version != null) && !this.wrappedReference.AssemblyName.Version.Equals(assemblyName.Version))
                {
                    return false;
                }
                if ((this.wrappedReference.AssemblyName.CultureInfo != null) && !this.wrappedReference.AssemblyName.CultureInfo.Equals(assemblyName.CultureInfo))
                {
                    return false;
                }
                byte[] publicKeyToken = this.wrappedReference.AssemblyName.GetPublicKeyToken();
                if (publicKeyToken != null)
                {
                    byte[] curKeyToken = assemblyName.GetPublicKeyToken();
                    if (!AssemblyNameEqualityComparer.IsSameKeyToken(publicKeyToken, curKeyToken))
                    {
                        return false;
                    }
                }
                return true;
            }

            public override int GetHashCode() => 
                this.wrappedReference.GetHashCode();
        }

        [StructLayout(LayoutKind.Sequential), SecuritySafeCritical]
        private struct ReadOnlyXmlnsMapping
        {
            private VisualBasicExpressionConverter.XmlnsMapping wrappedMapping;
            internal ReadOnlyXmlnsMapping(VisualBasicExpressionConverter.XmlnsMapping mapping)
            {
                this.wrappedMapping = mapping;
            }

            internal bool IsEmpty =>
                this.wrappedMapping.IsEmpty;
            internal IEnumerable<VisualBasicExpressionConverter.ReadOnlyVisualBasicImportReference> ImportReferences =>
                new <get_ImportReferences>d__5(-2) { <>3__<>4__this=this };
            [CompilerGenerated]
            private sealed class <get_ImportReferences>d__5 : IEnumerable<VisualBasicExpressionConverter.ReadOnlyVisualBasicImportReference>, IEnumerable, IEnumerator<VisualBasicExpressionConverter.ReadOnlyVisualBasicImportReference>, IDisposable, IEnumerator
            {
                private int <>1__state;
                private VisualBasicExpressionConverter.ReadOnlyVisualBasicImportReference <>2__current;
                private int <>l__initialThreadId;
                public VisualBasicExpressionConverter.ReadOnlyXmlnsMapping <>4__this;
                public VisualBasicExpressionConverter.ReadOnlyXmlnsMapping <>3__<>4__this;
                private System.Collections.Generic.HashSet<VisualBasicImportReference>.Enumerator <>7__wrap1;

                [DebuggerHidden]
                public <get_ImportReferences>d__5(int <>1__state)
                {
                    this.<>1__state = <>1__state;
                    this.<>l__initialThreadId = Environment.CurrentManagedThreadId;
                }

                private void <>m__Finally1()
                {
                    this.<>1__state = -1;
                    this.<>7__wrap1.Dispose();
                }

                private bool MoveNext()
                {
                    try
                    {
                        int num = this.<>1__state;
                        if (num == 0)
                        {
                            this.<>1__state = -1;
                            this.<>7__wrap1 = this.<>4__this.wrappedMapping.ImportReferences.GetEnumerator();
                            this.<>1__state = -3;
                            while (this.<>7__wrap1.MoveNext())
                            {
                                VisualBasicImportReference current = this.<>7__wrap1.Current;
                                this.<>2__current = new VisualBasicExpressionConverter.ReadOnlyVisualBasicImportReference(current);
                                this.<>1__state = 1;
                                return true;
                            Label_0064:
                                this.<>1__state = -3;
                            }
                            this.<>m__Finally1();
                            this.<>7__wrap1 = new System.Collections.Generic.HashSet<VisualBasicImportReference>.Enumerator();
                            return false;
                        }
                        if (num != 1)
                        {
                            return false;
                        }
                        goto Label_0064;
                    }
                    fault
                    {
                        this.System.IDisposable.Dispose();
                    }
                }

                [DebuggerHidden]
                IEnumerator<VisualBasicExpressionConverter.ReadOnlyVisualBasicImportReference> IEnumerable<VisualBasicExpressionConverter.ReadOnlyVisualBasicImportReference>.GetEnumerator()
                {
                    VisualBasicExpressionConverter.ReadOnlyXmlnsMapping.<get_ImportReferences>d__5 d__;
                    if ((this.<>1__state == -2) && (this.<>l__initialThreadId == Environment.CurrentManagedThreadId))
                    {
                        this.<>1__state = 0;
                        d__ = this;
                    }
                    else
                    {
                        d__ = new VisualBasicExpressionConverter.ReadOnlyXmlnsMapping.<get_ImportReferences>d__5(0);
                    }
                    d__.<>4__this = this.<>3__<>4__this;
                    return d__;
                }

                [DebuggerHidden]
                IEnumerator IEnumerable.GetEnumerator() => 
                    this.System.Collections.Generic.IEnumerable<Microsoft.VisualBasic.Activities.XamlIntegration.VisualBasicExpressionConverter.ReadOnlyVisualBasicImportReference>.GetEnumerator();

                [DebuggerHidden]
                void IEnumerator.Reset()
                {
                    throw new NotSupportedException();
                }

                [DebuggerHidden]
                void IDisposable.Dispose()
                {
                    switch (this.<>1__state)
                    {
                        case -3:
                        case 1:
                            try
                            {
                            }
                            finally
                            {
                                this.<>m__Finally1();
                            }
                            break;
                    }
                }

                VisualBasicExpressionConverter.ReadOnlyVisualBasicImportReference IEnumerator<VisualBasicExpressionConverter.ReadOnlyVisualBasicImportReference>.Current =>
                    this.<>2__current;

                object IEnumerator.Current =>
                    this.<>2__current;
            }
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct XmlnsMapping
        {
            public System.Collections.Generic.HashSet<VisualBasicImportReference> ImportReferences;
            public bool IsEmpty
            {
                get
                {
                    if (this.ImportReferences != null)
                    {
                        return (this.ImportReferences.Count == 0);
                    }
                    return true;
                }
            }
        }
    }
}

