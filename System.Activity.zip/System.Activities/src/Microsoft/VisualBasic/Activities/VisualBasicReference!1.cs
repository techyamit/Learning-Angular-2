﻿namespace Microsoft.VisualBasic.Activities
{
    using System;
    using System.Activities;
    using System.Activities.ExpressionParser;
    using System.Activities.Expressions;
    using System.Activities.XamlIntegration;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Linq.Expressions;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Windows.Markup;

    [DebuggerStepThrough]
    public sealed class VisualBasicReference<TResult> : CodeActivity<Location<TResult>>, IValueSerializableExpression, IExpressionContainer, ITextExpression
    {
        private Expression<Func<ActivityContext, TResult>> expressionTree;
        private LocationFactory<TResult> locationFactory;
        private CompiledExpressionInvoker invoker;

        public VisualBasicReference()
        {
            base.UseOldFastPath = true;
        }

        public VisualBasicReference(string expressionText) : this()
        {
            this.ExpressionText = expressionText;
        }

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            this.expressionTree = null;
            this.invoker = new CompiledExpressionInvoker(this, true, metadata);
            if (!this.invoker.IsStaticallyCompiled)
            {
                CodeActivityPublicEnvironmentAccessor publicAccessor = CodeActivityPublicEnvironmentAccessor.Create(metadata);
                this.expressionTree = this.CompileLocationExpression(publicAccessor, out string str);
                if (str != null)
                {
                    metadata.AddValidationError(str);
                }
            }
        }

        public bool CanConvertToString(IValueSerializerContext context) => 
            true;

        private Expression<Func<ActivityContext, TResult>> CompileLocationExpression(CodeActivityPublicEnvironmentAccessor publicAccessor, out string validationError)
        {
            Expression<Func<ActivityContext, TResult>> expression = null;
            validationError = null;
            try
            {
                expression = VisualBasicHelper.Compile<TResult>(this.ExpressionText, publicAccessor, true);
                string extraErrorMessage = null;
                if (publicAccessor.ActivityMetadata.HasViolations || ((expression != null) && ExpressionUtilities.IsLocation(expression, typeof(TResult), out extraErrorMessage)))
                {
                    return expression;
                }
                string invalidLValueExpression = System.Activities.SR.InvalidLValueExpression;
                if (extraErrorMessage != null)
                {
                    invalidLValueExpression = invalidLValueExpression + ":" + extraErrorMessage;
                }
                expression = null;
                validationError = System.Activities.SR.CompilerErrorSpecificExpression(this.ExpressionText, invalidLValueExpression);
            }
            catch (SourceExpressionException exception)
            {
                validationError = exception.Message;
            }
            return expression;
        }

        public string ConvertToString(IValueSerializerContext context) => 
            "[" + this.ExpressionText + "]";

        protected override Location<TResult> Execute(CodeActivityContext context)
        {
            if (this.invoker.IsStaticallyCompiled)
            {
                return (Location<TResult>) this.invoker.InvokeExpression(context);
            }
            if (this.expressionTree == null)
            {
                return null;
            }
            if (this.locationFactory == null)
            {
                this.locationFactory = ExpressionUtilities.CreateLocationFactory<TResult>(this.expressionTree);
            }
            return this.locationFactory.CreateLocation(context);
        }

        public Expression GetExpressionTree()
        {
            if (!base.IsMetadataCached)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.ActivityIsUncached));
            }
            if (this.expressionTree == null)
            {
                CodeActivityMetadata metadata = new CodeActivityMetadata(this, base.GetParentEnvironment(), false);
                CodeActivityPublicEnvironmentAccessor publicAccessor = CodeActivityPublicEnvironmentAccessor.CreateWithoutArgument(metadata);
                try
                {
                    this.expressionTree = this.CompileLocationExpression(publicAccessor, out string str);
                    if (str != null)
                    {
                        throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.VBExpressionTamperedSinceLastCompiled(str)));
                    }
                }
                finally
                {
                    metadata.Dispose();
                }
            }
            return ExpressionUtilities.RewriteNonCompiledExpressionTree(this.expressionTree);
        }

        public string ExpressionText { get; set; }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Language =>
            VisualBasicHelper.Language;

        public bool RequiresCompilation =>
            false;
    }
}

