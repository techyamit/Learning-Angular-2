﻿namespace Microsoft.VisualBasic.Activities
{
    using System;
    using System.Activities;
    using System.Activities.ExpressionParser;
    using System.Activities.Expressions;
    using System.Activities.XamlIntegration;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Linq.Expressions;
    using System.Runtime.CompilerServices;
    using System.Windows.Markup;

    [DebuggerStepThrough]
    public sealed class VisualBasicValue<TResult> : CodeActivity<TResult>, IValueSerializableExpression, IExpressionContainer, ITextExpression
    {
        private Expression<Func<ActivityContext, TResult>> expressionTree;
        private Func<ActivityContext, TResult> compiledExpression;
        private CompiledExpressionInvoker invoker;

        public VisualBasicValue()
        {
            base.UseOldFastPath = true;
        }

        public VisualBasicValue(string expressionText) : this()
        {
            this.ExpressionText = expressionText;
        }

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            this.expressionTree = null;
            this.invoker = new CompiledExpressionInvoker(this, false, metadata);
            if (!this.invoker.IsStaticallyCompiled)
            {
                CodeActivityPublicEnvironmentAccessor publicAccessor = CodeActivityPublicEnvironmentAccessor.Create(metadata);
                try
                {
                    this.expressionTree = VisualBasicHelper.Compile<TResult>(this.ExpressionText, publicAccessor, false);
                }
                catch (SourceExpressionException exception)
                {
                    metadata.AddValidationError(exception.Message);
                }
            }
        }

        public bool CanConvertToString(IValueSerializerContext context) => 
            true;

        public string ConvertToString(IValueSerializerContext context) => 
            "[" + this.ExpressionText + "]";

        protected override TResult Execute(CodeActivityContext context)
        {
            if (this.invoker.IsStaticallyCompiled)
            {
                return (TResult) this.invoker.InvokeExpression(context);
            }
            if (this.expressionTree == null)
            {
                return default(TResult);
            }
            if (this.compiledExpression == null)
            {
                this.compiledExpression = this.expressionTree.Compile();
            }
            return this.compiledExpression(context);
        }

        public Expression GetExpressionTree()
        {
            if (!base.IsMetadataCached)
            {
                throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.ActivityIsUncached));
            }
            if (this.expressionTree == null)
            {
                CodeActivityMetadata metadata = new CodeActivityMetadata(this, base.GetParentEnvironment(), false);
                CodeActivityPublicEnvironmentAccessor publicAccessor = CodeActivityPublicEnvironmentAccessor.CreateWithoutArgument(metadata);
                try
                {
                    this.expressionTree = VisualBasicHelper.Compile<TResult>(this.ExpressionText, publicAccessor, false);
                }
                catch (SourceExpressionException exception)
                {
                    throw FxTrace.Exception.AsError(new InvalidOperationException(System.Activities.SR.VBExpressionTamperedSinceLastCompiled(exception.Message)));
                }
                finally
                {
                    metadata.Dispose();
                }
            }
            return ExpressionUtilities.RewriteNonCompiledExpressionTree(this.expressionTree);
        }

        public string ExpressionText { get; set; }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Language =>
            VisualBasicHelper.Language;

        public bool RequiresCompilation =>
            false;
    }
}

