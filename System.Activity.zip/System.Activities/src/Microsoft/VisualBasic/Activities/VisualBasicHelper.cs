﻿namespace Microsoft.VisualBasic.Activities
{
    using Microsoft.Compiler.VisualBasic;
    using Microsoft.VisualBasic;
    using System;
    using System.Activities;
    using System.Activities.ExpressionParser;
    using System.Activities.Expressions;
    using System.CodeDom;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Reflection;
    using System.Runtime;
    using System.Runtime.Collections;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Security;
    using System.Security.Permissions;
    using System.Text;
    using System.Threading;

    internal class VisualBasicHelper
    {
        public static readonly HashSet<Assembly> DefaultReferencedAssemblies;
        private const int typeReferenceCacheMaxSize = 100;
        private static object typeReferenceCacheLock;
        private static HopperCache typeReferenceCache;
        private static ulong lastTimestamp;
        private const int rawTreeCacheMaxSize = 0x80;
        private static object rawTreeCacheLock;
        [SecurityCritical]
        private static HopperCache rawTreeCache;
        private const int HostedCompilerCacheSize = 10;
        [SecurityCritical]
        private static Dictionary<HashSet<Assembly>, HostedCompilerWrapper> HostedCompilerCache;
        private string textToCompile;
        private HashSet<Assembly> referencedAssemblies;
        private HashSet<string> namespaceImports;
        private LocationReferenceEnvironment environment;
        private CodeActivityPublicEnvironmentAccessor? publicAccessor;
        private bool isShortCutRewrite;
        private static FindMatch delegateFindLocationReferenceMatchShortcut;
        private static FindMatch delegateFindFirstLocationReferenceMatch;
        private static FindMatch delegateFindAllLocationReferenceMatch;

        static VisualBasicHelper()
        {
            HashSet<Assembly> set = new HashSet<Assembly> {
                typeof(int).Assembly,
                typeof(CodeTypeDeclaration).Assembly,
                typeof(Expression).Assembly,
                typeof(Microsoft.VisualBasic.Strings).Assembly,
                typeof(Activity).Assembly
            };
            DefaultReferencedAssemblies = set;
            typeReferenceCacheLock = new object();
            typeReferenceCache = new HopperCache(100, false);
            lastTimestamp = 0L;
            rawTreeCacheLock = new object();
            delegateFindLocationReferenceMatchShortcut = new FindMatch(VisualBasicHelper.FindLocationReferenceMatchShortcut);
            delegateFindFirstLocationReferenceMatch = new FindMatch(VisualBasicHelper.FindFirstLocationReferenceMatch);
            delegateFindAllLocationReferenceMatch = new FindMatch(VisualBasicHelper.FindAllLocationReferenceMatch);
        }

        private VisualBasicHelper(string expressionText)
        {
            this.textToCompile = expressionText;
        }

        public VisualBasicHelper(string expressionText, HashSet<AssemblyName> refAssemNames, HashSet<string> namespaceImportsNames) : this(expressionText)
        {
            this.Initialize(refAssemNames, namespaceImportsNames);
        }

        [SecuritySafeCritical, PermissionSet(SecurityAction.Demand, Name="FullTrust")]
        private static void AddToRawTreeCache(RawTreeCacheKey rawTreeKey, RawTreeCacheValueWrapper rawTreeHolder, LambdaExpression lambda)
        {
            if (rawTreeHolder != null)
            {
                rawTreeHolder.Value = lambda;
            }
            else
            {
                object rawTreeCacheLock = VisualBasicHelper.rawTreeCacheLock;
                lock (rawTreeCacheLock)
                {
                    if (RawTreeCache.GetValue(VisualBasicHelper.rawTreeCacheLock, rawTreeKey) == null)
                    {
                        RawTreeCacheValueWrapper wrapper1 = new RawTreeCacheValueWrapper {
                            Value = lambda
                        };
                        RawTreeCache.Add(rawTreeKey, wrapper1);
                    }
                }
            }
        }

        public Expression<Func<ActivityContext, T>> Compile<T>(LocationReferenceEnvironment environment) => 
            this.Compile<T>(environment, false);

        public Expression<Func<ActivityContext, T>> Compile<T>(CodeActivityPublicEnvironmentAccessor publicAccessor, bool isLocationReference = false)
        {
            this.publicAccessor = new CodeActivityPublicEnvironmentAccessor?(publicAccessor);
            return this.Compile<T>(publicAccessor.ActivityMetadata.Environment, isLocationReference);
        }

        [SecuritySafeCritical, PermissionSet(SecurityAction.Demand, Name="FullTrust")]
        public Expression<Func<ActivityContext, T>> Compile<T>(LocationReferenceEnvironment environment, bool isLocationReference)
        {
            Expression expression;
            CompilerResults results;
            Type returnType = typeof(T);
            this.environment = environment;
            if (this.referencedAssemblies == null)
            {
                this.referencedAssemblies = new HashSet<Assembly>();
            }
            this.referencedAssemblies.UnionWith(DefaultReferencedAssemblies);
            List<Import> importList = new List<Import>();
            foreach (string str in this.namespaceImports)
            {
                if (!string.IsNullOrEmpty(str))
                {
                    importList.Add(new Import(str));
                }
            }
            RawTreeCacheKey key = new RawTreeCacheKey(this.textToCompile, returnType, this.referencedAssemblies, this.namespaceImports);
            RawTreeCacheValueWrapper rawTreeHolder = RawTreeCache.GetValue(rawTreeCacheLock, key) as RawTreeCacheValueWrapper;
            if (rawTreeHolder != null)
            {
                LambdaExpression expression3 = rawTreeHolder.Value;
                this.isShortCutRewrite = true;
                expression = this.Rewrite(expression3.Body, null, isLocationReference, out bool flag);
                this.isShortCutRewrite = false;
                if (!flag)
                {
                    ParameterExpression[] expressionArray1 = new ParameterExpression[] { FindParameter(expression) ?? ExpressionUtilities.RuntimeContextParameter };
                    return Expression.Lambda<Func<ActivityContext, T>>(expression, expressionArray1);
                }
                if (this.publicAccessor.HasValue)
                {
                    this.publicAccessor.Value.ActivityMetadata.CurrentActivity.ResetTempAutoGeneratedArguments();
                }
            }
            HashSet<Type> typeReferences = null;
            EnsureTypeReferenced(returnType, ref typeReferences);
            foreach (Type type2 in typeReferences)
            {
                this.referencedAssemblies.Add(type2.Assembly);
            }
            VisualBasicScriptAndTypeScope scriptScope = new VisualBasicScriptAndTypeScope(this.environment, this.referencedAssemblies.ToList<Assembly>());
            IImportScope importScope = new VisualBasicImportScope(importList);
            CompilerOptions options = new CompilerOptions {
                OptionStrict = OptionStrictSetting.On
            };
            CompilerContext context = new CompilerContext(scriptScope, scriptScope, importScope, options);
            HostedCompilerWrapper cachedHostedCompiler = GetCachedHostedCompiler(this.referencedAssemblies);
            HostedCompiler compiler = cachedHostedCompiler.Compiler;
            if (TD.CompileVbExpressionStartIsEnabled())
            {
                TD.CompileVbExpressionStart(this.textToCompile);
            }
            try
            {
                HostedCompiler compiler2 = compiler;
                lock (compiler2)
                {
                    try
                    {
                        results = compiler.CompileExpression(this.textToCompile, context, returnType);
                    }
                    catch (Exception exception)
                    {
                        if (Fx.IsFatal(exception))
                        {
                            throw;
                        }
                        FxTrace.Exception.TraceUnhandledException(exception);
                        throw;
                    }
                }
            }
            finally
            {
                cachedHostedCompiler.Release();
            }
            if (TD.CompileVbExpressionStopIsEnabled())
            {
                TD.CompileVbExpressionStop();
            }
            if (scriptScope.ErrorMessage != null)
            {
                throw FxTrace.Exception.AsError(new SourceExpressionException(System.Activities.SR.CompilerErrorSpecificExpression(this.textToCompile, scriptScope.ErrorMessage)));
            }
            if ((results.Errors != null) && (results.Errors.Count > 0))
            {
                StringBuilder builder = new StringBuilder();
                builder.AppendLine();
                foreach (Microsoft.Compiler.VisualBasic.Error error in results.Errors)
                {
                    builder.AppendLine(error.Description);
                }
                throw FxTrace.Exception.AsError(new SourceExpressionException(System.Activities.SR.CompilerErrorSpecificExpression(this.textToCompile, builder.ToString())));
            }
            LambdaExpression codeBlock = results.CodeBlock;
            if (codeBlock == null)
            {
                return null;
            }
            AddToRawTreeCache(key, rawTreeHolder, codeBlock);
            expression = this.Rewrite(codeBlock.Body, null, isLocationReference, out flag);
            ParameterExpression[] parameters = new ParameterExpression[] { FindParameter(expression) ?? ExpressionUtilities.RuntimeContextParameter };
            return Expression.Lambda<Func<ActivityContext, T>>(expression, parameters);
        }

        public static Expression<Func<ActivityContext, T>> Compile<T>(string expressionText, CodeActivityPublicEnvironmentAccessor publicAccessor, bool isLocationExpression)
        {
            GetAllImportReferences(publicAccessor.ActivityMetadata.CurrentActivity, false, out IList<string> list, out IList<AssemblyReference> list2);
            VisualBasicHelper helper = new VisualBasicHelper(expressionText);
            HashSet<AssemblyName> refAssemNames = new HashSet<AssemblyName>();
            HashSet<string> namespaceImportsNames = new HashSet<string>(list);
            foreach (AssemblyReference reference in list2)
            {
                if (reference.Assembly != null)
                {
                    if (helper.referencedAssemblies == null)
                    {
                        helper.referencedAssemblies = new HashSet<Assembly>();
                    }
                    helper.referencedAssemblies.Add(reference.Assembly);
                }
                else if (reference.AssemblyName != null)
                {
                    refAssemNames.Add(reference.AssemblyName);
                }
            }
            helper.Initialize(refAssemNames, namespaceImportsNames);
            return helper.Compile<T>(publicAccessor, isLocationExpression);
        }

        [SecuritySafeCritical, PermissionSet(SecurityAction.Demand, Name="FullTrust")]
        public LambdaExpression CompileNonGeneric(LocationReferenceEnvironment environment)
        {
            Expression expression;
            CompilerResults results;
            this.environment = environment;
            if (this.referencedAssemblies == null)
            {
                this.referencedAssemblies = new HashSet<Assembly>();
            }
            this.referencedAssemblies.UnionWith(DefaultReferencedAssemblies);
            List<Import> importList = new List<Import>();
            foreach (string str in this.namespaceImports)
            {
                if (!string.IsNullOrEmpty(str))
                {
                    importList.Add(new Import(str));
                }
            }
            RawTreeCacheKey key = new RawTreeCacheKey(this.textToCompile, null, this.referencedAssemblies, this.namespaceImports);
            RawTreeCacheValueWrapper rawTreeHolder = RawTreeCache.GetValue(rawTreeCacheLock, key) as RawTreeCacheValueWrapper;
            if (rawTreeHolder != null)
            {
                LambdaExpression expression3 = rawTreeHolder.Value;
                this.isShortCutRewrite = true;
                expression = this.Rewrite(expression3.Body, null, false, out bool flag);
                this.isShortCutRewrite = false;
                if (!flag)
                {
                    return Expression.Lambda(expression3.Type, expression, expression3.Parameters);
                }
            }
            VisualBasicScriptAndTypeScope scriptScope = new VisualBasicScriptAndTypeScope(this.environment, this.referencedAssemblies.ToList<Assembly>());
            IImportScope importScope = new VisualBasicImportScope(importList);
            CompilerOptions options = new CompilerOptions {
                OptionStrict = OptionStrictSetting.On
            };
            CompilerContext context = new CompilerContext(scriptScope, scriptScope, importScope, options);
            HostedCompilerWrapper cachedHostedCompiler = GetCachedHostedCompiler(this.referencedAssemblies);
            HostedCompiler compiler = cachedHostedCompiler.Compiler;
            try
            {
                HostedCompiler compiler2 = compiler;
                lock (compiler2)
                {
                    try
                    {
                        results = compiler.CompileExpression(this.textToCompile, context);
                    }
                    catch (Exception exception)
                    {
                        if (Fx.IsFatal(exception))
                        {
                            throw;
                        }
                        FxTrace.Exception.TraceUnhandledException(exception);
                        throw;
                    }
                }
            }
            finally
            {
                cachedHostedCompiler.Release();
            }
            if (scriptScope.ErrorMessage != null)
            {
                throw FxTrace.Exception.AsError(new SourceExpressionException(System.Activities.SR.CompilerErrorSpecificExpression(this.textToCompile, scriptScope.ErrorMessage)));
            }
            if ((results.Errors != null) && (results.Errors.Count > 0))
            {
                StringBuilder builder = new StringBuilder();
                builder.AppendLine();
                foreach (Microsoft.Compiler.VisualBasic.Error error in results.Errors)
                {
                    builder.AppendLine(error.Description);
                }
                throw FxTrace.Exception.AsError(new SourceExpressionException(System.Activities.SR.CompilerErrorSpecificExpression(this.textToCompile, builder.ToString())));
            }
            LambdaExpression codeBlock = results.CodeBlock;
            if (codeBlock == null)
            {
                return null;
            }
            AddToRawTreeCache(key, rawTreeHolder, codeBlock);
            expression = this.Rewrite(codeBlock.Body, null, false, out flag);
            return Expression.Lambda(codeBlock.Type, expression, codeBlock.Parameters);
        }

        private static void EnsureTypeReferenced(Type type, ref HashSet<Type> typeReferences)
        {
            HashSet<Type> other = (HashSet<Type>) typeReferenceCache.GetValue(VisualBasicHelper.typeReferenceCacheLock, type);
            if (other != null)
            {
                if (typeReferences == null)
                {
                    typeReferences = other;
                }
                else
                {
                    typeReferences.UnionWith(other);
                }
            }
            else
            {
                other = new HashSet<Type>();
                EnsureTypeReferencedRecurse(type, other);
                object typeReferenceCacheLock = VisualBasicHelper.typeReferenceCacheLock;
                lock (typeReferenceCacheLock)
                {
                    typeReferenceCache.Add(type, other);
                }
                if (typeReferences == null)
                {
                    typeReferences = other;
                }
                else
                {
                    typeReferences.UnionWith(other);
                }
            }
        }

        private static void EnsureTypeReferencedRecurse(Type type, HashSet<Type> alreadyVisited)
        {
            if (!alreadyVisited.Contains(type))
            {
                alreadyVisited.Add(type);
                Type[] interfaces = type.GetInterfaces();
                for (int i = 0; i < interfaces.Length; i++)
                {
                    EnsureTypeReferencedRecurse(interfaces[i], alreadyVisited);
                }
                for (Type type2 = type.BaseType; (type2 != null) && (type2 != System.Runtime.TypeHelper.ObjectType); type2 = type2.BaseType)
                {
                    EnsureTypeReferencedRecurse(type2, alreadyVisited);
                }
                if (type.IsGenericType)
                {
                    Type[] genericArguments = type.GetGenericArguments();
                    for (int j = 1; j < genericArguments.Length; j++)
                    {
                        EnsureTypeReferencedRecurse(genericArguments[j], alreadyVisited);
                    }
                }
                if (type.HasElementType)
                {
                    EnsureTypeReferencedRecurse(type.GetElementType(), alreadyVisited);
                }
            }
        }

        private static void ExtractNamespacesAndReferences(VisualBasicSettings vbSettings, IList<string> namespaces, IList<AssemblyReference> assemblies)
        {
            foreach (VisualBasicImportReference reference in vbSettings.ImportReferences)
            {
                namespaces.Add(reference.Import);
                AssemblyReference item = new AssemblyReference {
                    Assembly = reference.EarlyBoundAssembly,
                    AssemblyName = reference.AssemblyName
                };
                assemblies.Add(item);
            }
        }

        private static bool FindAllLocationReferenceMatch(LocationReference reference, string targetName, Type targetType, out bool terminateSearch)
        {
            terminateSearch = false;
            return string.Equals(reference.Name, targetName, StringComparison.OrdinalIgnoreCase);
        }

        private static bool FindFirstLocationReferenceMatch(LocationReference reference, string targetName, Type targetType, out bool terminateSearch)
        {
            terminateSearch = false;
            if (string.Equals(reference.Name, targetName, StringComparison.OrdinalIgnoreCase))
            {
                terminateSearch = true;
                return true;
            }
            return false;
        }

        private static bool FindLocationReferenceMatchShortcut(LocationReference reference, string targetName, Type targetType, out bool terminateSearch)
        {
            terminateSearch = false;
            if (!string.Equals(reference.Name, targetName, StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }
            if (targetType != reference.Type)
            {
                terminateSearch = true;
                return false;
            }
            return true;
        }

        private static LocationReference FindLocationReferencesFromEnvironment(LocationReferenceEnvironment environment, FindMatch findMatch, string targetName, Type targetType, out bool foundMultiple)
        {
            LocationReferenceEnvironment parent = environment;
            foundMultiple = false;
            while (parent != null)
            {
                LocationReference reference = null;
                foreach (LocationReference reference2 in parent.GetLocationReferences())
                {
                    if (findMatch(reference2, targetName, targetType, out bool flag))
                    {
                        if (reference != null)
                        {
                            foundMultiple = true;
                            return reference;
                        }
                        reference = reference2;
                    }
                    if (flag)
                    {
                        return reference;
                    }
                }
                if (reference != null)
                {
                    return reference;
                }
                parent = parent.Parent;
            }
            return null;
        }

        private static ParameterExpression FindParameter(ICollection<ElementInit> collection)
        {
            foreach (ElementInit init in collection)
            {
                ParameterExpression expression = FindParameter(init.Arguments);
                if (expression != null)
                {
                    return expression;
                }
            }
            return null;
        }

        private static ParameterExpression FindParameter(ICollection<Expression> collection)
        {
            foreach (Expression expression in collection)
            {
                ParameterExpression expression2 = FindParameter(expression);
                if (expression2 != null)
                {
                    return expression2;
                }
            }
            return null;
        }

        private static ParameterExpression FindParameter(ICollection<MemberBinding> bindings)
        {
            foreach (MemberBinding binding in bindings)
            {
                ParameterExpression expression;
                switch (binding.BindingType)
                {
                    case MemberBindingType.Assignment:
                    {
                        MemberAssignment assignment = (MemberAssignment) binding;
                        expression = FindParameter(assignment.Expression);
                        break;
                    }
                    case MemberBindingType.MemberBinding:
                    {
                        MemberMemberBinding binding3 = (MemberMemberBinding) binding;
                        expression = FindParameter(binding3.Bindings);
                        break;
                    }
                    case MemberBindingType.ListBinding:
                    {
                        MemberListBinding binding2 = (MemberListBinding) binding;
                        expression = FindParameter(binding2.Initializers);
                        break;
                    }
                    default:
                        expression = null;
                        break;
                }
                if (expression != null)
                {
                    return expression;
                }
            }
            return null;
        }

        private static ParameterExpression FindParameter(Expression expression)
        {
            if (expression != null)
            {
                switch (expression.NodeType)
                {
                    case ExpressionType.Add:
                    case ExpressionType.AddChecked:
                    case ExpressionType.And:
                    case ExpressionType.AndAlso:
                    case ExpressionType.Coalesce:
                    case ExpressionType.Divide:
                    case ExpressionType.Equal:
                    case ExpressionType.ExclusiveOr:
                    case ExpressionType.GreaterThan:
                    case ExpressionType.GreaterThanOrEqual:
                    case ExpressionType.LeftShift:
                    case ExpressionType.LessThan:
                    case ExpressionType.LessThanOrEqual:
                    case ExpressionType.Modulo:
                    case ExpressionType.Multiply:
                    case ExpressionType.MultiplyChecked:
                    case ExpressionType.NotEqual:
                    case ExpressionType.Or:
                    case ExpressionType.OrElse:
                    case ExpressionType.Power:
                    case ExpressionType.RightShift:
                    case ExpressionType.Subtract:
                    case ExpressionType.SubtractChecked:
                    {
                        BinaryExpression expression2 = (BinaryExpression) expression;
                        return (FindParameter(expression2.Left) ?? FindParameter(expression2.Right));
                    }
                    case ExpressionType.ArrayLength:
                    case ExpressionType.Convert:
                    case ExpressionType.ConvertChecked:
                    case ExpressionType.Negate:
                    case ExpressionType.UnaryPlus:
                    case ExpressionType.NegateChecked:
                    case ExpressionType.Not:
                    case ExpressionType.Quote:
                    case ExpressionType.TypeAs:
                    {
                        UnaryExpression expression16 = (UnaryExpression) expression;
                        return FindParameter(expression16.Operand);
                    }
                    case ExpressionType.ArrayIndex:
                    {
                        MethodCallExpression expression9 = expression as MethodCallExpression;
                        if (expression9 == null)
                        {
                            BinaryExpression expression10 = (BinaryExpression) expression;
                            return (FindParameter(expression10.Left) ?? FindParameter(expression10.Right));
                        }
                        return (FindParameter(expression9.Object) ?? FindParameter(expression9.Arguments));
                    }
                    case ExpressionType.Call:
                    {
                        MethodCallExpression expression11 = (MethodCallExpression) expression;
                        return (FindParameter(expression11.Object) ?? FindParameter(expression11.Arguments));
                    }
                    case ExpressionType.Conditional:
                    {
                        ConditionalExpression expression3 = (ConditionalExpression) expression;
                        return (FindParameter(expression3.Test) ?? (FindParameter(expression3.IfTrue) ?? FindParameter(expression3.IfFalse)));
                    }
                    case ExpressionType.Constant:
                        return null;

                    case ExpressionType.Invoke:
                    {
                        InvocationExpression expression4 = (InvocationExpression) expression;
                        return (FindParameter(expression4.Expression) ?? FindParameter(expression4.Arguments));
                    }
                    case ExpressionType.Lambda:
                    {
                        LambdaExpression expression5 = (LambdaExpression) expression;
                        return FindParameter(expression5.Body);
                    }
                    case ExpressionType.ListInit:
                    {
                        ListInitExpression expression6 = (ListInitExpression) expression;
                        return (FindParameter(expression6.NewExpression) ?? FindParameter(expression6.Initializers));
                    }
                    case ExpressionType.MemberAccess:
                    {
                        MemberExpression expression7 = (MemberExpression) expression;
                        return FindParameter(expression7.Expression);
                    }
                    case ExpressionType.MemberInit:
                    {
                        MemberInitExpression expression8 = (MemberInitExpression) expression;
                        return (FindParameter(expression8.NewExpression) ?? FindParameter(expression8.Bindings));
                    }
                    case ExpressionType.New:
                    {
                        NewExpression expression13 = (NewExpression) expression;
                        return FindParameter(expression13.Arguments);
                    }
                    case ExpressionType.NewArrayInit:
                    case ExpressionType.NewArrayBounds:
                    {
                        NewArrayExpression expression12 = (NewArrayExpression) expression;
                        return FindParameter(expression12.Expressions);
                    }
                    case ExpressionType.Parameter:
                    {
                        ParameterExpression expression14 = (ParameterExpression) expression;
                        if (!(expression14.Type == typeof(ActivityContext)) || (expression14.Name != "context"))
                        {
                            return null;
                        }
                        return expression14;
                    }
                    case ExpressionType.TypeIs:
                    {
                        TypeBinaryExpression expression15 = (TypeBinaryExpression) expression;
                        return FindParameter(expression15.Expression);
                    }
                    case ExpressionType.Assign:
                    {
                        BinaryExpression expression19 = (BinaryExpression) expression;
                        return (FindParameter(expression19.Left) ?? FindParameter(expression19.Right));
                    }
                    case ExpressionType.Block:
                    {
                        BlockExpression expression17 = (BlockExpression) expression;
                        ParameterExpression expression18 = FindParameter(expression17.Expressions);
                        if (expression18 == null)
                        {
                            List<Expression> collection = new List<Expression>();
                            foreach (ParameterExpression expression20 in expression17.Variables)
                            {
                                collection.Add(expression20);
                            }
                            return FindParameter(collection);
                        }
                        return expression18;
                    }
                }
            }
            return null;
        }

        public static void GetAllImportReferences(Activity activity, bool isDesignTime, out IList<string> namespaces, out IList<AssemblyReference> assemblies)
        {
            List<string> list = new List<string>();
            List<AssemblyReference> list2 = new List<AssemblyReference>();
            ExtractNamespacesAndReferences(VisualBasicSettings.Default, list, list2);
            LocationReferenceEnvironment parentEnvironment = activity.GetParentEnvironment();
            if ((parentEnvironment == null) || (parentEnvironment.Root == null))
            {
                namespaces = list;
                assemblies = list2;
            }
            else
            {
                VisualBasicSettings vbSettings = VisualBasic.GetSettings(parentEnvironment.Root);
                if (vbSettings != null)
                {
                    ExtractNamespacesAndReferences(vbSettings, list, list2);
                }
                else
                {
                    IList<string> namespacesForImplementation;
                    IList<AssemblyReference> referencesForImplementation;
                    if (isDesignTime)
                    {
                        namespacesForImplementation = TextExpression.GetNamespacesForImplementation(parentEnvironment.Root);
                        referencesForImplementation = TextExpression.GetReferencesForImplementation(parentEnvironment.Root);
                        if ((namespacesForImplementation.Count == 0) && (referencesForImplementation.Count == 0))
                        {
                            namespacesForImplementation = TextExpression.GetNamespaces(parentEnvironment.Root);
                            referencesForImplementation = TextExpression.GetReferences(parentEnvironment.Root);
                        }
                    }
                    else
                    {
                        namespacesForImplementation = TextExpression.GetNamespacesInScope(activity);
                        referencesForImplementation = TextExpression.GetReferencesInScope(activity);
                    }
                    list.AddRange(namespacesForImplementation);
                    list2.AddRange(referencesForImplementation);
                }
                namespaces = list;
                assemblies = list2;
            }
        }

        [SecuritySafeCritical, PermissionSet(SecurityAction.Demand, Name="FullTrust")]
        private static HostedCompilerWrapper GetCachedHostedCompiler(HashSet<Assembly> assemblySet)
        {
            if (HostedCompilerCache == null)
            {
                Interlocked.CompareExchange<Dictionary<HashSet<Assembly>, HostedCompilerWrapper>>(ref HostedCompilerCache, new Dictionary<HashSet<Assembly>, HostedCompilerWrapper>(10, HashSet<Assembly>.CreateSetComparer()), null);
            }
            Dictionary<HashSet<Assembly>, HostedCompilerWrapper> hostedCompilerCache = HostedCompilerCache;
            lock (hostedCompilerCache)
            {
                if (HostedCompilerCache.TryGetValue(assemblySet, out HostedCompilerWrapper wrapper))
                {
                    wrapper.Reserve(lastTimestamp += (ulong) 1L);
                    return wrapper;
                }
                if (HostedCompilerCache.Count >= 10)
                {
                    ulong maxValue = ulong.MaxValue;
                    HashSet<Assembly> key = null;
                    foreach (KeyValuePair<HashSet<Assembly>, HostedCompilerWrapper> pair in HostedCompilerCache)
                    {
                        if (maxValue > pair.Value.Timestamp)
                        {
                            key = pair.Key;
                            maxValue = pair.Value.Timestamp;
                        }
                    }
                    if (key != null)
                    {
                        wrapper = HostedCompilerCache[key];
                        HostedCompilerCache.Remove(key);
                        wrapper.MarkAsKickedOut();
                    }
                }
                wrapper = new HostedCompilerWrapper(new HostedCompiler(assemblySet.ToList<Assembly>()));
                HostedCompilerCache[assemblySet] = wrapper;
                wrapper.Reserve(lastTimestamp += (ulong) 1L);
                return wrapper;
            }
        }

        public static AssemblyName GetFastAssemblyName(Assembly assembly) => 
            AssemblyReference.GetFastAssemblyName(assembly);

        private void Initialize(HashSet<AssemblyName> refAssemNames, HashSet<string> namespaceImportsNames)
        {
            this.namespaceImports = namespaceImportsNames;
            foreach (AssemblyName name in refAssemNames)
            {
                if (this.referencedAssemblies == null)
                {
                    this.referencedAssemblies = new HashSet<Assembly>();
                }
                Assembly item = AssemblyReference.GetAssembly(name);
                if (item != null)
                {
                    this.referencedAssemblies.Add(item);
                }
            }
        }

        private Expression Rewrite(Expression expression, ReadOnlyCollection<ParameterExpression> lambdaParameters, out bool abort) => 
            this.Rewrite(expression, lambdaParameters, false, out abort);

        private MemberBinding Rewrite(MemberBinding binding, ReadOnlyCollection<ParameterExpression> lambdaParameters, out bool abort)
        {
            int num;
            Expression expression;
            MemberListBinding binding2;
            List<ElementInit> list;
            abort = false;
            switch (binding.BindingType)
            {
                case MemberBindingType.Assignment:
                {
                    MemberAssignment assignment = (MemberAssignment) binding;
                    expression = this.Rewrite(assignment.Expression, lambdaParameters, out abort);
                    if (!abort)
                    {
                        return Expression.Bind(assignment.Member, expression);
                    }
                    return null;
                }
                case MemberBindingType.MemberBinding:
                {
                    MemberMemberBinding binding3 = (MemberMemberBinding) binding;
                    ReadOnlyCollection<MemberBinding> bindings = binding3.Bindings;
                    List<MemberBinding> list2 = new List<MemberBinding>(bindings.Count);
                    for (num = 0; num < bindings.Count; num++)
                    {
                        MemberBinding item = this.Rewrite(bindings[num], lambdaParameters, out abort);
                        if (abort)
                        {
                            return null;
                        }
                        list2.Add(item);
                    }
                    return Expression.MemberBind(binding3.Member, list2);
                }
                case MemberBindingType.ListBinding:
                {
                    binding2 = (MemberListBinding) binding;
                    list = null;
                    ReadOnlyCollection<ElementInit> initializers = binding2.Initializers;
                    if (initializers.Count > 0)
                    {
                        list = new List<ElementInit>(initializers.Count);
                        for (num = 0; num < initializers.Count; num++)
                        {
                            List<Expression> arguments = null;
                            ReadOnlyCollection<Expression> onlys = initializers[num].Arguments;
                            if (onlys.Count > 0)
                            {
                                arguments = new List<Expression>(onlys.Count);
                                for (int i = 0; i < onlys.Count; i++)
                                {
                                    expression = this.Rewrite(onlys[i], lambdaParameters, out abort);
                                    if (abort)
                                    {
                                        return null;
                                    }
                                    arguments.Add(expression);
                                }
                            }
                            list.Add(Expression.ElementInit(initializers[num].AddMethod, arguments));
                        }
                    }
                    break;
                }
                default:
                    return binding;
            }
            return Expression.ListBind(binding2.Member, list);
        }

        private Expression Rewrite(Expression expression, ReadOnlyCollection<ParameterExpression> lambdaParameters, bool isLocationExpression, out bool abort)
        {
            int num;
            Expression expression2;
            Expression expression3;
            List<Expression> list;
            NewExpression expression5;
            ReadOnlyCollection<Expression> arguments;
            ReadOnlyCollection<Expression> expressions;
            abort = false;
            if (expression == null)
            {
                return null;
            }
            switch (expression.NodeType)
            {
                case ExpressionType.Add:
                case ExpressionType.AddChecked:
                case ExpressionType.And:
                case ExpressionType.AndAlso:
                case ExpressionType.Coalesce:
                case ExpressionType.Divide:
                case ExpressionType.Equal:
                case ExpressionType.ExclusiveOr:
                case ExpressionType.GreaterThan:
                case ExpressionType.GreaterThanOrEqual:
                case ExpressionType.LeftShift:
                case ExpressionType.LessThan:
                case ExpressionType.LessThanOrEqual:
                case ExpressionType.Modulo:
                case ExpressionType.Multiply:
                case ExpressionType.MultiplyChecked:
                case ExpressionType.NotEqual:
                case ExpressionType.Or:
                case ExpressionType.OrElse:
                case ExpressionType.Power:
                case ExpressionType.RightShift:
                case ExpressionType.Subtract:
                case ExpressionType.SubtractChecked:
                {
                    BinaryExpression expression6 = (BinaryExpression) expression;
                    expression2 = this.Rewrite(expression6.Left, lambdaParameters, out abort);
                    if (!abort)
                    {
                        expression3 = this.Rewrite(expression6.Right, lambdaParameters, out abort);
                        if (abort)
                        {
                            return null;
                        }
                        LambdaExpression conversion = (LambdaExpression) this.Rewrite(expression6.Conversion, lambdaParameters, out abort);
                        if (abort)
                        {
                            return null;
                        }
                        return Expression.MakeBinary(expression6.NodeType, expression2, expression3, expression6.IsLiftedToNull, expression6.Method, conversion);
                    }
                    return null;
                }
                case ExpressionType.ArrayLength:
                case ExpressionType.Convert:
                case ExpressionType.ConvertChecked:
                case ExpressionType.Negate:
                case ExpressionType.NegateChecked:
                case ExpressionType.Not:
                case ExpressionType.Quote:
                case ExpressionType.TypeAs:
                {
                    UnaryExpression expression21 = (UnaryExpression) expression;
                    expression2 = this.Rewrite(expression21.Operand, lambdaParameters, out abort);
                    if (!abort)
                    {
                        return Expression.MakeUnary(expression21.NodeType, expression2, expression21.Type, expression21.Method);
                    }
                    return null;
                }
                case ExpressionType.ArrayIndex:
                {
                    MethodCallExpression expression15 = expression as MethodCallExpression;
                    if (expression15 == null)
                    {
                        BinaryExpression expression16 = (BinaryExpression) expression;
                        expression2 = this.Rewrite(expression16.Left, lambdaParameters, out abort);
                        if (abort)
                        {
                            return null;
                        }
                        expression3 = this.Rewrite(expression16.Right, lambdaParameters, out abort);
                        if (abort)
                        {
                            return null;
                        }
                        return Expression.ArrayIndex(expression2, expression3);
                    }
                    expression2 = this.Rewrite(expression15.Object, lambdaParameters, out abort);
                    if (!abort)
                    {
                        arguments = expression15.Arguments;
                        List<Expression> indexes = new List<Expression>(arguments.Count);
                        for (num = 0; num < arguments.Count; num++)
                        {
                            expression3 = this.Rewrite(arguments[num], lambdaParameters, out abort);
                            if (abort)
                            {
                                return null;
                            }
                            indexes.Add(expression3);
                        }
                        return Expression.ArrayIndex(expression2, indexes);
                    }
                    return null;
                }
                case ExpressionType.Call:
                {
                    MethodCallExpression expression17 = (MethodCallExpression) expression;
                    expression2 = this.Rewrite(expression17.Object, lambdaParameters, out abort);
                    if (!abort)
                    {
                        list = null;
                        arguments = expression17.Arguments;
                        if (arguments.Count > 0)
                        {
                            list = new List<Expression>(arguments.Count);
                            num = 0;
                            while (num < arguments.Count)
                            {
                                expression3 = this.Rewrite(arguments[num], lambdaParameters, out abort);
                                if (abort)
                                {
                                    return null;
                                }
                                list.Add(expression3);
                                num++;
                            }
                        }
                        return Expression.Call(expression2, expression17.Method, list);
                    }
                    return null;
                }
                case ExpressionType.Conditional:
                {
                    ConditionalExpression expression8 = (ConditionalExpression) expression;
                    expression2 = this.Rewrite(expression8.Test, lambdaParameters, out abort);
                    if (!abort)
                    {
                        expression3 = this.Rewrite(expression8.IfTrue, lambdaParameters, out abort);
                        if (abort)
                        {
                            return null;
                        }
                        Expression ifFalse = this.Rewrite(expression8.IfFalse, lambdaParameters, out abort);
                        if (abort)
                        {
                            return null;
                        }
                        return Expression.Condition(expression2, expression3, ifFalse);
                    }
                    return null;
                }
                case ExpressionType.Constant:
                    return expression;

                case ExpressionType.Invoke:
                {
                    InvocationExpression expression9 = (InvocationExpression) expression;
                    expression2 = this.Rewrite(expression9.Expression, lambdaParameters, out abort);
                    if (!abort)
                    {
                        list = null;
                        arguments = expression9.Arguments;
                        if (arguments.Count > 0)
                        {
                            list = new List<Expression>(arguments.Count);
                            for (num = 0; num < arguments.Count; num++)
                            {
                                expression3 = this.Rewrite(arguments[num], lambdaParameters, out abort);
                                if (abort)
                                {
                                    return null;
                                }
                                list.Add(expression3);
                            }
                        }
                        return Expression.Invoke(expression2, list);
                    }
                    return null;
                }
                case ExpressionType.Lambda:
                {
                    LambdaExpression expression10 = (LambdaExpression) expression;
                    expression2 = this.Rewrite(expression10.Body, expression10.Parameters, isLocationExpression, out abort);
                    if (!abort)
                    {
                        return Expression.Lambda(expression10.Type, expression2, expression10.Parameters);
                    }
                    return null;
                }
                case ExpressionType.ListInit:
                {
                    ListInitExpression expression11 = (ListInitExpression) expression;
                    expression5 = (NewExpression) this.Rewrite(expression11.NewExpression, lambdaParameters, out abort);
                    if (!abort)
                    {
                        ReadOnlyCollection<ElementInit> initializers = expression11.Initializers;
                        List<ElementInit> list2 = new List<ElementInit>(initializers.Count);
                        for (num = 0; num < initializers.Count; num++)
                        {
                            arguments = initializers[num].Arguments;
                            list = new List<Expression>(arguments.Count);
                            for (int i = 0; i < arguments.Count; i++)
                            {
                                expression2 = this.Rewrite(arguments[i], lambdaParameters, out abort);
                                if (abort)
                                {
                                    return null;
                                }
                                list.Add(expression2);
                            }
                            list2.Add(Expression.ElementInit(initializers[num].AddMethod, list));
                        }
                        return Expression.ListInit(expression5, list2);
                    }
                    return null;
                }
                case ExpressionType.MemberAccess:
                {
                    MemberExpression expression13 = (MemberExpression) expression;
                    bool flag = isLocationExpression && expression13.Member.DeclaringType.IsValueType;
                    expression2 = this.Rewrite(expression13.Expression, lambdaParameters, flag, out abort);
                    if (!abort)
                    {
                        return Expression.MakeMemberAccess(expression2, expression13.Member);
                    }
                    return null;
                }
                case ExpressionType.MemberInit:
                {
                    MemberInitExpression expression14 = (MemberInitExpression) expression;
                    expression5 = (NewExpression) this.Rewrite(expression14.NewExpression, lambdaParameters, out abort);
                    if (!abort)
                    {
                        ReadOnlyCollection<MemberBinding> bindings = expression14.Bindings;
                        List<MemberBinding> list3 = new List<MemberBinding>(bindings.Count);
                        for (num = 0; num < bindings.Count; num++)
                        {
                            MemberBinding item = this.Rewrite(bindings[num], lambdaParameters, out abort);
                            if (abort)
                            {
                                return null;
                            }
                            list3.Add(item);
                        }
                        return Expression.MemberInit(expression5, list3);
                    }
                    return null;
                }
                case ExpressionType.UnaryPlus:
                {
                    UnaryExpression expression22 = (UnaryExpression) expression;
                    expression2 = this.Rewrite(expression22.Operand, lambdaParameters, out abort);
                    if (!abort)
                    {
                        return Expression.UnaryPlus(expression2, expression22.Method);
                    }
                    return null;
                }
                case ExpressionType.New:
                    expression5 = (NewExpression) expression;
                    if (expression5.Constructor != null)
                    {
                        list = null;
                        arguments = expression5.Arguments;
                        if (arguments.Count > 0)
                        {
                            list = new List<Expression>(arguments.Count);
                            for (num = 0; num < arguments.Count; num++)
                            {
                                expression2 = this.Rewrite(arguments[num], lambdaParameters, out abort);
                                if (abort)
                                {
                                    return null;
                                }
                                list.Add(expression2);
                            }
                        }
                        return expression5.Update(list);
                    }
                    return expression;

                case ExpressionType.NewArrayInit:
                {
                    NewArrayExpression expression18 = (NewArrayExpression) expression;
                    expressions = expression18.Expressions;
                    List<Expression> initializers = new List<Expression>(expressions.Count);
                    for (num = 0; num < expressions.Count; num++)
                    {
                        expression2 = this.Rewrite(expressions[num], lambdaParameters, out abort);
                        if (abort)
                        {
                            return null;
                        }
                        initializers.Add(expression2);
                    }
                    return Expression.NewArrayInit(expression18.Type.GetElementType(), initializers);
                }
                case ExpressionType.NewArrayBounds:
                {
                    NewArrayExpression expression19 = (NewArrayExpression) expression;
                    expressions = expression19.Expressions;
                    List<Expression> bounds = new List<Expression>(expressions.Count);
                    for (num = 0; num < expressions.Count; num++)
                    {
                        expression2 = this.Rewrite(expressions[num], lambdaParameters, out abort);
                        if (abort)
                        {
                            return null;
                        }
                        bounds.Add(expression2);
                    }
                    return Expression.NewArrayBounds(expression19.Type.GetElementType(), bounds);
                }
                case ExpressionType.Parameter:
                {
                    ParameterExpression expression12 = (ParameterExpression) expression;
                    if ((lambdaParameters == null) || !lambdaParameters.Contains(expression12))
                    {
                        FindMatch delegateFindLocationReferenceMatchShortcut;
                        if (this.isShortCutRewrite)
                        {
                            delegateFindLocationReferenceMatchShortcut = VisualBasicHelper.delegateFindLocationReferenceMatchShortcut;
                        }
                        else
                        {
                            delegateFindLocationReferenceMatchShortcut = delegateFindFirstLocationReferenceMatch;
                        }
                        LocationReference originalReference = FindLocationReferencesFromEnvironment(this.environment, delegateFindLocationReferenceMatchShortcut, expression12.Name, expression12.Type, out bool flag2);
                        if ((originalReference != null) && !flag2)
                        {
                            if (this.publicAccessor.HasValue && ExpressionUtilities.TryGetInlinedReference(this.publicAccessor.Value, originalReference, isLocationExpression, out LocationReference reference2))
                            {
                                originalReference = reference2;
                            }
                            return ExpressionUtilities.CreateIdentifierExpression(originalReference);
                        }
                        if (this.isShortCutRewrite)
                        {
                            abort = true;
                            return null;
                        }
                        return expression12;
                    }
                    return expression12;
                }
                case ExpressionType.TypeIs:
                {
                    TypeBinaryExpression expression20 = (TypeBinaryExpression) expression;
                    expression2 = this.Rewrite(expression20.Expression, lambdaParameters, out abort);
                    if (!abort)
                    {
                        return Expression.TypeIs(expression2, expression20.TypeOperand);
                    }
                    return null;
                }
                case ExpressionType.Assign:
                {
                    BinaryExpression expression24 = (BinaryExpression) expression;
                    expression2 = this.Rewrite(expression24.Left, lambdaParameters, out abort);
                    if (!abort)
                    {
                        expression3 = this.Rewrite(expression24.Right, lambdaParameters, out abort);
                        if (abort)
                        {
                            return null;
                        }
                        return Expression.Assign(expression2, expression3);
                    }
                    return null;
                }
                case ExpressionType.Block:
                {
                    BlockExpression expression23 = (BlockExpression) expression;
                    ReadOnlyCollection<ParameterExpression> variables = expression23.Variables;
                    List<ParameterExpression> list6 = new List<ParameterExpression>(variables.Count);
                    num = 0;
                    while (num < variables.Count)
                    {
                        ParameterExpression item = (ParameterExpression) this.Rewrite(variables[num], lambdaParameters, out abort);
                        if (abort)
                        {
                            return null;
                        }
                        list6.Add(item);
                        num++;
                    }
                    expressions = expression23.Expressions;
                    List<Expression> list7 = new List<Expression>(expressions.Count);
                    for (num = 0; num < expressions.Count; num++)
                    {
                        expression2 = this.Rewrite(expressions[num], lambdaParameters, out abort);
                        if (abort)
                        {
                            return null;
                        }
                        list7.Add(expression2);
                    }
                    return Expression.Block((IEnumerable<ParameterExpression>) list6, (IEnumerable<Expression>) list7);
                }
            }
            return expression;
        }

        internal static string Language =>
            "VB";

        private static HopperCache RawTreeCache
        {
            [SecurityCritical]
            get
            {
                if (rawTreeCache == null)
                {
                    rawTreeCache = new HopperCache(0x80, false);
                }
                return rawTreeCache;
            }
        }

        public string TextToCompile =>
            this.textToCompile;

        private delegate bool FindMatch(LocationReference reference, string targetName, Type targetType, out bool terminateSearch);

        [SecurityCritical]
        private class HostedCompilerWrapper
        {
            private object wrapperLock = new object();
            private HostedCompiler compiler;
            private bool isCached;
            private int refCount;

            public HostedCompilerWrapper(HostedCompiler compiler)
            {
                this.compiler = compiler;
                this.isCached = true;
                this.refCount = 0;
            }

            public void MarkAsKickedOut()
            {
                HostedCompiler compiler = null;
                object wrapperLock = this.wrapperLock;
                lock (wrapperLock)
                {
                    this.isCached = false;
                    if (this.refCount == 0)
                    {
                        compiler = this.compiler;
                        this.compiler = null;
                    }
                }
                if (compiler != null)
                {
                    compiler.Dispose();
                }
            }

            public void Release()
            {
                HostedCompiler compiler = null;
                object wrapperLock = this.wrapperLock;
                lock (wrapperLock)
                {
                    this.refCount--;
                    if (!this.isCached && (this.refCount == 0))
                    {
                        compiler = this.compiler;
                        this.compiler = null;
                    }
                }
                if (compiler != null)
                {
                    compiler.Dispose();
                }
            }

            public void Reserve(ulong timestamp)
            {
                object wrapperLock = this.wrapperLock;
                lock (wrapperLock)
                {
                    this.refCount++;
                }
                this.Timestamp = timestamp;
            }

            public HostedCompiler Compiler =>
                this.compiler;

            public ulong Timestamp { get; private set; }
        }

        private class RawTreeCacheKey
        {
            private static IEqualityComparer<HashSet<Assembly>> AssemblySetEqualityComparer = HashSet<Assembly>.CreateSetComparer();
            private static IEqualityComparer<HashSet<string>> NamespaceSetEqualityComparer = HashSet<string>.CreateSetComparer();
            private string expressionText;
            private Type returnType;
            private HashSet<Assembly> assemblies;
            private HashSet<string> namespaces;
            private readonly int hashCode;

            public RawTreeCacheKey(string expressionText, Type returnType, HashSet<Assembly> assemblies, HashSet<string> namespaces)
            {
                this.expressionText = expressionText;
                this.returnType = returnType;
                this.assemblies = new HashSet<Assembly>(assemblies);
                this.namespaces = new HashSet<string>(namespaces);
                this.hashCode = (expressionText != null) ? expressionText.GetHashCode() : 0;
                this.hashCode = CombineHashCodes(this.hashCode, AssemblySetEqualityComparer.GetHashCode(this.assemblies));
                this.hashCode = CombineHashCodes(this.hashCode, NamespaceSetEqualityComparer.GetHashCode(this.namespaces));
                if (this.returnType != null)
                {
                    this.hashCode = CombineHashCodes(this.hashCode, returnType.GetHashCode());
                }
            }

            private static int CombineHashCodes(int h1, int h2) => 
                ((h1 << 5) + h1) ^ h2;

            public override bool Equals(object obj)
            {
                VisualBasicHelper.RawTreeCacheKey key = obj as VisualBasicHelper.RawTreeCacheKey;
                if ((key == null) || (this.hashCode != key.hashCode))
                {
                    return false;
                }
                return ((((this.expressionText == key.expressionText) && (this.returnType == key.returnType)) && AssemblySetEqualityComparer.Equals(this.assemblies, key.assemblies)) && NamespaceSetEqualityComparer.Equals(this.namespaces, key.namespaces));
            }

            public override int GetHashCode() => 
                this.hashCode;
        }

        private class RawTreeCacheValueWrapper
        {
            public LambdaExpression Value { get; set; }
        }

        private class VisualBasicImportScope : IImportScope
        {
            private IList<Import> importList;

            public VisualBasicImportScope(IList<Import> importList)
            {
                this.importList = importList;
            }

            public IList<Import> GetImports() => 
                this.importList;
        }

        private class VisualBasicScriptAndTypeScope : IScriptScope, ITypeScope
        {
            private LocationReferenceEnvironment environmentProvider;
            private List<Assembly> assemblies;
            private string errorMessage;

            public VisualBasicScriptAndTypeScope(LocationReferenceEnvironment environmentProvider, List<Assembly> assemblies)
            {
                this.environmentProvider = environmentProvider;
                this.assemblies = assemblies;
            }

            public Type[] FindTypes(string typeName, string nsPrefix) => 
                null;

            public Type FindVariable(string name)
            {
                LocationReference reference = null;
                VisualBasicHelper.FindMatch delegateFindAllLocationReferenceMatch = VisualBasicHelper.delegateFindAllLocationReferenceMatch;
                reference = VisualBasicHelper.FindLocationReferencesFromEnvironment(this.environmentProvider, delegateFindAllLocationReferenceMatch, name, null, out bool flag);
                if (reference == null)
                {
                    return null;
                }
                if (flag)
                {
                    this.errorMessage = System.Activities.SR.AmbiguousVBVariableReference(name);
                    return null;
                }
                return reference.Type;
            }

            public bool NamespaceExists(string ns) => 
                false;

            public string ErrorMessage =>
                this.errorMessage;
        }
    }
}

