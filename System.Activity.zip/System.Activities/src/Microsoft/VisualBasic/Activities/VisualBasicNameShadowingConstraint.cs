﻿namespace Microsoft.VisualBasic.Activities
{
    using System;
    using System.Activities;
    using System.Activities.Expressions;
    using System.Activities.Validation;

    internal sealed class VisualBasicNameShadowingConstraint : Constraint
    {
        private static bool FindLocationReferencesFromEnvironment(LocationReferenceEnvironment environment, string targetName)
        {
            LocationReference reference = null;
            for (LocationReferenceEnvironment environment2 = environment; environment2 != null; environment2 = environment2.Parent)
            {
                foreach (LocationReference reference2 in environment2.GetLocationReferences())
                {
                    if (string.Equals(reference2.Name, targetName, StringComparison.OrdinalIgnoreCase))
                    {
                        if (reference != null)
                        {
                            return true;
                        }
                        reference = reference2;
                    }
                }
            }
            return false;
        }

        protected override void OnExecute(NativeActivityContext context, object objectToValidate, ValidationContext objectToValidateContext)
        {
            ActivityWithResult result2 = (ActivityWithResult) objectToValidate;
            foreach (RuntimeArgument argument in result2.RuntimeArguments)
            {
                ActivityWithResult expression = argument.BoundArgument.Expression;
                if ((expression != null) && (expression is ILocationReferenceWrapper))
                {
                    LocationReference locationReference = ((ILocationReferenceWrapper) expression).LocationReference;
                    if ((locationReference != null) && FindLocationReferencesFromEnvironment(objectToValidateContext.Environment, locationReference.Name))
                    {
                        AddValidationError(context, new ValidationError(System.Activities.SR.AmbiguousVBVariableReference(locationReference.Name)));
                    }
                }
            }
        }
    }
}

