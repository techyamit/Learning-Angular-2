﻿namespace Microsoft.VisualBasic.Activities
{
    using System;
    using System.Activities.Expressions;
    using System.Globalization;
    using System.Reflection;
    using System.Runtime.CompilerServices;
    using System.Xaml;
    using System.Xml.Linq;

    public class VisualBasicImportReference : IEquatable<VisualBasicImportReference>
    {
        private static AssemblyNameEqualityComparer equalityComparer = new AssemblyNameEqualityComparer();
        private System.Reflection.AssemblyName assemblyName;
        private string assemblyNameString;
        private int hashCode;
        private string import;

        internal VisualBasicImportReference Clone()
        {
            VisualBasicImportReference reference = (VisualBasicImportReference) base.MemberwiseClone();
            reference.EarlyBoundAssembly = null;
            reference.assemblyName = (System.Reflection.AssemblyName) this.assemblyName.Clone();
            return reference;
        }

        public bool Equals(VisualBasicImportReference other)
        {
            if (other == null)
            {
                return false;
            }
            if (this == other)
            {
                return true;
            }
            if (this.EarlyBoundAssembly != other.EarlyBoundAssembly)
            {
                return false;
            }
            if (string.Compare(this.Import, other.Import, StringComparison.OrdinalIgnoreCase) != 0)
            {
                return false;
            }
            if ((this.AssemblyName == null) && (other.AssemblyName == null))
            {
                return true;
            }
            if ((this.AssemblyName == null) && (other.AssemblyName != null))
            {
                return false;
            }
            if ((this.AssemblyName != null) && (other.AssemblyName == null))
            {
                return false;
            }
            return equalityComparer.Equals(this.AssemblyName, other.AssemblyName);
        }

        internal void GenerateXamlNamespace(INamespacePrefixLookup namespaceLookup)
        {
            string ns = null;
            if ((this.Xmlns != null) && !string.IsNullOrEmpty(this.Xmlns.NamespaceName))
            {
                ns = this.Xmlns.NamespaceName;
            }
            else
            {
                object[] args = new object[] { this.Import, this.Assembly };
                ns = string.Format(CultureInfo.InvariantCulture, "clr-namespace:{0};assembly={1}", args);
            }
            namespaceLookup.LookupPrefix(ns);
        }

        public override int GetHashCode() => 
            this.hashCode;

        public string Assembly
        {
            get => 
                this.assemblyNameString;
            set
            {
                if (value == null)
                {
                    this.assemblyName = null;
                    this.assemblyNameString = null;
                }
                else
                {
                    this.assemblyName = new System.Reflection.AssemblyName(value);
                    this.assemblyNameString = this.assemblyName.FullName;
                }
                this.EarlyBoundAssembly = null;
            }
        }

        public string Import
        {
            get => 
                this.import;
            set
            {
                if (value != null)
                {
                    this.import = value.Trim();
                    this.hashCode = this.import.ToUpperInvariant().GetHashCode();
                }
                else
                {
                    this.import = null;
                    this.hashCode = 0;
                }
                this.EarlyBoundAssembly = null;
            }
        }

        internal System.Reflection.AssemblyName AssemblyName =>
            this.assemblyName;

        internal XNamespace Xmlns { get; set; }

        internal System.Reflection.Assembly EarlyBoundAssembly { get; set; }
    }
}

