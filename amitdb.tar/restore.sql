--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.4
-- Dumped by pg_dump version 9.6.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

SET search_path = public, pg_catalog;

--
-- Data for Name: channel; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2441.dat

--
-- Name: channel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('channel_id_seq', 11, false);


--
-- Data for Name: department; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2420.dat

--
-- Name: department_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('department_id_seq', 11, true);


--
-- Data for Name: feature; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2405.dat

--
-- Data for Name: feature_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2407.dat

--
-- Data for Name: guest; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2442.dat

--
-- Name: guest_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('guest_id_seq', 11, false);


--
-- Data for Name: investigation; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2456.dat

--
-- Name: investigation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('investigation_id_seq', 11, false);


--
-- Data for Name: investigation_status; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2454.dat

--
-- Name: investigation_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('investigation_status_id_seq', 11, false);


--
-- Data for Name: language; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2440.dat

--
-- Name: language_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('language_id_seq', 11, false);


--
-- Data for Name: permission_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2409.dat

--
-- Data for Name: problem; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2455.dat

--
-- Data for Name: problem_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2451.dat

--
-- Name: problem_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('problem_category_id_seq', 11, true);


--
-- Name: problem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('problem_id_seq', 13, true);


--
-- Data for Name: problem_investigation; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2452.dat

--
-- Name: problem_investigation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('problem_investigation_id_seq', 11, false);


--
-- Data for Name: problem_status; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2453.dat

--
-- Name: problem_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('problem_status_id_seq', 13, true);


--
-- Data for Name: property; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2439.dat

--
-- Name: property_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('property_id_seq', 11, false);


--
-- Data for Name: reservation; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2443.dat

--
-- Name: reservation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('reservation_id_seq', 11, false);


--
-- Data for Name: review; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2445.dat

--
-- Data for Name: review_comment; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2447.dat

--
-- Name: review_comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('review_comment_id_seq', 11, true);


--
-- Name: review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('review_id_seq', 14, true);


--
-- Data for Name: review_response; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2448.dat

--
-- Name: review_response_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('review_response_id_seq', 11, true);


--
-- Data for Name: review_status; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2450.dat

--
-- Name: review_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('review_status_id_seq', 11, true);


--
-- Data for Name: review_translation; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2446.dat

--
-- Name: review_translation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('review_translation_id_seq', 11, false);


--
-- Data for Name: review_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2449.dat

--
-- Name: review_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('review_type_id_seq', 11, false);


--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2411.dat

--
-- Data for Name: role_feature_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2413.dat

--
-- Name: role_feature_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('role_feature_permission_id_seq', 119, true);


--
-- Name: seq_bookmark_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('seq_bookmark_id', 9, true);


--
-- Name: seq_bookmark_permission_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('seq_bookmark_permission_id', 16, true);


--
-- Name: seq_permission_type_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('seq_permission_type_id', 6, true);


--
-- Name: seq_role_bookmark_permission_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('seq_role_bookmark_permission_id', 1, false);


--
-- Name: seq_role_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('seq_role_id', 13, true);


--
-- Name: seq_user_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('seq_user_id', 8, true);


--
-- Data for Name: translation; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2444.dat

--
-- Name: translation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('translation_id_seq', 11, false);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2416.dat

--
-- Data for Name: users_role; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2417.dat

--
-- Name: users_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('users_role_id_seq', 4, true);


--
-- PostgreSQL database dump complete
--

